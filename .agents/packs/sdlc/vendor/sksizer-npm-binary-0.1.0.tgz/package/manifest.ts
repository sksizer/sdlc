/**
 * The package.json of a platform package and of the launcher.
 *
 * `template` fields keep the position they have in the template. Fields this
 * module sets that the template does not name are appended, so a product
 * controls key order (and with it the bytes written) through its template.
 */
import { chmodSync, copyFileSync, writeFileSync } from 'node:fs'

import {
  type BinaryProduct,
  binaryPathInPackage,
  type NpmPlatform,
  platformKey,
  platformPackageName,
} from './platform.ts'

export type Manifest = Record<string, unknown>

export interface PlatformManifestOptions {
  version: string
  description: string
  template?: Manifest
}

/**
 * One platform package: gated by `os`/`cpu` so npm installs it only on a
 * matching host. `files` defaults to the binary alone. `preferUnplugged`
 * keeps the binary a real file under Yarn PnP so the launcher can exec it.
 */
export function platformManifest(
  product: BinaryProduct,
  platform: NpmPlatform,
  { version, description, template = {} }: PlatformManifestOptions,
): Manifest {
  const m: Manifest = { name: platformPackageName(product, platform), version, description }
  Object.assign(m, template)
  m.os = [platform.os]
  m.cpu = [platform.cpu]
  m.files ??= [binaryPathInPackage(product, platform)]
  m.preferUnplugged = true
  return m
}

export interface LauncherManifestOptions {
  version: string
  description: string
  /** The launcher script's path inside the package, e.g. `bin/launcher.js`. */
  launcherPath: string
  template?: Manifest
}

/**
 * The launcher package. Lists every platform package as an optional
 * dependency at the same version, built or not. No `type` field: the
 * launcher is CommonJS.
 */
export function launcherManifest(
  product: BinaryProduct,
  platforms: readonly NpmPlatform[],
  { version, description, launcherPath, template = {} }: LauncherManifestOptions,
): Manifest {
  const m: Manifest = { name: product.launcher, version, description }
  Object.assign(m, template)
  m.bin = { [product.binary]: launcherPath }
  m.files ??= [launcherPath, 'README.md']
  m.optionalDependencies = Object.fromEntries(
    platforms.map((p) => [platformPackageName(product, p), version]),
  )
  m.engines ??= { node: '>=18' }
  return m
}

/** The launcher's lookup table: platform key to package and binary path. */
export function launcherTable(
  product: BinaryProduct,
  platforms: readonly NpmPlatform[],
): Record<string, { package: string; binary: string }> {
  return Object.fromEntries(
    platforms.map((p) => [
      platformKey(p),
      { package: platformPackageName(product, p), binary: binaryPathInPackage(product, p) },
    ]),
  )
}

export function writeJson(path: string, value: unknown): void {
  writeFileSync(path, `${JSON.stringify(value, null, 2)}\n`)
}

export function copyExecutable(src: string, dest: string): void {
  copyFileSync(src, dest)
  chmodSync(dest, 0o755)
}
