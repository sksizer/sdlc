/**
 * Where cargo writes build output, asked of cargo rather than derived from a
 * path: workspace membership decides it.
 */
import { type CommandRunner, runChecked, spawnRunner } from '@sksizer/command-seam'

export interface CargoTargetDirOptions {
  cwd: string
  /** A crate outside the workspace at `cwd` has its own target dir. */
  manifestPath?: string
  runner?: CommandRunner
}

export function cargoTargetDir({
  cwd,
  manifestPath,
  runner = spawnRunner('cargo'),
}: CargoTargetDirOptions): string {
  const argv = ['metadata', '--no-deps', '--format-version', '1']
  if (manifestPath !== undefined) argv.push('--manifest-path', manifestPath)
  const { stdout } = runChecked(runner, argv, { cwd })
  return (JSON.parse(stdout) as { target_directory: string }).target_directory
}
