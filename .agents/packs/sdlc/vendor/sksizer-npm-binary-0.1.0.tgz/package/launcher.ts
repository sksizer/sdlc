/**
 * Render the Node launcher shim from `launcher.js`.
 */
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

import { launcherTable } from './manifest.ts'
import type { BinaryProduct, NpmPlatform } from './platform.ts'

const TEMPLATE = join(import.meta.dir, 'launcher.js')

export interface LauncherOptions {
  /** When this variable is set, the launcher prints which package and binary it resolved. */
  debugEnv?: string
}

export function renderLauncher(
  product: BinaryProduct,
  platforms: readonly NpmPlatform[],
  { debugEnv = '' }: LauncherOptions = {},
): string {
  const values: Record<string, string> = {
    platformPackages: JSON.stringify(launcherTable(product, platforms)),
    binary: product.binary,
    launcher: product.launcher,
    debugEnv,
  }
  return readFileSync(TEMPLATE, 'utf8').replace(
    /\{\{(\w+)\}\}/g,
    (whole, key: string) => values[key] ?? whole,
  )
}
