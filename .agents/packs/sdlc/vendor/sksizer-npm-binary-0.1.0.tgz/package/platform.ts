/**
 * The platforms a binary ships for, and the names derived from them.
 */

/** A platform as npm sees it: `process.platform` and `process.arch`. */
export interface NpmPlatform {
  readonly os: 'darwin' | 'linux' | 'win32'
  readonly cpu: 'arm64' | 'x64'
}

/** Every platform both products ship for, in publish and listing order. */
export const NPM_PLATFORMS: readonly NpmPlatform[] = [
  { os: 'darwin', cpu: 'arm64' },
  { os: 'darwin', cpu: 'x64' },
  { os: 'linux', cpu: 'x64' },
  { os: 'linux', cpu: 'arm64' },
  { os: 'win32', cpu: 'x64' },
]

/** The names one product ships under. */
export interface BinaryProduct {
  /** The executable name, on the user's PATH and inside each platform package. */
  readonly binary: string
  /** The launcher package users install. */
  readonly launcher: string
  /** Platform packages are `<scope>/<platformPrefix>-<os>-<cpu>`. */
  readonly scope: string
  readonly platformPrefix: string
  /** Directory inside a platform package that holds the binary; `''` is the package root. */
  readonly binaryDir: string
}

/** `darwin-arm64`: the key a platform goes by in directories and in the launcher. */
export function platformKey(p: Pick<NpmPlatform, 'os' | 'cpu'>): string {
  return `${p.os}-${p.cpu}`
}

export function platformPackageName(product: BinaryProduct, p: NpmPlatform): string {
  return `${product.scope}/${product.platformPrefix}-${platformKey(p)}`
}

/** The executable's extension, with its dot: `.exe` on Windows, empty elsewhere. */
export function binaryExt(p: Pick<NpmPlatform, 'os'>): string {
  return p.os === 'win32' ? '.exe' : ''
}

export function binaryFileName(product: BinaryProduct, p: Pick<NpmPlatform, 'os'>): string {
  return `${product.binary}${binaryExt(p)}`
}

/** The binary's path inside its platform package, `/`-separated. */
export function binaryPathInPackage(product: BinaryProduct, p: Pick<NpmPlatform, 'os'>): string {
  const file = binaryFileName(product, p)
  return product.binaryDir === '' ? file : `${product.binaryDir}/${file}`
}

export function findPlatform<P extends NpmPlatform>(platforms: readonly P[], key: string): P {
  const found = platforms.find((p) => platformKey(p) === key)
  if (!found) {
    throw new Error(`unknown platform "${key}"; known: ${platforms.map(platformKey).join(', ')}`)
  }
  return found
}

/** The entry for the machine this runs on. */
export function hostPlatform<P extends NpmPlatform>(platforms: readonly P[]): P {
  return findPlatform(platforms, `${process.platform}-${process.arch}`)
}
