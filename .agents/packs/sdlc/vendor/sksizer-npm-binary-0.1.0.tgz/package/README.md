# @sksizer/npm-binary

Ship a compiled binary through npm the way esbuild and biome do: one launcher
package that users install, plus one package per platform. Each platform
package is gated by `os` and `cpu`, and the launcher lists them all as
`optionalDependencies`, so npm downloads only the one that matches the host.

Internal to this repo; not published. sdlc
(`solutions/ontological/scripts/build-npm-wrapper.ts`) and agent-pants
(`solutions/agent-pants/npm/dist.ts`) both build their npm packages with it.
Each keeps its own build step and product names.

What it provides:

- Platform names: `platformKey`, `platformPackageName`, `binaryFileName`,
  `binaryPathInPackage`, `findPlatform`, `hostPlatform`, and `NPM_PLATFORMS`.
- `platformManifest` and `launcherManifest`: the two package.json shapes. A
  product's template fields keep their position, so the product controls key
  order.
- `renderLauncher`: the Node launcher shim. It resolves the platform package,
  runs the binary with inherited stdio, ignores SIGINT/SIGTERM/SIGHUP while
  the child runs, and re-raises the child's signal or exits `128 + signal`.
- `publishPackages`: platform packages first, the launcher last, skipping
  versions the registry already has.
- `cargoTargetDir`: cargo's target directory, from `cargo metadata`.

```ts
import { NPM_PLATFORMS, launcherManifest, renderLauncher, writeJson } from '@sksizer/npm-binary'

const product = {
  binary: 'tool',
  launcher: '@acme/tool',
  scope: '@acme',
  platformPrefix: 'tool',
  binaryDir: '',
}
writeJson('out/tool/package.json', launcherManifest(product, NPM_PLATFORMS, {
  version: '1.0.0',
  description: 'The tool CLI.',
  launcherPath: 'bin/tool.js',
}))
await Bun.write('out/tool/bin/tool.js', renderLauncher(product, NPM_PLATFORMS))
```
