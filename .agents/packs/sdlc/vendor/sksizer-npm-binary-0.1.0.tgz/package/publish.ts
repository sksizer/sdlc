/**
 * Publish a product's packages: platform packages first, the launcher last, so
 * its optional dependencies already exist on the registry when it lands.
 * A version the registry already has is skipped, so a half-finished run is
 * safe to re-run.
 */
import { readFileSync } from 'node:fs'
import { join } from 'node:path'

import { spawnRunnerAsync, streamRunner } from '@sksizer/command-seam'

export interface PublishOptions {
  platformDirs: readonly string[]
  launcherDir: string
  dryRun?: boolean
}

export async function publishPackages({
  platformDirs,
  launcherDir,
  dryRun = false,
}: PublishOptions): Promise<void> {
  const packages = [...platformDirs, launcherDir].map((dir) => ({
    dir,
    ...(JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')) as {
      name: string
      version: string
    }),
  }))
  const published = await Promise.all(
    packages.map(async ({ dir, name, version }) => {
      const existing = await spawnRunnerAsync('npm').run(
        ['view', `${name}@${version}`, 'version'],
        { cwd: dir },
      )
      return existing.exitCode === 0 && existing.stdout.trim() === version
    }),
  )
  for (const [i, { dir, name, version }] of packages.entries()) {
    if (published[i]) {
      console.log(`${name}@${version} is already published; skipping`)
      continue
    }
    const argv = ['publish', ...(dryRun ? ['--dry-run'] : [])]
    const result = streamRunner('npm').run(argv, { cwd: dir })
    if (result.exitCode !== 0) throw new Error(`npm ${argv.join(' ')} failed in ${dir}`)
  }
}
