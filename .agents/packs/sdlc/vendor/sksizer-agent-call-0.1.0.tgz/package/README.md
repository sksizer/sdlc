# @sksizer/agent-call

One canonical call spec for headless coding-agent CLIs.

Declare **what** you want — prompt, permission posture, context, output shape,
session behavior — once, in a typed, agent-agnostic form. Each adapter
translates it into a concrete CLI invocation (`claude -p`, `codex exec`,
`gemini`, `opencode run`) on a **best-effort** basis, and every approximation
is recorded, never silently dropped. Results come back normalized (final text,
structured output, session id, token usage, cost) with the raw output always
preserved, and an optional layer lifts the full transcript into a standard
conversation model for post-facto analysis.

```ts
import { adapterFor, callAgent } from "@sksizer/agent-call";

const result = await callAgent(adapterFor("claude"), {
  prompt: "Summarize the failing tests and propose a fix.",
  permissions: { mode: "read-only" },
  context: { files: ["src/runner.ts"], dirs: ["../shared"] },
  output: { schema: { type: "object", properties: { summary: { type: "string" } } } },
  timeoutMs: 120_000,
});

result.ok;          // exit + agent status combined
result.text;        // final answer
result.structured;  // parsed JSON (schema was requested)
result.sessionId;   // for later session.resume
result.usage;       // { inputTokens, outputTokens, cacheReadTokens, ... }
result.costUsd;     // where the agent reports it
result.planned;     // the EXACT argv/env/stdin that ran + capability notes
result.raw;         // untouched stdout/stderr, always kept
```

Swap `adapterFor("claude")` for `"codex"`, `"gemini"`, or `"opencode"` and the
same spec runs there — differently spelled, same intent.

## Why

Every project that shells out to an agent CLI grows its own argv builder,
JSON-envelope parser, permission flags, and retry glue. The CLIs disagree on
how prompts travel, what "auto-approve edits" is called, and whether structured
output is a flag at all. This package is that glue, written once, with the
disagreements documented in the capability map below.

## Design

- **Spec** (`AgentCallSpec`) — canonical description of one call. Only
  `prompt` is required.
- **Plan** (`planCall(adapter, spec)`) — pure translation: spec in,
  `PlannedCall` out (argv, stdin, env, temp files, capability notes). No side
  effects; golden-testable; inspect it before running anything.
- **Run** (`callAgent(adapter, spec)`) — spawns the planned call, applies the
  library-level timeout (no agent CLI has one), and returns an `AgentResult`.
  Never throws on agent failure — errors are structured
  (`spawn-failed | timeout | nonzero-exit | agent-error`).
- **Conversation** (optional) — `callAgent(..., { captureConversation: true })`
  lifts the transcript into `agent-conversation/1`: role-tagged messages of
  typed parts (`text | reasoning | tool-call | tool-result`) plus usage, cost,
  duration, stop reason — with `raw` retained alongside. The shape follows the
  common core of ACP session updates, OTel GenAI attributes, and the Vercel AI
  SDK message model, so it exports cleanly to any of them.

### Best-effort translation, honestly reported

Every planned call carries `notes: CapabilityNote[]` — one entry per spec
field that didn't map 1:1:

- `native` — first-class flag.
- `approximated` — closest available behavior.
- `emulated` — reproduced via prompt engineering or env plumbing.
- `dropped` — the CLI can't express it; field ignored, note says why.

### Capability map (v0.1)

| Spec field | claude | codex | gemini | opencode |
|---|---|---|---|---|
| `prompt` | stdin | stdin (`-`) | stdin | positional |
| `model` | `--model` | `--model` | `--model` | `--model` (provider/model) |
| `modelTier` | haiku/sonnet/opus | dropped | flash/auto/pro | dropped |
| `effort` | `--effort` | `model_reasoning_effort` | dropped | `--variant` |
| `systemPrompt` | `--system-prompt` | prompt-emulated | `GEMINI_SYSTEM_MD` file | prompt-emulated |
| `appendSystemPrompt` | `--append-system-prompt` | prompt-emulated | prompt-emulated | prompt-emulated |
| `permissions.mode: read-only` | `--permission-mode plan` | `--sandbox read-only` | `--approval-mode plan` | `OPENCODE_PERMISSION` deny map |
| `permissions.mode: edits` | `--permission-mode acceptEdits` | `--sandbox workspace-write` | `--approval-mode auto_edit` | `OPENCODE_PERMISSION` |
| `permissions.mode: full-auto` | acceptEdits + allowed Bash/Web | `--sandbox workspace-write` | `--approval-mode yolo` | `OPENCODE_PERMISSION` allow map |
| `permissions.mode: bypass` | `--dangerously-skip-permissions` | `--dangerously-bypass-approvals-and-sandbox` | `--approval-mode yolo` | `OPENCODE_PERMISSION` allow map |
| `permissions.allowTools` | `--allowedTools` | dropped | `--allowed-tools` | dropped |
| `permissions.denyTools` | `--disallowedTools` | dropped | dropped | dropped |
| `context.files` | prompt preamble | prompt preamble | `@path` in prompt | `--file` |
| `context.dirs` | `--add-dir` | `--add-dir` | `--include-directories` | dropped |
| `context.text` | prompt preamble | prompt preamble | prompt preamble | prompt preamble |
| `output.format` | `text\|json\|stream-json` | `--json` events | `text\|json\|stream-json` | `--format json` events |
| `output.schema` | `--json-schema` | `--output-schema` file | prompt-emulated | prompt-emulated |
| `session.resume` | `--resume` | `exec resume <id>` | `--resume` | `--session` |
| `session.continueLast` | `--continue` | `exec resume --last` | `--resume latest` | `--continue` |
| `session.id` | `--session-id` | dropped | dropped | dropped |
| `session.persist: false` | `--no-session-persistence` | `--ephemeral` | dropped | dropped |
| `mcp.servers` | `--mcp-config` | `-c mcp_servers.*` | dropped | dropped |
| `budgetUsd` | `--max-budget-usd` | dropped | dropped | dropped |
| `timeoutMs` | library-level (SIGTERM → SIGKILL) on all agents | | | |
| `extraArgs` | appended verbatim on all agents | | | |

When no `output.format` is given, adapters default to their richest aggregate
format (JSON envelope / event stream) so metadata is captured; `result.text`
always carries the final answer either way.

## Other entry points

```ts
import {
  planCall,          // pure spec → PlannedCall, run nothing
  detectAgents,      // probe which CLIs are installed (+ versions)
  customAdapter,     // wrap any one-shot CLI (aider, goose, in-house tools)
  claudeAdapter,     // per-adapter factories; override binary path:
} from "@sksizer/agent-call";

const claude = claudeAdapter({ binary: "/opt/claude/claude" });

const aider = customAdapter({
  name: "aider",
  binary: "aider",
  args: (spec, effectivePrompt) => ["--message", effectivePrompt, "--yes-always"],
});
```

Custom adapters get the emulation layer for free: context text/files, system
prompts, and output schemas are folded into `effectivePrompt`.

## Post-facto analysis

```ts
import { assistantText, toolCalls } from "@sksizer/agent-call";

const result = await callAgent(adapterFor("codex"), spec, {
  captureConversation: true,
});
const convo = result.conversation!;
convo.messages;        // [{role, parts: [{type: "tool-call", name: "shell", ...}]}]
toolCalls(convo);      // every tool call across the run
convo.usage;           // normalized token counts
convo.raw;             // the original transcript, untouched
JSON.stringify(convo); // stable `agent-conversation/1` schema — store it
```

## Development

Bun-first: `bun test` (unit; parsers are fixture-tested, runners exercised
against real processes), `bun run typecheck`, `bun run build` (tsc → `dist/`).

Live smoke tests make real (cheap) agent calls against whichever CLIs are
installed: `AGENT_CALL_LIVE=1 bun test src/live.test.ts`.

Verified against: claude 2.x, codex 0.5x, opencode 1.x (live); gemini
mappings are built from current docs and fixture-tested only — flag drift
there gets caught by the live suite once the CLI is installed.

## Non-goals

- **HTTP service / terminal emulation** — [coder/agentapi](https://github.com/coder/agentapi) owns
  that.
- **Model-API abstraction** — the Vercel AI SDK owns that layer; this package
  drives *agent CLIs as processes*.
- **Orchestration** (worktrees, queues, parallelism) — this is the invocation
  primitive such tools build on.
- **A trace backend** — `agent-conversation/1` is meant to be stored/exported;
  bring your own sink.
