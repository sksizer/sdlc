# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Version 0.1.0 has never been published. Everything below is the record of
how the package reached its current shape, reconstructed from commit
history and dated by commit.

The package was written on 2026-07-05 in a separate personal repository and
moved into this monorepo on 2026-07-12. The initial commit landed the
package whole, so the authoring history before that date is a single
snapshot rather than a sequence of changes.

### Added

- **The call spec.** `AgentCallSpec` describes one agent call in
  agent-agnostic terms: prompt, model and model tier, reasoning effort,
  system prompts, permission posture, context files and directories,
  output format and JSON schema, session behavior, MCP servers, budget,
  and timeout. Only `prompt` is required.
- **Pure planning.** `planCall(adapter, spec)` translates a spec into a
  `PlannedCall` — argv, stdin, env, temp files — with no side effects, so
  an invocation can be inspected and golden-tested before it runs.
- **Capability notes.** Every planned call carries one `CapabilityNote`
  per spec field that did not map 1:1, classified `native`,
  `approximated`, `emulated`, or `dropped`. No approximation is silent.
- **Four adapters** — `claude`, `codex`, `gemini`, `opencode` — plus
  `customAdapter` for wrapping any one-shot CLI, and `detectAgents` to
  probe which CLIs are installed.
- **Running.** `callAgent(adapter, spec)` spawns the planned call and
  applies a library-level timeout, which no agent CLI provides. It never
  throws on agent failure; errors are structured as `spawn-failed`,
  `timeout`, `nonzero-exit`, or `agent-error`.
- **Normalized results.** `AgentResult` carries final text, parsed
  structured output, session id, token usage, cost, and the plan that ran.
  Raw stdout and stderr are always preserved alongside.
- **Conversation model.** `captureConversation: true` lifts a transcript
  into `agent-conversation/1`: role-tagged messages of typed parts
  (`text`, `reasoning`, `tool-call`, `tool-result`) with usage, cost,
  duration, and stop reason.
- **Capability map** documenting, per spec field and per agent, exactly
  how the translation is spelled and where it is dropped (2026-07-05).

### Changed

- Model-tier and permission-mode argv construction moved into shared
  table-driven helpers (`applyModelTier`, `applyPermissionMode`), replacing
  duplicated switch chains in the claude, codex, and gemini adapters.
  Argv tokens and note text are unchanged. `opencode` sets permissions
  through an environment variable rather than flags and keeps its own
  path (2026-08-24).
- The package tsconfig now extends the shared monorepo base rather than
  standing alone, so its strictness matches its consumers (2026-08-23).
- Engines aligned to bun >= 1.3 and node >= 24 (2026-07-05).

### Packaging

- Published as `@sksizer/agent-call` under MIT, with a `LICENSE`, repository
  and homepage metadata, and this changelog in the tarball (2026-08-29).
- A `bun` export condition resolves the TypeScript source directly, so
  in-repo consumers need no build step; `types`/`import`/`default` resolve
  `dist/` for everyone else. Both source and `dist/` ship (2026-08-29).

### Fixed

- **An agent that exited without reading stdin crashed the host process.**
  The prompt was written to `child.stdin` with no `error` listener, so a
  CLI that rejected its flags, failed auth, or was killed by the
  timeout/abort path failed the write with `EPIPE` — an uncaught stream
  error that took the calling process down. The failure is now recorded on
  the new `RawProcessOutput.stdinError` instead of thrown. Callers that
  care about prompt integrity should read it: a child that consumes part
  of the prompt and still exits 0 answered a truncated question, and no
  other field reveals that (2026-09-04).
- **Multi-byte characters were destroyed at read boundaries.** stdout and
  stderr were accumulated by decoding each `Buffer` independently, so a
  UTF-8 sequence straddling two ~64KiB reads became two `U+FFFD`. Both
  streams now decode with `setEncoding("utf8")`, which holds a partial
  sequence over the boundary (2026-09-04).
- **The gemini adapter applied `systemPrompt` twice.** It is handled
  natively through `GEMINI_SYSTEM_MD`, but the prompt builder also
  prepended a `<system>` block and emitted a second, contradictory
  capability note. `buildEffectivePrompt` now suppresses `systemPrompt`
  and `appendSystemPrompt` independently, and gemini suppresses only the
  one it handles natively (2026-09-04).
- **An already-aborted signal was ignored and the agent still ran.** The
  `abort` listener was attached after `spawn`, and a signal that has
  already fired never fires again — so a pre-aborted call spawned the CLI
  and ran the full turn. The signal is now checked before spawning, and
  the result mirrors a mid-run abort: `timedOut`, no exit code, and a
  `timeout` error (2026-09-04).
- **claude `stream-json` runs with no result event reported empty
  success.** A stream that ended without its terminal envelope (crash,
  kill, truncated output) parsed to `text: ""` with `isError: false`,
  hiding the answer text sitting in the events. It now reports an error,
  matching the `json` format's existing missing-envelope guard, with the
  events still returned. **Behavior change:** a caller that consumed
  `stream-json` purely for the event list and ignored the terminal
  envelope now sees `ok: false` with reason `agent-error` where it
  previously saw `ok: true` (2026-09-04).
- **The package had never built.** `tsconfig.build.json` set `noEmit: false`
  while inheriting `allowImportingTsExtensions` from the shared base config,
  which TypeScript rejects for an emitting build (TS5096), so `bun run build`
  failed and no `dist/` was ever produced. Adding
  `rewriteRelativeImportExtensions` makes the emitting build legal and
  rewrites `.ts` import specifiers to `.js` in the output (2026-08-29).
- **Timeouts leaked child processes.** A timed-out call was killed with
  `child.kill`, which left grandchildren holding the stdio pipes open —
  on Linux the `close` event never fired and the call hung past its
  deadline. Children are now spawned detached and the whole process group
  is signalled (2026-07-12).
- **The codex adapter reported successful runs as failures.** Any
  error-level item in the event stream set `isError`, including
  warning-level ones such as config deprecation notices. The parser now
  tracks `turn.failed` and whether any agent message answered, and marks
  an error only when the turn actually failed or an error arrived with no
  answer (2026-07-05).
