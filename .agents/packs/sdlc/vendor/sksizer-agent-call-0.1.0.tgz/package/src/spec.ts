/**
 * The canonical, agent-agnostic description of one headless agent call.
 *
 * A spec says WHAT you want — prompt, permission posture, context, output
 * shape, session behavior — never HOW a particular CLI expresses it. Each
 * adapter translates the spec into a concrete invocation on a best-effort
 * basis and records every approximation as a `CapabilityNote` (see plan.ts),
 * so nothing is ever silently dropped.
 */

/** Adapters shipped with this package. Custom adapters may use any name. */
export type AgentName = 'claude' | 'codex' | 'gemini' | 'opencode'

/**
 * Canonical permission posture, ordered from most to least restricted.
 *
 * - `read-only`  — the agent may inspect but not mutate anything.
 * - `default`    — whatever the agent's own default posture is.
 * - `edits`      — file edits are pre-approved; shell/network still gated
 *                  (gated means denied under headless runs — nothing prompts).
 * - `full-auto`  — edits and workspace-scoped commands pre-approved, inside
 *                  whatever sandbox the agent offers.
 * - `bypass`     — skip all approvals and sandboxing. Dangerous; intended for
 *                  externally sandboxed environments only.
 */
export type PermissionMode = 'read-only' | 'default' | 'edits' | 'full-auto' | 'bypass'

export interface PermissionSpec {
  mode?: PermissionMode | undefined
  /**
   * Tool patterns to pre-approve. Passed through verbatim where the agent
   * supports tool rules (claude's `--allowedTools "Bash(git *) Edit"`);
   * recorded as dropped elsewhere.
   */
  allowTools?: string[] | undefined
  /** Tool patterns to deny. Same passthrough semantics as `allowTools`. */
  denyTools?: string[] | undefined
}

export interface ContextSpec {
  /**
   * Files the agent should consider. Attached natively where the CLI supports
   * it (opencode `-f`), otherwise emulated with a prompt preamble that lists
   * the paths (and `@path` references for agents with @-inclusion syntax).
   */
  files?: string[] | undefined
  /** Extra directories the agent may access (`--add-dir` and friends). */
  dirs?: string[] | undefined
  /** Freeform context prepended to the prompt on every agent. */
  text?: string | undefined
}

export type OutputFormat = 'text' | 'json' | 'stream-json'

export interface OutputSpec {
  /**
   * - `text`        — final answer as plain text.
   * - `json`        — one machine-readable envelope with metadata.
   * - `stream-json` — line-delimited JSON events as the run progresses.
   *
   * When omitted, adapters default to their richest aggregate format so
   * usage/cost/session metadata can be captured; `AgentResult.text` always
   * carries the final answer regardless.
   */
  format?: OutputFormat | undefined
  /**
   * JSON Schema the final answer must satisfy. Native where supported
   * (claude `--json-schema`, codex `--output-schema`), otherwise emulated by
   * appending a strict respond-only-with-JSON instruction to the prompt.
   * The parsed value lands in `AgentResult.structured`.
   */
  schema?: Record<string, unknown> | undefined
}

export interface SessionSpec {
  /** Pin the new session's id (claude only). */
  id?: string | undefined
  /** Resume an existing session/thread by id. */
  resume?: string | undefined
  /** Resume the most recent session instead of naming one. */
  continueLast?: boolean | undefined
  /** Set false to keep the run off disk where supported (default: agent's own). */
  persist?: boolean | undefined
}

/**
 * Cross-agent model intent when you don't want to name a concrete model.
 * Ignored when `model` is set. Mapping is per-adapter and recorded as an
 * `approximated` note (model families change faster than this library).
 */
export type ModelTier = 'fast' | 'standard' | 'max'

/**
 * Reasoning-effort intent, a separate axis from model choice. Maps to claude
 * `--effort`, codex `model_reasoning_effort`, opencode `--variant`.
 */
export type EffortLevel = 'low' | 'medium' | 'high' | 'max'

export interface McpSpec {
  /**
   * MCP servers to expose to the agent, in the common `mcpServers` config
   * shape: name → `{command, args?, env?}` or `{url}`. Native on claude
   * (`--mcp-config`), rendered to `-c mcp_servers.*` overrides on codex,
   * config-file-only (dropped, with a note) on gemini/opencode.
   */
  servers?: Record<string, Record<string, unknown>> | undefined
  /** Use ONLY these servers, ignoring user/project config (claude only). */
  strict?: boolean | undefined
}

/** The canonical call. Only `prompt` is required. */
export interface AgentCallSpec {
  prompt: string
  /** Concrete model id/alias for the target agent. Wins over `modelTier`. */
  model?: string | undefined
  modelTier?: ModelTier | undefined
  effort?: EffortLevel | undefined
  mcp?: McpSpec | undefined
  /** Replace the agent's system prompt (native on claude; else emulated). */
  systemPrompt?: string | undefined
  /** Append to the agent's system prompt (native on claude; else emulated). */
  appendSystemPrompt?: string | undefined
  permissions?: PermissionSpec | undefined
  context?: ContextSpec | undefined
  output?: OutputSpec | undefined
  session?: SessionSpec | undefined
  /** Hard dollar cap where supported (claude `--max-budget-usd`). */
  budgetUsd?: number | undefined
  /** Working directory for the agent process. */
  cwd?: string | undefined
  /** Extra environment variables for the agent process. */
  env?: Record<string, string> | undefined
  /** Kill the process after this long (SIGTERM, then SIGKILL after 5s). */
  timeoutMs?: number | undefined
  /** Escape hatch: appended verbatim to the built argv, after everything. */
  extraArgs?: string[] | undefined
}
