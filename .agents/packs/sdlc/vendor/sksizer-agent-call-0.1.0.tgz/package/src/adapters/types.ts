import type { Conversation, Usage } from '../conversation.js'
import type { PlannedCall } from '../plan.js'
import type { AgentCallSpec } from '../spec.js'

/** What actually came back from the child process. */
export interface RawProcessOutput {
  stdout: string
  stderr: string
  exitCode: number | null
  durationMs: number
  /** The run was cut short: a timeout elapsed, or the caller aborted. */
  timedOut: boolean
  /**
   * The prompt could not be fully written to the child's stdin, because the
   * child exited or closed the pipe first — so the agent answered a truncated
   * prompt. Absent when the write completed.
   */
  stdinError?: string | undefined
  /** Contents of `readBack` temp files, keyed by `TempFile.name`. */
  files?: Record<string, string> | undefined
}

/** Adapter-parsed view of a raw run, before assembly into an AgentResult. */
export interface ParsedOutput {
  /** Best-effort final assistant answer as plain text. */
  text: string
  /** Parsed JSON answer when `output.schema` was requested. */
  structured?: unknown | undefined
  sessionId?: string | undefined
  usage?: Usage | undefined
  costUsd?: number | undefined
  model?: string | undefined
  stopReason?: string | undefined
  /** Parsed JSONL events when a streaming format was used. */
  events?: unknown[] | undefined
  /** The agent itself reported failure (distinct from a nonzero exit). */
  isError?: boolean | undefined
  errorDetail?: string | undefined
}

/**
 * One agent CLI. `plan` is pure (spec in, invocation out); `parseResult`
 * is pure (bytes in, structure out). All process handling lives in the
 * runner, so adapters are trivially unit-testable.
 */
export interface AgentAdapter {
  name: string
  /** Binary to spawn; override via each adapter factory's `binary` option. */
  binary: string
  plan(spec: AgentCallSpec): PlannedCall
  parseResult(planned: PlannedCall, raw: RawProcessOutput): ParsedOutput
  /** Optional supplemental layer: lift the raw transcript into the normalized model. */
  toConversation?(planned: PlannedCall, raw: RawProcessOutput): Conversation | undefined
}
