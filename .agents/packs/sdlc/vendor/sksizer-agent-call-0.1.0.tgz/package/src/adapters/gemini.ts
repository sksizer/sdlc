import {
  CONVERSATION_SCHEMA,
  type Conversation,
  type ConversationMessage,
  type Usage,
} from '../conversation.js'
import { note, TMP_TOKEN, type CapabilityNote, type PlannedCall, type TempFile } from '../plan.js'
import type { AgentCallSpec, OutputFormat } from '../spec.js'
import {
  applyModelTier,
  applyPermissionMode,
  asNumber,
  asString,
  buildEffectivePrompt,
  get,
  parseJsonLines,
  tryParseJson,
} from './shared.js'
import type { AgentAdapter, ParsedOutput, RawProcessOutput } from './types.js'

export interface GeminiAdapterOptions {
  binary?: string
}

const SYSTEM_MD_FILE = 'system.md'

const TIER_MODEL: Record<string, string> = {
  fast: 'flash',
  standard: 'auto',
  max: 'pro',
}

/**
 * Google Gemini CLI. Headless via stdin prompt + `--output-format
 * text|json|stream-json`. Approval modes map onto the canonical permission
 * postures; system prompt replacement rides the `GEMINI_SYSTEM_MD` env var;
 * output schemas are emulated in the prompt.
 */
export function geminiAdapter(options: GeminiAdapterOptions = {}): AgentAdapter {
  const binary = options.binary ?? 'gemini'
  return {
    name: 'gemini',
    binary,
    plan(spec) {
      return planGemini(binary, spec)
    },
    parseResult(planned, raw) {
      return parseGemini(planned, raw)
    },
    toConversation(planned, raw) {
      return geminiConversation(planned, raw)
    },
  }
}

function planGemini(binary: string, spec: AgentCallSpec): PlannedCall {
  const notes: CapabilityNote[] = []
  const tempFiles: TempFile[] = []
  const env: Record<string, string> = { ...spec.env }
  const argv = [binary]

  const format: OutputFormat = spec.output?.format ?? 'json'
  if (format !== 'text') argv.push('--output-format', format)

  applyModelTier(argv, notes, spec, TIER_MODEL, 'gemini')

  if (spec.effort !== undefined) {
    note(notes, 'effort', 'dropped', 'gemini has no reasoning-effort flag')
  }
  if (spec.mcp?.servers !== undefined) {
    note(notes, 'mcp.servers', 'dropped', 'gemini takes MCP servers from settings.json, not a flag')
  }

  if (spec.systemPrompt !== undefined) {
    tempFiles.push({ name: SYSTEM_MD_FILE, content: spec.systemPrompt })
    env['GEMINI_SYSTEM_MD'] = `${TMP_TOKEN}/${SYSTEM_MD_FILE}`
    note(notes, 'systemPrompt', 'approximated', 'system prompt replaced via GEMINI_SYSTEM_MD file')
  }

  const permissions = spec.permissions
  applyPermissionMode(argv, notes, permissions?.mode, {
    'read-only': {
      argv: ['--approval-mode', 'plan'],
      support: 'approximated',
      detail: 'read-only mapped to --approval-mode plan (analysis only, no mutations)',
    },
    edits: {
      argv: ['--approval-mode', 'auto_edit'],
      support: 'native',
      detail: '--approval-mode auto_edit',
    },
    'full-auto': {
      argv: ['--approval-mode', 'yolo'],
      support: 'approximated',
      detail:
        'full-auto mapped to --approval-mode yolo (gemini approves everything; no workspace scoping)',
    },
    bypass: {
      argv: ['--approval-mode', 'yolo'],
      support: 'native',
      detail: '--approval-mode yolo',
    },
  })
  const allowTools = permissions?.allowTools ?? []
  if (allowTools.length > 0) {
    argv.push('--allowed-tools', allowTools.join(','))
    note(
      notes,
      'permissions.allowTools',
      'approximated',
      '--allowed-tools skips confirmation for these tools (flag deprecated upstream in favor of the policy engine)',
    )
  }
  if ((permissions?.denyTools ?? []).length > 0) {
    note(
      notes,
      'permissions.denyTools',
      'dropped',
      'no CLI flag; configure excludeTools in gemini settings.json',
    )
  }

  const dirs = spec.context?.dirs ?? []
  if (dirs.length > 0) {
    argv.push('--include-directories', dirs.join(','))
    note(notes, 'context.dirs', 'native', '--include-directories')
  }

  const session = spec.session
  if (session?.resume !== undefined) {
    argv.push('--resume', session.resume)
    note(notes, 'session.resume', 'native', '--resume')
  } else if (session?.continueLast === true) {
    argv.push('--resume', 'latest')
    note(notes, 'session.continueLast', 'native', '--resume latest')
  }
  if (session?.id !== undefined) {
    note(notes, 'session.id', 'dropped', 'gemini assigns session ids itself')
  }
  if (session?.persist === false) {
    note(notes, 'session.persist', 'dropped', 'gemini always persists sessions')
  }
  if (spec.budgetUsd !== undefined) {
    note(notes, 'budgetUsd', 'dropped', 'gemini has no budget cap flag')
  }

  argv.push(...(spec.extraArgs ?? []))

  // systemPrompt is already handled natively above via GEMINI_SYSTEM_MD;
  // appendSystemPrompt has no gemini flag and stays emulated in the prompt.
  const stdin = buildEffectivePrompt(spec, { filesAtSyntax: true, systemNative: true }, notes)

  return {
    agent: 'gemini',
    argv,
    stdin,
    env,
    cwd: spec.cwd,
    outputFormat: format,
    tempFiles,
    notes,
    spec,
  }
}

function parseGemini(planned: PlannedCall, raw: RawProcessOutput): ParsedOutput {
  if (planned.outputFormat === 'text') {
    const parsed: ParsedOutput = { text: raw.stdout.trim() }
    if (planned.spec.output?.schema !== undefined) {
      parsed.structured = tryParseJson(parsed.text)
    }
    return parsed
  }

  if (planned.outputFormat === 'stream-json') {
    return parseGeminiStream(planned, raw)
  }

  const envelope = tryParseJson(raw.stdout)
  if (envelope === undefined) {
    return {
      text: raw.stdout.trim(),
      isError: true,
      errorDetail: 'gemini --output-format json produced no parseable envelope',
    }
  }
  const text = asString(get(envelope, 'response')) ?? ''
  const error = get(envelope, 'error')
  const parsed: ParsedOutput = {
    text,
    usage: geminiUsage(get(envelope, 'stats')),
    isError: error !== undefined && error !== null,
    errorDetail: asString(get(error, 'message')),
  }
  if (planned.spec.output?.schema !== undefined) {
    parsed.structured = tryParseJson(text)
  }
  const models = get(envelope, 'stats', 'models')
  if (models !== null && typeof models === 'object') {
    parsed.model = Object.keys(models as Record<string, unknown>)[0]
  }
  return parsed
}

function parseGeminiStream(planned: PlannedCall, raw: RawProcessOutput): ParsedOutput {
  const events = parseJsonLines(raw.stdout)
  const textChunks: string[] = []
  let sessionId: string | undefined
  let usage: Usage | undefined
  let model: string | undefined
  let errorDetail: string | undefined

  for (const event of events) {
    const type = get(event, 'type')
    if (type === 'init') {
      sessionId = asString(get(event, 'session_id')) ?? asString(get(event, 'sessionId'))
      model = asString(get(event, 'model'))
    } else if (type === 'message') {
      const role = asString(get(event, 'role'))
      const content = asString(get(event, 'content')) ?? asString(get(event, 'text'))
      if (content !== undefined && role !== 'user') textChunks.push(content)
    } else if (type === 'error') {
      errorDetail = asString(get(event, 'message')) ?? 'gemini reported an error'
    } else if (type === 'result') {
      usage = geminiUsage(get(event, 'stats')) ?? usage
      const response = asString(get(event, 'response'))
      if (response !== undefined && textChunks.length === 0) {
        textChunks.push(response)
      }
    }
  }

  const parsed: ParsedOutput = {
    text: textChunks.join('').trim(),
    sessionId,
    usage,
    model,
    events,
    isError: errorDetail !== undefined,
    errorDetail,
  }
  if (planned.spec.output?.schema !== undefined && parsed.text !== '') {
    parsed.structured = tryParseJson(parsed.text)
  }
  return parsed
}

function geminiUsage(stats: unknown): Usage | undefined {
  const models = get(stats, 'models')
  if (models === null || typeof models !== 'object') return undefined
  const usage: Usage = {}
  for (const perModel of Object.values(models as Record<string, unknown>)) {
    const tokens = get(perModel, 'tokens')
    usage.inputTokens = (usage.inputTokens ?? 0) + (asNumber(get(tokens, 'prompt')) ?? 0)
    usage.outputTokens = (usage.outputTokens ?? 0) + (asNumber(get(tokens, 'candidates')) ?? 0)
    usage.cacheReadTokens = (usage.cacheReadTokens ?? 0) + (asNumber(get(tokens, 'cached')) ?? 0)
    usage.totalTokens = (usage.totalTokens ?? 0) + (asNumber(get(tokens, 'total')) ?? 0)
  }
  return usage
}

function geminiConversation(planned: PlannedCall, raw: RawProcessOutput): Conversation | undefined {
  const parsed = parseGemini(planned, raw)
  const messages: ConversationMessage[] = [
    { role: 'user', parts: [{ type: 'text', text: planned.stdin ?? '' }] },
  ]

  if (planned.outputFormat === 'stream-json') {
    for (const event of parsed.events ?? []) {
      const type = get(event, 'type')
      if (type === 'tool_use') {
        messages.push({
          role: 'assistant',
          parts: [
            {
              type: 'tool-call',
              callId: asString(get(event, 'id')),
              name: asString(get(event, 'name')) ?? 'unknown',
              input: get(event, 'input') ?? get(event, 'args'),
            },
          ],
        })
      } else if (type === 'tool_result') {
        messages.push({
          role: 'tool',
          parts: [
            {
              type: 'tool-result',
              callId: asString(get(event, 'id')),
              output: get(event, 'output') ?? get(event, 'content'),
              isError: get(event, 'status') === 'error',
            },
          ],
        })
      }
    }
  }
  if (parsed.text !== '') {
    messages.push({
      role: 'assistant',
      parts: [{ type: 'text', text: parsed.text }],
    })
  }

  return {
    schema: CONVERSATION_SCHEMA,
    agent: 'gemini',
    model: parsed.model,
    sessionId: parsed.sessionId,
    messages,
    usage: parsed.usage,
    stopReason: parsed.isError === true ? 'error' : undefined,
    raw: {
      format: `gemini/${planned.outputFormat}`,
      data:
        planned.outputFormat === 'stream-json'
          ? parsed.events
          : (tryParseJson(raw.stdout) ?? raw.stdout),
    },
  }
}
