import type { CapabilityNote, PlannedCall } from '../plan.js'
import { note } from '../plan.js'
import type { AgentCallSpec } from '../spec.js'
import { buildEffectivePrompt } from './shared.js'
import type { AgentAdapter, ParsedOutput } from './types.js'

export interface CustomAdapterOptions {
  name: string
  binary: string
  /**
   * Build the args (after the binary) for a spec. The effective prompt —
   * spec.prompt with context/system/schema folded in — is provided so simple
   * CLIs get the emulation layer for free. Return `stdinPrompt: true` from
   * `promptVia` instead to send it on stdin.
   */
  args: (spec: AgentCallSpec, effectivePrompt: string) => string[]
  /** How the prompt travels. Default: `"argv"` (your `args` must place it). */
  promptVia?: 'argv' | 'stdin'
  /** Optional custom parse; default returns trimmed stdout as text. */
  parse?: (stdout: string, stderr: string) => ParsedOutput
}

/**
 * Escape hatch for agents this package has no adapter for: aider, goose,
 * anything with a one-shot CLI. Spec fields with no representation in your
 * `args` builder are folded into the prompt (context, system, schema) or
 * recorded as dropped (permissions), so best-effort semantics still hold.
 */
export function customAdapter(options: CustomAdapterOptions): AgentAdapter {
  return {
    name: options.name,
    binary: options.binary,
    plan(spec): PlannedCall {
      const notes: CapabilityNote[] = []
      const effectivePrompt = buildEffectivePrompt(spec, {}, notes)
      if (spec.permissions?.mode !== undefined) {
        note(
          notes,
          'permissions.mode',
          'dropped',
          `custom adapter "${options.name}" defines no permission mapping`,
        )
      }
      const argv = [
        options.binary,
        ...options.args(spec, effectivePrompt),
        ...(spec.extraArgs ?? []),
      ]
      return {
        agent: options.name,
        argv,
        stdin: options.promptVia === 'stdin' ? effectivePrompt : undefined,
        env: { ...spec.env },
        cwd: spec.cwd,
        outputFormat: spec.output?.format ?? 'text',
        tempFiles: [],
        notes,
        spec,
      }
    },
    parseResult(_planned, raw): ParsedOutput {
      if (options.parse) return options.parse(raw.stdout, raw.stderr)
      return { text: raw.stdout.trim() }
    },
  }
}
