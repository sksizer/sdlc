// Barrel: re-exports only, no logic of its own. Every public entry point of
// the library is surfaced from here.

export type {
  AgentCallSpec,
  AgentName,
  ContextSpec,
  EffortLevel,
  McpSpec,
  ModelTier,
  OutputFormat,
  OutputSpec,
  PermissionMode,
  PermissionSpec,
  SessionSpec,
} from './spec.js'

export { TMP_TOKEN } from './plan.js'
export type { CapabilityNote, PlannedCall, Support, TempFile } from './plan.js'

export { callAgent, planCall } from './run.js'
export type { AgentResult, CallError, CallOptions } from './run.js'

export { adapterFor, BUILTIN_AGENTS, detectAgents } from './registry.js'
export type { AgentAvailability } from './registry.js'

export { claudeAdapter } from './adapters/claude.js'
export type { ClaudeAdapterOptions } from './adapters/claude.js'
export { codexAdapter } from './adapters/codex.js'
export type { CodexAdapterOptions } from './adapters/codex.js'
export { geminiAdapter } from './adapters/gemini.js'
export type { GeminiAdapterOptions } from './adapters/gemini.js'
export { opencodeAdapter } from './adapters/opencode.js'
export type { OpencodeAdapterOptions } from './adapters/opencode.js'
export { customAdapter } from './adapters/custom.js'
export type { CustomAdapterOptions } from './adapters/custom.js'
export type { AgentAdapter, ParsedOutput, RawProcessOutput } from './adapters/types.js'

export { assistantText, CONVERSATION_SCHEMA, toolCalls } from './conversation.js'
export type { Conversation, ConversationMessage, Part, Role, Usage } from './conversation.js'
