import { spawn } from 'node:child_process'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import type { AgentAdapter, ParsedOutput, RawProcessOutput } from './adapters/types.js'
import type { Conversation } from './conversation.js'
import { TMP_TOKEN, type PlannedCall } from './plan.js'
import type { AgentCallSpec } from './spec.js'

export interface CallError {
  reason: 'spawn-failed' | 'timeout' | 'nonzero-exit' | 'agent-error'
  detail: string
}

/** Everything a run produced: normalized fields plus the untouched raw output. */
export interface AgentResult extends ParsedOutput {
  ok: boolean
  exitCode: number | null
  durationMs: number
  error?: CallError | undefined
  /** The exact invocation that ran — argv, env additions, notes, spec. */
  planned: PlannedCall
  /** Raw process output, always preserved. */
  raw: RawProcessOutput
  /** Normalized transcript, when `captureConversation` was requested. */
  conversation?: Conversation | undefined
}

export interface CallOptions {
  /** Also lift the transcript into the normalized conversation model. */
  captureConversation?: boolean
  /** Abort the run early: kills the child, or skips the spawn if already aborted. */
  signal?: AbortSignal
}

/** Grace period between SIGTERM and SIGKILL on timeout/abort. */
const KILL_GRACE_MS = 5_000

/**
 * Plan a call without running it: the exact argv, stdin, env, temp files,
 * and capability notes the adapter would use. Pure and side-effect free.
 */
export function planCall(adapter: AgentAdapter, spec: AgentCallSpec): PlannedCall {
  return adapter.plan(spec)
}

/** Translate the spec through the adapter, run the CLI, normalize the result. */
export async function callAgent(
  adapter: AgentAdapter,
  spec: AgentCallSpec,
  options: CallOptions = {},
): Promise<AgentResult> {
  const planned = adapter.plan(spec)
  const raw = await execute(planned, spec, options.signal)

  let error: CallError | undefined
  if (raw.exitCode === null && !raw.timedOut) {
    error = { reason: 'spawn-failed', detail: raw.stderr.trim() }
  } else if (raw.timedOut) {
    error = {
      reason: 'timeout',
      detail: `killed after ${spec.timeoutMs ?? 0}ms`,
    }
  }

  const parsed =
    error === undefined ? adapter.parseResult(planned, raw) : { text: raw.stdout.trim() }

  if (error === undefined && raw.exitCode !== 0) {
    error = {
      reason: 'nonzero-exit',
      detail:
        parsed.errorDetail ??
        `${planned.argv[0]} exited ${raw.exitCode}: ${raw.stderr.trim().slice(0, 500)}`,
    }
  } else if (error === undefined && parsed.isError === true) {
    error = {
      reason: 'agent-error',
      detail: parsed.errorDetail ?? 'the agent reported an error',
    }
  }

  const result: AgentResult = {
    ...parsed,
    ok: error === undefined,
    exitCode: raw.exitCode,
    durationMs: raw.durationMs,
    error,
    planned,
    raw,
  }
  if (options.captureConversation === true && adapter.toConversation) {
    result.conversation = adapter.toConversation(planned, raw)
  }
  return result
}

async function execute(
  planned: PlannedCall,
  spec: AgentCallSpec,
  signal?: AbortSignal,
): Promise<RawProcessOutput> {
  let tempDir: string | undefined
  if (planned.tempFiles.length > 0) {
    tempDir = await mkdtemp(join(tmpdir(), 'agent-call-'))
    for (const file of planned.tempFiles) {
      await writeFile(join(tempDir, file.name), file.content, 'utf8')
    }
  }
  const resolveTmp = (value: string): string =>
    tempDir === undefined ? value : value.replaceAll(TMP_TOKEN, tempDir)

  const argv = planned.argv.map(resolveTmp)
  const env: NodeJS.ProcessEnv = { ...process.env }
  for (const [key, value] of Object.entries(planned.env)) {
    env[key] = resolveTmp(value)
  }

  const startedAt = Date.now()
  try {
    const raw = await spawnCollect(argv, {
      stdin: planned.stdin,
      cwd: planned.cwd,
      env,
      timeoutMs: spec.timeoutMs,
      signal,
    })
    raw.durationMs = Date.now() - startedAt

    if (tempDir !== undefined) {
      const files: Record<string, string> = {}
      for (const file of planned.tempFiles) {
        if (file.readBack !== true) continue
        try {
          files[file.name] = await readFile(join(tempDir, file.name), 'utf8')
        } catch {
          // The CLI may not have written it (e.g. errored before finishing).
        }
      }
      if (Object.keys(files).length > 0) raw.files = files
    }
    return raw
  } finally {
    if (tempDir !== undefined) {
      await rm(tempDir, { recursive: true, force: true })
    }
  }
}

interface SpawnOptions {
  stdin?: string | undefined
  cwd?: string | undefined
  env: NodeJS.ProcessEnv
  timeoutMs?: number | undefined
  signal?: AbortSignal | undefined
}

function spawnCollect(argv: string[], options: SpawnOptions): Promise<RawProcessOutput> {
  return new Promise((resolve) => {
    const [binary, ...args] = argv
    if (binary === undefined) {
      resolve({
        stdout: '',
        stderr: 'empty argv',
        exitCode: null,
        durationMs: 0,
        timedOut: false,
      })
      return
    }

    // An already-aborted signal never fires `abort` again, so it has to be
    // honored before spawn — otherwise the agent runs the full turn. The
    // result mirrors a mid-run abort: cut short, with no exit code.
    if (options.signal?.aborted === true) {
      resolve({
        stdout: '',
        stderr: '',
        exitCode: null,
        durationMs: 0,
        timedOut: true,
      })
      return
    }

    const child = spawn(binary, args, {
      cwd: options.cwd,
      env: options.env,
      stdio: ['pipe', 'pipe', 'pipe'],
      // Own process group, so a timeout/abort can kill the whole tree. Without
      // it, a shell child (e.g. `sh -c "sleep 30"`) leaves its grandchild
      // orphaned holding the stdio pipe open, and `close` never fires — the
      // call hangs until the real command ends instead of honoring timeoutMs.
      detached: true,
    })

    let stdout = ''
    let stderr = ''
    let timedOut = false
    let stdinError: string | undefined
    let settled = false

    let killTimer: ReturnType<typeof setTimeout> | undefined
    let graceTimer: ReturnType<typeof setTimeout> | undefined
    const killTree = (signal: NodeJS.Signals): void => {
      const pid = child.pid
      try {
        // Negative pid targets the whole process group (child is a group
        // leader via `detached`), so grandchildren die too and release the
        // stdio pipe. Fall back to a direct kill if the group is already gone
        // or the platform lacks process groups.
        if (pid !== undefined) process.kill(-pid, signal)
        else child.kill(signal)
      } catch {
        try {
          child.kill(signal)
        } catch {
          /* already exited */
        }
      }
    }
    const terminate = (): void => {
      killTree('SIGTERM')
      graceTimer = setTimeout(() => killTree('SIGKILL'), KILL_GRACE_MS)
    }
    if (options.timeoutMs !== undefined && options.timeoutMs > 0) {
      killTimer = setTimeout(() => {
        timedOut = true
        terminate()
      }, options.timeoutMs)
    }
    const onAbort = (): void => {
      timedOut = true
      terminate()
    }
    options.signal?.addEventListener('abort', onAbort, { once: true })

    const settle = (exitCode: number | null, spawnError?: Error): void => {
      if (settled) return
      settled = true
      if (killTimer !== undefined) clearTimeout(killTimer)
      if (graceTimer !== undefined) clearTimeout(graceTimer)
      options.signal?.removeEventListener('abort', onAbort)
      if (spawnError !== undefined && stderr === '') {
        stderr = spawnError.message
      }
      resolve({ stdout, stderr, exitCode, durationMs: 0, timedOut, stdinError })
    }

    // Decode through the stream, not per chunk: a UTF-8 sequence straddling
    // two reads must be held over the boundary instead of becoming two U+FFFD.
    child.stdout.setEncoding('utf8')
    child.stderr.setEncoding('utf8')
    child.stdout.on('data', (chunk: string) => {
      stdout += chunk
    })
    child.stderr.on('data', (chunk: string) => {
      stderr += chunk
    })
    child.on('error', (err) => settle(null, err))
    child.on('close', (code) => settle(code))

    // The child may exit before draining stdin (bad flag, auth failure, or a
    // kill from the timeout/abort path), which fails the write with EPIPE.
    // Without a listener that stream error is an uncaught exception that takes
    // the host process down. It is recorded rather than dropped: the failure
    // means the agent saw a truncated prompt, and nothing else reveals that
    // when the child still exits 0. Recorded at `settle` so the diagnostic
    // rides on the resolved value; node closes stdin before emitting `close`,
    // so the error always lands first.
    child.stdin.on('error', (err: Error) => {
      stdinError ??= err.message
    })

    if (options.stdin !== undefined) {
      child.stdin.write(options.stdin)
    }
    child.stdin.end()
  })
}
