/**
 * The pull requests of a repository, indexed by head branch.
 *
 * One `gh pr list` per repository, not one query per branch: a repository with
 * sixty branches would otherwise pay sixty round trips to answer a question
 * one listing covers.
 */

import type { Gh } from '@sksizer/easy-gh'

import type { PRInfo, RepoInfo } from './types.ts'

/** The fields classification consults. Asking for more costs latency. */
const FIELDS = ['number', 'state', 'mergedAt', 'headRefName', 'title', 'url'] as const

const LIMIT = 300

/** Open outranks merged outranks closed, and a newer PR outranks an older. */
function priority(state: string): number {
  return ({ OPEN: 3, MERGED: 2, CLOSED: 1 } as Record<string, number>)[state] ?? 0
}

/**
 * Every pull request whose head branch this repository still has, keyed by
 * that branch.
 *
 * A branch can carry several PRs over its life. The one that decides a
 * verdict is the most live: an open PR means keep whatever else happened, and
 * a merged one means the work landed. Ties go to the higher number, so two
 * runs over unchanged state agree.
 *
 * An empty map is the honest answer when `gh` is missing, unauthenticated or
 * failing. Classification degrades to git evidence and the report says so.
 */
export function fetchPrs(repo: RepoInfo, gh: Gh): Map<string, PRInfo> {
  const byHead = new Map<string, PRInfo>()
  if (!(repo.hasGh && repo.ghAuthenticated)) return byHead

  const rows = gh.at(repo.root).prList({ state: 'all', limit: LIMIT, fields: FIELDS })
  if (rows === null) return byHead

  for (const row of rows) {
    const head = row.headRefName
    if (!head) continue
    const info: PRInfo = {
      number: row.number,
      state: row.state,
      mergedAt: row.mergedAt,
      headRef: head,
      title: row.title,
      url: row.url,
    }
    const existing = byHead.get(head)
    if (existing === undefined) {
      byHead.set(head, info)
      continue
    }
    const prio = priority(info.state)
    const existingPrio = priority(existing.state)
    if (prio > existingPrio || (prio === existingPrio && info.number > existing.number)) {
      byHead.set(head, info)
    }
  }
  return byHead
}
