/**
 * Local and remote branches: gather them, then decide what each one is.
 *
 * Two signals settle most branches. A pull request that merged says the work
 * landed. Ancestry says the same thing without GitHub's help — if the branch
 * tip is reachable from the default branch, every commit on it is already
 * there. Either one is enough to call a branch spent; neither leaves the
 * branch for a person to look at.
 */

import type { Git } from '@sksizer/easy-git'

import { makeItem, type PRInfo, type RepoInfo, type SweepItem } from './types.ts'

/** Five fields in one pass, so a repository costs one `for-each-ref`. */
const LOCAL_FORMAT =
  '%(refname:short)%09%(upstream:short)%09%(upstream:track)%09%(committerdate:iso8601-strict)%09%(objectname:short)'

function prFacts(pr: PRInfo): Record<string, unknown> {
  return {
    number: pr.number,
    state: pr.state,
    merged_at: pr.mergedAt,
    url: pr.url,
    title: pr.title,
  }
}

// ── local branches ─────────────────────────────────────────────────────────

export function gatherLocalBranches(
  repo: RepoInfo,
  prs: Map<string, PRInfo>,
  worktreeBranches: ReadonlySet<string>,
  git: Git,
): SweepItem[] {
  const rows = git.at(repo.root).forEachRef('refs/heads/', { format: LOCAL_FORMAT })
  const items: SweepItem[] = []
  for (const line of rows) {
    const parts = line.split('\t')
    if (parts.length !== 5) continue
    const [name, upstream, track, lastCommit, sha] = parts as [
      string,
      string,
      string,
      string,
      string,
    ]
    items.push(
      classifyLocalBranch({
        name,
        upstream,
        track,
        lastCommit,
        sha,
        repo,
        prs,
        worktreeBranches,
        git,
      }),
    )
  }
  return items
}

export function classifyLocalBranch(opts: {
  name: string
  upstream: string
  track: string
  lastCommit: string
  sha: string
  repo: RepoInfo
  prs: Map<string, PRInfo>
  worktreeBranches: ReadonlySet<string>
  git: Git
}): SweepItem {
  const { name, upstream, track, lastCommit, sha, repo, prs, worktreeBranches, git } = opts
  const facts: Record<string, unknown> = {
    branch: name,
    upstream: upstream || null,
    track: track || null,
    last_commit: lastCommit,
    sha,
  }
  const keep = (reason: string): SweepItem =>
    makeItem({
      category: 'local_branch',
      id: name,
      classification: 'safe-to-keep',
      action: 'keep',
      reason,
      facts,
    })

  if (name === repo.mainBranch) return keep('default branch')
  if (name === repo.currentBranch) return keep('current HEAD')
  if (worktreeBranches.has(name))
    return keep('checked out in a worktree (handle via that worktree)')

  // Both revs are local branches this pipeline just read out of
  // `for-each-ref`, so a 128 here is a real failure.
  const isAncestor = git.at(repo.root).isAncestor(name, repo.mainBranch)
  facts['ancestor_of_main'] = isAncestor

  const pr = prs.get(name)
  if (pr) facts['pr'] = prFacts(pr)

  const safeDelete = [`git branch -d ${name}`]
  const forceDelete = [`git branch -D ${name}`]

  if (pr && pr.state === 'MERGED') {
    return makeItem({
      category: 'local_branch',
      id: name,
      classification: 'safe-to-delete',
      action: 'delete',
      reason: `PR #${pr.number} merged`,
      facts,
      commands: isAncestor ? safeDelete : forceDelete,
    })
  }
  if (isAncestor) {
    return makeItem({
      category: 'local_branch',
      id: name,
      classification: 'safe-to-delete',
      action: 'delete',
      reason: `fully merged into ${repo.mainBranch}`,
      facts,
      commands: safeDelete,
    })
  }
  if (pr && pr.state === 'OPEN') return keep(`open PR #${pr.number}`)

  const parts = [`Branch \`${name}\` is not an ancestor of \`${repo.mainBranch}\`.`]
  parts.push(upstream ? `Tracks \`${upstream}\` (${track || 'in sync'}).` : 'Has no upstream.')
  parts.push(
    pr
      ? `Associated PR #${pr.number} is ${pr.state} (${pr.url}).`
      : 'No PR found via `gh pr list`.',
  )
  parts.push(`Last commit: ${lastCommit} (${sha}).`)
  return makeItem({
    category: 'local_branch',
    id: name,
    classification: 'needs-investigation',
    action: 'review',
    reason: 'mixed or absent signals',
    facts,
    investigationParts: parts,
  })
}

// ── remote branches ────────────────────────────────────────────────────────

export function gatherRemoteBranches(
  repo: RepoInfo,
  prs: Map<string, PRInfo>,
  localBranchNames: ReadonlySet<string>,
  git: Git,
): SweepItem[] {
  if (repo.remote === null) return []
  // Default door: an unreachable remote throws rather than rendering as "the
  // remote has no branches". `[]` here means the remote really has none.
  const rows = git.at(repo.root).lsRemote(repo.remote, undefined, { heads: true })
  const items: SweepItem[] = []
  for (const { sha, ref } of rows) {
    if (!ref.startsWith('refs/heads/')) continue
    const name = ref.slice('refs/heads/'.length)
    items.push(classifyRemoteBranch({ name, sha, repo, prs, localBranchNames, git }))
  }
  return items
}

export function classifyRemoteBranch(opts: {
  name: string
  sha: string
  repo: RepoInfo
  prs: Map<string, PRInfo>
  localBranchNames: ReadonlySet<string>
  git: Git
}): SweepItem {
  const { name, sha, repo, prs, localBranchNames, git } = opts
  const id = `${repo.remote}/${name}`
  const facts: Record<string, unknown> = {
    branch: name,
    remote: repo.remote,
    sha,
    has_local: localBranchNames.has(name),
  }
  const keep = (reason: string): SweepItem =>
    makeItem({
      category: 'remote_branch',
      id,
      classification: 'safe-to-keep',
      action: 'keep',
      reason,
      facts,
    })

  if (name === repo.mainBranch) return keep('default branch')

  const remoteMain = `${repo.remote}/${repo.mainBranch}`
  // `try`, unlike the local-branch site: `sha` comes from `ls-remote`, so it
  // names an object the local clone may never have fetched, and `remoteMain`
  // is a remote-tracking ref that may not exist either. Both exit 128; this
  // report renders "cannot tell" as false.
  const ancestry = git.at(repo.root).try.isAncestor(sha, remoteMain)
  const isAncestor = ancestry.ok && ancestry.value
  facts['ancestor_of_remote_main'] = isAncestor

  const pr = prs.get(name)
  if (pr) {
    facts['pr'] = { number: pr.number, state: pr.state, merged_at: pr.mergedAt, url: pr.url }
  }

  const deleteCmd = [`git push ${repo.remote} --delete ${name}`]

  if (pr && pr.state === 'MERGED') {
    return makeItem({
      category: 'remote_branch',
      id,
      classification: 'safe-to-delete',
      action: 'delete',
      reason: `PR #${pr.number} merged (auto-delete didn't fire)`,
      facts,
      commands: deleteCmd,
    })
  }
  if (isAncestor) {
    return makeItem({
      category: 'remote_branch',
      id,
      classification: 'safe-to-delete',
      action: 'delete',
      reason: `fully merged into ${remoteMain}`,
      facts,
      commands: deleteCmd,
    })
  }
  if (pr && pr.state === 'OPEN') return keep(`open PR #${pr.number}`)

  const parts = [`Remote branch \`${id}\` is not an ancestor of \`${remoteMain}\`.`]
  parts.push(pr ? `Associated PR #${pr.number} is ${pr.state}.` : 'No PR found.')
  parts.push('Decide whether to push more work, delete, or leave it as long-lived.')
  return makeItem({
    category: 'remote_branch',
    id,
    classification: 'needs-investigation',
    action: 'review',
    reason: 'mixed or absent signals',
    facts,
    investigationParts: parts,
  })
}
