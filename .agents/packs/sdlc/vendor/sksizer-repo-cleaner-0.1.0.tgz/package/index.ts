/**
 * `@sksizer/repo-cleaner` — what has been merged into the default branch, and
 * what can go away.
 *
 * Point it at a repository and it inventories the local branches, worktrees
 * and remote branches, classifying each as safe-to-delete, safe-to-keep or
 * needs-investigation, with the evidence behind the verdict and the literal
 * command that would act on it. Read-only: it never deletes anything.
 *
 * Two signals settle most items — a merged pull request, and ancestry of the
 * default branch — and either alone is enough. A host that knows more than
 * git does (an issue tracker, a task corpus) re-ranks the returned rows
 * rather than reaching into classification, which is why every row carries
 * its facts and why `investigationParts` is a list rather than a sentence.
 */

export {
  classifyLocalBranch,
  classifyRemoteBranch,
  gatherLocalBranches,
  gatherRemoteBranches,
} from './branches.ts'
export { classifyWorktree, gatherWorktrees } from './worktrees.ts'
export { DiscoveryFailed, discoverRepo } from './discover.ts'
export { fetchPrs } from './prs.ts'
export {
  expandTilde,
  isCheckoutRoot,
  resolveEntries,
  type Resolution,
  type ResolveOptions,
} from './resolve.ts'
export { sweepRepo, sweepRepos, type SweepOptions, type SweepReposOptions } from './sweep.ts'
export {
  proposedCommands,
  renderJson,
  renderRepo,
  renderScan,
  renderSummary,
  renderText,
} from './render.ts'
export {
  CONFIG_ENV,
  DEFAULT_CONFIG,
  RepoCleanerConfigSchema,
  TOOL,
  clearConfigCache,
  configPath,
  configuredRepos,
  loadConfig,
  type RepoCleanerConfig,
} from './config.ts'
export {
  ALL_SCOPES,
  emptyBucket,
  emptyScan,
  makeItem,
  summarize,
  type Category,
  type Classification,
  type PRInfo,
  type RepoInfo,
  type RepoSweep,
  type ScanStats,
  type Scope,
  type SummaryBucket,
  type SweepItem,
  type SweepResult,
  type UnresolvedEntry,
} from './types.ts'
