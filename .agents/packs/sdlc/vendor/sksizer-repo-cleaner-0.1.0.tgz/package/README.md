# @sksizer/repo-cleaner

What has been merged into the default branch, and what can go away.

Point it at a repository and it inventories the local branches, worktrees and
remote branches, classifying each as `safe-to-delete`, `safe-to-keep` or
`needs-investigation` — with the evidence behind the verdict and the literal
command that would act on it.

It never deletes anything. It emits commands; running them is yours.

```console
$ repo-cleaner
/Users/me/work/api  (acme/api, default main, origin)
  local_branch   fix/login-redirect   delete  PR #412 merged
                 git branch -d fix/login-redirect
  local_branch   spike/cache          review  mixed or absent signals
  worktree       wt/412               delete  clean; PR #412 merged
                 git -C /Users/me/work/api worktree remove wt/412
  remote_branch  origin/fix/login-…   delete  PR #412 merged (auto-delete didn't fire)
                 git push origin --delete fix/login-redirect

1 to delete, 1 to review, across 1 repository.
```

## How it decides

Two signals settle most items, and either alone is enough:

| Signal | Source |
| --- | --- |
| A pull request whose state is `MERGED` | `gh pr list`, one listing per repository |
| The branch tip is reachable from the default branch | `git merge-base --is-ancestor` |

Everything else is held back. A branch that is neither merged nor an ancestor
is `needs-investigation` with the reasons spelled out, not a guess. A worktree
holding uncommitted or unpushed work is never proposed for removal whatever
else is true of it — losing an hour of someone's work costs more than any
amount of clutter.

Without `gh`, or without authentication, classification proceeds on git
evidence alone and the report says so.

## Scope is opt-in

```bash
repo-cleaner                        # the repository you are standing in
repo-cleaner ~/work/api ~/work/web  # named repositories
repo-cleaner ~/Developer            # every checkout under it
repo-cleaner --all                  # every repository in the config file
```

A bare invocation never fans out. What an argument names is read off the disk
rather than from how it is written: a path that is itself a checkout names
that repository, and a path that is not is searched for the checkouts under
it, descending through directories that are not checkouts — an owner
directory, a folder per client — and stopping at the ones that are.

A linked worktree collapses into the repository it belongs to, so a directory
holding a checkout and three of its worktrees sweeps one repository, not four.
Those worktrees still appear — as worktree rows in that repository's own
inventory.

The report ends with what the search cost — `searched 1 entry: 214
directories read, 12 checkouts found.` — because those numbers are how an
entry pointing at the wrong directory gets caught. A search that passes
10,000 directories says so on stderr while it is still running, and the walk
stops descending three levels below the entry.

An entry that resolves to nothing is reported rather than dropped. A worklist
that silently sweeps four of the five repositories it was given is worse than
one that says which it could not find.

## Options

| Flag | Effect |
| --- | --- |
| `--all` | Sweep the repositories named in the config file |
| `--config <path>` | Config file to read |
| `--scope <list>` | `local-branches`, `worktrees`, `remote-branches` |
| `--remote <name>` | Remote to measure against (default `origin`) |
| `--no-gh` | Classify on git evidence alone |
| `--keep` | Include `safe-to-keep` rows in the report |
| `--commands` | Print the proposed commands and nothing else |
| `--output json` | The full inventory, facts included |

## Configuration

Only the CLI reads a config file. The library takes repositories as an
argument, so a host that already knows where its repositories are passes them
in.

```yaml
paths:
  dev: ~/Developer
repos:
  - '{dev}'
  - ~/work/api
```

`paths:` names a directory once; any `repos:` entry then refers to it as
`{name}`. A token nothing defines is an error, not an empty path.

The file is [`@sksizer/cli-tool/config`](../cli-tool/config)'s machine config —
`config.yaml` in the host OS's config home, resolved through
[`@sksizer/fleet`](../fleet)'s standalone tier:

| OS | Path |
| --- | --- |
| macOS | `~/Library/Application Support/repo-cleaner/config.yaml` |
| Linux and other | `$XDG_CONFIG_HOME/repo-cleaner/config.yaml`, else `~/.config/repo-cleaner/config.yaml` |
| Windows | `%APPDATA%\repo-cleaner\config.yaml` |

`REPO_CLEANER_MACHINE_CONFIG`, or `--config <path>`, relocates it. A missing,
unreadable or malformed file degrades to no repositories rather than failing
the run.

## As a library

```ts
import { sweepRepo, sweepRepos } from '@sksizer/repo-cleaner'

const sweep = sweepRepo('/Users/me/work/api', { noGh: true })
for (const item of sweep.items) {
  console.log(item.classification, item.id, item.reason)
}

const result = sweepRepos(['~/Developer'], { cwd: process.cwd() })
```

`sweepRepo` never throws for a repository it cannot read: the failure comes
back as `error`, because a fan-out must not end on its first bad entry.

### Adding knowledge the library does not have

Every row carries the facts behind its verdict, and `investigationParts` is a
list of sentences rather than a finished string. That is deliberate: a host
that knows something git does not — an issue tracker, a task corpus — re-ranks
the returned rows and appends its own sentence, instead of reaching into
classification through a hook.

This works because of how the ladder is ordered. Every verdict the sweep
reaches on its own evidence outranks anything a host could contribute, so a
host never has to veto one. It only sharpens the rows left at `safe-to-keep`
or `needs-investigation`.

SDLC's `sdlc project cleanup` is this sweep with its task corpus applied that
way.

## Runtime dependencies

`git` on `PATH`, and `gh` when PR state should count. Authentication is `gh`'s
own — this package reads no token.
