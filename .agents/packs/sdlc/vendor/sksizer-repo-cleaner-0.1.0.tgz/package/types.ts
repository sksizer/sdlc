/**
 * The inventory a sweep produces, and the vocabulary it is described in.
 *
 * One shape serves every category. A caller that wants only worktrees filters
 * by `category` rather than reading a different type, and a host that adds its
 * own knowledge (SDLC's task linkage, say) rewrites rows in place.
 */

/** What the sweep concluded about an item. */
export type Classification = 'safe-to-delete' | 'safe-to-keep' | 'needs-investigation'

/** The kinds of thing a sweep inventories. */
export type Category = 'local_branch' | 'worktree' | 'remote_branch'

/** Which categories to gather. */
export const ALL_SCOPES = ['local-branches', 'worktrees', 'remote-branches'] as const

export type Scope = (typeof ALL_SCOPES)[number]

/** What the sweep learned about a repository before inventorying it. */
export interface RepoInfo {
  /** The main checkout's root, even when the sweep was pointed at a worktree. */
  root: string
  /** `owner/name` when the remote is a recognisable host coordinate. */
  slug: string | null
  mainBranch: string
  remote: string | null
  currentBranch: string
  hasGh: boolean
  ghAuthenticated: boolean
}

/** A pull request, reduced to what classification consults. */
export interface PRInfo {
  number: number
  state: string
  mergedAt: string | null
  headRef: string
  title: string
  url: string
}

export interface SweepItem {
  category: Category
  id: string
  classification: Classification
  action: string
  /** One line, already phrased for a report. */
  reason: string
  /** The evidence behind the verdict. A host re-ranking a row reads these. */
  facts: Record<string, unknown>
  /** Literal commands that would carry out `action`. Never run by this library. */
  commands: string[]
  /**
   * Sentences explaining what is unclear, for a `needs-investigation` row.
   *
   * Parts rather than one string: a host with knowledge this library does not
   * have appends its own sentence before anything is rendered. Empty for a row
   * that needs no investigation.
   */
  investigationParts: string[]
}

/** One repository's inventory, or the reason there is none. */
export interface RepoSweep {
  /** Present when the repository could be read. */
  repo: RepoInfo | null
  /** The path the sweep was pointed at, whether or not it could be read. */
  path: string
  items: SweepItem[]
  /** Why this repository produced no inventory. Null on success. */
  error: string | null
}

/** An entry that named no repository. */
export interface UnresolvedEntry {
  entry: string
  reason: string
}

/**
 * What resolving the entries cost. An entry that is itself a checkout costs
 * nothing to find; a container is walked, and a person who points one at the
 * wrong directory deserves to be told how much was read.
 */
export interface ScanStats {
  /** Entries that had to be searched, rather than naming a checkout outright. */
  containers: number
  /** Directories read across those searches. */
  directoriesScanned: number
  /** Directories left unopened because the depth cap stopped the walk. */
  depthLimited: number
  /** Checkouts found by those searches, worktrees included, before de-duplication. */
  checkoutsFound: number
}

/** Every repository swept in one run, plus the entries that named none. */
export interface SweepResult {
  repos: RepoSweep[]
  unresolved: UnresolvedEntry[]
  scan: ScanStats
}

export function emptyScan(): ScanStats {
  return { containers: 0, directoriesScanned: 0, depthLimited: 0, checkoutsFound: 0 }
}

export interface SummaryBucket {
  total: number
  'safe-to-delete': number
  'safe-to-keep': number
  'needs-investigation': number
}

export function emptyBucket(): SummaryBucket {
  return { total: 0, 'safe-to-delete': 0, 'safe-to-keep': 0, 'needs-investigation': 0 }
}

/** Per-category counts over `items`. */
export function summarize(items: readonly SweepItem[]): Record<string, SummaryBucket> {
  const out: Record<string, SummaryBucket> = {}
  for (const item of items) {
    const bucket = (out[item.category] ??= emptyBucket())
    bucket.total += 1
    bucket[item.classification] += 1
  }
  return out
}

/** Build an item, defaulting the three collection fields. */
export function makeItem(
  partial: Omit<SweepItem, 'facts' | 'commands' | 'investigationParts'> &
    Partial<Pick<SweepItem, 'facts' | 'commands' | 'investigationParts'>>,
): SweepItem {
  return {
    category: partial.category,
    id: partial.id,
    classification: partial.classification,
    action: partial.action,
    reason: partial.reason,
    facts: partial.facts ?? {},
    commands: partial.commands ?? [],
    investigationParts: partial.investigationParts ?? [],
  }
}
