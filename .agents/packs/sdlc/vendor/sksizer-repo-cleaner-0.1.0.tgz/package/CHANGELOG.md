# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Version 0.1.0 has never been published.

The sweep was written inside SDLC (`sdlc project cleanup`) and promoted into a
standalone package on 2026-09-11, leaving SDLC's task corpus behind as an
annotation over the returned inventory.

### Added

- **`sweepRepo` / `sweepRepos`.** A repository's local branches, worktrees and
  remote branches, classified `safe-to-delete` / `safe-to-keep` /
  `needs-investigation`, each row carrying the evidence behind its verdict and
  the command that would act on it. Read-only.
- **Multi-repository resolution.** What an entry names is read off the disk:
  a checkout names that repository, anything else is searched for the
  checkouts under it. The report says what that search cost — entries
  searched, directories read, checkouts found — and an enormous tree says so
  on stderr mid-walk rather than after it.
  Candidates de-duplicate on the main checkout, so a linked worktree collapses
  into the repository it belongs to. An entry that resolves to nothing is
  reported, never dropped.
- **Per-repository error containment.** A repository that cannot be read
  becomes an `error` row and the sweep continues. Single-repository callers
  check the field.
- **The config file is `@sksizer/cli-tool/config`'s machine file** —
  `<config-home>/repo-cleaner/config.yaml`, Zod as the contract, never
  throws, relocated by `REPO_CLEANER_MACHINE_CONFIG` or `--config`. It
  carries `paths:` as well, so a `repos:` entry says `{dev}` instead of
  spelling a directory twice.
- **The `repo-cleaner` CLI.** Scope is opt-in: a bare invocation sweeps the
  repository you are standing in, `--all` reaches the config file, and
  positional paths name repositories directly. `--output json`, `--commands`,
  `--scope`, `--no-gh`, `--keep`.

### Changed from SDLC's original

- **`investigation_prompt` became `investigationParts`.** A list of sentences
  rather than one string, so a host can append its own before rendering. The
  sentence naming `docs/planning/tasks/` left with SDLC.
- **PR state reads through `@sksizer/easy-gh`** rather than a hand-rolled
  `gh pr list --json` and `JSON.parse`.
- **Task-derived verdicts are gone.** They live in SDLC, applied to the
  returned rows. Every git-derived verdict already outranked them, so nothing
  in the ladder moved.
