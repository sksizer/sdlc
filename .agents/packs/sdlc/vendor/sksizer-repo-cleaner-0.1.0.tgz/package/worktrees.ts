/**
 * Worktrees: gather them, then decide what each one is.
 *
 * A worktree is a directory with work in it, so it is judged more cautiously
 * than a branch. Anything uncommitted or unpushed stops the verdict cold —
 * losing an hour of someone's work costs more than any amount of clutter.
 */

import { statSync } from 'node:fs'
import { isAbsolute, relative, resolve } from 'node:path'

import type { Git } from '@sksizer/easy-git'

import { makeItem, type PRInfo, type RepoInfo, type SweepItem } from './types.ts'

function isParentOf(parent: string, child: string): boolean {
  const rel = relative(parent, child)
  return rel !== '' && !rel.startsWith('..') && !isAbsolute(rel)
}

function isDir(path: string): boolean {
  try {
    return statSync(path).isDirectory()
  } catch {
    return false
  }
}

/**
 * Every worktree of `repo`, and the set of branches they hold.
 *
 * The branch set is returned because a local branch checked out in a worktree
 * must not be judged on its own: the worktree is what a person would act on.
 */
export function gatherWorktrees(
  repo: RepoInfo,
  prs: Map<string, PRInfo>,
  cwd: string,
  git: Git,
): [SweepItem[], Set<string>] {
  const entries = git.at(repo.root).worktrees()
  const items: SweepItem[] = []
  const branchesInWorktrees = new Set<string>()

  for (const entry of entries) {
    const branch = entry.branch ?? ''
    if (branch) branchesInWorktrees.add(branch)
    items.push(
      classifyWorktree({
        path: entry.path,
        branch,
        isBare: entry.bare,
        isDetached: entry.detached,
        isPrimary: entry.path === repo.root,
        repo,
        prs,
        cwd,
        git,
      }),
    )
  }
  return [items, branchesInWorktrees]
}

export function classifyWorktree(opts: {
  path: string
  branch: string
  isBare: boolean
  isDetached: boolean
  isPrimary: boolean
  repo: RepoInfo
  prs: Map<string, PRInfo>
  cwd: string
  git: Git
}): SweepItem {
  const { path, branch, isBare, isDetached, isPrimary, repo, prs, cwd, git } = opts
  const facts: Record<string, unknown> = {
    path,
    branch: branch || null,
    bare: isBare,
    detached: isDetached,
    primary: isPrimary,
  }
  const keep = (reason: string): SweepItem =>
    makeItem({
      category: 'worktree',
      id: path,
      classification: 'safe-to-keep',
      action: 'keep',
      reason,
      facts,
    })

  if (isPrimary) return keep('primary worktree (repo root)')

  // The caller is standing in this worktree. Proposing its removal would
  // propose removing the ground the caller is on.
  const resolvedPath = resolve(path)
  const resolvedCwd = resolve(cwd)
  if (resolvedCwd === resolvedPath || isParentOf(resolvedPath, resolvedCwd)) {
    return keep("current session's worktree")
  }

  const onDisk = isDir(path)
  facts['on_disk'] = onDisk

  let dirtyFiles: string[] = []
  let unpushed: string[] = []
  if (onDisk) {
    dirtyFiles = git.at(path).statusPorcelain()

    let compareAgainst = ''
    if (branch) {
      // `try`: a branch with no upstream exits 128, which is an ordinary state
      // here, not a failure.
      const upstream = git.at(path).try.revParse('--abbrev-ref', `${branch}@{upstream}`)
      if (upstream.ok && upstream.value) compareAgainst = upstream.value
    }
    if (!compareAgainst) {
      compareAgainst = repo.remote ? `${repo.remote}/${repo.mainBranch}` : repo.mainBranch
    }
    // `try`: `compareAgainst` is a guess — the fallback `origin/main` need not
    // exist locally, and an unresolvable range renders as zero unpushed commits.
    const range = git.at(path).try.logLines({ range: `${compareAgainst}..HEAD`, format: '%h %s' })
    if (range.ok) unpushed = range.value
    facts['compare_against'] = compareAgainst
  }
  facts['dirty_files'] = dirtyFiles.length
  facts['unpushed_commits'] = unpushed.length

  const branchExists = !!branch && git.at(repo.root).resolveRef(branch) !== null
  facts['branch_exists'] = branchExists

  const pr = branch ? prs.get(branch) : undefined
  if (pr) {
    facts['pr'] = {
      number: pr.number,
      state: pr.state,
      merged_at: pr.mergedAt,
      url: pr.url,
      title: pr.title,
    }
  }

  const safeRemove = [`git -C ${repo.root} worktree remove ${path}`]
  const forceRemove = [`git -C ${repo.root} worktree remove --force ${path}`]
  const pruneOnly = [`git -C ${repo.root} worktree prune`]

  if (!onDisk) {
    return makeItem({
      category: 'worktree',
      id: path,
      classification: 'safe-to-delete',
      action: 'remove',
      reason: 'worktree directory no longer on disk; prune the stale link',
      facts,
      commands: pruneOnly,
    })
  }

  if (dirtyFiles.length > 0 || unpushed.length > 0) {
    return makeItem({
      category: 'worktree',
      id: path,
      classification: 'needs-investigation',
      action: 'review',
      reason: `${dirtyFiles.length} dirty file(s), ${unpushed.length} commit(s) ahead of ${facts['compare_against']}`,
      facts,
      investigationParts: [
        `Worktree ${path} has uncommitted work or unpushed commits.`,
        `Branch: ${branch || '(detached)'}.`,
        'Decide whether to preserve, push, or discard.',
      ],
    })
  }

  if (pr && pr.state === 'MERGED') {
    return makeItem({
      category: 'worktree',
      id: path,
      classification: 'safe-to-delete',
      action: 'remove',
      reason: `clean; PR #${pr.number} merged`,
      facts,
      commands: safeRemove,
    })
  }

  if (branch && !branchExists) {
    return makeItem({
      category: 'worktree',
      id: path,
      classification: 'safe-to-delete',
      action: 'remove',
      reason: `branch \`${branch}\` no longer exists`,
      facts,
      commands: forceRemove,
    })
  }

  if (pr && pr.state === 'OPEN') return keep(`open PR #${pr.number}`)

  const parts = [`Worktree \`${path}\` is clean.`]
  if (branch) parts.push(`Branch: \`${branch}\`.`)
  parts.push(pr ? `PR #${pr.number} is ${pr.state}.` : 'No associated PR.')
  return makeItem({
    category: 'worktree',
    id: path,
    classification: 'needs-investigation',
    action: 'review',
    reason: 'clean but no clear disposability signal',
    facts,
    investigationParts: parts,
  })
}
