/**
 * `repo-cleaner` — what has been merged, and what can go away.
 *
 * Scope is opt-in. A bare invocation sweeps the repository you are standing
 * in and nothing else; the configured list is reached with `--all`, and
 * individual repositories with positional paths. Nothing here fans out
 * because a config file happens to exist.
 *
 * Read-only. `--commands` prints what would be run; running it is yours.
 */

import { CONFIG_ENV, configPath, configuredRepos } from './config.ts'
import { proposedCommands, renderJson, renderText } from './render.ts'
import { sweepRepos, type SweepReposOptions } from './sweep.ts'
import { ALL_SCOPES, type SweepResult } from './types.ts'

/**
 * The config home differs per OS, so the help resolves it rather than naming
 * one platform's path — the question "where does it read that from?" should
 * not need the README.
 */
const usage = (): string => `usage: repo-cleaner [options] [path ...]

Inventory branches, worktrees and remote branches, and say which have been
merged into the default branch. Read-only.

  (no path)        the repository you are standing in
  path ...         a checkout, or a directory containing checkouts
  --all            every repository in the config file

options:
  --all                  sweep the configured repositories
  --config <path>        config file to read
                         (default: ${configPath()})
  --scope <list>         comma-separated: ${ALL_SCOPES.join(', ')}
  --remote <name>        remote to measure against (default: origin)
  --no-gh                classify on git evidence alone
  --keep                 include safe-to-keep rows in the report
  --commands             print the proposed commands only
  --output <text|json>   report format (default: text)
  -h, --help             this message
`

interface Args {
  paths: string[]
  all: boolean
  config: string | null
  scope: string[] | null
  remote: string | null
  noGh: boolean
  keep: boolean
  commands: boolean
  output: 'text' | 'json'
  help: boolean
}

export function parseArgs(argv: readonly string[]): Args | { error: string } {
  const args: Args = {
    paths: [],
    all: false,
    config: null,
    scope: null,
    remote: null,
    noGh: false,
    keep: false,
    commands: false,
    output: 'text',
    help: false,
  }
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i]!
    const value = (): string | null => argv[++i] ?? null
    switch (arg) {
      case '-h':
      case '--help':
        args.help = true
        break
      case '--all':
        args.all = true
        break
      case '--no-gh':
        args.noGh = true
        break
      case '--keep':
        args.keep = true
        break
      case '--commands':
        args.commands = true
        break
      case '--config': {
        const v = value()
        if (v === null) return { error: '--config needs a path' }
        args.config = v
        break
      }
      case '--remote': {
        const v = value()
        if (v === null) return { error: '--remote needs a name' }
        args.remote = v
        break
      }
      case '--scope': {
        const v = value()
        if (v === null) return { error: '--scope needs a list' }
        const scopes = v
          .split(',')
          .map((s) => s.trim())
          .filter((s) => s !== '')
        const unknown = scopes.filter((s) => !(ALL_SCOPES as readonly string[]).includes(s))
        if (unknown.length > 0) return { error: `unknown scope(s): ${unknown.join(', ')}` }
        args.scope = scopes
        break
      }
      case '--output': {
        const v = value()
        if (v !== 'text' && v !== 'json') return { error: '--output must be text or json' }
        args.output = v
        break
      }
      default:
        if (arg.startsWith('-')) return { error: `unknown option: ${arg}` }
        args.paths.push(arg)
    }
  }
  return args
}

export interface MainIo {
  stdout: (line: string) => void
  stderr: (line: string) => void
  cwd: string
}

const DEFAULT_IO: MainIo = {
  stdout: (line) => process.stdout.write(line),
  stderr: (line) => process.stderr.write(line),
  cwd: process.cwd(),
}

/**
 * Exit codes: 0 swept, 1 bad arguments, 2 nothing to sweep — an `--all` whose
 * config named nothing, or entries that all failed to resolve. Distinct from
 * 0 because "no repositories" is usually a configuration mistake, not a clean
 * sweep.
 */
export function main(argv: readonly string[], io: MainIo = DEFAULT_IO): number {
  const parsed = parseArgs(argv)
  if ('error' in parsed) {
    io.stderr(`repo-cleaner: ${parsed.error}\n\n${usage()}`)
    return 1
  }
  if (parsed.help) {
    io.stdout(usage())
    return 0
  }

  const entries: string[] = [...parsed.paths]
  if (parsed.all) {
    // The shared loader relocates through the env var, so `--config` is that
    // same override said on the command line.
    if (parsed.config !== null) process.env[CONFIG_ENV] = parsed.config
    try {
      entries.push(...configuredRepos(undefined, io.cwd))
    } catch (err) {
      io.stderr(`repo-cleaner: ${err instanceof Error ? err.message : String(err)}\n`)
      return 1
    }
  }
  if (entries.length === 0) entries.push(io.cwd)

  const options: SweepReposOptions = {
    baseDir: io.cwd,
    cwd: io.cwd,
    noGh: parsed.noGh,
    // Mid-walk, while the wait is happening — the summary comes too late to
    // explain why the tool appeared to hang.
    onWarn: (message) => io.stderr(`repo-cleaner: ${message}\n`),
    ...(parsed.scope === null ? {} : { scope: parsed.scope }),
    ...(parsed.remote === null ? {} : { remote: parsed.remote }),
  }
  const result: SweepResult = sweepRepos(entries, options)

  if (parsed.commands) {
    const commands = proposedCommands(result)
    if (commands.length > 0) io.stdout(commands.join('\n') + '\n')
  } else if (parsed.output === 'json') {
    io.stdout(renderJson(result))
  } else {
    io.stdout(renderText(result, { keep: parsed.keep }))
  }

  return result.repos.length === 0 ? 2 : 0
}
