# Intersect

[![npm](https://img.shields.io/npm/v/%40sksizer%2Fintersect)](https://www.npmjs.com/package/@sksizer/intersect)
[![release](https://github.com/sksizer/intersect/actions/workflows/release.yml/badge.svg)](https://github.com/sksizer/intersect/actions/workflows/release.yml)
[![license: MIT](https://img.shields.io/badge/license-MIT-blue.svg)](https://github.com/sksizer/intersect/blob/main/LICENSE)

A path-pattern overlap engine. It answers one question: do two globs share a
common matching path? Pure pattern algebra over patterns-as-languages — it never
touches the filesystem, except through the opt-in `@sksizer/intersect/fs` layer.

## Install

```sh
bun add @sksizer/intersect
# or
npm install @sksizer/intersect
```

Ships ES modules with TypeScript declarations. Under Bun the package resolves
straight to its TypeScript source (the `bun` export condition); everywhere else
it resolves to compiled ES2022 JavaScript in `dist/`.

## Entry points

Three subpaths, layered so dependencies point down.

| Import | Layer | What it is | Runtime deps |
|---|---|---|---|
| `@sksizer/intersect` | L1 path API | Friendly surface: parses glob strings, set-aware primitives, the registry. | none |
| `@sksizer/intersect/segments` | L0 core | Pure engine over pre-split segment arrays — no strings, no disk. | none |
| `@sksizer/intersect/fs` | L2 filesystem | Async resolution against a real on-disk tree. | `tinyglobby` |

The core, the segments engine, and the path API pull **zero** runtime
dependencies. Only `@sksizer/intersect/fs` pulls `tinyglobby`; the dependency boundary is
the entry-point split itself.

## The rule: exact match vs. subtree

A pattern with **no wildcards is an exact-path match**. There is no
directory/file inference and no ambiguity error: a bare path is exactly that
path, and you opt into a subtree with `/**`.

```ts
import { intersects } from "@sksizer/intersect";

// No wildcards → an EXACT-path match:
intersects("src/siteA/components", "src/siteA/components");            // true  (same path)
intersects("src/siteA/components", "src/siteA/components/Button.vue"); // false (a child, not the path)

// A subtree is opted into explicitly with `**`:
intersects("src/siteA/components/**", "src/siteA/components/Button.vue"); // true
```

## Examples

### The core question — does one pattern overlap another?

```ts
import { intersects } from "@sksizer/intersect";

intersects("src/**/*.ts", "src/api/handler.ts"); // true  — the file is inside the glob
intersects("src/api/**", "src/web/**");           // false — disjoint subtrees
intersects("src/api/**", "src/**/*.ts");          // true  — src/api/x.ts is common to both
```

### Registry — which guidelines/standards apply to a scope

Index labeled pattern-sets, then ask which apply to where you are about to work.
Pure overlap, so the target files need not exist yet.

```ts
import { index } from "@sksizer/intersect";

const guidelines = index([
  { id: "guidelines/UI",     patterns: ["**/*.{vue,html,jsx}"] },
  { id: "guidelines/UI/vue", patterns: ["**/*.vue"] },
  { id: "guidelines/api",    patterns: ["src/api/**"] },
]);

// About to work under a directory — write the subtree explicitly (no files need exist):
guidelines.applicableTo("src/siteA/components/**");
// → ["guidelines/UI", "guidelines/UI/vue"]   (the api guideline does not overlap)
```

### Filesystem — resolve against a real tree (`@sksizer/intersect/fs`)

The only entry that reads disk, and the only one that pulls a globber.

```ts
import { filesInScope } from "@sksizer/intersect/fs";

// Every existing file under the scope (DR-0011: build headless-script context):
const context = await filesInScope(["src/api/**", "src/db/**"], { cwd: repoRoot });
// → ["src/api/user.ts", "src/api/routes/list.ts", "src/db/pool.ts", ...]
```

## Building the API docs

The docs are a standalone Astro Starlight site defined entirely within
`docs-site/`. It nests an auto-generated TypeScript API reference —
`starlight-typedoc` drives TypeDoc over the three entry points (`index.ts`,
`segments/index.ts`, `fs.ts`), so the reference always matches the shipped
surface — beside a hand-written overview. The build is fully static: the sidebar
renders as real `<a>` links and every page is pre-rendered, so navigation and
content work with client-side JavaScript disabled. The output is gitignored —
rebuild it on demand.

| Form | Command | Output |
|---|---|---|
| Root default | `bun run docs:intersect` (repo root) | `sites/intersect-api/` |
| Root, targeted | `bun run docs:intersect -- --outDir <dir>` | `<dir>` |
| Site-local | `cd docs-site && bun install && bun run build` | `sites/intersect-api/` |

The root script delegates to the site-local build (`cd docs-site && bun install
&& bun run build`); the docs-site's Astro `outDir` points at the repo-root
`sites/intersect-api`. An outside caller retargets the output by forwarding
`--outDir`, which wins over the default. That path is resolved relative to
`docs-site/` (Astro's project root), so pass an absolute path to be unambiguous.
The site-local form is self-contained and works unchanged in the extracted repo,
where all docs tooling lives in `docs-site/package.json` (the package manifest
itself stays lean — no Astro/TypeDoc dependencies).

For Cloudflare Pages: build command `bun install && bun run docs:intersect`,
output directory `sites/intersect-api`. Bun installs devDependencies by default,
so the Astro/Starlight/TypeDoc toolchain is present at build time.

## Development

```sh
bun install
bun test        # data-driven corpus under fixtures/*.cases.json + guard tests
bun run build   # emit dist/ (compiled JS + .d.ts) via tsconfig.build.json
```

The test corpus is data-driven: each `fixtures/*.cases.json` file specifies one
area's intended behavior; the harness in `fixtures.ts` runs the whole corpus
live.

## Releases & contributing

Development happens in a private monorepo;
[github.com/sksizer/intersect](https://github.com/sksizer/intersect) is its
read-only release mirror. Each release lands there as a single snapshot commit
plus a `vX.Y.Z` tag, and the mirror's release workflow builds, tests, and
publishes that tag to npm with provenance.

Issues are welcome on the mirror. Pull requests can't merge there directly —
the next snapshot would overwrite them — but they're read, applied upstream,
and credited in the release that ships them.

## Status

`v0.1`. Pattern-level negation (`!pat`) and `intersection(a, b)` are deferred
past v1.

## License

[MIT](https://github.com/sksizer/intersect/blob/main/LICENSE)
