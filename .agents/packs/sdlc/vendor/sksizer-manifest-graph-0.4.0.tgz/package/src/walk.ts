/**
 * The filesystem half: find manifests, parse each into a `ManifestInfo`.
 *
 * The actual reading and parsing of `Cargo.toml`/`package.json` happens
 * exactly once, in `@sksizer/detect-runners/aspects`'s `collectAspects` — the
 * same module `detect-runners`'s own providers (and System Graph) read
 * manifests through. This file's own job is narrower: turn its `AspectFacts`
 * catalog into this package's `ManifestInfo` shape, which the Rust-parity
 * fixture suite (`test/mini-repo.test.ts`, `test/aspects.test.ts`) holds to
 * byte-for-byte agreement with `manifest-graph`'s own crate.
 */

import { join } from 'node:path'
import {
  collectAspects,
  type CargoFact,
  type DepFact,
  type MalformedPackageJson,
  type PackageJsonFact,
} from '@sksizer/detect-runners/aspects'
import { byteCompare, type DepDecl, type ManifestInfo } from './model.ts'

/** Directory names the walk always skips. */
export const DEFAULT_EXCLUDES = [
  'node_modules',
  '.git',
  'target',
  'dist',
  '.nuxt',
  '.output',
  '.sdlc',
  '.claude',
] as const

export interface WalkOptions {
  /** Additional directory names to skip, merged with `DEFAULT_EXCLUDES`. */
  exclude?: string[]
}

/**
 * Recursively find and parse every `package.json` and `Cargo.toml` under
 * `root`. Skips the default excluded directory names (plus any in
 * `options.exclude`) and symlinked entries. A malformed manifest becomes an
 * entry with its `error` field set — the walk never throws for one.
 *
 * Results are sorted by `dir` (then path) for deterministic output.
 */
export async function walkManifests(
  root: string,
  options: WalkOptions = {},
): Promise<ManifestInfo[]> {
  const catalog = await collectAspects(root, {
    // A raw directory walk, not git — this package has never been git-aware,
    // and a walk root is often not a repository at all (a fixture tree, an
    // arbitrary directory a caller points at).
    discovery: 'walk',
    allowExec: false,
    // `useBuiltinExcludes: false` — `@sksizer/detect-runners`'s own built-in
    // exclude list is broader than this one (it also skips `fixtures`,
    // `vendor`, `build`, `.venv`, …) and would otherwise be unioned in
    // regardless of what this package names here. This package's own
    // `DEFAULT_EXCLUDES` is the Rust-parity contract (`walk.rs`'s own list) —
    // it must be the WHOLE exclude list, not an addition to a bigger one.
    excludePaths: [...DEFAULT_EXCLUDES, ...(options.exclude ?? [])],
    useBuiltinExcludes: false,
  })

  const found: ManifestInfo[] = []
  for (const unit of catalog.units) {
    // `AspectFacts` uses `"."` for the walk root; `ManifestInfo.dir` uses `""`
    // — the convention `relative(root, root)` already gave this package.
    const dir = unit.dir === '.' ? '' : unit.dir
    if (unit.cargo !== undefined) found.push(cargoManifestInfo(catalog.root, dir, unit.cargo))
    if (unit.packageJson !== undefined) {
      found.push(nodeManifestInfo(catalog.root, dir, unit.packageJson))
    }
  }
  for (const bad of catalog.malformed) {
    found.push(malformedManifestInfo(catalog.root, bad))
  }

  found.sort((a, b) => byteCompare(a.dir, b.dir) || byteCompare(a.path, b.path))
  return found
}

/** Every field `ManifestInfo` has beyond `path`/`dir`/`ecosystem`, before a manifest-kind sets its own. */
function emptyManifest(
  path: string,
  dir: string,
  ecosystem: ManifestInfo['ecosystem'],
): ManifestInfo {
  return {
    path,
    dir,
    ecosystem,
    name: null,
    version: null,
    private: false,
    description: null,
    workspaces: [],
    entry: { main: null, types: null },
    isNuxtLayer: false,
    hasBin: false,
    deps: [],
    error: null,
  }
}

/** `DepFact[]` is field-for-field `DepDecl[]` (see `DepFact`'s own doc) — no mapping needed. */
function asDeps(deps: DepFact[] | undefined): DepDecl[] {
  return deps ?? []
}

function cargoManifestInfo(root: string, dir: string, fact: CargoFact): ManifestInfo {
  const base = emptyManifest(join(root, fact.manifestPath), dir, 'rust')
  if (fact.error !== undefined) return { ...base, error: fact.error }
  return {
    ...base,
    name: fact.name ?? null,
    version: fact.version ?? null,
    private: fact.private ?? false,
    description: fact.description ?? null,
    workspaces: fact.workspaceMembers ?? [],
    hasBin: fact.hasBin ?? false,
    deps: asDeps(fact.deps),
  }
}

function nodeManifestInfo(root: string, dir: string, fact: PackageJsonFact): ManifestInfo {
  const base = emptyManifest(join(root, fact.manifestPath), dir, 'node')
  const main = fact.main ?? null
  return {
    ...base,
    name: fact.name ?? null,
    version: fact.version ?? null,
    private: fact.private ?? false,
    description: fact.description ?? null,
    workspaces: fact.workspaces ?? [],
    entry: { main, types: fact.types ?? null },
    // The Nuxt-layer convention: `main` points at a nuxt.config.
    isNuxtLayer: main !== null && main.endsWith('nuxt.config.ts'),
    hasBin: fact.hasBin ?? false,
    deps: asDeps(fact.deps),
  }
}

/**
 * A `package.json` found on disk but too malformed for `collectAspects` to
 * build a fact for — the walk never throws for one, it reports it, same as
 * every other manifest.
 */
function malformedManifestInfo(root: string, bad: MalformedPackageJson): ManifestInfo {
  const at = bad.path.lastIndexOf('/')
  const dir = at === -1 ? '' : bad.path.slice(0, at)
  return { ...emptyManifest(join(root, bad.path), dir, 'node'), error: bad.error }
}
