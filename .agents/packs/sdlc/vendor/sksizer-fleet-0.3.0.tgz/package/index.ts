/**
 * `@sksizer/fleet` — this repo's wrapper over `@sksizer/tiered-dirs`, with the
 * vendor and the override variables fixed.
 *
 * `@sksizer/tiered-dirs` does the work: the tier and home axes, the per-OS
 * table, the override order and the test-root rules. This package pins the two
 * things that belong to this repo:
 *
 * - {@link VENDOR}, `com.sizerllc`: the vendor tier's segment and the prefix of
 *   every suite segment (`com.sizerllc.<suite>`).
 * - {@link ENV_VARS}, the `FLEET_*` variables: `FLEET_ROOT`, `FLEET_<KEY>_DIR`
 *   and `FLEET_REQUIRE_OVERRIDE`. The app harness sets `FLEET_ROOT`, and the
 *   moon Rust `test` task sets `FLEET_REQUIRE_OVERRIDE`.
 *
 * ```ts
 * Fleet.fromSystem().suite('determined').cache().scoped('vaults', id).app('vault-search')
 * ```
 *
 * The Rust `fleet` crate is the twin of this wrapper, over the `tiered-dirs`
 * crate.
 */

import {
  TieredDirs,
  envVars,
  overrideVars,
  systemBaseDirs as resolveBaseDirs,
} from '@sksizer/tiered-dirs'
import type { BaseDirs, EnvVars, SystemBaseDirsOptions } from '@sksizer/tiered-dirs'

export {
  TieredDirs,
  TieredDirsError as FleetError,
  Tier as FleetTier,
  isValidSegment,
  rootedBaseDirs,
} from '@sksizer/tiered-dirs'
export type { BaseDirs, EnvVars, Home, SystemBaseDirsOptions, TierKind } from '@sksizer/tiered-dirs'

/**
 * The vendor segment, and a real prefix of every conformant bundle identifier
 * (`com.sizerllc.family.*`, `com.sizerllc.agentpants.desktop`).
 *
 * The suite segment is composed from it, never derived from a bundle id:
 * derivation would yield `com.sizerllc.family`, the brand being retired.
 */
export const VENDOR = 'com.sizerllc'

/** The `FLEET_*` override variables. */
export const ENV_VARS: EnvVars = envVars('FLEET')

/** `FLEET_ROOT`: moves every root not moved by its own {@link OVERRIDE_VAR}. */
export const ROOT_VAR = ENV_VARS.root

/** The variable that moves one base directory: `FLEET_<KEY>_DIR`. */
export const OVERRIDE_VAR: Readonly<Record<keyof BaseDirs, string>> = ENV_VARS.dirs

/** Every variable that moves a base directory. */
export const OVERRIDE_VARS: readonly string[] = overrideVars(ENV_VARS)

/** The base directories, resolved with the `FLEET_*` variables. */
export function systemBaseDirs(opts: SystemBaseDirsOptions = {}): BaseDirs {
  return resolveBaseDirs(ENV_VARS, opts)
}

/** A {@link TieredDirs} for {@link VENDOR} that reads the `FLEET_*` variables. */
export class Fleet extends TieredDirs {
  /**
   * Build from injected roots — the seam a nitro server arm uses, handing in
   * roots from `useRuntimeConfig()` because it cannot read the environment.
   */
  constructor(bases: BaseDirs) {
    super(VENDOR, bases)
  }

  /**
   * Build from the environment, reading it exactly once.
   *
   * Throws `FleetError` when no home directory can be found.
   */
  static fromSystem(opts: SystemBaseDirsOptions = {}): Fleet {
    return new Fleet(systemBaseDirs(opts))
  }
}
