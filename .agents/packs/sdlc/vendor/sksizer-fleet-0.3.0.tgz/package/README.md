# @sksizer/fleet

This repo's wrapper over [`@sksizer/tiered-dirs`](../tiered-dirs). It fixes the
two things that belong to this repo and keeps the `Fleet` API every in-repo
caller uses:

- `VENDOR` is `com.sizerllc`. The vendor tier is `com.sizerllc`, and a suite is
  `com.sizerllc.<suiteKey>`.
- The override variables are `FLEET_ROOT`, `FLEET_<HOME>_DIR`,
  `FLEET_SCRATCH_DIR` and `FLEET_REQUIRE_OVERRIDE` (`ENV_VARS`, `ROOT_VAR`,
  `OVERRIDE_VAR`, `OVERRIDE_VARS`).

```ts
import { Fleet } from '@sksizer/fleet';

const fleet = Fleet.fromSystem();

fleet.suite('determined').cache().scoped('vaults', vaultId).app('vault-search').path;
// ~/Library/Caches/com.sizerllc.determined/vaults/<vaultId>/vault-search

fleet.standalone('sdlc').config().path; // ~/.config/sdlc
```

The suite segment is composed from `VENDOR`, never derived from a bundle
identifier: derivation from `com.sizerllc.family.*` would yield
`com.sizerllc.family`, the brand being retired.

## API

```ts
const VENDOR: 'com.sizerllc';
const ENV_VARS: EnvVars;               // envVars('FLEET')
const ROOT_VAR: string;                // 'FLEET_ROOT'
const OVERRIDE_VAR: Record<keyof BaseDirs, string>;
const OVERRIDE_VARS: readonly string[];

function systemBaseDirs(opts?: SystemBaseDirsOptions): BaseDirs;  // reads FLEET_*

class Fleet extends TieredDirs {
  constructor(bases: BaseDirs);
  static fromSystem(opts?: SystemBaseDirsOptions): Fleet;
}
```

`FleetTier` and `FleetError` are `Tier` and `TieredDirsError` from
`@sksizer/tiered-dirs` under their old names. `TieredDirs`, `rootedBaseDirs`,
`isValidSegment` and the types are re-exported unchanged. See the
[tiered-dirs README](../tiered-dirs/README.md) for the tier and home model, the
per-OS table, the override order and the test-root rules.

The Rust `fleet` crate is the twin of this package, over the `tiered-dirs`
crate.
