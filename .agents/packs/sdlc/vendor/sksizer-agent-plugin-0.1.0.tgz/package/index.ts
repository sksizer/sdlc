/**
 * `@sksizer/agent-plugin` — a canonical, host-neutral model of an agentic
 * harness (an "agent plugin"), lifted from a live Claude Code surface.
 *
 * One definition of the surface — capabilities, commands, hooks, MCP servers,
 * permissions, context documents — read once from `.claude-plugin/`,
 * `skills/`, and `conventions/`. The SDLC plugin consumes this package through
 * its `harness model` op ([[D-HRNS-harness-model-and-exporters]],
 * [[C-HRNS-multi-harness-control-plane]]). Its sibling exporters (Claude,
 * Codex, Cursor, Gemini, portable JSON) and `sdlc harness export` were retired
 * in [[T-1NWG]] once the agent-pants vault build became sdlc's sole build
 * path — this package now only derives the model, it does not project it back
 * onto a host.
 *
 * Public surface (all re-exported here):
 *   - model    — the Zod `HarnessModel` shape + helpers
 *   - contract — markdown-contract body validation (`validateModelBodies`)
 *   - import   — `deriveHarnessModel` / `importClaude`, `readClaudeControlPlane`
 */

export * from './model.ts'
export * from './contract.ts'
export * from './derive.ts'
export * from './import-settings.ts'
