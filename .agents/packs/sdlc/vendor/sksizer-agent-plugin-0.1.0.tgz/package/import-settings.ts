/**
 * Read the Claude control-plane (hooks, permissions, MCP servers) at a root into
 * the canonical model's host-neutral shapes ([[D-HRNS-harness-model-and-exporters]],
 * [[T-TL3I]]).
 *
 * This READS `.claude/settings.json` (+ `.claude/settings.local.json`, merged)
 * and a sibling `.mcp.json`, so the importer bootstraps the whole surface —
 * not just skills + conventions — from an existing Claude project. Every
 * source is optional; a root with none yields empty collections. (The
 * counterpart that used to WRITE these shapes, `exporters/_settings.ts`, was
 * retired in [[T-1NWG]] along with the rest of this package's exporters.)
 *
 * This is bootstrap, not the ongoing source of truth: once imported, the
 * canonical model is authoritative (see the decision's "importer" section).
 *
 * Runtime-agnostic ([[T-WGV4]]): `node:` APIs only.
 */

import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import type { HarnessHook, HarnessMcpServer, HarnessPermissions } from './model.ts'

/** Parsed control-plane fields ready to fold into the model. */
export interface ClaudeControlPlane {
  hooks: HarnessHook[]
  mcpServers: HarnessMcpServer[]
  permissions: HarnessPermissions
}

function loadJson(path: string): Record<string, unknown> | null {
  if (!existsSync(path)) return null
  try {
    const parsed = JSON.parse(readFileSync(path, 'utf-8')) as unknown
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
      return parsed as Record<string, unknown>
    }
  } catch {
    /* ignore malformed settings — treat as absent */
  }
  return null
}

function asObject(value: unknown): Record<string, unknown> | null {
  return value && typeof value === 'object' && !Array.isArray(value)
    ? (value as Record<string, unknown>)
    : null
}

function asStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((v): v is string => typeof v === 'string') : []
}

function asStringRecord(value: unknown): Record<string, string> {
  const obj = asObject(value)
  if (!obj) return {}
  const out: Record<string, string> = {}
  for (const [k, v] of Object.entries(obj)) if (typeof v === 'string') out[k] = v
  return out
}

/** Parse a Claude `hooks` block into flat {@link HarnessHook}s (one per command). */
function parseHooks(value: unknown): HarnessHook[] {
  const byEvent = asObject(value)
  if (!byEvent) return []
  const hooks: HarnessHook[] = []
  for (const [event, entriesRaw] of Object.entries(byEvent)) {
    if (!Array.isArray(entriesRaw)) continue
    for (const entry of entriesRaw) {
      const e = asObject(entry)
      if (!e) continue
      const matcher = typeof e['matcher'] === 'string' ? (e['matcher'] as string) : undefined
      const list = Array.isArray(e['hooks']) ? (e['hooks'] as unknown[]) : []
      for (const h of list) {
        const ho = asObject(h)
        const command = ho && typeof ho['command'] === 'string' ? (ho['command'] as string) : null
        if (!command) continue
        hooks.push({ event, ...(matcher ? { matcher } : {}), action: command })
      }
    }
  }
  return hooks
}

/** Parse a `{ name → serverObject }` MCP map into {@link HarnessMcpServer}s. */
function parseMcpServers(value: unknown): HarnessMcpServer[] {
  const map = asObject(value)
  if (!map) return []
  const servers: HarnessMcpServer[] = []
  for (const [name, defRaw] of Object.entries(map)) {
    const def = asObject(defRaw)
    if (!def) continue
    const type = def['type']
    const isRemote = type === 'http' || type === 'sse' || typeof def['url'] === 'string'
    if (isRemote) {
      servers.push({
        name,
        transport: type === 'sse' ? 'sse' : 'http',
        args: [],
        env: {},
        ...(typeof def['url'] === 'string' ? { url: def['url'] as string } : {}),
        headers: asStringRecord(def['headers']),
      })
    } else {
      servers.push({
        name,
        transport: 'stdio',
        ...(typeof def['command'] === 'string' ? { command: def['command'] as string } : {}),
        args: asStringArray(def['args']),
        env: asStringRecord(def['env']),
        headers: {},
      })
    }
  }
  return servers.sort((a, b) => a.name.localeCompare(b.name))
}

/** Shallow-merge two settings objects (later wins for scalars; `b`'s keys added). */
function mergeSettings(
  a: Record<string, unknown> | null,
  b: Record<string, unknown> | null,
): Record<string, unknown> {
  return { ...(a ?? {}), ...(b ?? {}) }
}

/**
 * Read the Claude control-plane at `root`: `.claude/settings.json` merged over
 * `.claude/settings.local.json`, plus a sibling `.mcp.json` whose `mcpServers`
 * merge in. Absent sources contribute nothing.
 */
export function readClaudeControlPlane(root: string): ClaudeControlPlane {
  const base = loadJson(join(root, '.claude', 'settings.json'))
  const local = loadJson(join(root, '.claude', 'settings.local.json'))
  const settings = mergeSettings(local, base)

  const permsObj = asObject(settings['permissions']) ?? {}
  const permissions: HarnessPermissions = {
    allow: asStringArray(permsObj['allow']),
    deny: asStringArray(permsObj['deny']),
    ask: asStringArray(permsObj['ask']),
  }

  // Sort hooks deterministically (event → matcher → action) so re-deriving
  // the model from the same surface always reproduces the same order.
  const hooks = parseHooks(settings['hooks']).sort(
    (a, b) =>
      a.event.localeCompare(b.event) ||
      (a.matcher ?? '').localeCompare(b.matcher ?? '') ||
      a.action.localeCompare(b.action),
  )

  const servers = parseMcpServers(settings['mcpServers'])
  const mcpJson = loadJson(join(root, '.mcp.json'))
  if (mcpJson) {
    const extra = parseMcpServers(mcpJson['mcpServers'])
    const seen = new Set(servers.map((s) => s.name))
    for (const s of extra) if (!seen.has(s.name)) servers.push(s)
    servers.sort((a, b) => a.name.localeCompare(b.name))
  }

  return { hooks, mcpServers: servers, permissions }
}
