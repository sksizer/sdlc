/**
 * `deriveHarnessModel` — lift the live Claude-Code harness surface at a plugin
 * root into the target-agnostic {@link HarnessModel}
 * ([[D-HRNS-harness-model-and-exporters]]).
 *
 * The Claude surface is the current source of truth (the plugin is authored in
 * that shape); this reader makes the model a faithful VIEW of it. When
 * authoring later moves to a native model manifest, only this module is
 * replaced — the model shape is unaffected. (This package's per-host
 * exporters, which used to draw from the same model to project it back onto a
 * host, were retired in [[T-1NWG]] — see `README.md`.)
 *
 * Sources under `<pluginRoot>/`:
 *   - `.claude-plugin/plugin.json` → `metadata`
 *   - `skills/<name>/SKILL.md`      → one `skill` each (frontmatter normalized,
 *     body preserved, co-located non-test files captured as `resources`)
 *   - `conventions/*.md`            → one `document` each
 *
 * Runtime-agnostic ([[T-WGV4]]): `node:` APIs only.
 */

import { existsSync, readFileSync, readdirSync, statSync, type Dirent } from 'node:fs'
import { join, relative } from 'node:path'

import { splitFrontmatter, parseFrontmatter } from './frontmatter.ts'

import {
  HarnessModelSchema,
  type HarnessCapability,
  type HarnessDocument,
  type HarnessModel,
  type HarnessResource,
} from './model.ts'
import { readClaudeControlPlane } from './import-settings.ts'

/** Frontmatter keys the model normalizes into first-class fields. */
const NORMALIZED_KEYS = new Set(['description', 'allowed-tools', 'argument-hint'])

/** Coerce a frontmatter value to a trimmed string (block scalars arrive parsed). */
function asString(value: unknown): string {
  if (typeof value === 'string') return value.trim()
  if (value === undefined || value === null) return ''
  return String(value).trim()
}

/** Coerce a frontmatter `allowed-tools` value to a string[]. */
function asStringArray(value: unknown): string[] {
  if (Array.isArray(value)) return value.map((v) => String(v))
  if (typeof value === 'string') {
    // Tolerate a comma/space-separated scalar form.
    return value
      .split(/[,\n]/)
      .map((s) => s.trim())
      .filter(Boolean)
  }
  return []
}

/** Every regular file under `dir` as `/`-joined paths relative to `dir`, sorted. */
function walkFiles(dir: string): string[] {
  const out: string[] = []
  const rec = (d: string): void => {
    let entries: Dirent[]
    try {
      entries = readdirSync(d, { withFileTypes: true })
    } catch {
      return
    }
    for (const e of [...entries].sort((a, b) => a.name.localeCompare(b.name))) {
      const abs = join(d, e.name)
      if (e.isDirectory()) rec(abs)
      else if (e.isFile()) out.push(relative(dir, abs).split('\\').join('/'))
    }
  }
  rec(dir)
  return out
}

/** True when a skill-relative path is a co-located resource (not SKILL.md / a test). */
function isResourcePath(rel: string): boolean {
  if (rel === 'SKILL.md') return false
  const segments = rel.split('/')
  if (segments.includes('tests')) return false
  if (segments.some((s) => s.endsWith('.test.ts') || s.endsWith('.test.js'))) return false
  return true
}

/** Read one `<kindDir>/<name>/` directory into a {@link HarnessCapability}. */
function deriveCapability(
  kindDir: string,
  name: string,
  kind: HarnessCapability['kind'],
): HarnessCapability | null {
  const skillDir = join(kindDir, name)
  const skillMd = join(skillDir, 'SKILL.md')
  if (!existsSync(skillMd)) return null

  const text = readFileSync(skillMd, 'utf-8')
  const [, body] = splitFrontmatter(text)
  const fm = parseFrontmatter(text) ?? {}

  const annotations: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(fm)) {
    if (!NORMALIZED_KEYS.has(k)) annotations[k] = v
  }

  const resources: HarnessResource[] = []
  for (const rel of walkFiles(skillDir)) {
    if (!isResourcePath(rel)) continue
    const abs = join(skillDir, rel)
    resources.push({
      path: rel,
      contents: readFileSync(abs, 'utf-8'),
      executable: (statSync(abs).mode & 0o100) !== 0,
    })
  }

  const argumentHint = asString(fm['argument-hint'])

  return {
    name,
    kind,
    description: asString(fm['description']),
    instructions: body.replace(/^\n+/, ''),
    allowedTools: asStringArray(fm['allowed-tools']),
    ...(argumentHint ? { argumentHint } : {}),
    resources,
    annotations,
  }
}

/** Read the `conventions/` tree into {@link HarnessDocument}s. */
function deriveDocuments(conventionsDir: string): HarnessDocument[] {
  if (!existsSync(conventionsDir)) return []
  const docs: HarnessDocument[] = []
  for (const rel of walkFiles(conventionsDir)) {
    if (!rel.endsWith('.md')) continue
    docs.push({
      name: rel.replace(/\.md$/, ''),
      body: readFileSync(join(conventionsDir, rel), 'utf-8'),
    })
  }
  return docs
}

/** Load `.claude-plugin/plugin.json` (or a bare `plugin.json`) as a plain object. */
function loadManifest(pluginRoot: string): Record<string, unknown> {
  const candidate =
    [join(pluginRoot, '.claude-plugin', 'plugin.json'), join(pluginRoot, 'plugin.json')].find(
      existsSync,
    ) ?? null
  if (!candidate) return {}
  try {
    return JSON.parse(readFileSync(candidate, 'utf-8')) as Record<string, unknown>
  } catch {
    return {}
  }
}

/**
 * Derive the portable {@link HarnessModel} from the Claude surface at
 * `pluginRoot`. Skills and documents are sorted by `name` for a deterministic,
 * diff-friendly emit. The result is parsed through {@link HarnessModelSchema}
 * so a malformed source surfaces as a schema error at the seam, not downstream.
 */
export function deriveHarnessModel(pluginRoot: string): HarnessModel {
  const manifest = loadManifest(pluginRoot)
  const author = manifest['author']
  const authorName =
    author && typeof author === 'object' && 'name' in author
      ? String((author as Record<string, unknown>)['name'])
      : typeof author === 'string'
        ? author
        : undefined

  // Skills (model-invoked) live under `skills/`, commands (user-invoked) under
  // `commands/`; a target that separates them (Claude) round-trips both.
  const capabilities: HarnessCapability[] = []
  for (const [dir, kind] of [
    ['skills', 'skill'],
    ['commands', 'command'],
  ] as const) {
    const kindDir = join(pluginRoot, dir)
    if (!existsSync(kindDir)) continue
    for (const entry of readdirSync(kindDir, { withFileTypes: true }).sort((a, b) =>
      a.name.localeCompare(b.name),
    )) {
      if (!entry.isDirectory()) continue
      const capability = deriveCapability(kindDir, entry.name, kind)
      if (capability) capabilities.push(capability)
    }
  }
  capabilities.sort((a, b) => a.name.localeCompare(b.name))

  const documents = deriveDocuments(join(pluginRoot, 'conventions'))

  // Bootstrap the control-plane (hooks / MCP / permissions) from the root's
  // Claude settings, if any ([[T-TL3I]]). A plugin root without `.claude/` or
  // `.mcp.json` contributes nothing, leaving these at their empty defaults.
  const controlPlane = readClaudeControlPlane(pluginRoot)

  return HarnessModelSchema.parse({
    modelVersion: '2',
    metadata: {
      name: String(manifest['name'] ?? 'harness'),
      version: String(manifest['version'] ?? 'unknown'),
      description: String(manifest['description'] ?? ''),
      ...(authorName ? { author: authorName } : {}),
      ...(typeof manifest['homepage'] === 'string'
        ? { homepage: manifest['homepage'] as string }
        : {}),
    },
    capabilities,
    hooks: controlPlane.hooks,
    mcpServers: controlPlane.mcpServers,
    permissions: controlPlane.permissions,
    documents,
  })
}

/**
 * Bootstrap the canonical model from an existing Claude surface — the named
 * "importer" of [[D-HRNS-harness-model-and-exporters]]. An alias for
 * {@link deriveHarnessModel}: reading the Claude surface into the model IS the
 * import. Prefer this name at call sites that mean "seed the model from Claude."
 */
export const importClaude = deriveHarnessModel
