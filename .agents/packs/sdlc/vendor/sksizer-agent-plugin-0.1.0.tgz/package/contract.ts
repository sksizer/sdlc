/**
 * Markdown-contract validation for harness capability / document bodies
 * ([[D-HRNS-harness-model-and-exporters]]).
 *
 * The canonical model normalizes the FRONTMATTER concerns (description, tools,
 * hooks, MCP, permissions) into typed Zod fields; this module covers the other
 * plane — the markdown BODY of each capability and document — with
 * markdown-contract, the project's validation substrate ([[LIBRARIES]]).
 *
 * The contract is deliberately host-neutral and light: it validates that a body
 * is well-formed under mc's dialect (a broken table / malformed structure
 * surfaces as an error finding) and enforces one real, corpus-wide convention —
 * every capability/document body opens with a level-1 title heading. That rule
 * is a `docRule`, so its findings project to the same `path:line` shape the
 * entity validators use.
 *
 * Runtime-agnostic ([[T-WGV4]]): pure — mc + a structural mdast read, no I/O.
 */

import { contract, docRule, formatFinding, hasErrors, lenientBody } from 'markdown-contract'

/** Minimal structural view of the mdast root a `docRule` receives. */
interface MdastNode {
  type: string
  depth?: number
}
interface MdastRoot {
  children?: MdastNode[]
}

/**
 * Every capability / document body must open with a level-1 title heading — the
 * convention the whole SKILL.md + conventions corpus already follows, and the
 * anchor a host's rendering (a prompt header, a rule title) keys off.
 */
const titleRule = docRule('harness/body/title', (_doc, ctx, tree) => {
  const root = tree.mdast as unknown as MdastRoot
  const hasTitle = (root.children ?? []).some((n) => n.type === 'heading' && n.depth === 1)
  if (hasTitle) return []
  return [
    ctx.finding({
      id: 'harness/body/title',
      message: 'body must open with a level-1 title heading (`# <name>`)',
      level: 'error',
      pos: { line: 1, col: 1 },
    }),
  ]
})

/** The body contract: mc structural validation + the title rule. */
const bodyContract = contract({ body: lenientBody([]), rules: [titleRule] })

/** One validation finding, as a `path:line message` string. */
export interface BodyFinding {
  path: string
  message: string
}

/**
 * Validate a markdown body through the contract. Returns the error-level
 * findings (empty ⇒ valid). `label` names the source in findings
 * (`capability:task-work`, `document:commit-messages`).
 */
export function validateBody(body: string, label: string): BodyFinding[] {
  const { findings } = bodyContract.validate(body, { path: label })
  if (!hasErrors(findings)) return []
  return findings
    .filter((f) => f.level === 'error')
    .map((f) => ({ path: label, message: formatFinding(f) }))
}

/**
 * Validate every capability + document body in a model. Returns all error-level
 * findings across the surface (empty ⇒ the whole model's bodies are valid).
 */
export function validateModelBodies(model: {
  capabilities: { name: string; instructions: string }[]
  documents: { name: string; body: string }[]
}): BodyFinding[] {
  const out: BodyFinding[] = []
  for (const c of model.capabilities) {
    if (c.instructions.trim() === '') continue
    out.push(...validateBody(c.instructions, `capability:${c.name}`))
  }
  for (const d of model.documents) {
    if (d.body.trim() === '') continue
    out.push(...validateBody(d.body, `document:${d.name}`))
  }
  return out
}
