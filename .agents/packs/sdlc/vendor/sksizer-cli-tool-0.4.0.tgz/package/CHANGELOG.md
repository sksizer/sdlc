# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

## [0.4.0] - 2026-10-06

### Added

- **A yes/no prompt.** `askYesNo`, `canPrompt`, `readLine` and `isYes`: a
  synchronous terminal question with a default answer.

### Changed

- **BREAKING: a tool names its own vendor directories.** `ToolSpec` (devlink)
  and `machineConfigFile` require `vendorDirs` — a `VendorDirs` (the vendor
  segment plus its override variables) — so state lives under the tool's own
  vendor-scoped config home (`<config>/<tool>/`) instead of a fixed fleet
  segment. `VendorDirs` and
  `systemDirs` are new; `TieredDirs` and `envVars` are re-exported from
  `@sksizer/tiered-dirs`, which replaces the fleet wrapper as a dependency.

- The devlink PATH shim and machine-config writes go through
  `@sksizer/etag-write` (renamed from `@sksizer/atomic-write`).

## [0.3.0] - 2026-10-04

### Added

- **Close-match suggestions.** `closestMatches(input, candidates, { max })`
  returns the nearest names (edit distance, or a 3-character prefix) so every
  CLI built on this package suggests the same "did you mean" for a mistyped
  noun, verb, config key or repo.
- **Safe machine-config writes and migrations.** `write(text)` replaces the
  machine file atomically after a schema check, keeping a `.bak`, and rejects
  only issues the write itself introduces. A `migrations` list upgrades an older
  file in memory on load, `migrate()` writes the upgrade to disk, and a newer
  file is read as-is with a `newer_version` issue. `currentMachineVersion` and
  `migrateMachineRaw` are exported.

### Changed

- An invalid machine config file keeps its valid sections and reports what it
  dropped (`MachineConfigIssue`), instead of degrading wholesale to defaults;
  an unreadable file is reported apart from a YAML error.

- **`devlink install` writes a shim, not a symlink.** Each PATH name is a
  small `sh` file that runs the launcher. When the launcher's checkout is
  deleted, the shim says so and exits 1 instead of failing with "No such
  file". `install` replaces an existing symlink or older shim and still
  refuses any other file. `renderShim` and `readShimTarget` are exported.

### Fixed

- The bash launcher's dependency check handles one-line `dependencies` blocks
  and a non-ancestor checkout path, names the checkout, and says
  `bun install` when a package is missing. A shim that lost its execute bits
  is rewritten.

## [0.2.1] - 2026-09-26

### Fixed

- **The bash launcher names a missing install.** Before running a checkout's
  source under bun, it exits 1 with "run 'bun install' there" when the
  checkout has a `package.json` but no `node_modules` — a fresh worktree —
  instead of letting the first import fail with "Cannot find package".
- A dev checkout never runs a stale committed built entry.
- The untrusted-repository hint takes `flag: null` for a surface with no
  per-run override, so it no longer advises a flag the command rejects.

## [0.2.0] - 2026-09-18

### Added

#### The trust entry — `@sksizer/cli-tool/trust`

- **The trust store.** A repository-keyed trust store (`trustStore`) with
  `resolveExecGate`, which combines a configured value, a per-run flag and the
  store into one allow/deny with a reason (`allowed`, `allowed-by-flag`,
  `untrusted`, `configured-off`). A `--flag` is consent for one run and is
  never recorded ([#2156](https://github.com/sksizer/dev/pull/2156)).

- **`resolveExecGate` takes an optional precomputed `trusted`.** Used instead
  of `store.isTrusted(root)` when present, so a caller that layers a broader
  policy over the marker store — `@sksizer/sdlc-tool`'s `trustDecision`/
  `policyExecGate` — hands its answer straight through rather than paying for
  a second, marker-only lookup that could disagree with it. `root` is still
  resolved through `store.resolveRoot`, so a marker key and a policy match
  always agree on one root's resolved spelling.

## [0.1.0] - 2026-09-14

First release: the substrate extracted from sdlc's `dev` noun (T-F9TG), with
`sdlc` and `waypost` as the first two tools on it.

### Added

- **The CLI substrate.** `CliIo` with `processIo` and `captureIo`, the
  `CliContext` a `main` is handed, the `EXIT` codes and the 10-63 band a tool
  numbers its own outcomes in, `defineCli` for declaring flags over
  commander, and `runMain` for the bin shim. The shape is
  S-0015-standalone-cli-shape.

- **`EXIT.usage`, which is `2`.** A malformed command — an unknown flag or
  subcommand, a wrong argument count, a value of the wrong type — exits `2`
  in every tool, and `EXIT.error` (`1`) is every other failure. A script can
  branch on the split without parsing stderr: `2` means fix the command line,
  `1` means look at the state. `2` is also what argparse and most GNU tools
  use. The 10-63 band stays for outcomes of the work and is never a second
  spelling of the three universal codes. S-0015-standalone-cli-shape carries
  the rule; the README carries the table.

- **The two help tiers are documented.** `hidden`, `shortEpilogue` and
  `autoHelp: false` are one contract, not three options, and the README now
  says so with waypost as the worked example.

- **`devlink` names its exit codes.** `<tool> dev <verb>` returned bare
  literals; every exit in it is now `EXIT.ok`, `EXIT.error` or `EXIT.usage`.

- **A certain flag types as certain.** `required: true` now narrows a string
  or enum flag's parsed type the way `default` already did — commander
  refuses the run when it is absent, so it can never reach a handler as
  `undefined`, and no caller should have to write `?? fallback` for a value
  the parser guarantees. `required` also works on an enum now; it was
  declared only on a string flag before. Conversely a `list` flag with no
  `default` types as `string[] | undefined`, which is what it has always
  parsed to: an unmentioned list is absent, not empty, and a config layer
  underneath needs to tell those apart.

- **Two help tiers and three-state flags.** A flag marked `hidden` is left
  out of `help()` but kept in `help({ all: true })` and always parsed, which
  is how a tool offers a short surface and a complete one from one
  declaration. A `tristate` flag declares both `--x` and `--no-x` with no
  default, so an unmentioned flag reads `undefined` and a configuration layer
  underneath it can still answer.

#### The config entry — `@sksizer/cli-tool/config`

- **Named directories and `{token}` expansion.** `pathsSchema`,
  `pathTokens`, `expandTokens`, `resolveConfigPath` and `PATH_NAME`: the
  `paths:` map both files carry, and the `{name}` every other path-valued
  setting refers to it by. A directory that means something on one machine is
  written once and named from anywhere — the same reason the machine file
  exists. `pathsSchema({ reserved })` refuses names a consuming setting
  defines itself (`{owner}`, `{repo}` in a checkout layout). An unknown token
  raises `TokenError` rather than expanding to an empty string, since a value
  that silently becomes `/repo` instead of `/Users/me/dev/repo` fails
  somewhere far from the typo; the message names the setting it appeared in
  and what is available, and `defineHint` is where a tool names its own
  files.
- **Needs.** `configNeeds({ tool, projectFile, projectSchema, machine })`
  answers, for a command that declares `{ config: 'dotted.key', unlessInput? }`,
  whether the setting is set in the project config, the machine file or the
  stand-in input, and renders one message when it is not: the command, the
  key, the key's own schema description, and where to set it, chosen from
  which schema carries the key and whether the cwd is inside a project.
- **Pieces.** `valueAt`, `valueIsSet`, `leafSchema`, `keyExists`,
  `keyDescription`, `unwrapSchema`, `shapeOf` and `envStem`, for a tool that
  needs one of them on its own.
- **The machine file.** `machineConfigFile({ tool, schema })` reads
  `<config>/<tool>/config.yaml` from the tool's standalone config home
  through a Zod schema: every key has a default, a missing,
  unreadable or invalid file degrades to the defaults, the value is memoised
  per path, and `<STEM>_MACHINE_CONFIG` relocates the file for a test or a
  one-off run.

#### The devlink entry — `@sksizer/cli-tool/devlink`

- **The spec.** `ToolSpec` — name, checkout marker, entry, launcher, aliases,
  suppressors — validated by `validateSpec`; `homeVar`, `cwdDevVar` and
  `quietVar` derive the tool's environment variables from its name.
- **Resolution.** `resolve(spec)` picks a checkout in four layers — the
  `<NAME>_HOME` env, a checkout above the cwd, the linked checkout, local —
  skipping a layer whose directory is no longer a checkout and treating a
  layer that names the launcher's own checkout as local.
- **State.** The active link in `<config>/<name>/home` (a bare path, so a
  bash launcher can `cat` it) and an append-only `history.jsonl` of every
  `link` / `use` / `off` event with the checkout's branch and HEAD at the
  time, read from `.git` without spawning git.
- **The verbs.** `install`, `link`, `use` (`#n`, a path, or `canonical`),
  `off`, `status`, `history` as functions with typed results, every one
  honouring `dryRun`; `runDevCli` mounts them as `<tool> dev <verb>` with
  `--json` and `--dry-run`.
- **Two launcher shapes.** `execSelection` for a JavaScript `bin` shim that
  hands off to a selected checkout under bun; `renderLauncher` for a bash
  launcher that must decide before a runtime exists, with `launcherDrift`
  to keep the committed file honest. The test suite drives the rendered
  script through every layer and asserts it agrees with `resolve()`.

Extracted from sdlc's `dev` noun (T-F9TG), which now mounts this package;
`sdlc` and `waypost` are the first two tools on it.
