/**
 * `@sksizer/command-seam` — one injectable contract for running external
 * binaries and capturing their result, in both a synchronous and an
 * asynchronous door.
 *
 * The seam exists so that "shell out to `git`" is a dependency a caller
 * supplies rather than an ambient capability: production wires
 * `spawnRunner(binary)` / `spawnRunnerAsync(binary)`, tests inject a fake,
 * and a host with its own process supervision injects that. Both doors share
 * one vocabulary — {@link CommandResult}, {@link CommandRunOptions},
 * {@link CommandFailed} — so a call site can move between them without
 * re-learning the contract, and one `instanceof CommandFailed` check matches
 * failures from either.
 */

export {
  CommandFailed,
  runChecked,
  spawnRunner,
  type CommandResult,
  type CommandRunner,
  type CommandRunOptions,
} from './sync.ts'

export {
  asAsync,
  runCheckedAsync,
  spawnRunnerAsync,
  type AsyncCommandRunner,
  type AsyncCommandRunOptions,
} from './async.ts'
