# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

### Fixed

A call with no `env` override lost any var a caller set on `process.env`
after the process started — under Bun (not Node), `env: undefined` and even
`env` omitted entirely fell back to a snapshot rather than live
`process.env`, so `PATH`/`HOME` (present at startup) survived while a test
pointing an env var at a fresh temp dir right before spawning silently saw
the real, unwritten default instead. Both doors now always build an explicit
env object from `process.env` at call time, merged with any override, never
relying on implicit inheritance.

`timeoutMs` was not a hard cap on the sync door. `spawnSync` signals the child
with the default `SIGTERM` on expiry and then goes on waiting for it to exit,
so a child that traps or ignores `TERM` ran to completion and the caller
blocked for its full runtime — measured at 3s against a 300ms cap. Both sync
paths now pass `killSignal: "SIGKILL"`, matching the async door and the
documented contract. A child that used `SIGTERM` to clean up no longer gets
that chance.

The async door never flushed its `StringDecoder`s, so output ending mid
multi-byte sequence — truncated capture, or bytes that were never UTF-8 — lost
its trailing bytes silently. They now surface as U+FFFD, matching the sync
door.

The `"."` export's `"types"` condition pointed at `./index.ts`. An external
TypeScript consumer resolving it failed to build with TS5097 on the package's
own `./sync.ts` imports. It now points at `./dist/index.d.ts`, as every
sibling package does. In-repo dependents resolve through `"bun"` and are
unaffected.

A result the seam fabricated — a spawn that failed, a child a timeout or an
abort killed, a child a signal took down — reported `exitCode: 1` and nothing
else, indistinguishable from a command that genuinely exited 1. Since 1 is the
"legitimate negative" code of plenty of binaries (`grep` with no matches,
`git config --get` on an unset key), a caller reading exit codes as answers
read a binary missing from PATH as a confident negative. Both doors now set
`neverExited: true` on any result where the child never reported a status.

Version 0.1.0 has never been published. Everything below is the record of how
the package reached its current shape, reconstructed from commit history and
dated by commit.

The seam was written in-place inside an application, where it began life as an
op-context DI parameter and outgrew it. The sync door was later carried into
`@sksizer/easy-git` while the async door stayed application-side; this package
reunites them.

### Added

- **The sync door.** `CommandRunner` is a run-and-capture contract:
  `run(argv, { cwd, timeoutMs?, input?, env? })` returns
  `{ exitCode, stdout, stderr }` and never throws on command failure.
  `spawnRunner(binary)` is the `spawnSync`-backed default. `runChecked` is
  the throwing twin, raising `CommandFailed` with the argv and full result
  attached (2026-07-19).
- **The async door.** `AsyncCommandRunner` and `spawnRunnerAsync(binary)`
  mirror the sync contract as promises, adding `AbortSignal` cancellation —
  the one capability sync cannot offer. `runCheckedAsync` mirrors
  `runChecked`, and `asAsync` views a sync runner through the async seam so
  one recording fake serves both suites (2026-07-19).
- **`CommandFailed.detail`** — a getter joining both streams, trimmed, with
  empty ones dropped. `message` interpolates stderr only, and several commands
  write the sentence that explains the failure to stdout instead (a rejecting
  git hook, `git commit` on a clean tree, `git apply --check`), so every caller
  reporting a failure to a human was hand-rolling this. Both streams are joined
  rather than one preferred: a rejecting hook puts git's "commit failed" on
  stderr and the hook's reason on stdout, and preferring either drops the half
  the reader needs.
- Extracted from `@sksizer/easy-git` and the application's
  `lib/util/command.ts` into this standalone package, so the seam is usable
  without pulling a git client along with it (2026-08-29).

### Fixed

- **`timeoutMs` silently did nothing on some runtimes.** The async door
  handed the value to `child_process.spawn`'s own `timeout` option, which is
  a no-op on some Bun versions — so the same code capped the child locally
  and let it run to completion on CI. The cap is now enforced in-process
  with an explicit timer and a `SIGKILL`, which behaves identically
  everywhere (2026-07-19).
- **The timeout timer was unref'd**, and an unref'd timer does not reliably
  fire on every Bun version — which restored the bug in new clothes. The
  unref bought nothing: `finish` clears the timer on both close and error,
  so it can never outlive the child (2026-07-19).
- **The async door settled on stdio EOF rather than on the deadline.** The
  timer fired and the `SIGKILL` landed, but `spawnRunnerAsync` resolved from
  the `close` event, and `close` waits for the stdio pipes to reach EOF —
  pipes a forked grandchild survives the kill still holding. Measured at a
  250ms cap: the child exits at 255ms, `close` at 5022ms. A hard cap must be
  enforced on the deadline, not on stdio a hung process controls, so the
  promise now settles from the timer with the output captured so far
  (2026-07-19).
- **Captured output came back empty under `bun test`.** Once a large module
  graph is loaded in the test process, Bun mis-wires the stdio it hands to
  child processes: the child runs and its filesystem effects land, but the
  parent reads nothing back. Confirmed for sync and async spawns, pipes and
  parent-opened fds, across Bun 1.2.x–1.3.x, and not reproducible under
  `bun run`. `spawnRunner` now captures via the one path Bun does not
  corrupt — the child performs its own `<in >out 2>err` redirects to temp
  files, which the seam reads back. Binary and argv ride as separate `sh`
  positional args, so they are never shell-parsed and metacharacters are
  inert, and `exec` replaces `sh` so exit status, cwd, env, and timeout all
  belong to the child (2026-07-22).
- **A failed spawn was indistinguishable from a silent exit 1.** Under the
  redirect capture path, the output files are created by the child's own
  `>` — so when `sh` never ran at all (an `EAGAIN` under a saturated process
  table), reading them threw `ENOENT` from the capture layer. Missing now
  reads as empty, and `proc.error`'s message is surfaced on stderr when the
  spawn itself failed, matching what the async door already reported
  (2026-08-22).
- **The production pipe path dropped `proc.error`.** The `spawnSync` branch
  `spawnRunner` takes outside `bun test` reported `{ exitCode: 1, stdout: "",
  stderr: "" }` for a spawn that never ran — a missing binary said nothing at
  all, so a host without `gh` installed failed with an empty message. It now
  surfaces `proc.error`'s message on stderr when the child produced none,
  matching the redirect path and the async door (2026-09-02).
- **The async door leaked the pipes of a killed child.** On the timeout path
  `finish` cleared the timer and resolved but left the `data` handlers
  installed and the pipes open, and the `SIGKILL` reaps only the direct
  child. A surviving grandchild went on writing, and the parent went on
  appending that output to a string nobody would ever read — measured at
  ~26MB of extra heap over two seconds of otherwise-idle time, unbounded in a
  long-lived host. `finish` now closes both read ends (2026-09-02).
- **The async door corrupted multi-byte UTF-8 at chunk boundaries.** Each
  pipe chunk was decoded independently with `Buffer.toString()`, so a
  character straddling a 64KB boundary became two U+FFFD replacements and the
  captured string differed from what the child wrote. Both streams now decode
  through a `StringDecoder`, which holds a partial sequence back until the
  rest arrives. Both sync paths were already immune — they decode the whole
  buffer, or the whole file, at once (2026-09-02).
- **A child that closed stdin early took the host process down.** `input` was
  written with `child.stdin.end(...)` and `child.stdin` is its own emitter, so
  the EPIPE raised when the child closed its read end mid-write never reached
  the `child.on("error")` handler — an unhandled `error` on an emitter, and so
  an uncaught exception, thrown after the promise had already resolved where no
  caller's `try`/`catch` could catch it. The error is now handled: the child's
  own exit code stays the result, and the write failure is reported on stderr
  when the child wrote none of its own, since it means the child read only part
  of `input` (2026-09-04).
