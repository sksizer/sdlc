/**
 * The managed-process subprocess seam — an injectable spawn-and-hand-back-a-
 * handle contract, for a long-lived child the caller supervises rather than
 * waits on: start it, watch it, kill it.
 *
 * Distinct from every other door in this package: the capture doors
 * (`sync.ts`/`async.ts`) and the streaming door (`stream.ts`) all BLOCK the
 * caller until the child exits (synchronously or via a promise) and hand
 * back how it went. This door returns as soon as the child exists — the
 * point of a supervised process (a detached server, a process-group leader
 * wrapping a wedged tool) is that the caller goes on to do other things
 * (watch a timeout, respond to signals, reap the process later) while it
 * runs.
 */

import { spawn } from 'node:child_process'

/** Per-call options for a {@link ManagedProcessRunner}. */
export interface ManagedProcessOptions {
  /** Defaults to the parent's own cwd when omitted (`node:child_process`'s own default). */
  cwd?: string | undefined
  env?: Record<string, string> | undefined
  /**
   * Make the child its own process-group leader. {@link
   * ManagedProcessHandle.kill} then signals the WHOLE group
   * (`process.kill(-pid, …)`) instead of just the direct child — the only
   * way to reap a grandchild the child itself forked and left behind
   * (`scripts/supervise.ts`'s reason for existing: a wedged `vue-tsc` fork
   * survives its own parent's death).
   */
  detached?: boolean | undefined
}

/** How a managed process ended. */
export interface ManagedProcessExit {
  exitCode: number
  signal: NodeJS.Signals | null
  /**
   * The process never reported a real exit — the spawn itself failed (e.g. a
   * missing binary). Mirrors `CommandResult.neverExited` from the capture
   * doors (`sync.ts`).
   */
  neverExited?: boolean | undefined
}

/** A running child: its pid, a way to kill it, and a promise settling once it's gone. */
export interface ManagedProcessHandle {
  /** `-1` when the child could not be spawned at all (see `child_process.ChildProcess.pid`'s own doc). */
  readonly pid: number
  kill(signal?: NodeJS.Signals | number): void
  readonly exited: Promise<ManagedProcessExit>
}

/** Seam for a long-lived process the caller supervises rather than waits on. */
export interface ManagedProcessRunner {
  run(argv: string[], opts?: ManagedProcessOptions): ManagedProcessHandle
}

/**
 * A spawn-backed {@link ManagedProcessRunner} for `binary`. stdio is always
 * inherited — every current caller supervises a process specifically because
 * its live output matters to the operator; a capturing variant can be added
 * if one ever needs it.
 */
export function managedProcessRunner(binary: string): ManagedProcessRunner {
  return {
    run(argv: string[], opts: ManagedProcessOptions = {}): ManagedProcessHandle {
      const detached = opts.detached ?? false
      const child = spawn(binary, argv, {
        cwd: opts.cwd,
        detached,
        stdio: 'inherit',
        // ALWAYS an explicit object built from the CURRENT `process.env`,
        // never `process.env` handed through verbatim — see `sync.ts`'s
        // `mergedEnv` doc for why Bun's spawn otherwise snapshots stale.
        env: { ...process.env, ...opts.env } as NodeJS.ProcessEnv,
      })
      const pid = child.pid ?? -1

      const exited = new Promise<ManagedProcessExit>((resolve) => {
        let settled = false
        const finish = (result: ManagedProcessExit): void => {
          if (settled) return
          settled = true
          resolve(result)
        }
        // A spawn failure (e.g. ENOENT): no exit was ever reported.
        child.on('error', () => finish({ exitCode: 1, signal: null, neverExited: true }))
        child.on('exit', (code, signal) => {
          finish({
            exitCode: code ?? 1,
            signal,
            ...(code === null ? { neverExited: true as const } : {}),
          })
        })
      })

      return {
        pid,
        kill(signal: NodeJS.Signals | number = 'SIGTERM'): void {
          if (pid === -1) return
          // Negative pid signals the whole process group — see `detached`'s
          // doc above.
          const target = detached ? -pid : pid
          try {
            process.kill(target, signal)
          } catch {
            // Already gone — nothing to reap.
          }
        },
        exited,
      }
    },
  }
}
