import { realpathSync, statSync } from 'node:fs'
import { dirname, isAbsolute, resolve } from 'node:path'

import { PathError, validateRelative } from './lexical.ts'

/** How the containment layer canonicalises a path. POSIX paths only. */
export interface Resolver {
  /**
   * `path` with every symlink resolved. Must throw when `path` does not exist.
   * When `path` resolves, so must each of its leading parts.
   */
  realpath(path: string): string
}

/**
 * The real filesystem. A `..` is resolved physically, as the OS `realpath`
 * does: `link/..` is the parent of the link's target. `realpathSync` alone
 * cannot be trusted with that: Node's JS version, and Bun's in both forms,
 * fold `..` textually first.
 */
export const nodeResolver: Resolver = {
  realpath(path) {
    if (path === '') throw fsError('ENOENT', path)
    const { absolute, segs } = components(path)
    let current = absolute ? '/' : '.'
    for (const seg of segs) {
      if (seg === '..') {
        const real = realpathSync(current)
        if (!statSync(real).isDirectory()) throw fsError('ENOTDIR', current)
        current = dirname(real)
      } else current = joinPath(current, seg)
    }
    return realpathSync(current)
  },
}

function fsError(code: string, path: string): Error {
  return Object.assign(new Error(`${code}: ${path}`), { code })
}

/**
 * Absolute `path` resolved by {@link nodeResolver}. When that fails, returns
 * the absolute path with `..` folded textually.
 */
export function realpathOrSelf(path: string): string {
  const abs = isAbsolute(path) ? path : `${process.cwd()}/${path}`
  try {
    return nodeResolver.realpath(abs)
  } catch {
    return resolve(abs)
  }
}

/**
 * Layers 1 + 2: validate `raw`, join it onto `root`, and prove the result stays
 * inside. Port of the Rust `resolve`.
 *
 * The path need not exist: containment is checked against the realpath of its
 * deepest existing ancestor, so a create-new-file call uses the same guard as a
 * read. Returns the joined path (not its realpath). Throws a {@link PathError}.
 */
export function resolveInside(
  root: string,
  raw: string,
  resolver: Resolver = nodeResolver,
): string {
  const rel = validateRelative(raw)
  const joined = joinPath(root, rel)
  const realRoot = tryRealpath(resolver, root) ?? root
  if (!startsWith(canonicalExistingPrefix(joined, resolver), realRoot)) {
    throw new PathError(
      'escapes',
      `path escapes the root: ${JSON.stringify(raw)} resolves outside ${JSON.stringify(realRoot)}`,
    )
  }
  return joined
}

/**
 * Is `inner` the same directory as `outer`, or beneath it, once both are
 * reduced by {@link canonicalExistingPrefix}? Compared by whole components, so
 * `/vault-bee` is not inside `/vault-b`. Port of the Rust `contains`.
 */
export function contains(outer: string, inner: string, resolver: Resolver = nodeResolver): boolean {
  return startsWith(
    canonicalExistingPrefix(inner, resolver),
    canonicalExistingPrefix(outer, resolver),
  )
}

/**
 * Canonicalise as much of `path` as exists and keep the rest lexically. Port of
 * the Rust `canonical_existing_prefix`, which documents the order: resolve each
 * `..` physically where the filesystem can, and fold it textually only where it
 * cannot.
 */
export function canonicalExistingPrefix(path: string, resolver: Resolver = nodeResolver): string {
  const physical = walkToExisting(resolver, path)
  if (components(physical).segs.includes('..')) {
    return walkToExisting(resolver, normalize(path))
  }
  return physical
}

/**
 * Realpath the deepest existing ancestor of `path` and re-attach the tail.
 * Returns `path` unchanged when nothing along it exists, or when the tail holds
 * a `.` or `..`.
 *
 * A leading part that resolves has every shorter one resolving too, so a binary
 * search finds the deepest in O(log n) resolver calls, however long the missing
 * tail.
 */
function walkToExisting(resolver: Resolver, path: string): string {
  const { absolute, segs } = components(path)
  const probe = (n: number) => tryRealpath(resolver, format(absolute, segs.slice(0, n)))
  const whole = probe(segs.length)
  if (whole !== null) return whole
  // Invariant: `segs[0, found)` resolves to `real` (null: none known); `segs[0, missing)` does not.
  // An absolute path starts at -1 so the search can probe `/`; a relative one never probes `''`.
  let found = absolute ? -1 : 0
  let real: string | null = null
  let missing = segs.length
  while (missing - found > 1) {
    const mid = (found + missing) >> 1
    const r = probe(mid)
    if (r === null) missing = mid
    else [found, real] = [mid, r]
  }
  if (real === null) return path
  const tail = segs.slice(found)
  if (tail.some((seg) => seg === '.' || seg === '..')) return path
  return tail.reduce(joinPath, real)
}

/** `.` dropped and `..` folded, touching no filesystem. */
function normalize(path: string): string {
  const { absolute, segs } = components(path)
  const out: string[] = []
  for (const seg of segs) {
    if (seg === '.') continue
    if (seg === '..') out.pop()
    else out.push(seg)
  }
  return format(absolute, out)
}

/** Whole-component prefix test, as Rust's `Path::starts_with`. */
function startsWith(path: string, base: string): boolean {
  const p = components(path)
  const b = components(base)
  return (
    p.absolute === b.absolute &&
    b.segs.length <= p.segs.length &&
    b.segs.every((seg, i) => p.segs[i] === seg)
  )
}

/**
 * Rust's `Path::components` for a POSIX path: empty segments and `.` are
 * dropped, except a `.` that starts a relative path.
 */
function components(path: string): { absolute: boolean; segs: string[] } {
  const absolute = path.startsWith('/')
  const segs = path
    .split('/')
    .filter((seg, i) => seg !== '' && (seg !== '.' || (i === 0 && !absolute)))
  return { absolute, segs }
}

function format(absolute: boolean, segs: string[]): string {
  return (absolute ? '/' : '') + segs.join('/')
}

/** Rust's `Path::join` for a relative `rel`. */
function joinPath(base: string, rel: string): string {
  if (base === '') return rel
  return base.endsWith('/') ? base + rel : `${base}/${rel}`
}

function tryRealpath(resolver: Resolver, path: string): string | null {
  if (path === '') return null
  try {
    return resolver.realpath(path)
  } catch {
    return null
  }
}
