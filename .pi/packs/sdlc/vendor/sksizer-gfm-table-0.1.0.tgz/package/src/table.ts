/** Whole tables: read row lines into cells, and render cells into row lines. */

import { cellTextFromSource, escapeCell } from './cell-text.ts'
import { padRow } from './grid.ts'
import { type ColumnAlign, isDelimiterRow, parseAlign, splitRow } from './row.ts'
import { rowLineText } from './splices.ts'

/** A cell as written (`raw`, trimmed source) and as text (pipe escapes read). */
export interface TableCell {
  raw: string
  text: string
}

/** A table read from its row lines. */
export interface TableData {
  header: TableCell[]
  align: ColumnAlign[]
  /** Body rows, each with the cells it has: rows are not padded or cut to the header. */
  rows: TableCell[][]
}

function rowCells(line: string): TableCell[] {
  return splitRow(line).cells.map((cell) => {
    const raw = line.slice(cell.content.from, cell.content.to).trim()
    return { raw, text: cellTextFromSource(raw).text }
  })
}

/** The text of each cell of one row line: trimmed, pipe escapes read. */
export function rowCellTexts(line: string): string[] {
  return rowCells(line).map((cell) => cell.text)
}

/**
 * Read a table from its lines: header, delimiter row, then body rows. Lines
 * carry no container prefix (`> `, list indent). Null when the second line
 * is not a delimiter row as wide as the header.
 */
export function readTable(lines: readonly string[]): TableData | null {
  const [head, delimiter, ...body] = lines
  if (head === undefined || delimiter === undefined || !isDelimiterRow(delimiter)) return null
  const header = rowCells(head)
  const align = rowCells(delimiter).map((cell) => parseAlign(cell.raw))
  if (align.length !== header.length) return null
  return { header, align, rows: body.map(rowCells) }
}

const ALIGN_SPEC: Record<ColumnAlign, string> = {
  none: '---',
  left: ':---',
  center: ':---:',
  right: '---:',
}

/** Cell texts for {@link renderTable}; `align` defaults to `none` per column. */
export interface TableInput {
  header: readonly string[]
  align?: readonly ColumnAlign[]
  rows: readonly (readonly string[])[]
}

/**
 * A table's markdown from cell texts, one space of padding per cell side.
 * Every cell goes through {@link escapeCell}. Short body rows are padded with
 * empty cells to the header's width; longer ones keep their extra cells. An
 * empty header gives `''`: no table has no columns.
 */
export function renderTable(table: TableInput, options: { lineBreak?: string } = {}): string {
  const width = table.header.length
  if (width === 0) return ''
  const line = (cells: readonly string[]) => rowLineText(cells.map(escapeCell)).text
  const delimiter = rowLineText(
    Array.from({ length: width }, (_, i) => ALIGN_SPEC[table.align?.[i] ?? 'none']),
  ).text
  return [line(table.header), delimiter, ...table.rows.map((row) => line(padRow(row, width)))].join(
    options.lineBreak ?? '\n',
  )
}
