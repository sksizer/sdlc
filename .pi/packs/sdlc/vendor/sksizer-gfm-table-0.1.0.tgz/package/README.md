# @sksizer/gfm-table

GFM pipe tables as strings and offsets, with no dependencies.

Scope: it works on row text and character offsets only. It has no parser, DOM
or editor dependency. Finding a table in a document, and stripping container
prefixes such as `> `, stay with the caller.

A backslash escapes the next character, as in the GFM spec. `\|` is a literal
pipe in a cell; every other escape is inline markdown and stays in the text.

## Main exports

- Rows: `splitRow`, `rowPipes`, `isDelimiterRow`, `parseAlign`. Offsets are
  absolute from the `base` you pass.
- Whole tables: `readTable`, `rowCellTexts`, `renderTable`.
- Cell text: `cellTextFromSource`, `escapeCell` (plain cells), `escapeCodeCell`
  (cells inside a backtick code span), `literalPipeFixes`, `endsWithEscape`.
- Edits: `rowLineText`, `insertCellSplice`, `deleteCellSplice`, `padRowSplice`.
- Grids and clipboard: `gridFromTsv`, `tsvFromGrid`, `gridFromCsv`, `toCsv`,
  `htmlFromGrid`, `pasteRect`.

```ts
import { renderTable, rowCellTexts } from '@sksizer/gfm-table'

rowCellTexts('| a \\| b | c |') // ['a | b', 'c']
renderTable({ header: ['Name'], rows: [['a|b']] }) // escapes cells itself
```
