/**
 * The **canonical harness model** — a host-neutral description of an agentic
 * harness ([[D-HRNS-harness-model-and-exporters]], [[C-HRNS-multi-harness-control-plane]]).
 *
 * A "harness" is the control-plane surface a coding agent runs inside: its
 * invocable capabilities, the context it carries, the tools it may use, the MCP
 * servers it can reach, the permissions that gate it, and the lifecycle hooks
 * that fire around it. This module holds the canonical model of the surface,
 * derived from a live Claude Code plugin tree ({@link deriveHarnessModel} in
 * `./derive.ts`). The model's per-host exporters (Claude, Codex, Cursor,
 * Gemini, portable JSON) were retired in [[T-1NWG]] once the agent-pants vault
 * build became sdlc's sole build path; this module now describes the shape a
 * Claude Code surface derives INTO, not a target every host projects onto.
 *
 * Every field is host-neutral — there is no Claude-specific escape hatch. The
 * model is a plain, JSON-serializable Zod shape, so it also serves as its own
 * portable interchange form.
 *
 * Capability and document markdown BODIES validate through `./contract.ts`
 * (markdown-contract), so a malformed body fails at the model seam.
 *
 * Runtime-agnostic ([[T-WGV4]]): pure schema, no `node:`/Bun coupling.
 */

import { z } from 'zod'

/** Schema version of the canonical model. Exporters key compatibility off it. */
export const HARNESS_MODEL_VERSION = '2' as const

/** Plugin identity — the fields every target manifest needs. */
export const HarnessMetadataSchema = z.object({
  /** Machine name / plugin id (kebab), e.g. `"sdlc"`. */
  name: z.string().min(1),
  /** Semver-ish version string, or `"unknown"`. */
  version: z.string().min(1),
  /** One-paragraph human description. */
  description: z.string().default(''),
  /** Author name, when the source manifest declares one. */
  author: z.string().optional(),
  /** Project homepage / repo URL, when declared. */
  homepage: z.string().optional(),
})
export type HarnessMetadata = z.infer<typeof HarnessMetadataSchema>

/**
 * A file co-located with a capability (a helper script, a fixture). Contents are
 * carried as text — the surface is markdown + source scripts, never binary —
 * with the executable bit preserved so a launcher stays runnable.
 */
export const HarnessResourceSchema = z.object({
  /** Path RELATIVE to the capability's own directory (e.g. `"start_task.ts"`). */
  path: z.string().min(1),
  /** File contents, verbatim. */
  contents: z.string(),
  /** True when the source file carried a user-executable bit. */
  executable: z.boolean().default(false),
})
export type HarnessResource = z.infer<typeof HarnessResourceSchema>

/**
 * A capability's kind. `skill` is a model-invoked capability (Claude skill,
 * Cursor rule); `command` is a user-invoked one (`/name` slash command, Codex
 * custom prompt). Most hosts collapse the two; the distinction lets a
 * host that separates them (Claude: skills vs commands) route each correctly.
 */
export const CapabilityKindSchema = z.enum(['skill', 'command'])
export type CapabilityKind = z.infer<typeof CapabilityKindSchema>

/**
 * An invocable capability. `name` is the kebab id (and the invocation leaf). The
 * fields are host-neutral: `instructions` is the markdown the agent runs against,
 * `allowedTools` the permitted tools, `argumentHint` the CLI-style hint hosts
 * that take command args surface. `annotations` is a host-neutral extension bag
 * for keys a future field will promote — NOT a per-host residue.
 */
export const HarnessCapabilitySchema = z.object({
  /** Kebab id, unique within the harness (`"task-work"`). */
  name: z.string().min(1),
  /** skill (model-invoked) or command (user-invoked). */
  kind: CapabilityKindSchema.default('skill'),
  /** Invocation summary — what it does, when to reach for it. */
  description: z.string().default(''),
  /** Markdown instruction body the agent runs against. */
  instructions: z.string().default(''),
  /** Tools the capability is permitted to use (host-neutral tool names). */
  allowedTools: z.array(z.string()).default([]),
  /** CLI-style argument hint, for hosts whose commands take arguments. */
  argumentHint: z.string().optional(),
  /** Co-located helper files, by capability-relative path. */
  resources: z.array(HarnessResourceSchema).default([]),
  /** Host-neutral extension bag (e.g. `need_human_review`); never per-host. */
  annotations: z.record(z.string(), z.unknown()).default({}),
})
export type HarnessCapability = z.infer<typeof HarnessCapabilitySchema>

/**
 * A lifecycle hook: a shell `action` fired on `event` (e.g. `PreToolUse`,
 * `Stop`, `SessionStart`), optionally gated by a `matcher` (a tool-name / event
 * pattern).
 */
export const HarnessHookSchema = z.object({
  /** Lifecycle event name, in Claude Code's own spelling. */
  event: z.string().min(1),
  /** Optional matcher (tool-name / pattern) scoping when the hook fires. */
  matcher: z.string().optional(),
  /** The shell command to run. */
  action: z.string().min(1),
})
export type HarnessHook = z.infer<typeof HarnessHookSchema>

/** MCP transport kind. */
export const McpTransportSchema = z.enum(['stdio', 'http', 'sse'])
export type McpTransport = z.infer<typeof McpTransportSchema>

/**
 * An MCP server the harness can reach. `stdio` servers carry `command`/`args`/
 * `env`; `http`/`sse` servers carry `url` (+ optional `headers`). Every host has
 * an MCP registry — they differ only in file (settings.json, config.toml,
 * .mcp.json, mcp.json) — so this maps cleanly everywhere.
 */
export const HarnessMcpServerSchema = z.object({
  /** Server id, unique within the harness. */
  name: z.string().min(1),
  transport: McpTransportSchema.default('stdio'),
  /** stdio: the binary to launch. */
  command: z.string().optional(),
  /** stdio: launch arguments. */
  args: z.array(z.string()).default([]),
  /** stdio: environment overrides. */
  env: z.record(z.string(), z.string()).default({}),
  /** http/sse: the endpoint URL. */
  url: z.string().optional(),
  /** http/sse: request headers. */
  headers: z.record(z.string(), z.string()).default({}),
})
export type HarnessMcpServer = z.infer<typeof HarnessMcpServerSchema>

/**
 * Tool permission rule sets — the host-neutral `allow`/`deny`/`ask` triad Claude
 * settings use directly and other hosts approximate (Codex `approval_policy`,
 * Cursor allow/deny). Rules are host-neutral tool patterns (`"Bash(git *)"`).
 */
export const HarnessPermissionsSchema = z.object({
  allow: z.array(z.string()).default([]),
  deny: z.array(z.string()).default([]),
  ask: z.array(z.string()).default([]),
})
export type HarnessPermissions = z.infer<typeof HarnessPermissionsSchema>

/**
 * A shared context document the capabilities draw on — the `conventions/` tree
 * today. Addressed by a stable `name` (basename without extension) so a body's
 * `${…}conventions/<name>.md` reference resolves under any target's layout.
 */
export const HarnessDocumentSchema = z.object({
  /** Stable basename id (`"commit-messages"`). */
  name: z.string().min(1),
  /** Full markdown document, verbatim. */
  body: z.string().default(''),
})
export type HarnessDocument = z.infer<typeof HarnessDocumentSchema>

/**
 * The whole canonical harness — the portable interchange format the importer
 * ({@link deriveHarnessModel}) produces from an existing Claude Code surface.
 */
export const HarnessModelSchema = z.object({
  /** Model schema version — see {@link HARNESS_MODEL_VERSION}. */
  modelVersion: z.literal(HARNESS_MODEL_VERSION).default(HARNESS_MODEL_VERSION),
  metadata: HarnessMetadataSchema,
  /** Capabilities, sorted by `name` for a deterministic emit. */
  capabilities: z.array(HarnessCapabilitySchema).default([]),
  /** Lifecycle hooks. */
  hooks: z.array(HarnessHookSchema).default([]),
  /** MCP servers, sorted by `name`. */
  mcpServers: z.array(HarnessMcpServerSchema).default([]),
  /** Tool permissions. */
  permissions: HarnessPermissionsSchema.default({ allow: [], deny: [], ask: [] }),
  /** Shared context documents, sorted by `name`. */
  documents: z.array(HarnessDocumentSchema).default([]),
})
export type HarnessModel = z.infer<typeof HarnessModelSchema>

/** Total resource-file count across every capability — a cheap summary stat. */
export function countResources(model: HarnessModel): number {
  return model.capabilities.reduce((n, c) => n + c.resources.length, 0)
}

/** Capabilities of a given kind, in model order. */
export function capabilitiesOfKind(model: HarnessModel, kind: CapabilityKind): HarnessCapability[] {
  return model.capabilities.filter((c) => c.kind === kind)
}
