# @sksizer/agent-plugin

A canonical, **host-neutral model** of an agentic harness (an "agent plugin"),
lifted from a live Claude Code surface: capabilities, commands, hooks, MCP
servers, permissions, and shared context documents.

See `D-HRNS-harness-model-and-exporters` and `C-HRNS-multi-harness-control-plane`.

This package's exporters (Claude, Codex, Cursor, Gemini, portable JSON) and
sdlc's `harness export` op were retired in `T-1NWG` once the agent-pants vault
build became sdlc's sole build path. This package now only derives the model
from a Claude Code surface — it does not project it back onto a host.

## Model

`model.ts` — a plain, JSON-serializable Zod shape.

| Field | Is |
|---|---|
| `metadata` | name, version, description, author, homepage |
| `capabilities[]` | `kind` (skill \| command), name, description, instructions, allowedTools, argumentHint, resources[], annotations |
| `hooks[]` | event, matcher, action (shell command) |
| `mcpServers[]` | name, transport (stdio \| http \| sse), command/args/env or url/headers |
| `permissions` | allow[], deny[], ask[] |
| `documents[]` | name, body (shared context / conventions) |

Capability and document markdown bodies validate through `contract.ts`
(markdown-contract): well-formedness plus a required level-1 title.

## Usage

```ts
import { deriveHarnessModel, importClaude, validateModelBodies } from "@sksizer/agent-plugin";

// Bootstrap the model from an existing Claude surface…
const model = importClaude("/path/to/plugin");        // alias of deriveHarnessModel

// Validate the markdown bodies.
const findings = validateModelBodies(model);          // [] when valid
```

## Dependencies

`zod`, `yaml`, `markdown-contract`, `@sksizer/frontmatter-lossless` — no framework, no
host SDK. The frontmatter reader (`frontmatter.ts`) is a thin
`{ fm, parseError }` wrapper over `@sksizer/frontmatter-lossless`'s shared splitter; a
shared markdown toolkit belongs there or in `markdown-contract`, not a sibling
micro-package.
