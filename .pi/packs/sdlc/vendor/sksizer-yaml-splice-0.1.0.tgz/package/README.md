# @sksizer/yaml-splice

Span-preserving YAML field editing over bytes — the `yaml-splice` Rust crate
projected to TypeScript over WebAssembly (`yaml-splice-wasm`). Set, remove,
or rename top-level fields of a YAML mapping without reserializing: comments,
key order, quoting, BOM, and line endings outside the edited span stay
byte-identical.
