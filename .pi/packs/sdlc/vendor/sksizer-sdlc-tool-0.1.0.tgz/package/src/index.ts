/**
 * `@sksizer/sdlc-tool` — the repo-aware substrate any sdlc-shaped tool
 * mounts, the sibling of `@sksizer/cli-tool` (the generic CLI substrate).
 *
 * It knows git and GitHub — it sits downstream of `@sksizer/cli-tool`,
 * `@sksizer/easy-git` and `@sksizer/easy-gh` — and it knows nothing about
 * `sdlc.yaml`, entities or ops. A tool of this shape (today, `sdlc`) mounts
 * this package and layers its own config format and vocabulary on top; see
 * `README.md` for the boundary rule in full.
 *
 * First resident: the trust policy — see the `./trust` subpath, or import
 * straight off the package entry as this module re-exports it.
 */

export {
  policyDecision,
  policyExecGate,
  trustDecision,
  type PolicyBy,
  type PolicyDecision,
  type PolicyDecisionOptions,
  type TrustBy,
  type TrustDecision,
  type TrustPolicy,
} from './trust.ts'
