/**
 * The git-aware trust POLICY: which repository roots a tool may treat as
 * consented-to run their own scripts, decided from a policy object the
 * caller supplies rather than any config file this package reads itself.
 *
 * Ported from sdlc's `lib/config/trust.ts`
 * ([[D-V2XJ-verb-cascade-and-repo-trust]]): the path glob matcher and its
 * dialect, the `origin` remote's owner lookup, and the marker → path → owner
 * precedence. Generalised so any tool of this package's shape can mount it —
 * see the package README for the full boundary rule and the threat model
 * behind `trustDecision`'s three layers.
 *
 * {@link trustDecision} is where consent is actually decided, in order:
 *
 *   1. A marker grant in the caller's {@link TrustStore} (`@sksizer/cli-tool/trust`).
 *   2. `policy.paths` — a glob over the resolved repo root.
 *   3. `policy.owners` — a case-insensitive match on the `origin` remote's
 *      owner.
 *
 * `policy` is caller-supplied data, never read from a file here: a tool's own
 * config format (sdlc's machine-file `trust:` block, or another tool's
 * equivalent) is exactly the kind of thing this package must not know about.
 * Path token expansion (`~`, `{name}` and whatever else a tool's own paths
 * vocabulary defines) is likewise the caller's — {@link policyDecision} and
 * {@link trustDecision} take it as an injected `expandPath` callback.
 *
 * {@link policyExecGate} is the one call a tool makes to turn a trust
 * decision into the boolean it actually acts on: it layers `trustDecision`
 * over `@sksizer/cli-tool/trust`'s `resolveExecGate`, so `configured` and a
 * per-run flag combine with the marker-or-policy decision the same way they
 * combine with a marker-only one, and `by`/`rule` ride along on the result.
 */

import { Git } from '@sksizer/easy-git'
import { parseOwnerRepo } from '@sksizer/easy-gh'
import {
  resolveExecGate,
  resolveTrustRoot,
  type ExecGate,
  type ResolveExecGateArgs,
  type TrustStore,
} from '@sksizer/cli-tool/trust'

/**
 * Pure string glob match — no filesystem access, unlike a globber (`tinyglobby`
 * and friends) that only reports entries that exist on disk right now. A
 * trust policy has to answer for a root that may have been deleted since (an
 * `untrust`-style query on a gone checkout is still a valid question), so
 * matching is a string comparison against the resolved pattern, never a
 * directory walk.
 *
 * `minimatch`/`micromatch`/`picomatch` are not a dependency of this package,
 * and this matcher supports exactly what a directory policy needs: `**` (any
 * number of path segments, `/` included) and `*`/`?` (within one segment) —
 * not a general-purpose glob engine.
 */
function pathGlobToRegExp(pattern: string): RegExp {
  let src = ''
  for (let i = 0; i < pattern.length; i += 1) {
    const c = pattern[i] as string
    if (c === '*' && pattern[i + 1] === '*') {
      src += '.*'
      i += 1
      // `a/**/b` should also match `a/b` — swallow one adjoining slash.
      if (pattern[i + 1] === '/') i += 1
    } else if (c === '*') {
      src += '[^/]*'
    } else if (c === '?') {
      src += '[^/]'
    } else {
      src += c.replace(/[.+^${}()|[\]\\]/g, '\\$&')
    }
  }
  return new RegExp(`^${src}$`)
}

/**
 * `root`'s `origin` remote owner, or null when there is none we can read.
 */
function originOwner(root: string): string | null {
  const res = new Git(root).try.remoteGetUrl('origin')
  if (!res.ok || res.value === null) return null
  return parseOwnerRepo(res.value)?.owner ?? null
}

/** The plain, caller-supplied policy `trustDecision`/`policyDecision` decide over. */
export interface TrustPolicy {
  /** Glob patterns (see `pathGlobToRegExp`'s dialect) over the resolved, symlink-free repo root. */
  paths: string[]
  /** Owners matched case-insensitively against the `origin` remote's owner. */
  owners: string[]
}

/** How, if at all, {@link trustDecision} resolved trust for a root. */
export type TrustBy = 'marker' | 'path' | 'owner'
/** How, if at all, {@link policyDecision} resolved trust — never `'marker'`. */
export type PolicyBy = Exclude<TrustBy, 'marker'>

export interface TrustDecision {
  trusted: boolean
  /** Which layer decided; null when untrusted by every layer. */
  by: TrustBy | null
  /** The matching `policy.paths`/`policy.owners` entry; only set when `by` is `'path'` or `'owner'`. */
  rule?: string
}

/** {@link TrustDecision}, narrowed to the layers {@link policyDecision} can return. */
export interface PolicyDecision {
  trusted: boolean
  by: PolicyBy | null
  rule?: string
}

export interface PolicyDecisionOptions {
  /**
   * Expand a `policy.paths` pattern's own vocabulary (a leading `~`, `{name}`
   * tokens, whatever else the caller's paths format defines) before matching
   * — this package has no such vocabulary of its own. Identity when omitted.
   */
  expandPath?: (raw: string) => Promise<string> | string
  /**
   * An existing {@link TrustStore} to resolve the root through, so a caller
   * that already has one (as {@link trustDecision}'s caller does) does not
   * pay for a second resolution. Defaults to {@link resolveTrustRoot} — the
   * same function a store's own `resolveRoot` is, so a marker key and a path
   * match always agree on one root's resolved spelling.
   */
  store?: TrustStore
}

/**
 * `policy.paths`/`policy.owners` only — never a marker store. Exposed
 * separately from {@link trustDecision} so a caller can ask "does policy
 * ALSO cover this root" independent of whether a marker exists (an
 * `untrust`-style "removing the marker changes nothing" notice).
 */
export async function policyDecision(
  root: string,
  policy: TrustPolicy,
  opts: PolicyDecisionOptions = {},
): Promise<PolicyDecision> {
  if (policy.paths.length > 0) {
    const resolvedRoot = opts.store
      ? await opts.store.resolveRoot(root)
      : await resolveTrustRoot(root)
    for (const pattern of policy.paths) {
      const expanded = opts.expandPath ? await opts.expandPath(pattern) : pattern
      if (pathGlobToRegExp(expanded).test(resolvedRoot)) {
        return { trusted: true, by: 'path', rule: pattern }
      }
    }
  }
  if (policy.owners.length > 0) {
    const owner = originOwner(root)
    if (owner !== null) {
      const hit = policy.owners.find((o) => o.toLowerCase() === owner.toLowerCase())
      if (hit !== undefined) return { trusted: true, by: 'owner', rule: hit }
    }
  }
  return { trusted: false, by: null }
}

/**
 * Whether `root` (any spelling — a symlink and its target are one decision)
 * is trusted, and by what: a marker grant in `store` first, then `policy`
 * ({@link policyDecision}).
 */
export async function trustDecision(
  store: TrustStore,
  root: string,
  policy: TrustPolicy,
  opts: PolicyDecisionOptions = {},
): Promise<TrustDecision> {
  if (await store.isTrusted(root)) return { trusted: true, by: 'marker' }
  return policyDecision(root, policy, { ...opts, store })
}

/**
 * {@link resolveExecGate} (`@sksizer/cli-tool/trust`), with {@link trustDecision}
 * — marker store, then `policy` — standing in for the store's own
 * marker-only `isTrusted` check. The one call a tool of this package's shape
 * makes to turn "is this root trusted, by marker or by policy" plus "is
 * execution configured on, and did a per-run flag say otherwise" into the
 * single boolean it acts on, with `by`/`rule` attached so a `--show`-style
 * surface can report which layer decided without a second lookup.
 *
 * `args.root` is resolved once, through `store` — the same resolution
 * `trustDecision`'s own marker check and `policy.paths` matching agree on,
 * per {@link PolicyDecisionOptions.store}.
 */
export async function policyExecGate(
  store: TrustStore,
  policy: TrustPolicy,
  args: { root: string; configured: boolean; flag?: boolean | undefined },
  opts: PolicyDecisionOptions = {},
): Promise<ExecGate & { by: TrustBy | null; rule?: string }> {
  const decision = await trustDecision(store, args.root, policy, opts)
  const gateArgs: ResolveExecGateArgs = { ...args, trusted: decision.trusted }
  const gate = await resolveExecGate(store, gateArgs)
  // `rule` omitted rather than set to `undefined` — under `exactOptionalPropertyTypes`
  // those are different things, and `JSON.stringify` treats them the same only
  // by accident of that flag being off wherever a caller serializes this.
  return {
    ...gate,
    by: decision.by,
    ...(decision.rule !== undefined ? { rule: decision.rule } : {}),
  }
}
