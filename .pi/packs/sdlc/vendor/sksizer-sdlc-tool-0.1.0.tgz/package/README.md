# `@sksizer/sdlc-tool`

The repo-aware substrate any sdlc-shaped tool mounts — the sibling of
[`@sksizer/cli-tool`](../cli-tool/README.md) (the generic CLI substrate).

## The boundary rule

This package knows git and GitHub. It sits downstream of `@sksizer/cli-tool`,
`@sksizer/easy-git` and `@sksizer/easy-gh`, and it knows **nothing** about
`sdlc.yaml`, entities or ops. A setting name, a file format, an op's exit
code — anything specific to one consuming tool belongs in that tool's own
adapter, never here. Where this package needs a piece of a tool's own
vocabulary — a path pattern's `~`/`{name}` tokens, say — it takes it as an
injected callback rather than growing an opinion about it.

`sdlc` is the first consumer, mounting the trust policy below behind a thin
adapter at `solutions/ontological/lib/config/trust.ts` that layers its own
machine-file `trust:` block and token expansion on top. `waypost` and
`detect-runners` (`packages/ts/detect-runners`) are the second: they mount
the same policy behind `trust.paths`/`trust.owners` in the USER layer of
their own shared config (`packages/ts/detect-runners/src/config.ts`), with
`~`-only path expansion in place of sdlc's `{name}` tokens.

## Trust policy

Some things a tool does to a repository it did not write are code execution
in disguise — running that repository's own scripts, evaluating its build
config, firing its hooks. A setting the repository itself can write cannot be
what authorizes that, because a setting a repository can write is a setting a
repository can grant itself. `@sksizer/cli-tool/trust`'s marker store answers
"has a person consented to this repository, once, by hand?"; this package
adds two more layers a tool's own configuration can pre-authorize a whole
class of repositories through, and the precedence between all three:

```ts
import { trustStore } from '@sksizer/cli-tool/trust'
import { policyDecision, trustDecision } from '@sksizer/sdlc-tool/trust'

const policy = { paths: ['/home/me/work/**'], owners: ['my-org'] }

// Policy only — no marker store consulted.
const p = await policyDecision(repoRoot, policy)

// Marker first, then policy.
const store = trustStore({ tool: 'my-tool' })
const t = await trustDecision(store, repoRoot, policy)
if (t.trusted) console.log(`trusted by ${t.by}`, t.rule ?? '')
```

### API

| Export | From | Does |
|---|---|---|
| `policyDecision(root, policy, opts?)` | `.`, `./trust` | `policy.paths`/`policy.owners` only, never a marker store |
| `trustDecision(store, root, policy, opts?)` | `.`, `./trust` | a marker grant in `store` first, then `policyDecision` |
| `policyExecGate(store, policy, args, opts?)` | `.`, `./trust` | `trustDecision` layered over `@sksizer/cli-tool/trust`'s `resolveExecGate`; `args` is `{ root, configured, flag? }`, the result is an `ExecGate` with `by`/`rule` attached |
| `TrustPolicy` | `.`, `./trust` | `{ paths: string[]; owners: string[] }` — plain caller-supplied data |
| `TrustBy` / `PolicyBy` | `.`, `./trust` | which layer decided: `'marker' \| 'path' \| 'owner'`, or the two `policyDecision` can return |
| `TrustDecision` / `PolicyDecision` | `.`, `./trust` | `{ trusted, by, rule? }` |
| `PolicyDecisionOptions` | `.`, `./trust` | `{ expandPath?, store? }` — see below |

`policyExecGate` is the one call a tool of this package's shape makes to turn
a trust decision into the boolean it actually acts on:

```ts
import { trustStore } from '@sksizer/cli-tool/trust'
import { policyExecGate } from '@sksizer/sdlc-tool/trust'

const store = trustStore({ tool: 'waypost' })
const gate = await policyExecGate(store, policy, { root: repoRoot, configured, flag })
if (gate.allowExec) { /* … */ }
// gate.by / gate.rule say which layer decided, for a `--show`-style report.
```

`opts.expandPath?: (raw: string) => Promise<string> | string` expands a
`policy.paths` pattern's own vocabulary — a leading `~`, `{name}` tokens,
whatever else the caller's own paths format defines — before matching. This
package has no such vocabulary of its own, so patterns are matched literally
when `expandPath` is omitted. `opts.store` lets a caller that already holds a
`TrustStore` (as `trustDecision`'s caller does) reuse its root resolution
instead of resolving twice; both ultimately call `@sksizer/cli-tool/trust`'s
`resolveTrustRoot`, so a marker key and a path match always agree on one
root's resolved spelling regardless of which one supplied it.

Owner comparison is case-insensitive and lives entirely inside this package —
a caller passes `policy.owners` exactly as configured.

### The glob dialect

`policy.paths` entries are matched against a small, deliberate glob dialect —
not a general-purpose glob engine, a directory policy matcher. Only `*`,
`?`, and `**` are special. `*` and `?` do not cross a `/` (`*` is "anything
within one path segment", `?` is "one character within one path segment");
`**` does cross `/` (any number of segments, including zero) and swallows one
adjoining slash, so `a/**/b` also matches `a/b`. `[...]` character classes
and `{a,b}` brace alternation are NOT part of the dialect, so each of those
characters matches only itself, literally, with no diagnostic when that is
not what was meant. A trailing `/**` matches descendants only, never the
named directory itself: `/home/me/work/**` does not match `/home/me/work`.
To trust a directory that IS itself a repo root, list it literally in
addition to (or instead of) the `/**` glob.

`policy.owners` only matches hosts `@sksizer/easy-gh`'s `parseOwnerRepo`
(built on `@sksizer/easy-git`'s `parseGitUrl`, in turn built on
`hosted-git-info`) knows — GitHub, GitLab, Bitbucket, and Sourcehut. A
self-hosted or enterprise origin (`https://ghe.example.com/owner/repo`) is
never recognized as belonging to any owner, however the entry is spelled;
use `policy.paths` for those repos instead.

### Threat model: the `origin` remote is a proxy, not proof — in both directions

`policy.owners` matches whoever a repository was cloned FROM, not who wrote
its code — a fork with `origin` renamed, or a mirror, answers to a different
owner than its authors. Prefer `policy.paths` when what is actually meant is
"repos I keep under this directory."

The reverse direction is the one worth reasoning about carefully: can a
stranger's repo grant ITSELF owner trust? No. The `origin` URL lives in
`.git/config`, which the operator writes at clone time (or by hand, via
`git remote add`/`set-url`) — nothing in a repository's tracked content (its
files, a hook committed into the tree, submodule config) can rewrite another
checkout's `.git/config`. Two real exposures follow from what `policy.owners`
is actually trusting, not from any way to spoof it:

1. An unpacked archive or a directory copied wholesale (not `git clone`d) can
   carry its own pre-written `.git/config`, with whatever `origin` its author
   chose. `policy.owners` is only sound for repositories the operator
   actually cloned themselves — never for a directory tree that arrived some
   other way.
2. Trust is repository-level, not branch-level. Every linked worktree off the
   same checkout shares one common `.git` directory, and so the same
   `origin` — a worktree checked out from a stranger's branch is still
   owner-trusted for as long as the target repository is. A caller that
   reviews untrusted content from a branch (a PR, say) needs its own per-ref
   guard on top of this policy; a collaborator with push access is trusted
   by definition regardless.

This is also why a policy grant is written config, not one-time consent: a
marker grant (`@sksizer/cli-tool/trust`) is a decision made by hand, once,
per repository, outside any file that travels between machines. A
`policy.paths`/`policy.owners` entry lives in whatever config a consuming
tool loads it from, which DOES travel — pushing it to a new machine re-grants
it there with no prompt. That is a fact about how a tool should present the
policy to a person, not something this package enforces; it just answers the
question honestly, both ways.

## Runtime

`@sksizer/cli-tool/trust`, `@sksizer/easy-git`, `@sksizer/easy-gh` only; no
`node:child_process` of its own. Runs under Bun and Node.
