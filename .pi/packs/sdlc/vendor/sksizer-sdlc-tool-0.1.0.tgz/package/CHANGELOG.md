# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Version 0.1.0 has never been published.

### Added

- **First resident: the trust policy, moved from `sdlc`'s
  `lib/config/trust.ts`.** `policyDecision`/`trustDecision`, the path glob
  matcher and its dialect (`*`, `?`, `**`, with a trailing `/**` never
  matching the directory itself), and the origin-owner lookup over
  `@sksizer/easy-git`/`@sksizer/easy-gh`. Path token expansion (`~`,
  `{name}`) is injected by the caller — this package has no vocabulary of
  its own for that — so `policyDecision`/`trustDecision` take an optional
  `expandPath` alongside the plain `{ paths, owners }` policy object. sdlc
  keeps a thin adapter over its machine-file `trust:` block; see
  `packages/ts/sdlc-tool/README.md` for the glob dialect and the
  origin-remote threat model this package now owns.
- **`policyExecGate(store, policy, args, opts?)`** — `trustDecision` layered
  over `@sksizer/cli-tool/trust`'s `resolveExecGate` (via its new `trusted`
  hook), so a tool combines its configured value, a per-run flag AND the
  marker-or-policy decision in one call and gets `by`/`rule` back alongside
  the `ExecGate`. `detect-runners` and `waypost`
  (`packages/ts/detect-runners`, `packages/ts/waypost`) are the second
  consumer, mounting this behind a user-layer `trust.paths`/`trust.owners`
  config block.
