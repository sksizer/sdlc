/**
 * `pr-update survey` — every open PR's drift from its base, the stack it sits
 * in, and how it would be brought up to date.
 *
 * Read-only: it fetches, then reads. No checkout, no worktree, no index, and
 * nothing is pushed. `pr-update update` is what acts on this.
 *
 * Three things it knows that a per-PR check cannot.
 *
 * **Drift is measured locally.** GitHub only reports
 * `mergeStateStatus: BEHIND` when branch protection requires an up-to-date
 * branch; without it the field stays silent however far a branch has drifted.
 * So behind-ness comes from `rev-list --left-right --count` over the
 * remote-tracking refs, and `mergeStateStatus` is a corroborating hint.
 *
 * **Staleness is transitive.** When PR A targets PR B's head branch, A is
 * stacked on B, and updating A before B is wasted work — A's base is about to
 * move. A PR can read zero-behind and still be blocked, so the survey builds
 * the stack graph, sorts it parent-first, and marks a child `blocked` on the
 * nearest ancestor that is itself behind.
 *
 * **A rebase is not always safe.** Each row carries the strategy it would be
 * updated with and the rule that chose it, so the plan is auditable before
 * anything runs. See `./strategy.ts` for why the unpushed-work guard outranks
 * everything else.
 *
 * Conflicts are predicted with `merge-tree`, which merges in the object
 * database and never touches a working tree. That is what makes surveying
 * every PR affordable: the alternative is a full checkout each, and most of
 * them turn out to merge cleanly. A conflict prediction also carries
 * `conflictBaseSha` — the base ref's resolved sha at the moment it was
 * measured — so a caller (a router keying a delivery signature on it, say)
 * can tell whether the prediction is still fresh.
 *
 * Scope defaults come from `PrUpdateConfig`, and every key there has a
 * default — so the verb works with no config at all. Flags override config;
 * config overrides the built-in defaults.
 */

import { z } from 'zod'

import { Git, parseGitUrl, type Worktree } from '@sksizer/easy-git'

import type { CodeHost, CodeHostPrDetail } from '@sksizer/code-host'
import type { CommandRunner } from '@sksizer/command-seam'
import { githubCodeHostFor } from './code-host.ts'
import { chooseStrategy, type Strategy } from './strategy.ts'
import type { PrUpdateConfig } from './config.ts'
import type { Ports } from './ports.ts'

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

/** Where a PR stands relative to its base, and to its stack. Declared once so
 *  the `status` zod enum below can't drift from this type — see its own
 *  `SurveyStatus` reference. */
const SURVEY_STATUSES = ['up-to-date', 'behind', 'blocked', 'unknown'] as const
export type SurveyStatus = (typeof SURVEY_STATUSES)[number]

/** What merging the base into the head would do. Declared once for the same
 *  reason as {@link SURVEY_STATUSES}. */
const MERGE_PREDICTIONS = ['clean', 'conflict', 'unknown'] as const
export type MergePrediction = (typeof MERGE_PREDICTIONS)[number]

/** A repository to survey, and the checkout its drift is measured in. */
export interface RepoTarget {
  /** `owner/name`, as GitHub knows it. */
  slug: string
  /**
   * Local checkout, or null when this machine has none. Drift and conflict
   * prediction read git objects, so a target with no path is listed and
   * reported unmeasurable rather than guessed at.
   */
  path: string | null
}

export interface SurveyRow {
  repo: string
  number: number
  title: string
  url: string
  base: string
  head: string
  isDraft: boolean
  /**
   * The head sha GitHub reports right now. A rebase force-push is pinned to
   * it, so a PR someone pushes to between the survey and the update is
   * refused rather than overwritten.
   */
  headOid: string | null
  /** The base's remote-tracking sha when measured. Null when unmeasurable. */
  baseOid: string | null
  /** Commits the head carries that the base does not. Null when unmeasurable. */
  ahead: number | null
  /** Commits the base carries that the head does not. Null when unmeasurable. */
  behind: number | null
  /** The open PR this one is stacked on, if any. */
  parent: number | null
  /** Nearest ancestor that is itself behind — the one to update first. */
  blockedBy: number | null
  status: SurveyStatus
  merge: MergePrediction
  conflicts: string[]
  /**
   * The base ref's resolved sha at the moment `merge-tree` predicted this
   * conflict. Null when `merge` is not `'conflict'`, or when the base ref
   * itself could not be resolved.
   */
  conflictBaseSha: string | null
  /** Submitted reviews; a rewrite would outdate the threads anchored to them. */
  reviews: number
  /** The head branch is checked out somewhere holding unpushed commits. */
  unpushedLocal: boolean
  strategy: Strategy
  strategyRule: string
  strategyReason: string
}

// ---------------------------------------------------------------------------
// The stack graph
// ---------------------------------------------------------------------------

/**
 * Order PRs parent-first, so a stack is updated from its root down.
 *
 * A Kahn walk over the "A's base is B's head" edges. PRs at the same depth
 * keep PR-number order so two runs over the same state print the same list.
 * Anything still unemitted at the end sits in a cycle — impossible through
 * the GitHub UI, but a survey that silently dropped those PRs would be
 * lying, so they are returned separately.
 */
export function topoOrder(prs: readonly CodeHostPrDetail[]): {
  order: CodeHostPrDetail[]
  cycles: number[]
} {
  const parentOf = parentEdges(prs)
  const pending = [...prs].sort((a, b) => a.number - b.number)
  const emitted = new Set<number>()
  const order: CodeHostPrDetail[] = []

  let progress = true
  while (progress) {
    progress = false
    for (const pr of pending) {
      if (emitted.has(pr.number)) continue
      const parent = parentOf.get(pr.number) ?? null
      if (parent !== null && !emitted.has(parent)) continue
      emitted.add(pr.number)
      order.push(pr)
      progress = true
    }
  }

  const cycles = pending.filter((pr) => !emitted.has(pr.number)).map((pr) => pr.number)
  return { order, cycles }
}

/** The `parent` edge for each PR, by number. */
export function parentEdges(prs: readonly CodeHostPrDetail[]): Map<number, number | null> {
  const byHead = new Map<string, number>()
  for (const pr of prs) byHead.set(pr.headRef, pr.number)
  const edges = new Map<number, number | null>()
  for (const pr of prs) {
    const parent = byHead.get(pr.baseRef) ?? null
    // A PR whose base is its own head is not a stack, it is a broken row.
    edges.set(pr.number, parent === pr.number ? null : parent)
  }
  return edges
}

/**
 * The nearest ancestor that is behind — the PR to update before this one.
 *
 * Walks up the stack rather than checking only the immediate parent: a
 * grandparent's drift reaches every descendant, and stopping at one level
 * would report a child as ready when its base is still about to move.
 */
export function nearestBehindAncestor(
  prNumber: number,
  edges: ReadonlyMap<number, number | null>,
  behindOf: ReadonlyMap<number, number | null>,
): number | null {
  const seen = new Set<number>([prNumber])
  let cursor = edges.get(prNumber) ?? null
  while (cursor !== null && !seen.has(cursor)) {
    seen.add(cursor)
    const behind = behindOf.get(cursor) ?? null
    if (behind !== null && behind > 0) return cursor
    cursor = edges.get(cursor) ?? null
  }
  return null
}

/** Classify one row, given its own drift and its ancestry. */
export function statusFor(behind: number | null, blockedBy: number | null): SurveyStatus {
  if (blockedBy !== null) return 'blocked'
  if (behind === null) return 'unknown'
  return behind > 0 ? 'behind' : 'up-to-date'
}

// ---------------------------------------------------------------------------
// Measurement
// ---------------------------------------------------------------------------

/**
 * Drift and predicted merge for one PR, read from the remote-tracking refs.
 *
 * Every git call goes through `try`: a ref this checkout has never fetched is
 * a legitimate "not known", and one unmeasurable PR must not sink the survey.
 * Null and zero are kept distinct — only zero means up to date.
 */
export function measure(
  git: Git,
  pr: CodeHostPrDetail,
): Pick<SurveyRow, 'baseOid' | 'ahead' | 'behind' | 'merge' | 'conflicts' | 'conflictBaseSha'> {
  const base = `origin/${pr.baseRef}`
  const head = `origin/${pr.headRef}`

  // `resolveRef` answers `null` for a ref that does not resolve; `soft` also
  // answers `null` for a broken object store.
  const baseOid = git.soft.resolveRef(base)

  const counts = git.try.aheadBehind(base, head)
  const ahead = counts.ok ? counts.value.ahead : null
  const behind = counts.ok ? counts.value.behind : null
  const quiet = { baseOid, ahead, behind, conflicts: [], conflictBaseSha: null }

  // Nothing to merge when the head already contains the base, and merge-tree
  // on an up-to-date pair is a wasted subprocess per PR.
  if (behind === 0) return { ...quiet, merge: 'clean' }

  const predicted = git.try.mergeTree(head, base)
  if (!predicted.ok) return { ...quiet, merge: 'unknown' }
  if (predicted.value.status === 'clean') return { ...quiet, merge: 'clean' }
  return {
    ...quiet,
    merge: 'conflict',
    conflicts: predicted.value.conflicts,
    conflictBaseSha: baseOid,
  }
}

/**
 * Does a checkout of `head` hold commits the remote has not seen?
 *
 * The one question a force-push cannot ask for itself. `--force-with-lease`
 * compares against the remote ref, which a local-only commit leaves
 * untouched, so it reports everything as safe right up until it discards
 * someone's afternoon.
 *
 * Unknown counts as unsafe. A safety interlock that cannot read the refs has
 * not established that rewriting is fine, and the cost of being wrong here is
 * asymmetric: a needless merge commit versus unrecoverable work.
 */
export function unpushedLocalWork(git: Git, worktrees: readonly Worktree[], head: string): boolean {
  const wt = worktrees.find((w) => w.branch === head)
  if (wt === undefined) return false
  if (wt.head === null) return true
  const counts = git.try.aheadBehind(`origin/${head}`, wt.head)
  if (!counts.ok) return true
  return counts.value.ahead > 0
}

/** Assemble one repository's rows. Pure given `git`. */
export function surveyRows(
  git: Git,
  prs: readonly CodeHostPrDetail[],
  opts: { repo: string; worktrees: readonly Worktree[]; cfg: PrUpdateConfig; measurable: boolean },
): { rows: SurveyRow[]; cycles: number[] } {
  const { order, cycles } = topoOrder(prs)
  const edges = parentEdges(prs)

  const unmeasured = {
    baseOid: null,
    ahead: null,
    behind: null,
    merge: 'unknown' as const,
    conflicts: [],
    conflictBaseSha: null,
  }
  const measured = new Map<number, ReturnType<typeof measure>>()
  for (const pr of order) {
    measured.set(pr.number, opts.measurable ? measure(git, pr) : unmeasured)
  }

  const behindOf = new Map<number, number | null>()
  for (const [num, m] of measured) behindOf.set(num, m.behind)

  return {
    cycles,
    rows: order.map((pr) => {
      const m = measured.get(pr.number)!
      const blockedBy = nearestBehindAncestor(pr.number, edges, behindOf)
      const unpushed = opts.measurable ? unpushedLocalWork(git, opts.worktrees, pr.headRef) : false
      const decision = chooseStrategy(
        {
          base: pr.baseRef,
          labels: pr.labels,
          ahead: m.ahead,
          reviews: pr.reviewCount,
          unpushedLocal: unpushed,
          crossRepo: pr.isCrossRepository,
        },
        opts.cfg,
      )
      return {
        repo: opts.repo,
        number: pr.number,
        title: pr.title,
        url: pr.url,
        base: pr.baseRef,
        head: pr.headRef,
        isDraft: pr.isDraft,
        headOid: pr.headSha,
        ...m,
        parent: edges.get(pr.number) ?? null,
        blockedBy,
        status: statusFor(m.behind, blockedBy),
        reviews: pr.reviewCount,
        unpushedLocal: unpushed,
        strategy: decision.strategy,
        strategyRule: decision.rule,
        strategyReason: decision.reason,
      }
    }),
  }
}

// ---------------------------------------------------------------------------
// Repository targets
// ---------------------------------------------------------------------------

/**
 * Which repositories to survey, and where each is checked out.
 *
 * The repository at `--project-root` is always the default target and needs
 * no config at all. `--repo owner/name` names others, and `ports.locate`
 * finds each one's checkout (the host's own `repos:`-container scan, or
 * whatever a standalone run wires up — see `defaults.ts`).
 *
 * `--repo` is what puts a repository in this verb's scope; nothing about a
 * host's own repo registry does, so a bare invocation stays local and never
 * fans out across the machine.
 *
 * A named slug with no checkout on this machine is kept and reported
 * unmeasurable rather than dropped: silently surveying fewer repositories
 * than were asked for is the worse failure.
 */
export function resolveTargets(
  localSlug: string | null,
  localPath: string,
  selected: readonly string[],
  locate: (slug: string) => string | null,
): RepoTarget[] {
  if (selected.length === 0) {
    return localSlug === null ? [] : [{ slug: localSlug, path: localPath }]
  }
  const seen = new Set<string>()
  const out: RepoTarget[] = []
  for (const slug of selected) {
    if (seen.has(slug)) continue
    seen.add(slug)
    out.push({ slug, path: slug === localSlug ? localPath : locate(slug) })
  }
  return out
}

// ---------------------------------------------------------------------------
// Op I/O schemas
// ---------------------------------------------------------------------------

/**
 * The scope flags. Exported as a shape rather than a schema because `update`
 * takes all of them plus its own, and a shape composes where a built schema
 * does not.
 */
export const SCOPE_SHAPE = {
  author: z
    .string()
    .optional()
    .describe(
      'Only survey PRs by this author; `@me` is the authenticated user. Defaults to `pr_update.author`, which itself defaults to every author.',
    ),
  repo: z
    .array(z.string())
    .default([])
    .describe(
      'Repository to survey as `owner/name`, repeatable. Defaults to the repository at --project-root alone. Others are located via the host `locate` port; one with no checkout on this machine is listed as unmeasurable.',
    ),
  noFetch: z
    .boolean()
    .default(false)
    .describe(
      'Skip the fetch and measure against the remote-tracking refs as they stand. Drift is only as fresh as the last fetch.',
    ),
  noDrafts: z
    .boolean()
    .default(false)
    .describe('Exclude draft PRs. Defaults to `pr_update.include_drafts`.'),
  limit: z.coerce
    .number()
    .int()
    .default(100)
    .describe('Maximum number of open PRs to list per repository.'),
  remote: z.string().default('origin').describe('Remote to fetch from and measure against.'),
} as const

export const input = z.object(SCOPE_SHAPE)

export const row = z.object({
  repo: z.string(),
  number: z.number(),
  title: z.string(),
  url: z.string(),
  base: z.string(),
  head: z.string(),
  isDraft: z.boolean(),
  headOid: z.string().nullable(),
  baseOid: z
    .string()
    .nullable()
    .describe("The base branch's remote-tracking sha when measured; null otherwise."),
  ahead: z.number().nullable(),
  behind: z.number().nullable(),
  parent: z.number().nullable(),
  blockedBy: z.number().nullable(),
  /** {@link SurveyStatus}, as a zod enum over the same source array. */
  status: z.enum(SURVEY_STATUSES),
  /** {@link MergePrediction}, as a zod enum over the same source array. */
  merge: z.enum(MERGE_PREDICTIONS),
  conflicts: z.array(z.string()),
  conflictBaseSha: z
    .string()
    .nullable()
    .describe("The base ref's resolved sha when `merge` is `conflict`; null otherwise."),
  reviews: z.number(),
  unpushedLocal: z.boolean(),
  strategy: z.string(),
  strategyRule: z.string(),
  strategyReason: z.string(),
})

export const output = z.object({
  repos: z
    .array(z.object({ slug: z.string(), measurable: z.boolean(), fetched: z.boolean() }))
    .describe('Repositories surveyed. `measurable` is false when no local checkout is known.'),
  prs: z.array(row).describe('Open PRs in stack order — a parent always precedes its children.'),
  cycles: z
    .array(z.number())
    .describe('PR numbers whose base/head edges form a cycle; excluded from the ordering.'),
  counts: z.object({
    total: z.number(),
    upToDate: z.number(),
    behind: z.number(),
    blocked: z.number(),
    conflicted: z.number(),
    unknown: z.number(),
    rebase: z.number(),
    merge: z.number(),
    skip: z.number(),
  }),
})

// ---------------------------------------------------------------------------
// Handler
// ---------------------------------------------------------------------------

/** A count, or an em dash when it could not be measured. */
export function num(n: number | null): string {
  return n === null ? '—' : String(n)
}

/** Everything `survey` reports. `update` plans from the same call. */
export type SurveyReport = z.infer<typeof output>

/** The scope flags both `survey` and `update` accept. */
export type SurveyArgs = z.infer<typeof input>

/** Everything a run needs beyond the args and the config. */
export interface SurveyEnv {
  projectRoot: string
  dryRun: boolean
  git: CommandRunner
  /** Runs `gh` for the default GitHub code host; unused when `codeHost` is given. */
  gh: CommandRunner
  /**
   * The code host for one surveyed repository: `cwd` is the checkout to run
   * from, `slug` the repository. Absent means GitHub over `gh`.
   */
  codeHost?: ((target: { cwd: string; slug: string }) => CodeHost) | undefined
  cfg: PrUpdateConfig
  ports: Pick<Ports, 'locate'>
}

/** `owner/name` from a git remote reference, or null when it names no project. */
function remoteSlug(url: string): string | null {
  const info = parseGitUrl(url)
  return info === null || !info.user || !info.project ? null : `${info.user}/${info.project}`
}

/**
 * Run the survey.
 *
 * Kept separate from `update` so `update` plans from exactly what `survey`
 * reports, rather than a second implementation that could drift from it. An
 * update is the survey plus an apply step, and this is the seam that keeps
 * that true.
 */
export function runSurvey(args: SurveyArgs, env: SurveyEnv): SurveyReport {
  const { cfg } = env
  const localGit = new Git(env.projectRoot, { runner: env.git })
  const localUrl = localGit.soft.remoteGetUrl(args.remote)
  const localSlug = localUrl !== null ? remoteSlug(localUrl) : null
  const codeHostFor = env.codeHost ?? githubCodeHostFor(env.gh)

  const targets = resolveTargets(localSlug, env.projectRoot, args.repo, env.ports.locate)
  // Flags beat config; config beats the built-in default.
  const author = args.author ?? cfg.author ?? undefined
  const includeDrafts = args.noDrafts ? false : cfg.include_drafts

  const repos: { slug: string; measurable: boolean; fetched: boolean }[] = []
  const allRows: SurveyRow[] = []
  const allCycles: number[] = []

  for (const target of targets) {
    const measurable = target.path !== null
    const git = new Git(target.path ?? env.projectRoot, { runner: env.git })
    // `try`: an unreachable remote means the survey reports what the last
    // fetch left behind, flagged, rather than failing the whole run.
    const fetched =
      measurable && !args.noFetch && !env.dryRun
        ? git.try.fetch(args.remote, undefined, { prune: true }).ok
        : false

    const isLocal = target.slug === localSlug
    const codeHost = codeHostFor({ cwd: target.path ?? env.projectRoot, slug: target.slug })
    const listed =
      codeHost.listPrDetails({
        limit: args.limit,
        ...(isLocal ? {} : { repo: target.slug }),
        ...(author !== undefined ? { author } : {}),
      }) ?? []
    const prs = includeDrafts ? listed : listed.filter((p) => !p.isDraft)
    const worktrees = measurable ? git.soft.worktrees() : []

    const { rows, cycles } = surveyRows(git, prs, {
      repo: target.slug,
      worktrees,
      cfg,
      measurable,
    })
    repos.push({ slug: target.slug, measurable, fetched })
    allRows.push(...rows)
    allCycles.push(...cycles)
  }

  const count = (fn: (r: SurveyRow) => boolean): number => allRows.filter(fn).length
  return {
    repos,
    prs: allRows,
    cycles: allCycles,
    counts: {
      total: allRows.length,
      upToDate: count((r) => r.status === 'up-to-date'),
      behind: count((r) => r.status === 'behind'),
      blocked: count((r) => r.status === 'blocked'),
      conflicted: count((r) => r.merge === 'conflict'),
      unknown: count((r) => r.status === 'unknown'),
      rebase: count((r) => r.strategy === 'rebase'),
      merge: count((r) => r.strategy === 'merge'),
      skip: count((r) => r.strategy === 'skip'),
    },
  }
}

function pad(text: string, width: number): string {
  return text.length >= width ? text : text + ' '.repeat(width - text.length)
}

/** Render a survey report as the same aligned text `pr-update survey` prints. */
export function renderSurveyText(out: SurveyReport): string {
  const lines: string[] = []
  // Before the rows, and before any early return: a repository we could
  // not reach listing zero PRs must not read as a repository with none.
  const unmeasured = out.repos.filter((r) => !r.measurable)
  for (const r of unmeasured) {
    lines.push(`${r.slug}: no local checkout — drift not measured`)
  }
  if (out.prs.length === 0) {
    lines.push('PR-SURVEY: no open PRs')
    return `${lines.join('\n')}\n`
  }
  if (unmeasured.length > 0) lines.push('')
  const multi = out.repos.length > 1
  const w = {
    pr: Math.max(3, ...out.prs.map((p) => String(p.number).length + 1)),
    status: Math.max(6, ...out.prs.map((p) => p.status.length)),
    plan: Math.max(4, ...out.prs.map((p) => p.strategy.length)),
    head: Math.max(4, ...out.prs.map((p) => p.head.length)),
  }
  const repoCol = multi ? `${pad('REPO', 18)}  ` : ''
  lines.push(
    `${repoCol}${pad('PR', w.pr)}  ${pad('STATUS', w.status)}  ${pad('BEHIND', 6)}  ` +
      `${pad('AHEAD', 5)}  ${pad('PLAN', w.plan)}  ${pad('HEAD', w.head)}  BASE`,
  )
  for (const p of out.prs) {
    // Each note changes what to do about the PR, and more than one can be
    // true at once — a conflicted PR inside a stale stack, updated by a
    // strategy a guard picked rather than the project default.
    const notes: string[] = []
    if (p.blockedBy !== null) notes.push(`blocked on #${p.blockedBy}`)
    if (p.merge === 'conflict') {
      const shown = p.conflicts.slice(0, 3).join(', ')
      const rest = p.conflicts.length > 3 ? ` (+${p.conflicts.length - 3})` : ''
      notes.push(`conflicts: ${shown}${rest}`)
    }
    if (p.strategyRule !== 'default') notes.push(p.strategyReason)
    const note = notes.length > 0 ? `  ← ${notes.join('; ')}` : ''
    lines.push(
      `${multi ? `${pad(p.repo, 18)}  ` : ''}${pad(`#${p.number}`, w.pr)}  ` +
        `${pad(p.status, w.status)}  ${pad(num(p.behind), 6)}  ${pad(num(p.ahead), 5)}  ` +
        `${pad(p.strategy, w.plan)}  ${pad(p.head, w.head)}  ${p.base}${note}`,
    )
  }
  if (out.cycles.length > 0) {
    lines.push(`\nunordered (base/head cycle): ${out.cycles.map((n) => `#${n}`).join(', ')}`)
  }
  const c = out.counts
  lines.push(
    `\nPR-SURVEY: total=${c.total} up-to-date=${c.upToDate} behind=${c.behind} ` +
      `blocked=${c.blocked} conflicted=${c.conflicted} unknown=${c.unknown}` +
      ` | plan rebase=${c.rebase} merge=${c.merge} skip=${c.skip}`,
  )
  return `${lines.join('\n')}\n`
}
