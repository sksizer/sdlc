/**
 * The `Ports` a standalone `pr-update` run supplies for itself, with no host
 * (like sdlc's own repo registry or trust store) in front of it.
 *
 * A library consumer builds its own `Ports` instead — sdlc's thin wrapper ops
 * bind `locate` to `locateRepo`/`repoContainers`, `runVerb` to
 * `shellArmExec`, and `resolveVerifyVerbs` to `resolveWorkflowCommands`/
 * `requireTrustedVerbs`, none of which this package depends on.
 */

import { runShell } from '@sksizer/command-seam'

import type { PrUpdateConfig } from './config.ts'
import type { Ports, Repair } from './ports.ts'
import { attemptsFile, fileAttemptStore } from './update/attempts.ts'

/**
 * A `Repair` that runs `command` with `sh -c` in the update worktree. The
 * request arrives as JSON on stdin and as `PR_UPDATE_*` variables; exit 0
 * claims success, and the note is the command's last line of output.
 */
export function commandRepair(command: string): Repair {
  return (req) => {
    const res = runShell(command, {
      cwd: req.worktree,
      input: JSON.stringify(req),
      env: {
        PR_UPDATE_KIND: req.kind,
        PR_UPDATE_PR: String(req.pr),
        PR_UPDATE_BASE: req.base,
        PR_UPDATE_HEAD: req.head,
        PR_UPDATE_WORKTREE: req.worktree,
        PR_UPDATE_PATHS: req.paths.join('\n'),
        PR_UPDATE_REASON: req.reason,
      },
    })
    const out = (res.stdout.trim() || res.stderr.trim()).split('\n')
    return { ok: res.exitCode === 0, note: out[out.length - 1] ?? '' }
  }
}

/**
 * A standalone run has no repository registry to scan, so `--repo` naming
 * anything other than the local checkout always comes back unmeasurable —
 * honest, since there is nothing here to guess a path from.
 *
 * With `projectRoot`, failed updates are recorded in
 * `<projectRoot>/.pr-update/attempts.json`.
 */
export function standalonePorts(cfg?: PrUpdateConfig, projectRoot?: string): Ports {
  const command = cfg?.repair.command ?? null
  const testCommand = cfg?.test_command ?? null
  return {
    locate: () => null,
    runVerb: (verb, cwd) => runShell(verb, { cwd }),
    // A standalone run has no host registry to resolve `check` from, and runs
    // `test` only from `test_command`. Failing loudly beats running zero verbs
    // and reporting a push as verified when it was not checked at all.
    async resolveVerifyVerbs({ which }) {
      if (which === 'check') {
        throw new Error(
          'verify: check has no meaning in a standalone run — embed @sksizer/pr-update as a ' +
            "library and supply Ports.resolveVerifyVerbs, or set verify: 'none'",
        )
      }
      if (testCommand === null) {
        throw new Error(
          "verify: test needs test_command in a standalone run — set it in .pr-update.yaml, or set verify: 'none'",
        )
      }
      return [testCommand]
    },
    ...(command === null ? {} : { repair: commandRepair(command) }),
    ...(projectRoot === undefined ? {} : { attempts: fileAttemptStore(attemptsFile(projectRoot)) }),
  }
}
