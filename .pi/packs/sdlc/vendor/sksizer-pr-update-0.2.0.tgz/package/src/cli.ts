/**
 * `pr-update` — the standalone CLI, per [[S-0015-standalone-cli-shape]].
 *
 * Two subcommands, `survey` and `update`, each declared to `defineCli`
 * separately (there is no subcommand primitive in `defineCli` itself — the
 * dispatch on `argv[0]` below is the whole of it, same as every other
 * multi-command tool in this workspace).
 *
 * Config layers: a flag beats `.pr-update.yaml` in the project root, which
 * beats the built-in defaults (see `config-file.ts`) — every `PrUpdateConfig`
 * key has a default, so both subcommands work with no config file at all.
 *
 * Exit code, per S-0015: `0` on a fully clean run (`survey`, always; `update`
 * only when every target ended `updated`/`up-to-date`/deliberately skipped),
 * `1` when the command ran to completion but didn't fully succeed against
 * the state it found (an unexpected thrown error, caught by `runMain`; or,
 * for `update`, any target left `conflict`/`failed` — read `results`/
 * `counts` for which), `2` on a malformed command line.
 */

import { EXIT, defineCli, runMain, type CliContext } from '@sksizer/cli-tool'
import { spawnRunner } from '@sksizer/command-seam'

import { loadConfigFile } from './config-file.ts'
import { standalonePorts } from './defaults.ts'
import { renderSurveyText, runSurvey } from './survey.ts'
import { UpdateUsageError, renderUpdateText, runUpdate, type UpdateEnv } from './update.ts'

type OutputForm = 'text' | 'json'

function resolveOutput(v: { output: OutputForm | undefined; json: boolean }): OutputForm {
  return v.output ?? (v.json ? 'json' : 'text')
}

function parseIntFlag(name: string, raw: string): number | { error: string } {
  const n = Number(raw)
  return Number.isInteger(n) ? n : { error: `--${name} must be an integer, got '${raw}'` }
}

const surveyCli = defineCli({
  name: 'pr-update survey',
  summary: "Report every open PR's drift from its base, in stack order.",
  flags: {
    author: {
      kind: 'string',
      valueName: 'login',
      help: 'Only PRs by this author (`@me` for yourself).',
    },
    repo: {
      kind: 'list',
      valueName: 'owner/name',
      default: [],
      help: 'Repository to survey; repeatable.',
    },
    fetch: {
      kind: 'boolean',
      negatable: true,
      help: 'Fetch before measuring. --no-fetch measures the refs as they stand.',
    },
    drafts: {
      kind: 'boolean',
      negatable: true,
      help: 'Include draft PRs. --no-drafts excludes them.',
    },
    limit: {
      kind: 'string',
      valueName: 'n',
      default: '100',
      help: 'Maximum open PRs per repository.',
    },
    remote: {
      kind: 'string',
      valueName: 'name',
      default: 'origin',
      help: 'Remote to measure against.',
    },
    output: {
      kind: 'enum',
      choices: ['text', 'json'] as const,
      valueName: 'form',
      help: 'text (aligned) or json. Default: text',
    },
    json: { kind: 'boolean', help: 'alias for --output json' },
  },
})

const updateCli = defineCli({
  name: 'pr-update update',
  summary: 'Bring out-of-date PRs up to date, in stack order.',
  flags: {
    author: {
      kind: 'string',
      valueName: 'login',
      help: 'Only PRs by this author (`@me` for yourself).',
    },
    repo: {
      kind: 'list',
      valueName: 'owner/name',
      default: [],
      help: 'Repository to update; repeatable.',
    },
    fetch: {
      kind: 'boolean',
      negatable: true,
      help: 'Fetch before measuring. --no-fetch measures the refs as they stand.',
    },
    drafts: {
      kind: 'boolean',
      negatable: true,
      help: 'Include draft PRs. --no-drafts excludes them.',
    },
    limit: {
      kind: 'string',
      valueName: 'n',
      default: '100',
      help: 'Maximum open PRs per repository.',
    },
    remote: {
      kind: 'string',
      valueName: 'name',
      default: 'origin',
      help: 'Remote to measure against and push to.',
    },
    apply: { kind: 'boolean', help: 'Push the updates. Without it, nothing is written.' },
    interactive: { kind: 'boolean', help: 'Pick the PRs from a checklist, then watch them run.' },
    confirmPush: {
      kind: 'boolean',
      help: 'Show the commits and diffstat and ask y/N before each force-push. Needs --apply and a terminal.',
    },
    pr: { kind: 'list', valueName: 'n', default: [], help: 'Update only this PR; repeatable.' },
    trust: {
      kind: 'boolean',
      help: 'Treat this repo as trusted for this run (satisfies the trust gate on verify: check).',
    },
    retryFailed: {
      kind: 'boolean',
      help: 'Attempt PRs whose update already failed at their current head and base.',
    },
    strategy: {
      kind: 'enum',
      choices: ['rebase', 'merge'] as const,
      valueName: 'name',
      help: "Override this run's default strategy; does not beat a per-PR override or the unpushed-local guard.",
    },
    output: {
      kind: 'enum',
      choices: ['text', 'json'] as const,
      valueName: 'form',
      help: 'text (aligned) or json. Default: text',
    },
    json: { kind: 'boolean', help: 'alias for --output json' },
  },
})

const TOP_HELP = `pr-update <command>

Commands:
  survey   Report every open PR's drift from its base, in stack order.
  update   Bring out-of-date PRs up to date, in stack order.

Run 'pr-update <command> --help' for a command's own flags.`

function runEnv(projectRoot: string): UpdateEnv {
  const cfg = loadConfigFile(projectRoot)
  return {
    projectRoot,
    dryRun: false,
    git: spawnRunner('git'),
    gh: spawnRunner('gh'),
    cfg,
    ports: standalonePorts(cfg, projectRoot),
  }
}

function runSurveyCommand(argv: readonly string[], ctx: CliContext): number {
  const { io } = ctx
  const parsed = surveyCli.parse(argv, io)
  if (parsed.status === 'help') return EXIT.ok
  if (parsed.status === 'error') {
    io.stderr(`pr-update survey: ${parsed.message}\n`)
    return EXIT.usage
  }
  const v = parsed.values
  const limit = parseIntFlag('limit', v.limit)
  if (typeof limit !== 'number') {
    io.stderr(`pr-update survey: ${limit.error}\n`)
    return EXIT.usage
  }
  const report = runSurvey(
    {
      ...(v.author !== undefined ? { author: v.author } : {}),
      repo: v.repo,
      noFetch: !v.fetch,
      noDrafts: !v.drafts,
      limit,
      remote: v.remote,
    },
    runEnv(ctx.cwd),
  )
  io.stdout(
    resolveOutput(v) === 'json' ? `${JSON.stringify(report, null, 2)}\n` : renderSurveyText(report),
  )
  return EXIT.ok
}

async function runUpdateCommand(argv: readonly string[], ctx: CliContext): Promise<number> {
  const { io } = ctx
  const parsed = updateCli.parse(argv, io)
  if (parsed.status === 'help') return EXIT.ok
  if (parsed.status === 'error') {
    io.stderr(`pr-update update: ${parsed.message}\n`)
    return EXIT.usage
  }
  const v = parsed.values
  const limit = parseIntFlag('limit', v.limit)
  if (typeof limit !== 'number') {
    io.stderr(`pr-update update: ${limit.error}\n`)
    return EXIT.usage
  }
  const prNumbers: number[] = []
  for (const raw of v.pr) {
    const n = parseIntFlag('pr', raw)
    if (typeof n !== 'number') {
      io.stderr(`pr-update update: ${n.error}\n`)
      return EXIT.usage
    }
    prNumbers.push(n)
  }
  const env: UpdateEnv = runEnv(ctx.cwd)
  let out
  try {
    out = await runUpdate(
      {
        ...(v.author !== undefined ? { author: v.author } : {}),
        repo: v.repo,
        noFetch: !v.fetch,
        noDrafts: !v.drafts,
        limit,
        remote: v.remote,
        apply: v.apply,
        interactive: v.interactive,
        confirmPush: v.confirmPush,
        pr: prNumbers,
        trust: v.trust,
        retryFailed: v.retryFailed,
        ...(v.strategy !== undefined ? { strategy: v.strategy } : {}),
      },
      env,
    )
  } catch (e) {
    if (!(e instanceof UpdateUsageError)) throw e
    io.stderr(`pr-update update: ${e.message}\n`)
    return EXIT.usage
  }
  if (!out.interactive) {
    io.stdout(
      resolveOutput(v) === 'json' ? `${JSON.stringify(out, null, 2)}\n` : renderUpdateText(out),
    )
  }
  // Per S-0015 `1`: "a well-formed command that failed against the state it
  // found" — the run itself completed (every target was at least attempted
  // and nothing was left half-applied), but a conflict or push failure means
  // some PR did not end up updated. A script driving this in a loop needs
  // that distinction in its exit code, not just in the JSON `counts`.
  return out.counts.conflict > 0 || out.counts.failed > 0 ? EXIT.error : EXIT.ok
}

/** `main(argv, ctx)` per S-0015: returns, never exits, reads nothing ambient. */
export async function main(argv: readonly string[], ctx: CliContext): Promise<number> {
  const [sub, ...rest] = argv
  if (sub === undefined || sub === '--help' || sub === '-h') {
    ctx.io.stdout(`${TOP_HELP}\n`)
    return EXIT.ok
  }
  if (sub === 'survey') return runSurveyCommand(rest, ctx)
  if (sub === 'update') return runUpdateCommand(rest, ctx)
  ctx.io.stderr(`pr-update: unknown command '${sub}'\n\n${TOP_HELP}\n`)
  return EXIT.usage
}

// Runs when executed directly (`bun run src/cli.ts`), stays inert when
// imported — the published `bin/` shim imports `main` and calls it itself
// through `runMain`.
if (import.meta.main) {
  await runMain(main, { name: 'pr-update' })
}
