/**
 * The interactive surface for `pr-update update`.
 *
 * The verb without this is all-or-nothing: rehearse everything, or apply
 * everything. That is the wrong shape for the actual decision, which is
 * per-PR and made while looking at the list — this one is mine and safe, that
 * one is someone else's, this stack can wait. A checklist is the smallest
 * thing that lets a person express it.
 *
 * What it deliberately does NOT do is decide anything. The plan, the
 * strategy, the guards and the skips all come from the survey exactly as the
 * non-interactive path sees them; this only chooses which rows to run and
 * shows what happened. Two ways to compute a plan would be one too many.
 *
 * Rows the executor would refuse are shown but not selectable. Hiding them
 * would be worse: "my PR is not in the list" is a question, and the answer —
 * unpushed work in a worktree, a fork, a base that is itself behind — is
 * exactly what the reader needs to see.
 *
 * On the dependencies: Ink brings React and a flexbox layout engine into the
 * binary, which is why it is imported lazily by the op — no other verb pays
 * for it. `react-devtools-core` is a direct dependency for a reason that is
 * purely mechanical: Ink's reconciler reaches for it behind
 * `if (process.env.DEV === 'true')`, inside a try/catch that already handles
 * it being absent, but the bundler resolves that import while building and
 * fails over a package no shipped path can reach. Declaring it external
 * instead moves the failure to startup. It tree-shakes down to well under a
 * megabyte in the compiled binary.
 */

import { Box, Text, useApp, useInput } from 'ink'
import { useCallback, useMemo, useState } from 'react'

import type { UpdateResult, UpdateTarget } from './execute.ts'
import { describeOutcome } from './execute.ts'

/** One line in the list: either a selectable target or a locked explanation. */
export interface TuiRow {
  number: number
  head: string
  base: string
  strategy: string
  /** Why this row cannot be selected, or null when it can. */
  locked: string | null
  /** Ahead/behind, for the size of what is being asked. */
  behind: number | null
}

export interface TuiProps {
  rows: readonly TuiRow[]
  /**
   * Applies the chosen PRs. Resolves when the run ends; `onResult` fires per
   * PR so a run over many minutes shows progress rather than a frozen screen.
   */
  apply: (numbers: number[], onResult: (r: UpdateResult) => void) => Promise<UpdateResult[]>
  /** Called once the user is finished, with whatever the run produced. */
  onDone: (results: UpdateResult[], applied: boolean) => void
}

type Phase = 'choosing' | 'running' | 'done'

/**
 * Initial selection: everything actionable.
 *
 * Pre-checking the safe rows makes the common case one keystroke, and the
 * expensive mistake here is not "updated one I did not mean to" — every
 * selectable row is one the guards already cleared — but "gave up and ran the
 * whole thing unattended".
 */
export function initialSelection(rows: readonly TuiRow[]): Set<number> {
  return new Set(rows.filter((r) => r.locked === null).map((r) => r.number))
}

/** `✓ rebase` / `· merge`, padded so the column lines up. */
function pad(text: string, width: number): string {
  return text.length >= width ? text : text + ' '.repeat(width - text.length)
}

export function UpdateTui({ rows, apply, onDone }: TuiProps): JSX.Element {
  const { exit } = useApp()
  const [selected, setSelected] = useState<Set<number>>(() => initialSelection(rows))
  const [cursor, setCursor] = useState(0)
  const [phase, setPhase] = useState<Phase>('choosing')
  const [results, setResults] = useState<UpdateResult[]>([])
  const [running, setRunning] = useState<number | null>(null)

  const selectable = useMemo(() => rows.filter((r) => r.locked === null), [rows])
  const widths = useMemo(
    () => ({
      pr: Math.max(3, ...rows.map((r) => String(r.number).length + 1)),
      strategy: Math.max(6, ...rows.map((r) => r.strategy.length)),
      head: Math.max(4, ...rows.map((r) => r.head.length)),
    }),
    [rows],
  )

  const start = useCallback(() => {
    const numbers = rows.filter((r) => selected.has(r.number)).map((r) => r.number)
    if (numbers.length === 0) {
      onDone([], false)
      exit()
      return
    }
    setPhase('running')
    setRunning(numbers[0] ?? null)
    void apply(numbers, (r) => {
      setResults((prev) => {
        const next = [...prev, r]
        setRunning(numbers[next.length] ?? null)
        return next
      })
    }).then((all) => {
      setPhase('done')
      setRunning(null)
      onDone(all, true)
      exit()
    })
  }, [rows, selected, apply, onDone, exit])

  useInput((input, key) => {
    if (phase !== 'choosing') return
    if (key.upArrow || input === 'k') setCursor((c) => Math.max(0, c - 1))
    else if (key.downArrow || input === 'j') setCursor((c) => Math.min(rows.length - 1, c + 1))
    else if (input === ' ') {
      const row = rows[cursor]
      // A locked row is shown for its explanation, never toggled — the guard
      // that locked it is not a preference the UI may override.
      if (row === undefined || row.locked !== null) return
      setSelected((prev) => {
        const next = new Set(prev)
        if (next.has(row.number)) next.delete(row.number)
        else next.add(row.number)
        return next
      })
    } else if (input === 'a') setSelected(new Set(selectable.map((r) => r.number)))
    else if (input === 'n') setSelected(new Set())
    else if (key.return) start()
    else if (input === 'q' || key.escape) {
      onDone([], false)
      exit()
    }
  })

  if (phase !== 'choosing') {
    return (
      <Box flexDirection="column">
        {results.map((r) => (
          <Text key={r.number}>
            <Text color={outcomeColor(r)}>{outcomeMark(r)}</Text>
            {` #${r.number}  ${r.head}  ${describeOutcome(r.outcome)}`}
          </Text>
        ))}
        {running !== null && <Text dimColor>{`… #${running}`}</Text>}
        {phase === 'done' && <Text>{'\n'}Done.</Text>}
      </Box>
    )
  }

  return (
    <Box flexDirection="column">
      <Text bold>
        {`  ${pad('PR', widths.pr)}  ${pad('PLAN', widths.strategy)}  ${pad('HEAD', widths.head)}  BASE`}
      </Text>
      {rows.map((row, i) => {
        const here = i === cursor
        const box = row.locked !== null ? ' ' : selected.has(row.number) ? '✓' : ' '
        return (
          <Text key={row.number} inverse={here} dimColor={row.locked !== null}>
            {`${box} ${pad(`#${row.number}`, widths.pr)}  ` +
              `${pad(row.strategy, widths.strategy)}  ${pad(row.head, widths.head)}  ${row.base}` +
              (row.locked !== null ? `  ← ${row.locked}` : behindNote(row.behind))}
          </Text>
        )
      })}
      <Text>{'\n'}</Text>
      <Text dimColor>
        {`${selected.size} of ${selectable.length} selected · space toggle · a all · n none · enter apply · q quit`}
      </Text>
    </Box>
  )
}

function behindNote(behind: number | null): string {
  if (behind === null || behind === 0) return ''
  return `  (${behind} behind)`
}

function outcomeMark(r: UpdateResult): string {
  switch (r.outcome.status) {
    case 'updated':
      return '✓'
    case 'up-to-date':
      return '·'
    case 'conflict':
      return '!'
    case 'failed':
      return '✗'
  }
}

function outcomeColor(r: UpdateResult): string {
  switch (r.outcome.status) {
    case 'updated':
      return 'green'
    case 'up-to-date':
      return 'gray'
    case 'conflict':
      return 'yellow'
    case 'failed':
      return 'red'
  }
}

/** Build the list from the executor's targets plus the rows it declined. */
export function toRows(
  targets: readonly UpdateTarget[],
  skipped: readonly { number: number; head: string; reason: string }[],
  meta: ReadonlyMap<number, { base: string; behind: number | null }>,
): TuiRow[] {
  const rows: TuiRow[] = targets.map((t) => ({
    number: t.number,
    head: t.head,
    base: t.base,
    strategy: t.strategy,
    locked: null,
    behind: meta.get(t.number)?.behind ?? null,
  }))
  for (const s of skipped) {
    rows.push({
      number: s.number,
      head: s.head,
      base: meta.get(s.number)?.base ?? '',
      strategy: '—',
      locked: s.reason,
      behind: meta.get(s.number)?.behind ?? null,
    })
  }
  // Stack order for the actionable rows is load-bearing — the executor applies
  // them in the order given — so targets keep theirs and the locked rows
  // follow, sorted, as an appendix.
  return rows
}
