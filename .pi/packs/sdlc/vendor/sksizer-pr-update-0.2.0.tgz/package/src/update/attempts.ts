/**
 * A JSON-file record of failed updates, so a PR that failed is not retried
 * with the same inputs on every run.
 *
 * One entry per repo, head branch and base branch: a failure at a new head or
 * base sha replaces the old entry rather than adding to it. Entries older than
 * 30 days are dropped on every write. A missing or unreadable file reads as
 * empty, and the next write replaces it.
 */

import { readFileSync } from 'node:fs'
import { join } from 'node:path'

import { atomicWrite } from '@sksizer/etag-write'

import type { AttemptKey, AttemptRecord, AttemptStore } from '../ports.ts'

const MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000

interface Entry extends AttemptKey, AttemptRecord {}

/** Where a run rooted at `projectRoot` keeps its record. */
export function attemptsFile(projectRoot: string): string {
  return join(projectRoot, '.pr-update', 'attempts.json')
}

function sameBranch(a: AttemptKey, b: Pick<AttemptKey, 'repo' | 'head'>): boolean {
  return a.repo === b.repo && a.head === b.head
}

function sameKey(a: AttemptKey, b: AttemptKey): boolean {
  return sameBranch(a, b) && a.base === b.base && a.headOid === b.headOid && a.baseOid === b.baseOid
}

function read(file: string): Entry[] {
  try {
    const parsed: unknown = JSON.parse(readFileSync(file, 'utf8'))
    const entries = (parsed as { entries?: unknown }).entries
    return Array.isArray(entries) ? (entries as Entry[]) : []
  } catch {
    return []
  }
}

function write(file: string, entries: readonly Entry[]): void {
  atomicWrite(file, `${JSON.stringify({ entries }, null, 2)}\n`)
}

export function fileAttemptStore(file: string, opts: { now?: () => Date } = {}): AttemptStore {
  const now = opts.now ?? (() => new Date())
  const fresh = (entries: readonly Entry[]): Entry[] => {
    const cutoff = now().getTime() - MAX_AGE_MS
    return entries.filter((e) => Date.parse(e.at) >= cutoff)
  }
  return {
    get(key) {
      const hit = read(file).find((e) => sameKey(e, key))
      return hit === undefined ? null : { failures: hit.failures, reason: hit.reason, at: hit.at }
    },
    recordFailure(key, reason) {
      const entries = fresh(read(file))
      const prior = entries.find((e) => sameKey(e, key))
      const rest = entries.filter((e) => !(sameBranch(e, key) && e.base === key.base))
      rest.push({
        ...key,
        failures: (prior?.failures ?? 0) + 1,
        reason,
        at: now().toISOString(),
      })
      write(file, rest)
    },
    clear(repo, head) {
      const entries = read(file)
      const rest = entries.filter((e) => !sameBranch(e, { repo, head }))
      if (rest.length !== entries.length) write(file, fresh(rest))
    },
  }
}
