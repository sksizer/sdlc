/**
 * Loading `PrUpdateConfig` for a standalone run: `.pr-update.yaml` in the
 * project root, layered under the built-in defaults. A host embedding this
 * package as a library (sdlc's own thin wrapper ops, say) skips this file
 * entirely and builds a `PrUpdateConfig` from its own config format instead —
 * this is only for `pr-update` run with no host CLI in front of it.
 */

import { readFileSync } from 'node:fs'
import { join } from 'node:path'

import { parse } from 'yaml'

import { DEFAULT_PR_UPDATE_CONFIG, prUpdateConfigSchema, type PrUpdateConfig } from './config.ts'

/** `.pr-update.yaml` failed to parse or did not match the config shape. */
export class ConfigFileError extends Error {}

/**
 * Read `.pr-update.yaml` from `projectRoot`, if it exists. Absent is not an
 * error — every `PrUpdateConfig` key has a default, so the tool works with no
 * config file at all.
 */
export function loadConfigFile(projectRoot: string): PrUpdateConfig {
  const path = join(projectRoot, '.pr-update.yaml')
  let text: string
  try {
    text = readFileSync(path, 'utf8')
  } catch {
    return DEFAULT_PR_UPDATE_CONFIG
  }
  let raw: unknown
  try {
    raw = parse(text)
  } catch (e) {
    throw new ConfigFileError(`${path}: ${e instanceof Error ? e.message : String(e)}`)
  }
  const result = prUpdateConfigSchema.safeParse(raw ?? {})
  if (!result.success) {
    throw new ConfigFileError(`${path}: ${result.error.message}`)
  }
  return result.data
}
