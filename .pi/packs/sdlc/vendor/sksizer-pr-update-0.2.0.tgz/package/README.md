# @sksizer/pr-update

Survey every open pull request's drift from its base, and bring the ones that
are behind up to date — rebase or merge, one PR or a whole stack, with
conflicts predicted before anything is checked out.

```ts
import { prUpdateConfigSchema, runSurvey, standalonePorts } from "@sksizer/pr-update";
import { spawnRunner } from "@sksizer/command-seam";

const report = runSurvey(
  { repo: [], noFetch: false, noDrafts: false, limit: 100, remote: "origin" },
  {
    projectRoot: process.cwd(),
    dryRun: false,
    git: spawnRunner("git"),
    gh: spawnRunner("gh"),
    cfg: prUpdateConfigSchema.parse({}),
    ports: standalonePorts(),
  },
);
```

Or from a shell:

```sh
pr-update survey --output json
pr-update update --apply --strategy rebase
```

## Why this exists as its own package

A stack of PRs drifts constantly — every merge to `main` puts the next PR one
commit further behind, and a PR three deep in a stack can look clean while
sitting on a base that is itself stale. Catching that by eye does not scale
past a handful of PRs; surveying it costs a GitHub API call and a
`git merge-tree` per PR, both cheap enough to run on every one that is open.

This package started life inside a larger CLI. It moved out once "run this
standalone against any repository, with your own idea of trust and your own
GitHub client" stopped being a hypothetical — see [[T-4AQN]] and the CodeHost
port ([[T-DVLT]]) it now leaves to a caller entirely.

## Three things it knows that a per-PR check cannot

**Drift is measured locally.** GitHub only reports `mergeStateStatus: BEHIND`
when branch protection requires an up-to-date branch; without it the field
stays silent however far a branch has drifted. So behind-ness comes from
`git rev-list --left-right --count` over the remote-tracking refs.

**Staleness is transitive.** When PR A targets PR B's head branch, A is
stacked on B, and updating A before B is wasted work — A's base is about to
move. `survey` builds the stack graph, sorts it parent-first, and marks a
child `blocked` on the nearest ancestor that is itself behind, however many
levels up that ancestor sits.

**A rebase is not always safe.** `--force-with-lease` compares against the
*remote*, so it does not notice a checkout holding commits nobody has pushed;
rebasing over that would orphan the work with no warning. The
`guards.unpushed_local` guard checks for this ahead of every preference and no
override defeats it.

## Conflicts, predicted before anything is checked out

`survey` predicts each PR's merge with `git merge-tree`, which merges in the
object database and never touches a working tree — the only thing that makes
surveying every open PR affordable; a full checkout per PR would cost minutes,
not seconds, across a large stack. A conflict prediction carries the
conflicted paths and `conflictBaseSha` — the base ref's resolved commit at the
moment it was measured — so a caller (a router keying a delivery signature on
it, say) can tell whether the prediction is still fresh.

## Resolving a conflict without asking anyone

`update` walks a resolver ladder before giving up on a conflict: git's own
`rerere` replay, the built-in lockfile rule (take a side, re-run
`lockfile_install`), then a project's own `resolvers` — glob-matched paths
paired with the shell verb that rebuilds them (`sdlc docs generate`, say), then
a host's in-process `generators`. A conflict no rung claims is reported with
the path and why, in `update`'s structured `conflicts` field — never guessed
at.

The one exception is opt-in. With `repair.command` set (or a host's `repair`
port), `update --apply` calls the repair once for whatever the ladder left: an
unclaimed `conflict`, and a failed verify step when `repair.on` lists
`verify-failed`. The repair only edits files. `update` then rejects it if HEAD
moved or a ref was created, or if conflict markers or `git diff --check`
errors remain. Otherwise `update` stages, commits, re-runs `verify` and
pushes. The result lists each fix under `repaired`. A rehearsal never calls
the repair.

A standalone run's `repair.command` gets the request as JSON on stdin and as
`PR_UPDATE_KIND`, `PR_UPDATE_PR`, `PR_UPDATE_BASE`, `PR_UPDATE_HEAD`,
`PR_UPDATE_WORKTREE`, `PR_UPDATE_PATHS` (one per line) and
`PR_UPDATE_REASON`. Exit 0 claims success; the last line of output is the
note.

## Checking before a push

`verify` decides what must pass before an updated branch is pushed. `none`
(the default) leaves it to CI on the PR. `check` and `test` run a verb list in
the update worktree, and a failure blocks the push. The host resolves that
list through `Ports.resolveVerifyVerbs({ which, trust })`. A standalone run
has no list for `check`, and runs `test` from `test_command`:

```yaml
# .pr-update.yaml
verify: test
test_command: bun test
```

With `verify: test` and no `test_command`, a standalone `update` fails before
it touches any PR.

## Not retrying a failure that will repeat

An update that ends `conflict` or `failed` will fail the same way next time
unless the head or the base has moved. So `update --apply` records each
failure in `.pr-update/attempts.json`, keyed by repo, head branch, head sha,
base branch and base sha. Once a PR has failed `max_failed_attempts` times
(default `1`) at its current key, later runs list it under `skipped` with the
reason `failed N time(s) at this head and base; waiting for either to move`,
and do not check it out. A new commit on either branch changes the key, so the
next run attempts it again. A PR whose head or base sha is unknown has no key
and is never skipped. An `updated` or `up-to-date` result clears the
branch's entries. Entries older than 30 days are dropped.

`--retry-failed` attempts recorded PRs anyway and still records new failures.
`max_failed_attempts: 0` turns the check off. A rehearsal reads the record but
never writes it: it cannot call the repair, so its failures say nothing about a
real run.

## Seeing a force-push before it happens

`update --apply --confirm-push` stops before each rebase force-push. It prints
the PR, the commits that will be on the branch (`git log
<remote>/<head>..HEAD`), how many commits the push replaces, and `git diff
--stat <remote>/<head> HEAD`, then asks `Force-push to <head>? [y/N]`. Only
`y` or `yes` pushes. Anything else leaves the branch as it was and reports
`push declined`. A prompt that fails (the terminal went away) counts as no and
is not recorded as a failed update. A merge push is a fast-forward and is not
asked about, and a dry run never asks.

The flag needs `--apply` and a terminal on stdin and stderr, and cannot be combined with
`--interactive`. A library caller sets `confirmPush: true` in the args and may
supply `Ports.confirmPush` to ask some other way than the terminal.

## Config layering

A CLI flag beats `.pr-update.yaml` in the project root, which beats the
built-in defaults — every key in `PrUpdateConfig` has one, so both `survey`
and `update` work with no config file at all. A host embedding this package as
a library (rather than running the `pr-update` binary) builds its own
`PrUpdateConfig` from whatever config format it already has; nothing here
requires `.pr-update.yaml`.

## The `Ports` a host supplies

Three things this package deliberately does not know for itself, two
optional extensions to the conflict ladder, an optional record of failed
updates, and an optional push confirmation:

| Port | What it answers |
|---|---|
| `locate(slug)` | Where `owner/name` is checked out on this machine, or `null` |
| `runVerb(verb, cwd)` | Run one shell verb — the resolver/verify seam |
| `resolveVerifyVerbs({ which, trust })` | The trust-gated verb list `verify: check` or `verify: test` runs before a push |
| `generators` (optional) | In-process rebuild steps, each with `claims(path)` and `run(worktree)` |
| `repair(req)` (optional) | The last rung: edit the worktree to fix a `conflict` or `verify-failed` |
| `attempts` (optional) | The failed-update record: `get(key)`, `recordFailure(key, reason)`, `clear(repo, head)` |
| `confirmPush(preview)` (optional) | Under `confirmPush: true`, whether to make one rebase force-push; the terminal prompt when absent |

`standalonePorts(cfg, projectRoot)` gives a `pr-update` CLI run reasonable defaults for the first
two, builds `repair` from `repair.command`, stores attempts in
`<projectRoot>/.pr-update/attempts.json` (`fileAttemptStore`), answers `verify: test` with
`test_command`, and refuses `verify: check` outright (a standalone run has no host registry to
resolve `check` from — set `verify: 'none'`, or embed this package as a library and supply real
ports). `commandRepair(command)` is the same command-backed repair, for a host that gates the
command itself.

## Code hosts

`survey` and `update` list PRs through the `CodeHost` port
(`@sksizer/code-host`, `listPrDetails`), so no GitHub client is imported
here. The default is `GithubCodeHost` over `gh` (`src/code-host.ts`, the only
file that names a concrete host); a host that wants another adapter, Forgejo
for one, supplies `SurveyEnv.codeHost`. The standalone CLI still builds the
GitHub default.

## License

MIT
