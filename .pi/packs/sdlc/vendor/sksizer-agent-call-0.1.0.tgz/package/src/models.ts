// Node-free entry point (`@sksizer/agent-call/models`): the model-selection
// vocabulary and the built-in tier tables. Imports nothing, so a browser bundle
// can take it without pulling in the process runner (`node:child_process`) that
// the package barrel re-exports.

/**
 * Cross-agent model intent when you don't want to name a concrete model.
 * Ignored when `model` is set. Mapping is per-adapter and recorded as an
 * `approximated` note (model families change faster than this library).
 */
export type ModelTier = 'fast' | 'standard' | 'max'

/**
 * Reasoning-effort intent, a separate axis from model choice. Maps to claude
 * `--effort`, codex `model_reasoning_effort`, opencode `--variant`.
 */
export const EFFORT_LEVELS = ['low', 'medium', 'high', 'max'] as const
export type EffortLevel = (typeof EFFORT_LEVELS)[number]

/** The Claude Code tier-to-model table, exported so a resolver can reuse it rather than copy it. */
export const CLAUDE_TIER_MODEL: Record<string, string> = {
  fast: 'haiku',
  standard: 'sonnet',
  max: 'opus',
}

/** The Gemini CLI tier-to-model table, exported so a resolver can reuse it rather than copy it. */
export const GEMINI_TIER_MODEL: Record<string, string> = {
  fast: 'flash',
  standard: 'auto',
  max: 'pro',
}
