/**
 * The asynchronous subprocess seam — for long-lived processes where a
 * blocking spawnSync would freeze the event loop, and for fanning out
 * network-bound calls concurrently. Same vocabulary as the sync door:
 * {@link CommandResult}, {@link CommandRunOptions}, `CommandFailed`.
 *
 * Sequential CLI one-shots should stay on the sync door — blocking costs
 * them nothing and keeps their call graphs uncolored.
 */

import { spawn } from 'node:child_process'
import { StringDecoder } from 'node:string_decoder'

import {
  CommandFailed,
  mergedEnv,
  type CommandResult,
  type CommandRunner,
  type CommandRunOptions,
} from './sync.ts'

/** {@link CommandRunOptions} plus mid-flight cancellation (async-only). */
export interface AsyncCommandRunOptions extends CommandRunOptions {
  signal?: AbortSignal | undefined
  /**
   * Called once with the child's pid right after it spawns, before the
   * command finishes — for a caller that must record the process while it is
   * still running (a liveness record that outlives a killed parent). Not
   * called when the spawn itself fails (no pid exists).
   */
  onSpawn?: ((pid: number) => void) | undefined
}

/** The async seam: same contract as {@link CommandRunner}, promised. */
export interface AsyncCommandRunner {
  run(argv: string[], opts: AsyncCommandRunOptions): Promise<CommandResult>
}

/**
 * A spawn-backed {@link AsyncCommandRunner} for `binary`. Never rejects on
 * command failure: a missing binary, timeout kill, or abort degrades to a
 * non-zero `exitCode` (stderr carries the spawn error's message when the
 * child produced none, and `neverExited` marks the result as the seam's
 * stand-in rather than the command's answer), mirroring the sync door's
 * flattening.
 *
 * NOTE: this async door captures via pipes and so is subject to the same
 * `bun test` child-stdio corruption the sync `spawnRunner` works around (see
 * its `runViaChildRedirect`). No async call site in this package's consumers
 * currently shells out under a corrupted test process, so the workaround is
 * not ported here. If an async-door test ever comes back with empty output
 * under `bun test`, apply the same child-redirect capture.
 */
export function spawnRunnerAsync(binary: string): AsyncCommandRunner {
  return {
    run(argv: string[], opts: AsyncCommandRunOptions): Promise<CommandResult> {
      return new Promise((resolve) => {
        // The timeout is enforced here rather than handed to spawn's own
        // `timeout` option: that option is a no-op on some Bun versions, so
        // the cap silently vanished on any runtime that did not implement it
        // (CI pins `bun-version: latest`, local dev does not — the same code
        // capped the child on one and ran it to completion on the other).
        // An explicit timer behaves identically everywhere.
        const child = spawn(binary, argv, {
          cwd: opts.cwd,
          signal: opts.signal,
          ...mergedEnv(opts),
        })
        if (child.pid !== undefined) opts.onSpawn?.(child.pid)
        let stdout = ''
        let stderr = ''
        let stdinError: Error | undefined
        let settled = false
        let timer: ReturnType<typeof setTimeout> | undefined
        // Decoded through a StringDecoder rather than per-chunk `toString()`:
        // a multi-byte character straddling a chunk boundary would otherwise
        // be decoded as two partial sequences and each half replaced with
        // U+FFFD. The decoder holds the partial sequence back until the rest
        // of it arrives. (Both sync paths are immune — they decode the whole
        // buffer, or the whole file, at once.)
        const outDecoder = new StringDecoder('utf8')
        const errDecoder = new StringDecoder('utf8')
        /**
         * Settle once, with the streams flushed. `end()` is what surfaces a
         * sequence the decoder is still holding back when the output ends
         * mid-character — truncated capture, or bytes that were never UTF-8:
         * unflushed those bytes are dropped, so the result is shorter than
         * what the child wrote and disagrees with the sync door. Every settle
         * path routes through here, so one flush covers close, timeout and
         * error. `stderrFallback` is consulted only when the child wrote no
         * stderr of its own — it is read after the flush for that reason.
         */
        const finish = (
          result: Omit<CommandResult, 'stdout' | 'stderr'>,
          stderrFallback?: string,
        ) => {
          if (settled) return
          settled = true
          if (timer !== undefined) clearTimeout(timer)
          stdout += outDecoder.end()
          stderr += errDecoder.end()
          // Close the read ends. On `close` this is a no-op, but on the
          // timeout path the SIGKILL reaps only the direct child: a surviving
          // grandchild still holds the write ends and keeps writing, and
          // handlers left installed would go on appending to `stdout` /
          // `stderr` long after this promise resolved — an unbounded heap
          // leak in a long-lived host, and one that also keeps the abandoned
          // grandchild alive by draining what it writes.
          child.stdout?.destroy()
          child.stderr?.destroy()
          resolve({ ...result, stdout, stderr: stderr || stderrFallback || '' })
        }
        if (opts.timeoutMs !== undefined) {
          // Deliberately NOT unref'd: an unref'd timer does not reliably fire
          // on every Bun version. It needs no unref anyway — `finish` clears
          // it on close and on error, so it can never outlive the child.
          timer = setTimeout(() => {
            // SIGKILL, not the default SIGTERM: the contract is a hard cap and
            // the child is by assumption already hung, so a signal it may trap
            // or ignore is no cap at all.
            child.kill('SIGKILL')
            // Settle here rather than leaving it to `close`. `close` waits for
            // the stdio pipes to hit EOF, and those pipes are not ours to
            // wait on: if the child forked (`sh -c "cmd &"`, and `/bin/sh`
            // implementations differ on whether they exec or fork), the
            // grandchild survives the kill still holding the write ends, and
            // `close` does not fire until it exits. Measured: killing at
            // 250ms, `exit` lands at 255ms but `close` at 5022ms — the cap
            // silently degrades to the runtime of the very process it was
            // meant to bound. A hard cap must be enforced on the deadline,
            // not on stdio a hung process controls, so we resolve with the
            // output captured so far and let the kill land in the background.
            finish({ exitCode: 1, neverExited: true })
          }, opts.timeoutMs)
        }
        child.stdout?.on('data', (d: Buffer) => {
          stdout += outDecoder.write(d)
        })
        child.stderr?.on('data', (d: Buffer) => {
          stderr += errDecoder.write(d)
        })
        child.on('error', (err) => {
          // A spawn failure or an abort: no exit code was ever reported, so
          // the 1 is this seam's stand-in and says so.
          finish({ exitCode: 1, neverExited: true }, err.message)
        })
        child.on('close', (code) => {
          finish(
            {
              exitCode: code ?? 1,
              ...(code === null ? { neverExited: true as const } : {}),
            },
            stdinError?.message,
          )
        })
        // `child.stdin` is its own emitter — an `error` on it never reaches the
        // `child.on("error")` handler above, and an unhandled `error` on an
        // emitter is rethrown as an uncaught exception that takes the host
        // process down. A child that closes its read end before `input` drains
        // (it exits, or closes fd 0) fails the write with EPIPE. That is not a
        // command failure: the child ran, and its own exit code is the result
        // `close` still delivers. But it does mean the child read only part of
        // `input`, so the message rides out on stderr when the child wrote none
        // of its own, the way a spawn error already does. (An EPIPE that lands
        // after the promise settles is only swallowed — nothing left to report
        // it on.)
        child.stdin?.on('error', (err) => {
          stdinError = err
        })
        if (opts.input !== undefined) child.stdin?.end(opts.input)
        else child.stdin?.end()
      })
    },
  }
}

/** Async twin of `runChecked` — throws the same `CommandFailed`. */
export async function runCheckedAsync(
  runner: AsyncCommandRunner,
  argv: string[],
  opts: AsyncCommandRunOptions,
): Promise<CommandResult> {
  const result = await runner.run(argv, opts)
  if (result.exitCode !== 0) throw new CommandFailed(argv, result)
  return result
}

/**
 * View a sync runner through the async seam (`signal` is ignored — a sync
 * runner cannot be cancelled mid-flight). Lets tests reuse one recording fake
 * for both doors, and lets async call paths accept a host's sync runner.
 */
export function asAsync(runner: CommandRunner): AsyncCommandRunner {
  return {
    run: (argv, opts) => Promise.resolve(runner.run(argv, opts)),
  }
}
