# @sksizer/command-seam

An injectable subprocess seam for external binaries. Four doors — capture
(sync and async), stream, and managed-process — with a hard timeout that
actually fires (the capture and streaming doors) and failures flattened into
a result rather than thrown.

```ts
import { spawnRunner, runChecked } from "@sksizer/command-seam";

const git = spawnRunner("git");

// Non-throwing door: the caller reads exitCode.
const r = git.run(["rev-parse", "HEAD"], { cwd });
if (r.exitCode === 0) console.log(r.stdout.trim());

// Checked door: throws CommandFailed, with argv and the full result attached.
runChecked(git, ["push", "origin", "main"], { cwd, timeoutMs: 30_000 });
```

## Why a seam

"Shell out to git" is a capability, not an ambient fact. Making it a
parameter means production wires a real spawn, tests inject a fake, and a
host with its own process supervision injects that — without any of them
touching the code in between.

```ts
const fake: CommandRunner = {
  run: (argv) => ({ exitCode: 0, stdout: recorded[argv.join(" ")] ?? "", stderr: "" }),
};
```

## Both doors, one vocabulary

`CommandResult`, `CommandRunOptions`, and `CommandFailed` are shared, so a
call site can move between sync and async without re-learning the contract,
and a single `instanceof CommandFailed` catches failures from either.

| | sync | async |
| --- | --- | --- |
| runner | `CommandRunner` | `AsyncCommandRunner` |
| default | `spawnRunner(binary)` | `spawnRunnerAsync(binary)` |
| checked | `runChecked` | `runCheckedAsync` |
| cancellation | — | `signal: AbortSignal` |

### Reporting a failure

`CommandFailed.message` interpolates stderr only, and several commands write
the sentence that explains the failure to stdout instead — a rejecting git
hook, `git commit` on a clean tree, `git apply --check`. Report `e.detail`,
which joins both streams, trimmed, dropping empty ones — a rejecting hook is
the case where each carries a distinct half.

```ts
catch (e) {
  if (e instanceof CommandFailed) report(e.detail);
}
```

`asAsync(syncRunner)` views a sync runner through the async seam, so one
recording fake serves both suites.

Sequential one-shots should stay on the sync door: blocking costs them
nothing and keeps their call graphs uncolored. The async door is for
long-lived processes, where a blocking `spawnSync` would freeze the event
loop, and for fanning network-bound calls out concurrently.

## Contract

- **Neither door rejects on command failure.** A missing binary, a timeout
  kill, or an abort degrades to a non-zero `exitCode`. When the child
  produced no stderr of its own, the spawn error's message is put there — a
  failed run always says *something*, because silent empty output at exit 1
  is indistinguishable from a command that genuinely exited 1. A child that
  closes its read end before `input` drains is reported the same way: the
  child's own exit code stays the result (it ran), and the write's EPIPE
  lands on an otherwise-empty stderr, since it means the child read only
  part of `input`.
  A result whose child never reported a status also carries
  `neverExited: true`: the `exitCode` is the seam's stand-in, not the
  command's, so a caller that reads particular exit codes as answers can tell
  the two apart.
- **`cwd` is mandatory.** The runner has no ambient default.
- **`timeoutMs` is a hard cap.** It is enforced in-process with an explicit
  timer and a `SIGKILL`, and the async door settles on the deadline rather
  than on stdio EOF — a killed child's surviving grandchild can hold the
  pipes open long past the cap, which silently degrades the bound to the
  runtime of the very process it was meant to bound.
- **argv is never re-parsed as a shell.** Arguments containing spaces,
  metacharacters, or `$()` are inert.
- **Capture, stream, or manage — pick the door that matches the site.** The
  capture doors (above) are for a command whose output the caller reads. The
  streaming and managed-process doors below are for a site the capture doors
  never covered: live output the operator must see, or a process the caller
  supervises rather than waits on. A site that needs neither — non-uniform
  stdio wiring a plain inherit can't express — is the rare, genuine
  `@sdlc:ignore-spawn` exception.

## Streaming: live output, no capture

For a build, a test run, or an interactive handoff — anywhere the capture
doors would withhold everything until the child exited:

```ts
import { streamRunner } from "@sksizer/command-seam";

const astro = streamRunner("bunx");
const { exitCode } = astro.run(["astro", "build"], { cwd });
```

`stdio` is always fully inherited (stdin, stdout, stderr); the result carries
only `exitCode` (and `neverExited`, mirroring the capture doors) — there is no
output left to report. Same injectable-factory shape as `spawnRunner`, so a
test injects a `StreamRunner` fake the same way.

## Managed process: a handle to something still running

For a long-lived child the caller supervises instead of waiting on:

```ts
import { managedProcessRunner } from "@sksizer/command-seam";

const proc = managedProcessRunner("some-server").run(["--port", "4000"], {
  cwd,
  detached: true, // makes `kill()` reap the whole process group
});

proc.pid; // number
await proc.exited; // { exitCode, signal, neverExited? }
proc.kill("SIGKILL");
```

`run()` returns as soon as the child exists — it never waits for it to
finish. `detached: true` makes the child its own process-group leader, so
`kill()` signals the whole group rather than just the direct child, the only
way to reap a grandchild the child itself forked and left behind.

## Running under `bun test`

Bun mis-wires child-process stdio once a large module graph is loaded in the
test process: the child runs and its filesystem effects land, but the parent
reads nothing back. `spawnRunner` detects `NODE_ENV=test` (which `bun test`
sets) and captures via the one path Bun does not corrupt — the child performs
its own `<in >out 2>err` redirects to temp files, which the seam reads back.
The production path is untouched.

The async door captures via pipes and is subject to the same bug; the
workaround is not ported there because no async call site has needed it yet.

## License

MIT
