/**
 * sRGB colour arithmetic.
 *
 * A colour is an {@link Rgba}: channels 0-255, alpha 0-1. Parsing accepts the
 * CSS syntaxes a browser reports; mixing and compositing happen in
 * gamma-encoded sRGB. Contrast is the WCAG 2 relative luminance ratio.
 */

/** A parsed colour. Channels are 0-255; `a` is 0-1. */
export interface Rgba {
  r: number
  g: number
  b: number
  a: number
}

const HEX_RE = /^#([0-9a-f]{3,8})$/i
const FUNC_RE = /^rgba?\(([^)]*)\)$/i
const COLOR_SRGB_RE = /^color\(srgb\s+([^)]*)\)$/i

function clampChannel(n: number): number {
  return Math.min(255, Math.max(0, Math.round(n)))
}

/**
 * Parse a hex (`#rgb`, `#rgba`, `#rrggbb`, `#rrggbbaa`), `rgb()`/`rgba()`, or
 * `color(srgb r g b [/ a])` colour. The last is what a browser's
 * `getComputedStyle` reports for anything resolved through `color-mix(in
 * srgb, …)` — Chromium's out-of-`rgb()`-precision serialisation, channels as
 * 0-1 floats rather than 0-255 integers. Throws on anything else: a colour in
 * a syntax the caller cannot resolve should fail loudly, not silently become
 * garbage.
 */
export function parseColor(css: string): Rgba {
  const text = css.trim()
  const hex = HEX_RE.exec(text)
  if (hex) {
    const digits = hex[1]!
    if (digits.length === 3 || digits.length === 4) {
      const [r, g, b, a] = [...digits].map((d) => Number.parseInt(d + d, 16))
      return { r: r!, g: g!, b: b!, a: a === undefined ? 1 : a / 255 }
    }
    if (digits.length === 6 || digits.length === 8) {
      const pair = (i: number) => Number.parseInt(digits.slice(i, i + 2), 16)
      return {
        r: pair(0),
        g: pair(2),
        b: pair(4),
        a: digits.length === 8 ? pair(6) / 255 : 1,
      }
    }
    throw new Error(`color: unsupported hex colour '${css}'`)
  }
  const colorSrgb = COLOR_SRGB_RE.exec(text)
  if (colorSrgb) {
    // `color(srgb …)` channels are 0-1 floats (or a percentage of 1), unlike
    // `rgb()`'s 0-255 integers — scale to the same 0-255 representation Rgba
    // uses everywhere else.
    const parts = colorSrgb[1]!.split(/[\s/]+/).filter((p) => p.length > 0)
    if (parts.length < 3) throw new Error(`color: unparseable colour '${css}'`)
    const unit = (part: string): number => {
      const pct = part.endsWith('%')
      const n = Number.parseFloat(pct ? part.slice(0, -1) : part)
      if (Number.isNaN(n)) throw new Error(`color: unparseable colour '${css}'`)
      return pct ? n / 100 : n
    }
    return {
      r: unit(parts[0]!) * 255,
      g: unit(parts[1]!) * 255,
      b: unit(parts[2]!) * 255,
      a: parts[3] === undefined ? 1 : unit(parts[3]),
    }
  }
  const func = FUNC_RE.exec(text)
  if (func) {
    const parts = func[1]!.split(/[\s,/]+/).filter((p) => p.length > 0)
    if (parts.length < 3) throw new Error(`color: unparseable colour '${css}'`)
    // A part is a percentage or a plain number, and the two scale differently:
    // a channel's 100% is 255 while an alpha's 100% is 1. Reading `50%` with a
    // bare parseFloat yields 50, which is a legal-looking channel and a legal-
    // looking alpha, so the mistake never surfaces as an error.
    const value = (part: string, full: number): number => {
      const pct = part.endsWith('%')
      const n = Number.parseFloat(pct ? part.slice(0, -1) : part)
      if (Number.isNaN(n)) throw new Error(`color: unparseable colour '${css}'`)
      return pct ? (n / 100) * full : n
    }
    return {
      r: value(parts[0]!, 255),
      g: value(parts[1]!, 255),
      b: value(parts[2]!, 255),
      a: parts[3] === undefined ? 1 : value(parts[3], 1),
    }
  }
  throw new Error(`color: unsupported colour syntax '${css}'`)
}

/** Format as `#rrggbb`, or `#rrggbbaa` when the alpha is not fully opaque. */
export function formatHex(color: Rgba): string {
  const hex = (n: number) => clampChannel(n).toString(16).padStart(2, '0')
  const rgb = `#${hex(color.r)}${hex(color.g)}${hex(color.b)}`
  if (color.a >= 1) return rgb
  return `${rgb}${hex(color.a * 255)}`
}

/**
 * Blend `amount` (0-1) of `overlay` into `base`, per channel, in sRGB.
 *
 * Equivalent to `color-mix(in srgb, base, overlay <amount>%)` for opaque
 * inputs.
 */
export function mixColors(base: Rgba, overlay: Rgba, amount: number): Rgba {
  const t = Math.min(1, Math.max(0, amount))
  const lerp = (x: number, y: number) => x + (y - x) * t
  return {
    r: lerp(base.r, overlay.r),
    g: lerp(base.g, overlay.g),
    b: lerp(base.b, overlay.b),
    a: lerp(base.a, overlay.a),
  }
}

/** Replace a colour's alpha, keeping its channels. */
export function withAlpha(color: Rgba, alpha: number): Rgba {
  return { ...color, a: Math.min(1, Math.max(0, alpha)) }
}

/**
 * Convert a `[r, g, b, a]` pixel — `ImageData.data`'s layout, alpha 0-255 —
 * into the canonical `Rgba`, whose alpha is 0-1.
 */
export function fromPixel(px: ArrayLike<number>): Rgba {
  if (px.length < 4) throw new Error(`color: a pixel needs 4 channels, got ${px.length}`)
  return { r: px[0]!, g: px[1]!, b: px[2]!, a: px[3]! / 255 }
}

/**
 * Composite `src` over an OPAQUE `ground` (source-over, straight alpha),
 * returning an opaque colour.
 *
 * Contrast is a property of painted pixels, and a colour declared with alpha
 * never paints its own channels. The mixed channels are rounded to 8 bits, so
 * the result is the pixel the browser actually paints rather than the
 * unrounded maths.
 */
export function compositeOver(src: Rgba, ground: Rgba): Rgba {
  if (src.a >= 1) return src
  const mix = (s: number, g: number) => Math.round(s * src.a + g * (1 - src.a))
  return { r: mix(src.r, ground.r), g: mix(src.g, ground.g), b: mix(src.b, ground.b), a: 1 }
}

/** WCAG 2 relative luminance. Alpha is ignored — composite first if it matters. */
export function relativeLuminance(color: Rgba): number {
  const channel = (v: number) => {
    const s = v / 255
    return s <= 0.04045 ? s / 12.92 : ((s + 0.055) / 1.055) ** 2.4
  }
  return 0.2126 * channel(color.r) + 0.7152 * channel(color.g) + 0.0722 * channel(color.b)
}

/** WCAG 2 contrast ratio between two opaque colours, 1-21. */
export function contrastRatio(a: Rgba | string, b: Rgba | string): number {
  const ca = typeof a === 'string' ? parseColor(a) : a
  const cb = typeof b === 'string' ? parseColor(b) : b
  const la = relativeLuminance(ca)
  const lb = relativeLuminance(cb)
  const [hi, lo] = la >= lb ? [la, lb] : [lb, la]
  return (hi + 0.05) / (lo + 0.05)
}
