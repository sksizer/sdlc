# @sksizer/color

sRGB colour arithmetic. Parses the CSS colour syntaxes a browser reports —
hex, `rgb()`/`rgba()`, and the `color(srgb …)` form `getComputedStyle` returns
for anything resolved through `color-mix()` — into one canonical `Rgba`
(channels 0-255, alpha 0-1).

Mixing matches `color-mix(in srgb, …)`: per-channel interpolation in
gamma-encoded sRGB. `compositeOver` is source-over with straight alpha, so a
translucent colour can be measured as the pixel it actually paints. Contrast
is the WCAG 2 relative luminance ratio. No dependencies.
