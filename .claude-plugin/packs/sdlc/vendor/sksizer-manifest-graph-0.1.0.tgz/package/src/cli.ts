#!/usr/bin/env bun
/**
 * Dump a project's `SystemGraph` payload as JSON.
 *
 * This is how the system-graph lab's fixtures are regenerated. It exists so
 * that producing one is a command rather than a throwaway test dropped into
 * the tauri crate, which is what it took while the walker was Rust-only.
 *
 *   bun packages/ts/manifest-graph/src/cli.ts . --out repo.json
 *   bun packages/ts/manifest-graph/src/cli.ts . --external --out repo-external.json
 */

import { writeFile } from 'node:fs/promises'
import { buildSystemGraph } from './system-graph.ts'

interface Args {
  root: string
  external: boolean
  out: string | null
  pretty: boolean
}

function parseArgs(argv: string[]): Args {
  const args: Args = { root: '.', external: false, out: null, pretty: false }
  const positional: string[] = []
  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]!
    if (arg === '--external') args.external = true
    else if (arg === '--pretty') args.pretty = true
    else if (arg === '--out') args.out = argv[++i] ?? null
    else if (arg === '--help' || arg === '-h') {
      console.log(
        'usage: manifest-graph <root> [--external] [--pretty] [--out FILE]\n\n' +
          "  <root>        project to walk (default '.')\n" +
          '  --external    also materialise registry dependencies\n' +
          '  --pretty      indent the JSON\n' +
          '  --out FILE    write to FILE instead of stdout',
      )
      process.exit(0)
    } else if (arg.startsWith('-')) {
      console.error(`unknown flag: ${arg}`)
      process.exit(2)
    } else positional.push(arg)
  }
  if (positional.length > 0) args.root = positional[0]!
  return args
}

const args = parseArgs(process.argv.slice(2))
const graph = await buildSystemGraph(args.root, { includeExternal: args.external })
const json = args.pretty ? JSON.stringify(graph, null, 2) : JSON.stringify(graph)

if (args.out === null) {
  console.log(json)
} else {
  await writeFile(args.out, json)
  // To stderr, so `--out` plus a redirect still produces a clean file.
  console.error(
    `${args.out}: ${graph.nodes.length} nodes, ${graph.edges.length} edges, ` +
      `${graph.manifests_scanned} manifests scanned`,
  )
}
