/** The filesystem half: find manifests, parse each into a `ManifestInfo`. */

import { readdir, readFile } from 'node:fs/promises'
import { join, relative, sep } from 'node:path'
import { parse as parseToml } from 'smol-toml'
import {
  byteCompare,
  type DepDecl,
  type DepKind,
  type Ecosystem,
  type ManifestInfo,
} from './model.ts'

/** Directory names the walk always skips. */
export const DEFAULT_EXCLUDES = [
  'node_modules',
  '.git',
  'target',
  'dist',
  '.nuxt',
  '.output',
  '.sdlc',
  '.claude',
] as const

export interface WalkOptions {
  /** Additional directory names to skip, merged with `DEFAULT_EXCLUDES`. */
  exclude?: string[]
}

/**
 * Recursively find and parse every `package.json` and `Cargo.toml` under
 * `root`. Skips the default excluded directory names (plus any in
 * `options.exclude`) and symlinked entries. A malformed manifest becomes an
 * entry with its `error` field set — the walk never throws for one.
 *
 * Results are sorted by `dir` (then path) for deterministic output.
 */
export async function walkManifests(
  root: string,
  options: WalkOptions = {},
): Promise<ManifestInfo[]> {
  const excluded = new Set<string>([...DEFAULT_EXCLUDES, ...(options.exclude ?? [])])
  const found: ManifestInfo[] = []
  await walkDir(root, root, excluded, found)
  found.sort((a, b) => byteCompare(a.dir, b.dir) || byteCompare(a.path, b.path))
  return found
}

async function walkDir(
  root: string,
  dir: string,
  excluded: Set<string>,
  out: ManifestInfo[],
): Promise<void> {
  let entries
  try {
    entries = await readdir(dir, { withFileTypes: true })
  } catch {
    return // unreadable directory — skip, never abort the walk
  }
  for (const entry of entries) {
    if (entry.isSymbolicLink()) continue // avoid cycles; symlinked trees are someone else's manifests
    const full = join(dir, entry.name)
    if (entry.isDirectory()) {
      if (!excluded.has(entry.name)) await walkDir(root, full, excluded, out)
    } else if (entry.name === 'package.json' || entry.name === 'Cargo.toml') {
      out.push(await parseManifest(root, full, entry.name === 'package.json' ? 'node' : 'rust'))
    }
  }
}

async function parseManifest(
  root: string,
  path: string,
  ecosystem: Ecosystem,
): Promise<ManifestInfo> {
  const base: ManifestInfo = {
    path,
    // `/`-separated whatever the host does, because this string is a payload
    // field the peer implementations are diffed on.
    dir: relative(root, join(path, '..')).split(sep).join('/'),
    ecosystem,
    name: null,
    version: null,
    private: false,
    description: null,
    workspaces: [],
    entry: { main: null, types: null },
    isNuxtLayer: false,
    hasBin: false,
    deps: [],
    error: null,
  }
  let raw: string
  try {
    raw = await readFile(path, 'utf8')
  } catch (e) {
    return { ...base, error: `unreadable: ${message(e)}` }
  }
  try {
    return ecosystem === 'node' ? parseNodeManifest(base, raw) : parseCargoManifest(base, raw)
  } catch (e) {
    return { ...base, error: `parse failed: ${message(e)}` }
  }
}

function message(e: unknown): string {
  return e instanceof Error ? e.message : String(e)
}

/**
 * A dependency table's entries, ordered by key.
 *
 * Both of the Rust peer's parsers hand their tables back as a `BTreeMap`, so
 * sorted is the reference order — and dep order is part of the payload the two
 * implementations are diffed on. Sorting on the TABLE KEY matters for cargo,
 * where a renamed dependency's key is the alias and its `name` is the real
 * crate.
 */
function sortedEntries(table: unknown): Array<[string, unknown]> {
  return Object.entries(table as Record<string, unknown>).sort(([a], [b]) => byteCompare(a, b))
}

/**
 * A real key/value table, not an array.
 *
 * `typeof [] === 'object'`, so the array check is the load-bearing half: the
 * Rust peer's `as_object()` / `as_table()` reject an array outright, and
 * without this an array-valued table would yield index-named entries.
 */
function isTable(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

// ---------------------------------------------------------------------------
// node — package.json
// ---------------------------------------------------------------------------

const NODE_DEP_FIELDS: ReadonlyArray<[string, DepKind]> = [
  ['dependencies', 'prod'],
  ['devDependencies', 'dev'],
  ['peerDependencies', 'peer'],
  ['optionalDependencies', 'optional'],
]

function parseNodeManifest(base: ManifestInfo, raw: string): ManifestInfo {
  const pkg = JSON.parse(raw) as Record<string, unknown>
  if (typeof pkg !== 'object' || pkg === null || Array.isArray(pkg)) {
    throw new Error('package.json is not a JSON object')
  }

  const deps: DepDecl[] = []
  for (const [field, kind] of NODE_DEP_FIELDS) {
    const table = pkg[field]
    if (!isTable(table)) continue
    for (const [name, spec] of sortedEntries(table)) {
      const specifier = typeof spec === 'string' ? spec : String(spec)
      deps.push({ name, kind, specifier, specifierKind: classifyNodeSpecifier(specifier) })
    }
  }

  // node `workspaces` is either an array of globs or `{ packages: [...] }`.
  const ws = pkg['workspaces']
  const workspaces = Array.isArray(ws)
    ? ws.filter((g): g is string => typeof g === 'string')
    : typeof ws === 'object' &&
        ws !== null &&
        Array.isArray((ws as Record<string, unknown>)['packages'])
      ? ((ws as Record<string, unknown>)['packages'] as unknown[]).filter(
          (g): g is string => typeof g === 'string',
        )
      : []

  const main = pkg['main']
  const bin = pkg['bin']
  return {
    ...base,
    name: typeof pkg['name'] === 'string' ? pkg['name'] : null,
    version: typeof pkg['version'] === 'string' ? pkg['version'] : null,
    private: pkg['private'] === true,
    description: typeof pkg['description'] === 'string' ? pkg['description'] : null,
    workspaces,
    entry: {
      main: typeof main === 'string' ? main : null,
      types: typeof pkg['types'] === 'string' ? pkg['types'] : null,
    },
    isNuxtLayer: typeof main === 'string' && main.endsWith('nuxt.config.ts'),
    hasBin: typeof bin === 'string' || (isTable(bin) && Object.keys(bin).length > 0),
    deps,
  }
}

function classifyNodeSpecifier(spec: string): DepDecl['specifierKind'] {
  if (spec.startsWith('workspace:')) return 'workspace'
  if (spec.startsWith('file:')) return 'file'
  // git/github/http/npm-alias/link specifiers all carry a ':' or start like a
  // path; a plain registry range or dist-tag never does.
  if (spec.includes(':') || spec.startsWith('.') || spec.startsWith('/')) return 'other'
  return 'registry'
}

// ---------------------------------------------------------------------------
// rust — Cargo.toml
// ---------------------------------------------------------------------------

const CARGO_DEP_TABLES: ReadonlyArray<[string, DepKind]> = [
  ['dependencies', 'prod'],
  ['dev-dependencies', 'dev'],
  ['dev_dependencies', 'dev'], // deprecated cargo alias, still accepted
  ['build-dependencies', 'build'],
  ['build_dependencies', 'build'],
]

function parseCargoManifest(base: ManifestInfo, raw: string): ManifestInfo {
  const doc = parseToml(raw) as Record<string, unknown>

  const deps: DepDecl[] = []
  for (const [table, kind] of CARGO_DEP_TABLES) {
    const t = doc[table]
    if (!isTable(t)) continue
    for (const [key, spec] of sortedEntries(t)) {
      deps.push(cargoDep(key, spec, kind))
    }
  }

  const pkg = (
    typeof doc['package'] === 'object' && doc['package'] !== null ? doc['package'] : {}
  ) as Record<string, unknown>
  const workspace = (
    typeof doc['workspace'] === 'object' && doc['workspace'] !== null ? doc['workspace'] : {}
  ) as Record<string, unknown>
  const members = workspace['members']
  return {
    ...base,
    name: typeof pkg['name'] === 'string' ? pkg['name'] : null,
    // `version.workspace = true` parses as a table — only plain strings count.
    version: typeof pkg['version'] === 'string' ? pkg['version'] : null,
    private: pkg['publish'] === false,
    description: typeof pkg['description'] === 'string' ? pkg['description'] : null,
    workspaces: Array.isArray(members)
      ? members.filter((m): m is string => typeof m === 'string')
      : [],
    entry: { main: null, types: null },
    isNuxtLayer: false,
    hasBin: Array.isArray(doc['bin']) && doc['bin'].length > 0,
    deps,
  }
}

function cargoDep(key: string, spec: unknown, kind: DepKind): DepDecl {
  if (typeof spec === 'string') {
    return { name: key, kind, specifier: spec, specifierKind: 'registry' }
  }
  const t = (typeof spec === 'object' && spec !== null ? spec : {}) as Record<string, unknown>
  // A renamed dep (`alias = { package = "real" }`) matches by its real name.
  const name = typeof t['package'] === 'string' ? t['package'] : key
  if (typeof t['path'] === 'string') {
    return { name, kind, specifier: t['path'], specifierKind: 'path' }
  }
  if (t['workspace'] === true) {
    return { name, kind, specifier: 'workspace', specifierKind: 'workspace' }
  }
  if (typeof t['git'] === 'string') {
    return { name, kind, specifier: t['git'], specifierKind: 'other' }
  }
  if (typeof t['version'] === 'string') {
    return { name, kind, specifier: t['version'], specifierKind: 'registry' }
  }
  return { name, kind, specifier: '', specifierKind: 'other' }
}
