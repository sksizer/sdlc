# @sksizer/manifest-graph

Point it at a directory tree; it finds every `package.json` and `Cargo.toml`,
parses each into a typed `ManifestInfo`, builds the dependency graph they
declare, and derives the containment tree their layout implies.

```ts
import { applyContainment, buildDependencyGraph, walkManifests } from '@sksizer/manifest-graph'

const manifests = await walkManifests('/path/to/monorepo')
const graph = buildDependencyGraph(manifests, { includeExternal: false })
applyContainment(graph)

for (const edge of graph.edges) console.log(`${edge.from} -> ${edge.to} (${edge.kind})`)
```

Malformed manifests never abort a walk — they come back as entries carrying an
`error`, so one bad file cannot blank a whole view.

## Two relations, two shapes

Dependencies are a mesh and live on `graph.edges`. Containment is a tree and
lives on `GraphNode.parent`. A renderer that folds a container needs the tree,
and a tree smuggled in as edges has to be re-derived by every consumer.

`applyContainment` adds two synthetic node populations: one `repo` root
standing for the checkout, and `group` nodes for directories that hold
manifests but declare none (`packages/ts`, `apps`). A group with a single child
is collapsed away, so `…/runners/sqlite/builder` reports one node rather than
three. Externals stay outside the tree — a registry package is not *within* the
repo — optionally gathered under one group per ecosystem.

## The wire payload

`buildSystemGraph` runs all three passes and flattens the result into the
`SystemGraph` payload the system-graph viewer reads: snake_case field names,
node labels resolved, manifests reduced to the handful of fields the view uses.

`src/cli.ts` dumps that payload as JSON. This is how the system-graph lab's
fixtures are regenerated:

```sh
bun packages/ts/manifest-graph/src/cli.ts . --out repo.json
bun packages/ts/manifest-graph/src/cli.ts . --external --out repo-external.json
```

## Peer of the Rust crate

`solutions/ontological/crates/manifest-graph` is the same library in Rust, and
is what SDF's system-graph service actually calls. This package is the peer
implementation: same passes, same model, same output.

The two are held together by ONE fixture tree, which the crate's
`tests/mini_repo.rs` and this package's `test/mini-repo.test.ts` both walk while
asserting the same contract. A change to one that the other does not match
fails in the other's suite.

The tree lives at `solutions/ontological/crates/manifest-graph/tests/mini-repo`
and is reachable from here as `test/fixtures/mini-repo`, a relative symlink —
so each suite reads it by a local path and there is still only one copy to keep
correct. Two copies would look tidier and would quietly stop gating anything.

The symlink is invisible to a walk: `walkManifests` resolves the root it is
handed but skips symlinked entries it meets on the way down, so a repo-wide
walk still meets these nine manifests exactly once, under the crate. Both
implementations do this, and the whole-repo counts are identical with the
symlink present.

For a whole-repo comparison, dump both and diff:

```sh
cargo run -q -p manifest-graph --example dump -- . > /tmp/rust.json
bun packages/ts/manifest-graph/src/cli.ts . > /tmp/ts.json
```

They are not literally byte-comparable — the Rust example emits the crate's
`DependencyGraph` with snake_case field names, this CLI emits the flattened
`SystemGraph` — but node order, edge order, warning text and every field value
agree. Two ordering rules exist only to keep that true, and should not be
"simplified" away:

- **Dependency tables are read in sorted key order.** Both of Rust's parsers
  hand a table back as a `BTreeMap`; JavaScript's preserve document order. For
  cargo the sort is on the table key, which for a renamed dependency is the
  alias rather than the real crate name.
- **String ordering is byte-wise** (`byteCompare`), which is what Rust's
  `String::cmp` gives. JavaScript's default sort compares UTF-16 code units and
  disagrees above the BMP.

One difference is expected and not worth chasing: a malformed manifest's
`error` text is whatever the underlying parser said, and `JSON.parse` and
`serde_json` word it differently. The contract is that the field is set.
