# @sksizer/agent-dev

Verify a changeset against the rules that actually govern it.

A repository's rules are scattered across nested `CLAUDE.md` files, `AGENTS.md`
files, and whatever formal standards corpus it keeps. They are read while code
is being written and forgotten by the time it is committed. This package finds
every rule source whose scope encloses a changed file and dispatches one
headless judgement per source, over exactly the files it covers.

```ts
import {
  changedFiles, defaultBase, discoverSources, fileDiffs,
  instructionFiles, verify, DEFAULT_CONFIG,
} from "@sksizer/agent-dev";
import { Git } from "@sksizer/easy-git";

const git = new Git(projectRoot);
const base = defaultBase(git);
const files = changedFiles(git, base);

const sources = await discoverSources([instructionFiles()], { projectRoot, changedFiles: files });
const run = await verify({
  projectRoot, sources, changedFiles: files,
  diffs: fileDiffs(git, base, files),
  config: { ...DEFAULT_CONFIG, model: "claude-haiku-4-5-20251001" },
});

run.findings;   // merged, ordered broad-to-specific
run.skipped;    // sources proven irrelevant — these cost nothing
run.degraded;   // true when a judgement failed to complete
```

## The `dfv` command

The package ships its own CLI. It needs nothing but a git repo — the
instruction-file provider reads the `CLAUDE.md` / `AGENTS.md` files already
there.

```bash
dfv                    # judge uncommitted work
dfv --dry-run          # what it would judge, and what that would cost — free
dfv --base main        # the whole branch
dfv --blocking         # exit non-zero on findings at or above the floor
dfv --json             # the run as JSON
dfv --max-files 6      # split wide rule sources into smaller judgements
```

`--base` takes any rev: a branch name for the whole branch, `@{u}` to include
unpushed commits, a sha or `HEAD~3` to reach further back. Omitted, it compares
against `HEAD` — uncommitted work only.

`dfv` ships one provider by design. Another rule corpus is a
`RuleSourceProvider` supplied by whatever owns it; teaching this binary about
one would put that knowledge in a package built to stay blind to it.

## The model

Selection is set intersection, not a tree walk. Every rule source declares the
paths it governs, and `@sksizer/intersect` decides which ones the changeset
touches.

| Rule source | Scope |
|---|---|
| `CLAUDE.md` / `AGENTS.md` at directory `D` | `D/**`, implicitly |
| Anything else | whatever its provider declares |

Given a changeset touching `lib/model/read.ts`, `skills/task-work/SKILL.md`,
and `apps/pumice/src/main.rs`:

```text
                                    read.ts  SKILL.md  main.rs
  CLAUDE.md /                          ●         ●        ●     → job: all three
  CLAUDE.md /docs                      ·         ·        ·     → dropped, costs nothing
  CLAUDE.md /apps/pumice               ·         ·        ●     → job: main.rs
  CLAUDE.md /lib                       ●         ·        ·     → job: read.ts
  CLAUDE.md /skills                    ·         ●        ·     → job: SKILL.md
  standard, skills/**/SKILL.md         ·         ●        ·     → job: SKILL.md
```

Two things fall out. `docs/CLAUDE.md` is proven irrelevant by pattern algebra,
so no model call is made for it. And `SKILL.md` is judged three times, by three
different rule sets — the root rules, the skills-directory rules, and the
standard. That overlap is the point: each judge sees one ruleset and is asked
about nothing else.

Jobs are flat and isolated. Each carries only its own rule text, so no judge
can silently overrule another, and a finding is never reported twice for the
same reason. Concurrency is a rate limit rather than a correctness concern —
verification is read-only and no job touches the working tree.

## Sharding

A rule source scoped at the repo root governs every changed file, so on a wide
branch it draws the entire changeset into one prompt. `maxFilesPerJob` (default
12, `--max-files` on the CLI) splits such a source into several jobs, each
judged against the same rules over its own slice of the files.

The constraint being managed is attention, not context. A judge handed sixty
diffs reasons worse about each one than a judge handed a dozen, well before any
window fills. The wide job also sets the run's wall clock, because everything
else finishes while it is still reading.

Sharding is not free, and the trade is explicit: every shard re-sends the full
rule text, so total prompt volume goes up while each individual judgement gets
smaller and they run at the same time. It buys latency and judgement quality
with tokens.

Findings are attributed to the rule source, never to the shard, so a split is
invisible downstream — the report shows one row per source, and the merge
behaves as if the source had been judged once.

Sharding and `concurrency` are coupled, and this is the part worth getting
right. A judgement costs roughly the same wall clock whatever its prompt size,
because the time goes on starting an agent and having it reason rather than on
reading — so a run costs about `ceil(jobs / concurrency)` of those, and
splitting a job in six does not divide its time by six. Measured on a 63-file
branch:

| Jobs | Concurrency | Waves | Wall clock |
|---|---|---|---|
| 12 (unsharded) | 6 | 2 | 190s |
| 30 (sharded) | 12 | 3 | 253s |
| 30 (sharded) | 32 | 1 | 155s |

Sharding under a cap below the job count is the one configuration that loses to
not sharding at all. The default `concurrency` is therefore a ceiling sized for
a branch-wide run to be a single wave, not a target — a small changeset plans
few jobs and opens only those.

## Providers

The package ships one provider, for instruction files, because every repository
has those. Every other rule corpus arrives through `RuleSourceProvider`, so
`agent-dev` never learns that corpus exists:

```ts
interface RuleSourceProvider {
  id: string;
  discover(ctx: DiscoveryContext): Promise<RuleSource[]>;
}
```

Downstream — planner, dispatch, findings — sees only `RuleSource`: an id, some
prose, and the patterns it governs. `@sksizer/sdlc` registers a `sdlcStandards()`
provider this way, and it lives there rather than here because standards are an
SDLC concept.

Instruction files that only redirect (`See @./README.md`) have their `@path`
imports inlined, the way Claude Code reads them; otherwise those become jobs
with no rules in them. `[[wikilinks]]` are deliberately not followed — they are
cross-references, not imports, and following them would pull a whole docs tree
into one prompt.

## Dispatch

Judgements go through `@sksizer/agent-call`, so the engine is swappable
(`claude`, `codex`, `gemini`, `opencode`) and the exact invocation is
inspectable before anything spawns. `verify` accepts a `dispatch` seam, which
is how the whole pipeline is tested without a model.

Findings are validated, never cast: a judge that returns a malformed entry
loses that entry, not the rest, and one citing a file outside its own scope is
rejected.

## Prompt size

Sizes are measured in bytes, and reported as an estimated token count —
`estimateTokens` divides by a round constant. There is deliberately no
tokenizer: Anthropic publishes no local one for current Claude models, so the
exact count needs a `count_tokens` round-trip that would cost `--dry-run` its
one strong property, that it is free and offline. A third-party BPE would be
OpenAI's vocabulary, precise-looking and wrong; and with four engines behind
`agent-call`, no single tokenizer is correct for all of them anyway.

`maxPromptBytes` therefore stays denominated in bytes, which are exact and
engine-independent. When a real run's engine reports its own input-token count,
that lands on the outcome as `promptTokens` — the true cost of the call, and
not comparable to the estimate, since a CLI agent prepends its own system
prompt to whatever was sent.

## Testing

`bun test`. No test spawns a model — the dispatch seam is injected, and spec
construction is asserted through `agent-call`'s pure `planCall`.
