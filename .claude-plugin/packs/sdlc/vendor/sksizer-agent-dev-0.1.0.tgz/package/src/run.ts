/**
 * Discovery, dispatch, and collection — the one module that does IO.
 *
 * Fan-out is concurrency-capped. There is no correctness reason for the cap:
 * verification is read-only and no job touches the working tree, so jobs
 * cannot conflict with each other. It exists purely so a wide changeset does
 * not open thirty agent processes at once.
 */
import { adapterFor, BUILTIN_AGENTS, callAgent } from '@sksizer/agent-call'
import type { AgentCallSpec, AgentName, AgentResult } from '@sksizer/agent-call'

import { mergeFindings, parseFindings } from './findings.js'
import { planJobs } from './plan.js'
import { buildSpec, type FileDiff } from './prompt.js'
import type {
  DiscoveryContext,
  JobOutcome,
  RuleSource,
  RuleSourceProvider,
  VerifyConfig,
  VerifyJob,
  VerifyRun,
} from './types.js'

/** Collect rule sources from every provider, in registration order. */
export async function discoverSources(
  providers: readonly RuleSourceProvider[],
  ctx: DiscoveryContext,
): Promise<RuleSource[]> {
  const collected = await Promise.all(providers.map((p) => p.discover(ctx)))

  // Ids must be unique — the intersect registry throws on a duplicate at
  // construction, and a collision here means two providers disagree about
  // what they own. Surface it as that, not as an opaque registry error.
  const seen = new Map<string, string>()
  const sources: RuleSource[] = []
  collected.forEach((batch, i) => {
    const providerId = providers[i]?.id ?? 'unknown'
    for (const source of batch) {
      const owner = seen.get(source.id)
      if (owner !== undefined) {
        throw new Error(
          `rule source id '${source.id}' claimed by both '${owner}' and '${providerId}'`,
        )
      }
      seen.set(source.id, providerId)
      sources.push(source)
    }
  })
  return sources
}

/**
 * The dispatch seam.
 *
 * Defaults to a real `callAgent`. Injected in tests so the planner, the
 * concurrency cap, and finding attribution can be exercised without spawning
 * an agent.
 */
export type Dispatch = (spec: AgentCallSpec, config: VerifyConfig) => Promise<AgentResult>

const dispatchViaAgentCall: Dispatch = (spec, config) =>
  callAgent(adapterFor(engineName(config.engine)), spec)

/**
 * Narrow a configured engine name to one `adapterFor` accepts.
 *
 * `engine` is caller-supplied configuration, so it is an arbitrary string
 * until checked. Failing here names the valid set; letting it through would surface
 * as an opaque adapter error per job instead.
 */
function engineName(engine: string): AgentName {
  if (!(BUILTIN_AGENTS as readonly string[]).includes(engine)) {
    throw new Error(`unknown engine '${engine}' (expected one of: ${BUILTIN_AGENTS.join(', ')})`)
  }
  return engine as AgentName
}

export interface VerifyOptions {
  projectRoot: string
  sources: readonly RuleSource[]
  changedFiles: readonly string[]
  diffs: readonly FileDiff[]
  config: VerifyConfig
  /**
   * Per-job settings, when the caller scopes them more narrowly than the run.
   *
   * Called once per planned job. Only the dispatch fields are read per job —
   * engine, model, and timeout. `concurrency` and `exclude` stay run-level by
   * construction: the cap governs the whole fan-out, and exclusions are
   * applied before any job exists.
   */
  configFor?: (job: VerifyJob) => VerifyConfig
  /**
   * Plan and measure without dispatching anything.
   *
   * Every stage before the agent call is deterministic and free, so a dry run
   * can answer what would be judged, by which rules, at what prompt size —
   * the questions worth asking before paying for the answers.
   */
  dryRun?: boolean
  /** Called as each job settles, for progress output. */
  onJobSettled?: (outcome: JobOutcome) => void
  /** Override the agent call. Defaults to `callAgent` on `config.engine`. */
  dispatch?: Dispatch
}

/** Plan the run, dispatch every job, and collect the findings. */
export async function verify(options: VerifyOptions): Promise<VerifyRun> {
  const { jobs, skipped } = planJobs(options.sources, options.changedFiles, options.config)

  const dryRun = options.dryRun === true
  const outcomes = dryRun
    ? jobs.map((job) => measureJob(job, options))
    : await mapCapped(jobs, options.config.concurrency, (job) => runJob(job, options))

  return {
    jobs,
    outcomes,
    findings: mergeFindings(outcomes),
    skipped,
    degraded: outcomes.some((o) => o.error !== undefined),
    dryRun,
  }
}

/**
 * Everything about a job that is knowable without dispatching it.
 *
 * Prompt size is measured on the built prompt rather than the raw diff: what
 * matters is what the judge actually receives, rules and framing included.
 */
function prepare(
  job: VerifyJob,
  options: VerifyOptions,
): {
  config: VerifyConfig
  spec: ReturnType<typeof buildSpec>
  promptBytes: number
  oversize?: { bytes: number; limit: number }
} {
  const config = options.configFor?.(job) ?? options.config
  const spec = buildSpec(job, options.diffs, config, options.projectRoot)
  const promptBytes = Buffer.byteLength(spec.prompt, 'utf8')
  const oversize =
    config.maxPromptBytes > 0 && promptBytes > config.maxPromptBytes
      ? { bytes: promptBytes, limit: config.maxPromptBytes }
      : undefined
  return { config, spec, promptBytes, ...(oversize !== undefined ? { oversize } : {}) }
}

/** What a job would do, without doing it. */
function measureJob(job: VerifyJob, options: VerifyOptions): JobOutcome {
  const { promptBytes, oversize } = prepare(job, options)
  return {
    job,
    findings: [],
    durationMs: 0,
    promptBytes,
    ...(oversize !== undefined ? { oversize } : {}),
  }
}

async function runJob(job: VerifyJob, options: VerifyOptions): Promise<JobOutcome> {
  const { config, spec, promptBytes, oversize } = prepare(job, options)

  let outcome: JobOutcome
  try {
    const dispatch = options.dispatch ?? dispatchViaAgentCall
    const result = await dispatch(spec, config)
    // `callAgent` never throws on agent failure; it reports structurally. A
    // failed job degrades the run rather than aborting it, because a partial
    // set of real findings is worth more than none.
    outcome =
      result.error !== undefined
        ? {
            job,
            findings: [],
            error: `${result.error.reason}: ${result.error.detail}`,
            durationMs: result.durationMs,
            promptBytes,
            ...(oversize !== undefined ? { oversize } : {}),
          }
        : {
            job,
            findings: parseFindings(result.structured, job),
            durationMs: result.durationMs,
            promptBytes,
            ...(result.costUsd !== undefined ? { costUsd: result.costUsd } : {}),
            ...(result.usage?.inputTokens !== undefined
              ? { promptTokens: result.usage.inputTokens }
              : {}),
            ...(oversize !== undefined ? { oversize } : {}),
          }
  } catch (err) {
    // Reached only for a failure before the call — an unknown engine name,
    // most likely.
    outcome = {
      job,
      findings: [],
      error: err instanceof Error ? err.message : String(err),
      durationMs: 0,
      promptBytes,
      ...(oversize !== undefined ? { oversize } : {}),
    }
  }

  options.onJobSettled?.(outcome)
  return outcome
}

/**
 * `Promise.all` with a ceiling on in-flight work, preserving input order.
 *
 * Written out rather than pulled in: the repo has no concurrency-capped
 * helper to reuse, and its existing `Promise.all` fan-outs are uncapped —
 * fine for `gh`, not for N agent processes.
 */
async function mapCapped<T, R>(
  items: readonly T[],
  limit: number,
  fn: (item: T) => Promise<R>,
): Promise<R[]> {
  const results = new Array<R>(items.length)
  const width = Math.max(1, Math.min(limit, items.length))
  let next = 0

  await Promise.all(
    Array.from({ length: width }, async () => {
      for (;;) {
        const i = next++
        if (i >= items.length) return
        const item = items[i]
        if (item === undefined) return
        results[i] = await fn(item)
      }
    }),
  )
  return results
}
