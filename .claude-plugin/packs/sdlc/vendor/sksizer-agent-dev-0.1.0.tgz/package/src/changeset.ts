/**
 * Reading the changeset out of git.
 *
 * Goes through `@sksizer/easy-git`'s typed client — no hand-built argv.
 */
import { Git } from '@sksizer/easy-git'

import type { FileDiff } from './prompt.js'

export interface Changeset {
  /** The ref the changeset was computed against. */
  base: string
  files: string[]
}

/**
 * Resolve the default comparison base: the remote's own default branch.
 *
 * Falls back to `main` when the symbolic ref is absent — a fresh clone, or a
 * repo whose `origin/HEAD` was never set.
 */
export function defaultBase(git: Git): string {
  const head = git.revParse('--abbrev-ref', 'origin/HEAD')
  if (head === null) return 'main'
  return head.startsWith('origin/') ? head.slice('origin/'.length) : head
}

/**
 * Rev syntax that names a commit directly rather than a branch.
 *
 * `HEAD` is the one that bites: `origin/HEAD` exists in any cloned repo as the
 * symbolic ref to the default branch, so treating every base as a branch name
 * silently rewrites `--base HEAD` into `--base main` and compares the whole
 * branch when the caller asked for the working tree.
 */
const NAMES_A_COMMIT = /^HEAD$|[~^:@]|^[0-9a-f]{7,40}$/

/**
 * Resolve `base` to the ref actually worth diffing against.
 *
 * A branch name prefers the remote's copy, because a local `main` is often
 * behind and would make already-merged commits look like part of this change.
 * Anything that names a commit outright is used as written.
 */
function baseRef(git: Git, base: string): string {
  if (NAMES_A_COMMIT.test(base)) return base
  return git.objectExists(`origin/${base}`) ? `origin/${base}` : base
}

/**
 * Resolve the comparison point: the merge base of `base` and `HEAD`.
 *
 * Diffing against the merge base rather than the branch tip means a stale base
 * branch does not make unrelated commits look like part of this change — the
 * `base...HEAD` guarantee — while still leaving a concrete rev the working
 * tree can be diffed against.
 */
function forkPoint(git: Git, base: string): string {
  const ref = baseRef(git, base)
  return git.mergeBase(ref, 'HEAD') ?? ref
}

/**
 * Files changed between the fork point and the working tree.
 *
 * Uncommitted work is included deliberately. Under a pre-push hook the working
 * tree matches HEAD and this is the branch diff either way; run on demand
 * mid-change it reports what you are actually about to be judged on, rather
 * than an empty changeset because nothing is committed yet.
 */
export function changedFiles(git: Git, base: string): string[] {
  const tracked = git.diffNameOnly({ rangeArgs: [forkPoint(git, base)] })
  // `git diff` never lists an untracked file, so a brand-new file would go
  // unjudged — exactly the case a rule about new code most wants to see.
  const untracked = git.lsFiles({ others: true, excludeStandard: true })
  return [...new Set([...tracked, ...untracked])].sort()
}

/**
 * Unified diff per file.
 *
 * Deleted files are skipped: there is nothing left to judge, and a rule about
 * file content cannot be breached by absence.
 */
export function fileDiffs(git: Git, base: string, files: readonly string[]): FileDiff[] {
  const ref = forkPoint(git, base)
  const out: FileDiff[] = []
  for (const file of files) {
    const tracked = git.diffText(ref, { paths: [file] }).trim()
    if (tracked !== '') {
      out.push({ file, diff: tracked })
      continue
    }
    // Untracked files produce no diff above; render them as all-added so new
    // and modified files reach the judge in the same shape.
    const added = git.diffAddedFile(file).trim()
    if (added !== '') out.push({ file, diff: added })
  }
  return out
}
