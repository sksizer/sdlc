/**
 * Selection: which rule sources does this changeset actually touch?
 *
 * Pure — no disk, no network, no model. Mirrors the `planCall`/`callAgent`
 * split in `@sksizer/agent-call`: the decision of what to run is separable
 * from running it, so the whole selection step is golden-testable.
 *
 * A source survives only if one of its patterns matches a changed file. That
 * is what makes the fan-out affordable: `docs/CLAUDE.md` against a changeset
 * that touches no docs is proven irrelevant by pattern algebra, and never
 * costs a model call.
 */
import { index, matches } from '@sksizer/intersect'

import type { RuleSource, VerifyConfig, VerifyJob } from './types.js'

export interface PlanResult {
  jobs: VerifyJob[]
  /** Sources that matched nothing — reported, so a silent drop is visible. */
  skipped: { id: string; label: string }[]
}

/**
 * Pair every rule source with the changed files it governs.
 *
 * @param sources - Discovered rule sources. Ids must be unique; the intersect
 * registry rejects duplicates at construction rather than silently keeping one.
 * @param changedFiles - Repo-relative paths in the changeset.
 * @param config - `exclude` prunes the changeset; `maxFilesPerJob` caps how
 * many files one job carries, splitting a broad source across several.
 * @returns Jobs in broad-to-specific order, plus the sources that were dropped.
 */
export function planJobs(
  sources: readonly RuleSource[],
  changedFiles: readonly string[],
  config: Pick<VerifyConfig, 'exclude' | 'maxFilesPerJob'>,
): PlanResult {
  const files =
    config.exclude.length === 0
      ? [...changedFiles]
      : changedFiles.filter((f) => !matches(f, [...config.exclude]))

  const registry = index(sources.map((s) => ({ id: s.id, patterns: [...s.patterns] })))

  // Query per file, then invert. Intersect answers "which sources cover this
  // path", which is the direction the registry is built for; grouping the
  // other way would mean recompiling matchers per source.
  const covered = new Map<string, string[]>()
  for (const file of files) {
    for (const id of registry.matching(file)) {
      const group = covered.get(id)
      if (group === undefined) covered.set(id, [file])
      else group.push(file)
    }
  }

  const jobs: VerifyJob[] = []
  const skipped: { id: string; label: string }[] = []
  for (const source of sources) {
    const group = covered.get(source.id)
    if (group === undefined) {
      skipped.push({ id: source.id, label: source.label })
      continue
    }
    for (const shard of shardFiles(group, config.maxFilesPerJob)) {
      jobs.push({ source, ...shard })
    }
  }

  jobs.sort(byBreadth)
  return { jobs, skipped }
}

/**
 * Split one source's files into jobs of at most `limit` files.
 *
 * Consecutive slices of the incoming order, which is the changeset's own
 * order, so a shard boundary lands between neighbouring paths and each job
 * tends to cover one area of the tree. A single shard carries no `shard`
 * field: the overwhelmingly common case should not have to explain itself.
 */
function shardFiles(
  files: readonly string[],
  limit: number,
): { files: readonly string[]; shard?: { index: number; of: number } }[] {
  if (limit <= 0 || files.length <= limit) return [{ files }]

  // Spread evenly rather than filling each shard to the limit, so five files
  // over a limit of four become 3+2 and not 4+1 — a one-file job judges
  // nothing the others did not, and costs a whole call to say so.
  const count = Math.ceil(files.length / limit)
  const size = Math.ceil(files.length / count)
  const slices: (readonly string[])[] = []
  for (let i = 0; i < files.length; i += size) slices.push(files.slice(i, i + size))

  // Numbered off the slices actually produced, so `of` can never promise a
  // shard that the arithmetic did not yield.
  return slices.map((sliced, i) => ({
    files: sliced,
    shard: { index: i + 1, of: slices.length },
  }))
}

/**
 * Broadest scope first, ties broken by id so ordering is total and stable.
 * Reports read top-down from repo-wide rules to the most local ones.
 */
function byBreadth(a: VerifyJob, b: VerifyJob): number {
  if (a.source.depth !== b.source.depth) return a.source.depth - b.source.depth
  if (a.source.id !== b.source.id) return a.source.id < b.source.id ? -1 : 1
  return (a.shard?.index ?? 0) - (b.shard?.index ?? 0)
}
