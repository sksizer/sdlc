import { describe, expect, test } from 'bun:test'

import { adapterFor, planCall } from '@sksizer/agent-call'

import { buildSpec, FINDINGS_SCHEMA, type FileDiff } from './prompt.js'
import { DEFAULT_CONFIG, type RuleSource, type VerifyJob } from './types.js'

const SOURCE: RuleSource = {
  id: 'instruction:solutions/ontological/lib/CLAUDE.md',
  kind: 'instruction',
  path: 'solutions/ontological/lib/CLAUDE.md',
  depth: 3,
  patterns: ['solutions/ontological/lib/**'],
  text: 'Entity reads go through readEntity, never hand-rolled parsing.',
  label: 'CLAUDE.md (solutions/ontological/lib)',
}

const JOB: VerifyJob = {
  source: SOURCE,
  files: ['solutions/ontological/lib/model/read.ts'],
}

const DIFFS: FileDiff[] = [
  { file: 'solutions/ontological/lib/model/read.ts', diff: '+ const x = 1;' },
  { file: 'apps/pumice/src/main.rs', diff: '+ fn main() {}' },
]

const CONFIG = { ...DEFAULT_CONFIG, model: 'claude-haiku-4-5-20251001' }

describe('buildSpec', () => {
  test('sends only the files this job governs', () => {
    const prompt = buildSpec(JOB, DIFFS, CONFIG, '/repo').prompt

    expect(prompt).toContain('solutions/ontological/lib/model/read.ts')
    expect(prompt).not.toContain('apps/pumice/src/main.rs')
    expect(prompt).toContain('# The changed files (1)')
  })

  test('carries the rule text verbatim', () => {
    // Paraphrasing the rules would change what is actually enforced.
    expect(buildSpec(JOB, DIFFS, CONFIG, '/repo').prompt).toContain(SOURCE.text)
  })

  test("names only this source's rules, so jobs stay independent", () => {
    const prompt = buildSpec(JOB, DIFFS, CONFIG, '/repo').prompt

    expect(prompt).toContain(SOURCE.path)
    expect(prompt).toContain('the complete and only ruleset')
  })

  test('requests read-only permissions and a non-persisted session', () => {
    const spec = buildSpec(JOB, DIFFS, CONFIG, '/repo')

    expect(spec.permissions?.mode).toBe('read-only')
    expect(spec.session?.persist).toBe(false)
    expect(spec.cwd).toBe('/repo')
    expect(spec.timeoutMs).toBe(DEFAULT_CONFIG.timeoutMs)
  })

  test('pins the reply shape to the findings schema', () => {
    expect(buildSpec(JOB, DIFFS, CONFIG, '/repo').output?.schema).toBe(FINDINGS_SCHEMA)
  })

  test('omits model entirely when none is configured', () => {
    const spec = buildSpec(JOB, DIFFS, DEFAULT_CONFIG, '/repo')

    expect(spec).not.toHaveProperty('model')
  })
})

describe('the planned invocation', () => {
  test('claude runs read-only with the configured model and no mutation flags', () => {
    const planned = planCall(adapterFor('claude'), buildSpec(JOB, DIFFS, CONFIG, '/repo'))

    expect(planned.argv[0]).toBe('claude')
    expect(planned.argv).toContain('claude-haiku-4-5-20251001')
    // Nothing that could let a verification run edit the tree.
    const argv = planned.argv.join(' ')
    expect(argv).not.toContain('--dangerously-skip-permissions')
    expect(argv).not.toContain('bypassPermissions')
    expect(argv).not.toContain('acceptEdits')
  })

  test('the prompt travels over stdin, not argv', () => {
    // A whole changeset on the command line risks E2BIG on a wide diff.
    const planned = planCall(adapterFor('claude'), buildSpec(JOB, DIFFS, CONFIG, '/repo'))

    expect(planned.stdin).toContain(SOURCE.text)
    expect(planned.argv.join(' ')).not.toContain(SOURCE.text)
  })

  test('the spec survives translation to a second engine', () => {
    // agent-dev must not quietly depend on claude-specific behavior.
    const planned = planCall(adapterFor('codex'), buildSpec(JOB, DIFFS, CONFIG, '/repo'))

    expect(planned.argv[0]).toBe('codex')
    // Every field that did not map 1:1 is recorded rather than dropped silently.
    for (const note of planned.notes) {
      expect(typeof note.field).toBe('string')
      expect(typeof note.detail).toBe('string')
    }
  })
})
