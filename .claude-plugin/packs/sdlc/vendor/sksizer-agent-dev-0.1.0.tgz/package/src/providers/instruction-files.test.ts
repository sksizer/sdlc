import { afterAll, beforeAll, describe, expect, test } from 'bun:test'
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join } from 'node:path'

import { instructionFiles } from './instruction-files.js'
import type { RuleSource } from '../types.js'

let root: string

/** Write a file, creating parents. */
async function put(rel: string, body: string): Promise<void> {
  const abs = join(root, rel)
  await mkdir(dirname(abs), { recursive: true })
  await writeFile(abs, body, 'utf8')
}

beforeAll(async () => {
  root = await mkdtemp(join(tmpdir(), 'agent-dev-instr-'))

  await put('CLAUDE.md', 'Root rule: never commit secrets.')
  await put('docs/CLAUDE.md', 'Docs rule: sentence case headings.')
  await put('apps/web/src/AGENTS.md', 'Web rule: no inline handlers.')

  // A pointer file — no rules of its own, redirects to a sibling README.
  await put('apps/api/CLAUDE.md', 'See @./README.md for the rules.')
  await put('apps/api/README.md', 'API rule: every endpoint is versioned.')

  // A cycle, to prove the walk terminates.
  await put('cyc/CLAUDE.md', 'Cyclic: @./other.md')
  await put('cyc/other.md', 'Back again: @./CLAUDE.md')

  // An import that tries to climb out of the repo.
  await put('escape/CLAUDE.md', 'Escape: @../../../../etc/hosts')

  await put('empty/CLAUDE.md', '   \n\n  ')
  await put('node_modules/pkg/CLAUDE.md', 'Vendored: should never be read.')
})

afterAll(async () => {
  await rm(root, { recursive: true, force: true })
})

/** The fixture tree is not a git repo, so enumerate it directly. */
const listFixture = (): string[] => [
  'CLAUDE.md',
  'docs/CLAUDE.md',
  'apps/web/src/AGENTS.md',
  'apps/api/CLAUDE.md',
  'cyc/CLAUDE.md',
  'escape/CLAUDE.md',
  'empty/CLAUDE.md',
]

async function discover(): Promise<RuleSource[]> {
  return instructionFiles({ list: listFixture }).discover({
    projectRoot: root,
    changedFiles: [],
  })
}

function byPath(sources: RuleSource[], path: string): RuleSource {
  const found = sources.find((s) => s.path === path)
  if (found === undefined) throw new Error(`no source at ${path}`)
  return found
}

describe('instructionFiles', () => {
  test('scopes the root file to the whole repo at depth 0', async () => {
    const root0 = byPath(await discover(), 'CLAUDE.md')

    expect(root0.patterns).toEqual(['**'])
    expect(root0.depth).toBe(0)
    expect(root0.label).toBe('CLAUDE.md (repo root)')
  })

  test('scopes a nested file to its own subtree', async () => {
    const web = byPath(await discover(), 'apps/web/src/AGENTS.md')

    expect(web.patterns).toEqual(['apps/web/src/**'])
    expect(web.depth).toBe(3)
    expect(web.kind).toBe('instruction')
  })

  test('finds AGENTS.md as well as CLAUDE.md', async () => {
    const paths = (await discover()).map((s) => s.path)

    expect(paths).toContain('apps/web/src/AGENTS.md')
    expect(paths).toContain('CLAUDE.md')
  })

  test('inlines an @path import so a pointer file carries real rules', async () => {
    const api = byPath(await discover(), 'apps/api/CLAUDE.md')

    expect(api.text).toContain('API rule: every endpoint is versioned.')
    // Attribution is kept so the judge cannot misattribute borrowed prose.
    expect(api.text).toContain('imported from apps/api/README.md')
  })

  test('import resolution terminates on a cycle', async () => {
    const cyc = byPath(await discover(), 'cyc/CLAUDE.md')

    expect(cyc.text).toContain('Back again')
    expect(cyc.text.match(/imported from/g) ?? []).toHaveLength(1)
  })

  test('refuses an import that escapes the project root', async () => {
    const escape = byPath(await discover(), 'escape/CLAUDE.md')

    expect(escape.text).not.toContain('imported from')
  })

  test('maxImportDepth 0 disables resolution entirely', async () => {
    const sources = await instructionFiles({ list: listFixture, maxImportDepth: 0 }).discover({
      projectRoot: root,
      changedFiles: [],
    })

    expect(byPath(sources, 'apps/api/CLAUDE.md').text).not.toContain('every endpoint is versioned')
  })

  test('skips a file with no rules in it', async () => {
    expect((await discover()).map((s) => s.path)).not.toContain('empty/CLAUDE.md')
  })

  test('a path the lister names but disk does not is dropped, not thrown on', async () => {
    const sources = await instructionFiles({
      list: () => ['CLAUDE.md', 'deleted/CLAUDE.md'],
    }).discover({ projectRoot: root, changedFiles: [] })

    expect(sources.map((s) => s.path)).toEqual(['CLAUDE.md'])
  })

  test('duplicates from the lister collapse to one source', async () => {
    // The default lister concatenates tracked and untracked results, so a
    // repeat is possible; a duplicate id would abort the whole registry.
    const sources = await instructionFiles({
      list: () => ['CLAUDE.md', 'CLAUDE.md'],
    }).discover({ projectRoot: root, changedFiles: [] })

    expect(sources).toHaveLength(1)
  })

  test('ids are unique, so the registry accepts the whole set', async () => {
    const ids = (await discover()).map((s) => s.id)

    expect(new Set(ids).size).toBe(ids.length)
  })
})
