/**
 * The built-in provider: `CLAUDE.md` and `AGENTS.md` as scoped rule sources.
 *
 * An instruction file governs its own directory and everything under it, so
 * its scope is `<dir>/**` — the one place this package hard-codes a scoping
 * convention, because that convention is what an instruction file *is*.
 *
 * Pointer files are resolved. Several instruction files carry no rules of
 * their own and exist only to redirect (`See @./README.md`); dispatching one
 * verbatim spends a model call on a file that says nothing, so `@path`
 * imports are inlined the way Claude Code itself reads them.
 */
import { readFile } from 'node:fs/promises'
import { dirname, isAbsolute, relative, resolve } from 'node:path'

import { Git } from '@sksizer/easy-git'

import type { DiscoveryContext, RuleSource, RuleSourceProvider } from '../types.js'

export const INSTRUCTION_KIND = 'instruction'

const FILENAMES = ['CLAUDE.md', 'AGENTS.md'] as const

/** git pathspecs matching those names at any depth. */
const PATHSPECS = FILENAMES.map((name) => `*${name}`)

/**
 * Claude Code's import syntax: `@` followed by a path with an extension.
 *
 * Deliberately does NOT match `[[wikilinks]]`. Those are cross-references
 * between documents, not imports — following them would pull an entire docs
 * tree into a single prompt, which is a different feature with a different
 * cost profile.
 */
const IMPORT_RE = /@((?:\.{1,2}\/)?[\w.\-/]+\.\w+)/g

/** Enumerates candidate instruction-file paths, repo-relative. */
export type FileLister = (projectRoot: string) => Promise<string[]> | string[]

/**
 * Ask git, not the filesystem.
 *
 * A tree walk is the obvious implementation and the wrong one: globbing
 * `**\/CLAUDE.md` across a monorepo stats every build output and dependency
 * tree, which on a large repo does not finish in any useful time. git answers
 * the same question from its index in milliseconds and skips everything
 * .gitignore already excludes. Untracked files are included so a
 * newly-written instruction file governs the change that adds it.
 */
export const gitFileLister: FileLister = (projectRoot) => {
  const git = new Git(projectRoot)
  return [
    ...git.lsFiles({ paths: [...PATHSPECS] }),
    ...git.lsFiles({ others: true, excludeStandard: true }).filter((p) => {
      const name = p.split('/').pop() ?? ''
      return (FILENAMES as readonly string[]).includes(name)
    }),
  ]
}

export interface InstructionFilesOptions {
  /**
   * How candidate paths are found. Defaults to {@link gitFileLister}; supply
   * your own for a project that is not a git repository.
   */
  list?: FileLister
  /**
   * How many levels of `@path` import to follow. 0 disables resolution.
   * Bounded because an import chain is user-authored and may cycle.
   */
  maxImportDepth?: number
}

/** Discover `CLAUDE.md`/`AGENTS.md` beneath the project root. */
export function instructionFiles(options: InstructionFilesOptions = {}): RuleSourceProvider {
  const list = options.list ?? gitFileLister
  const maxImportDepth = options.maxImportDepth ?? 2

  return {
    id: 'instruction-files',
    async discover(ctx: DiscoveryContext): Promise<RuleSource[]> {
      const paths = [...new Set(await list(ctx.projectRoot))].sort()

      const sources: RuleSource[] = []
      for (const relPath of paths) {
        const text = await readWithImports(ctx.projectRoot, relPath, maxImportDepth)
        if (text.trim() === '') continue
        sources.push(toSource(relPath, text))
      }
      return sources
    },
  }
}

function toSource(relPath: string, text: string): RuleSource {
  const dir = dirname(relPath)
  const atRoot = dir === '.' || dir === ''
  const segments = atRoot ? [] : dir.split('/')
  return {
    id: `instruction:${relPath}`,
    kind: INSTRUCTION_KIND,
    path: relPath,
    depth: segments.length,
    patterns: [atRoot ? '**' : `${dir}/**`],
    text,
    label: `${relPath.split('/').pop()} (${atRoot ? 'repo root' : dir})`,
  }
}

/**
 * Read an instruction file, inlining `@path` imports depth-first.
 *
 * Each import is fenced with its source path so the judge can tell borrowed
 * prose from the instruction file's own words, and cannot misattribute a rule.
 */
async function readWithImports(
  projectRoot: string,
  relPath: string,
  depthBudget: number,
  seen: Set<string> = new Set(),
): Promise<string> {
  if (seen.has(relPath)) return ''
  seen.add(relPath)

  let text: string
  try {
    text = await readFile(resolve(projectRoot, relPath), 'utf8')
  } catch {
    return ''
  }
  if (depthBudget <= 0) return text

  const imported: string[] = []
  for (const target of importTargets(projectRoot, relPath, text)) {
    if (seen.has(target)) continue
    const body = await readWithImports(projectRoot, target, depthBudget - 1, seen)
    if (body.trim() === '') continue
    imported.push(`\n\n<!-- imported from ${target} -->\n${body}`)
  }
  return imported.length === 0 ? text : text + imported.join('')
}

/** Repo-relative targets of every `@path` import, deduped, in document order. */
function importTargets(projectRoot: string, relPath: string, text: string): string[] {
  const baseDir = dirname(resolve(projectRoot, relPath))
  const out: string[] = []
  const seen = new Set<string>()

  for (const match of text.matchAll(IMPORT_RE)) {
    const raw = match[1]
    if (raw === undefined) continue
    const abs = resolve(baseDir, raw)
    const rel = relative(projectRoot, abs)
    // Refuse to escape the repo: an import is a convenience, not a way to
    // pull arbitrary host files into a prompt.
    if (rel.startsWith('..') || isAbsolute(rel)) continue
    if (seen.has(rel)) continue
    seen.add(rel)
    out.push(rel)
  }
  return out
}
