import { describe, expect, test } from 'bun:test'

import { main } from './cli.js'

/** Run the CLI with stdout/stderr captured. */
async function run(argv: string[]): Promise<{ code: number; out: string; err: string }> {
  let out = ''
  let err = ''
  const stdout = process.stdout.write.bind(process.stdout)
  const stderr = process.stderr.write.bind(process.stderr)
  process.stdout.write = ((s: string) => {
    out += s
    return true
  }) as typeof process.stdout.write
  process.stderr.write = ((s: string) => {
    err += s
    return true
  }) as typeof process.stderr.write
  try {
    return { code: await main(argv), out, err }
  } finally {
    process.stdout.write = stdout
    process.stderr.write = stderr
  }
}

describe('dfv argument handling', () => {
  test('--help prints usage to stdout and exits 0', async () => {
    const { code, out } = await run(['--help'])

    expect(code).toBe(0)
    expect(out).toContain('dfv — verify a changeset')
    expect(out).toContain('--dry-run')
  })

  test('an unknown option fails with a pointer to --help', async () => {
    const { code, err } = await run(['--bogus'])

    expect(code).toBe(2)
    expect(err).toContain("unknown option '--bogus'")
    expect(err).toContain('--help')
  })

  test('a flag missing its value is rejected, not silently swallowed', async () => {
    // Without the check, `--base --json` would take "--json" as the ref.
    const { code, err } = await run(['--base', '--json'])

    expect(code).toBe(2)
    expect(err).toContain('--base needs a value')
  })

  test('--severity rejects a level outside the enum', async () => {
    const { code, err } = await run(['--severity', 'nonsense'])

    expect(code).toBe(2)
    expect(err).toContain('violation, tension, or drift')
  })

  test('--concurrency rejects a non-positive integer', async () => {
    expect((await run(['--concurrency', '0'])).code).toBe(2)
    expect((await run(['--concurrency', 'abc'])).code).toBe(2)
  })

  test('a directory outside a git repo fails cleanly', async () => {
    const { code, err } = await run(['-C', '/'])

    expect(code).toBe(2)
    expect(err).toContain('not inside a git repository')
  })
})
