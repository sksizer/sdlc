import { afterAll, beforeAll, describe, expect, test } from 'bun:test'
import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { Git } from '@sksizer/easy-git'

import { changedFiles, defaultBase, fileDiffs } from './changeset.js'

let origin: string
let repo: string
let git: Git

function sh(g: Git, argv: string[]): void {
  const r = g.raw(argv)
  if (r.exitCode !== 0) throw new Error(`${argv.join(' ')}: ${r.stderr}`)
}

function write(rel: string, body: string): void {
  const abs = join(repo, rel)
  mkdirSync(join(abs, '..'), { recursive: true })
  writeFileSync(abs, body, 'utf8')
}

beforeAll(() => {
  // A bare origin plus a clone, so `origin/HEAD` exists exactly as it does in
  // a real checkout — which is the condition the base-resolution bug needed.
  origin = mkdtempSync(join(tmpdir(), 'agent-dev-origin-'))
  const seed = mkdtempSync(join(tmpdir(), 'agent-dev-seed-'))
  const bare = new Git(origin)
  sh(bare, ['init', '--bare', '-b', 'main', '.'])

  const s = new Git(seed)
  sh(s, ['init', '-b', 'main', '.'])
  sh(s, ['config', 'user.email', 't@t'])
  sh(s, ['config', 'user.name', 't'])
  writeFileSync(join(seed, 'base.txt'), 'one\n')
  s.add(['.'])
  s.commit({ message: 'c1' })
  sh(s, ['remote', 'add', 'origin', origin])
  s.push('origin', 'main')

  repo = mkdtempSync(join(tmpdir(), 'agent-dev-clone-'))
  rmSync(repo, { recursive: true, force: true })
  sh(new Git(tmpdir()), ['clone', '-q', origin, repo])
  git = new Git(repo)
  sh(git, ['config', 'user.email', 't@t'])
  sh(git, ['config', 'user.name', 't'])

  // One commit past main, then one uncommitted edit and one new file.
  sh(git, ['checkout', '-q', '-b', 'feature'])
  write('committed.txt', 'committed\n')
  git.add(['committed.txt'])
  git.commit({ message: 'c2' })

  write('base.txt', 'one\ntwo\n')
  write('untracked.txt', 'new\n')
})

afterAll(() => {
  for (const d of [origin, repo]) rmSync(d, { recursive: true, force: true })
})

describe('changedFiles', () => {
  test('--base HEAD sees only uncommitted work', () => {
    // `origin/HEAD` exists in any clone, so a naive `origin/${base}` lookup
    // rewrites HEAD into the default branch and silently returns the whole
    // branch diff instead.
    const files = changedFiles(git, 'HEAD')

    expect(files).toEqual(['base.txt', 'untracked.txt'])
    expect(files).not.toContain('committed.txt')
  })

  test('a branch base sees committed work as well', () => {
    expect(changedFiles(git, 'main')).toEqual(['base.txt', 'committed.txt', 'untracked.txt'])
  })

  test('a sha base is used as written', () => {
    const head = git.revParse('HEAD')
    expect(head).not.toBeNull()

    expect(changedFiles(git, head!)).toEqual(['base.txt', 'untracked.txt'])
  })

  test('HEAD~1 reaches back past the branch commit', () => {
    expect(changedFiles(git, 'HEAD~1')).toContain('committed.txt')
  })

  test('untracked files are included — new code is what rules most want to see', () => {
    expect(changedFiles(git, 'HEAD')).toContain('untracked.txt')
  })
})

describe('defaultBase', () => {
  test('follows origin/HEAD, stripped of its remote prefix', () => {
    expect(defaultBase(git)).toBe('main')
  })
})

describe('fileDiffs', () => {
  test('renders a modified file as a diff', () => {
    const [diff] = fileDiffs(git, 'HEAD', ['base.txt'])

    expect(diff?.file).toBe('base.txt')
    expect(diff?.diff).toContain('+two')
  })

  test('renders an untracked file as all-added', () => {
    const [diff] = fileDiffs(git, 'HEAD', ['untracked.txt'])

    expect(diff?.diff).toContain('+new')
  })

  test('skips a path with nothing to show', () => {
    expect(fileDiffs(git, 'HEAD', ['never-existed.txt'])).toEqual([])
  })
})
