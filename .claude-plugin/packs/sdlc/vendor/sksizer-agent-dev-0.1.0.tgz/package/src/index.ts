/**
 * agent-dev — verify a changeset against the rules that govern it.
 *
 * See README.md for the model. In short: every rule source declares the paths
 * it governs, intersecting those scopes against a changeset yields the jobs
 * worth running, and each job is judged independently by a headless agent.
 */
export type {
  DiscoveryContext,
  Finding,
  JobOutcome,
  RuleSource,
  RuleSourceProvider,
  Severity,
  VerifyConfig,
  VerifyJob,
  VerifyRun,
} from './types.js'
export { DEFAULT_CONFIG, SEVERITY_ORDER } from './types.js'

export { planJobs, type PlanResult } from './plan.js'
export { BYTES_PER_TOKEN, estimateTokens, formatTokens, jobLabel } from './tokens.js'
export { buildSpec, FINDINGS_SCHEMA, type FileDiff } from './prompt.js'
export { exitCodeFor, meetsFloor, mergeFindings, parseFindings } from './findings.js'
export { discoverSources, verify, type Dispatch, type VerifyOptions } from './run.js'
export { changedFiles, defaultBase, fileDiffs, resolveBase, type Changeset } from './changeset.js'
export {
  gitFileLister,
  instructionFiles,
  INSTRUCTION_KIND,
  type FileLister,
  type InstructionFilesOptions,
} from './providers/instruction-files.js'
