/**
 * The verb table — every `gh` invocation this library knows, as data.
 *
 * Same shape and same reasoning as `@sksizer/easy-git`'s: a {@link GhVerb}
 * pairs the argv to run with the function that reads the result, and nothing
 * here spawns anything. That is what lets a synchronous client and an
 * asynchronous fan-out drive the same definitions without either duplicating
 * the other's parsing.
 *
 * `checked` marks a mutation: its only sane failure handling is to surface
 * stderr. Queries are unchecked and fold failure into an absence value.
 */

import type { CommandResult } from '@sksizer/command-seam'

import { parseLabels, parsePullRequest, type PullRequestJson } from './parse.ts'
import type { IssueRow, Label, PullRequest } from './types.ts'

/** One `gh` invocation: what to run, and how to read what came back. */
export interface GhVerb<T> {
  argv: string[]
  /** True for mutations — throw on a non-zero exit instead of parsing. */
  checked: boolean
  parse(result: CommandResult): T
}

/**
 * The cheapest useful set: enough to identify a PR and nothing more.
 *
 * Reach for this whenever the question is "which PR is this branch?".
 * `mergeable` and `mergeStateStatus` are absent on purpose — GitHub computes
 * them per PR on demand, so asking for them across a fan-out of branches
 * turns a cheap listing into a rate-limit incident.
 */
export const PR_REF_FIELDS = ['number', 'state', 'headRefName', 'url'] as const

/**
 * The light field set for triage: everything needed to decide what to do with
 * a PR without paying for its body, comments, reviews, or check rollup.
 *
 * `mergeable` and `mergeStateStatus` are the expensive pair — GitHub computes
 * them lazily and answers `UNKNOWN` until it has, so a cold query over many
 * PRs commonly needs a retry. See {@link needsMergeStateRetry}.
 */
export const PR_LIST_FIELDS = [
  'number',
  'state',
  'title',
  'url',
  'isDraft',
  'baseRefName',
  'headRefName',
  'headRefOid',
  'isCrossRepository',
  'mergeable',
  'mergeStateStatus',
  'reviewDecision',
  'author',
  'labels',
  'mergedAt',
  'createdAt',
  'updatedAt',
] as const

/** {@link PR_LIST_FIELDS} plus the heavy ones a single PR can afford. */
export const PR_VIEW_FIELDS = [
  ...PR_LIST_FIELDS,
  'body',
  'comments',
  'reviews',
  'statusCheckRollup',
] as const

/** Parse a `--json` payload that is a single object. */
function oneOrNull(r: CommandResult): PullRequest | null {
  if (r.exitCode !== 0) return null
  let data: unknown
  try {
    data = JSON.parse(r.stdout)
  } catch {
    return null
  }
  return parsePullRequest(data as PullRequestJson)
}

/**
 * Parse a `--json` payload that is an array. Null — not `[]` — when the call
 * failed: a caller must be able to tell "no PRs" from "couldn't ask".
 */
function manyOrNull(r: CommandResult): PullRequest[] | null {
  if (r.exitCode !== 0) return null
  let data: unknown
  try {
    data = JSON.parse(r.stdout || '[]')
  } catch {
    return null
  }
  if (!Array.isArray(data)) return null
  const rows: PullRequest[] = []
  for (const item of data) {
    const pr = parsePullRequest(item as PullRequestJson)
    if (pr !== null) rows.push(pr)
  }
  return rows
}

/** A mutation's result carries no value. */
function nothing(): void {}

/**
 * Parse a `gh label list --json name,color,description` payload. Null — not
 * `[]` — when the call failed, same "no rows" vs. "couldn't ask" split as
 * {@link manyOrNull}: a repo with genuinely zero labels and a `gh` call that
 * never ran must not collapse onto the same value.
 */
function manyLabelsOrNull(r: CommandResult): Label[] | null {
  if (r.exitCode !== 0) return null
  let data: unknown
  try {
    data = JSON.parse(r.stdout || '[]')
  } catch {
    return null
  }
  if (!Array.isArray(data)) return null
  return parseLabels(data)
}

/** The `gh issue list`/`view --json` field set the `issues` surface needs. */
const ISSUE_FIELDS = 'number,title,body,labels,state'

/** Parse one `gh issue list`/`view --json` row into an {@link IssueRow}. */
function parseIssueRow(data: unknown): IssueRow | null {
  if (data === null || typeof data !== 'object') return null
  const rec = data as Record<string, unknown>
  const number = rec['number']
  if (typeof number !== 'number') return null
  return {
    number,
    title: typeof rec['title'] === 'string' ? rec['title'] : '',
    body: typeof rec['body'] === 'string' ? rec['body'] : '',
    labels: parseLabels(rec['labels']),
    state: typeof rec['state'] === 'string' ? rec['state'] : '',
  }
}

/** Parse a `gh issue view --json` payload that is a single object. */
function oneIssueOrNull(r: CommandResult): IssueRow | null {
  if (r.exitCode !== 0) return null
  let data: unknown
  try {
    data = JSON.parse(r.stdout)
  } catch {
    return null
  }
  return parseIssueRow(data)
}

/**
 * Parse a `gh issue list --json` payload that is an array. Null — not `[]` —
 * on failure, the same "no rows" vs. "couldn't ask" split {@link manyOrNull}
 * makes for PRs.
 */
function manyIssuesOrNull(r: CommandResult): IssueRow[] | null {
  if (r.exitCode !== 0) return null
  let data: unknown
  try {
    data = JSON.parse(r.stdout || '[]')
  } catch {
    return null
  }
  if (!Array.isArray(data)) return null
  const rows: IssueRow[] = []
  for (const item of data) {
    const row = parseIssueRow(item)
    if (row !== null) rows.push(row)
  }
  return rows
}

// ── queries ─────────────────────────────────────────────────────────────────

/** What to narrow a listing to. Every filter is optional; none means "all open". */
export interface PrListOptions {
  /**
   * `owner/name` to list from, instead of the repository at the client's cwd.
   * The only way to reach a repository this machine has no checkout of.
   */
  repo?: string | undefined
  state?: 'open' | 'closed' | 'merged' | 'all' | undefined
  /** Exact base branch filter (gh-side). */
  base?: string | undefined
  /**
   * Head branch filter. gh matches this as a prefix, so a caller needing an
   * exact match filters the rows itself — {@link pickPrForBranch} does.
   */
  head?: string | undefined
  /** Raw `--search` query, for anything the flags do not cover. */
  search?: string | undefined
  author?: string | undefined
  limit?: number | undefined
  /** Field subset; defaults to {@link PR_LIST_FIELDS}. */
  fields?: readonly string[] | undefined
}

/** `gh pr list …` — open PRs by default. */
export function prList(opts: PrListOptions = {}): GhVerb<PullRequest[] | null> {
  const argv = ['pr', 'list', '--state', opts.state ?? 'open']
  if (opts.repo !== undefined) argv.push('--repo', opts.repo)
  if (opts.base !== undefined) argv.push('--base', opts.base)
  if (opts.head !== undefined) argv.push('--search', `head:${opts.head}`)
  if (opts.search !== undefined) argv.push('--search', opts.search)
  if (opts.author !== undefined) argv.push('--author', opts.author)
  argv.push('--json', (opts.fields ?? PR_LIST_FIELDS).join(','))
  argv.push('--limit', String(opts.limit ?? 100))
  return { argv, checked: false, parse: manyOrNull }
}

/** `gh pr view <n> --json …` — one PR, with the heavy fields by default. */
export function prView(
  number: number,
  fields: readonly string[] = PR_VIEW_FIELDS,
): GhVerb<PullRequest | null> {
  return {
    argv: ['pr', 'view', String(number), '--json', fields.join(',')],
    checked: false,
    parse: oneOrNull,
  }
}

/**
 * Open PRs whose head *starts with* `branch` — gh's own search semantics.
 *
 * The common shape behind "which PR is this branch?", bundling the cheap
 * field set with a small limit. Pair it with {@link pickPrForBranch}, which
 * is what turns the prefix match into an exact one.
 */
export function openPrsForBranch(branch: string, limit = 5): GhVerb<PullRequest[] | null> {
  return prList({ head: branch, limit, fields: PR_REF_FIELDS })
}

/**
 * `gh pr view <n> --json body -q .body` — just the PR body. Null when gh
 * failed. gh's `-q` output ends with a newline that is not part of the body,
 * so every trailing newline is trimmed (including any that were part of the body).
 */
export function prBody(number: number): GhVerb<string | null> {
  return {
    argv: ['pr', 'view', String(number), '--json', 'body', '-q', '.body'],
    checked: false,
    parse: (r) => (r.exitCode === 0 ? r.stdout.replace(/\n+$/, '') : null),
  }
}

/** One `gh api` answer: HTTP status, entity tag, and the decoded JSON body. */
export interface ApiResponse {
  /** True iff gh exited 0 and the status is below 400 (2xx, or a 304 on a conditional GET). */
  ok: boolean
  /** HTTP status; read off the header block under `-i`. Without `-i` it is synthesized (200 on exit 0, 0 on failure), not observed. */
  status: number
  /** The response `ETag`, when headers were requested and one came back. */
  etag: string | null
  /** The decoded JSON body; null when empty (e.g. a 304), unparseable, or the call failed. */
  body: unknown
  /** True when a non-empty body arrived but was not valid JSON (`body` is then null). */
  malformed: boolean
  /** gh's stderr, trimmed. */
  stderr: string
}

export interface ApiOptions {
  /** Send `If-None-Match: <etag>` (implies `includeHeaders`). */
  etag?: string | null | undefined
  /** Pass `-i` and read status/ETag off the header block. */
  includeHeaders?: boolean | undefined
}

/**
 * `gh api [-i] [-H If-None-Match: …] <endpoint>` — a GET against the REST API. `{owner}` and
 * `{repo}` placeholders in the endpoint are filled by gh from the cwd's repo.
 * Unchecked: failure is a value (`ok: false`), so a caller can tell a 304
 * from an outage.
 */
export function api(endpoint: string, opts: ApiOptions = {}): GhVerb<ApiResponse> {
  const conditional = opts.etag !== undefined && opts.etag !== null && opts.etag !== ''
  const withHeaders = conditional || opts.includeHeaders === true
  const argv = ['api']
  if (withHeaders) argv.push('-i')
  if (conditional) argv.push('-H', `If-None-Match: ${opts.etag}`)
  argv.push(endpoint)
  return { argv, checked: false, parse: (r) => parseApi(r, withHeaders) }
}

/** Split a `gh api -i` payload (status line + headers, blank line, body) and decode it. */
function parseApi(r: CommandResult, withHeaders: boolean): ApiResponse {
  let status = r.exitCode === 0 ? 200 : 0
  let etag: string | null = null
  let bodyText = r.stdout
  if (withHeaders) {
    const raw = r.stdout
    const crlf = raw.indexOf('\r\n\r\n')
    const sepIdx = crlf >= 0 ? crlf : raw.indexOf('\n\n')
    const headerBlock = sepIdx >= 0 ? raw.slice(0, sepIdx) : raw
    bodyText = sepIdx >= 0 ? raw.slice(sepIdx).replace(/^[\r\n]+/, '') : ''
    const statusMatch = headerBlock.match(/HTTP\/[\d.]+\s+(\d{3})/i)
    if (statusMatch) status = Number(statusMatch[1])
    const etagMatch = headerBlock.match(/^etag:\s*(.+)$/im)
    if (etagMatch) etag = etagMatch[1]!.trim()
  }
  let body: unknown = null
  let malformed = false
  if (r.exitCode === 0 && bodyText.trim() !== '') {
    try {
      body = JSON.parse(bodyText)
    } catch {
      malformed = true
    }
  }
  const ok = r.exitCode === 0 && status >= 200 && status < 400
  return { ok, status, etag, body, malformed, stderr: r.stderr.trim() }
}

/** `gh --version` — the install probe. */
export function version(): GhVerb<boolean> {
  return { argv: ['--version'], checked: false, parse: (r) => r.exitCode === 0 }
}

/** What `gh auth status` said: whether it passed, and its output (stderr, else stdout), trimmed. */
export interface AuthStatus {
  ok: boolean
  detail: string
}

/** `gh auth status` — the credential probe. */
export function authStatus(): GhVerb<AuthStatus> {
  return {
    argv: ['auth', 'status'],
    checked: false,
    parse: (r) => ({ ok: r.exitCode === 0, detail: (r.stderr || r.stdout).trim() }),
  }
}

/**
 * `gh label list --json name,color,description` — every label on the repo.
 * `--limit` is explicit and generous (1000): `gh`'s own default page size is
 * 30, well under this repo's own label vocabulary (the 22 `sdlc:stage/*` /
 * `sdlc:auto/*` chain labels plus every other label the repo carries), so an
 * unset limit would silently truncate the very listing a labels-vocabulary
 * caller (`apply/labels.ts`) needs to see in full.
 */
export function labelList(): GhVerb<Label[] | null> {
  return {
    argv: ['label', 'list', '--json', 'name,color,description', '--limit', '1000'],
    checked: false,
    parse: manyLabelsOrNull,
  }
}

/** What to narrow an issue listing to. Every filter is optional. */
export interface IssueListOptions {
  /** Exact label filter (gh-side) — the common case is one `sdlc:stage/<x>` label. */
  label?: string | undefined
}

/** `gh issue list --json …` — open issues by default, optionally by label. */
export function issueList(opts: IssueListOptions = {}): GhVerb<IssueRow[] | null> {
  const argv = ['issue', 'list']
  if (opts.label !== undefined) argv.push('--label', opts.label)
  argv.push('--json', ISSUE_FIELDS, '--limit', '200')
  return { argv, checked: false, parse: manyIssuesOrNull }
}

/** `gh issue view <n> --json …` — one issue, same field set as {@link issueList}. */
export function issueView(number: number): GhVerb<IssueRow | null> {
  return {
    argv: ['issue', 'view', String(number), '--json', ISSUE_FIELDS],
    checked: false,
    parse: oneIssueOrNull,
  }
}

// ── mutations (checked — the caller throws CommandFailed on non-zero) ────────

export interface CreatePrOptions {
  head: string
  base: string
  title: string
  body: string
  draft?: boolean | undefined
}

/** `gh pr create …`, returning the URL gh prints (its last non-empty line). */
export function createPr(opts: CreatePrOptions): GhVerb<string> {
  const argv = ['pr', 'create', '--head', opts.head, '--base', opts.base]
  if (opts.draft) argv.push('--draft')
  argv.push('--title', opts.title, '--body', opts.body)
  return {
    argv,
    checked: true,
    parse(r) {
      const lines = r.stdout
        .split('\n')
        .map((l) => l.trim())
        .filter((l) => l !== '')
      const url = lines[lines.length - 1]
      if (url === undefined) throw new Error('gh pr create printed no URL')
      return url
    },
  }
}

/** `gh pr edit <n>` — retitle or rewrite the body. */
export function editPr(
  number: number,
  opts: { title?: string | undefined; body?: string | undefined },
): GhVerb<void> {
  const argv = ['pr', 'edit', String(number)]
  if (opts.title !== undefined) argv.push('--title', opts.title)
  if (opts.body !== undefined) argv.push('--body', opts.body)
  return { argv, checked: true, parse: nothing }
}

/** `gh pr edit <n> --body` — rewrite just the body. */
export function editPrBody(number: number, body: string): GhVerb<void> {
  return editPr(number, { body })
}

/** `gh pr comment <n> --body` — post a conversation comment. */
export function prComment(number: number, body: string): GhVerb<void> {
  return { argv: ['pr', 'comment', String(number), '--body', body], checked: true, parse: nothing }
}

/** `gh pr update-branch <n> [--rebase]` — bring the head up to date with its base. */
export function prUpdateBranch(number: number, style: 'merge' | 'rebase' = 'merge'): GhVerb<void> {
  const argv = ['pr', 'update-branch', String(number)]
  if (style === 'rebase') argv.push('--rebase')
  return { argv, checked: true, parse: nothing }
}

export interface CreateLabelOptions {
  name: string
  color: string
  description: string
}

/**
 * `gh label create <name> --color <hex> --description <text> --force`.
 * `--force` makes this idempotent-safe on its own: a `create` `Change` from
 * an applier's `plan()` should still succeed even if the label already
 * exists by the time `apply()` actually runs.
 */
export function labelCreate(opts: CreateLabelOptions): GhVerb<void> {
  const argv = [
    'label',
    'create',
    opts.name,
    '--color',
    opts.color,
    '--description',
    opts.description,
    '--force',
  ]
  return { argv, checked: true, parse: nothing }
}

/** `gh label edit <name>` — recolor or redescribe; omits a flag not given. */
export function labelEdit(
  name: string,
  opts: { color?: string | undefined; description?: string | undefined },
): GhVerb<void> {
  const argv = ['label', 'edit', name]
  if (opts.color !== undefined) argv.push('--color', opts.color)
  if (opts.description !== undefined) argv.push('--description', opts.description)
  return { argv, checked: true, parse: nothing }
}

/**
 * `gh issue edit <n> [--remove-label <current>] --add-label <new>` — advance
 * an issue's `sdlc:stage/<x>` label in ONE call, so the issue is never
 * briefly unlabeled or briefly holding two stage labels at once BETWEEN the
 * remove and the add — that atomicity is real and is this one call's own
 * guarantee. It does NOT cover the window before the call: `currentLabel` is
 * whatever the caller already read (typically minutes earlier, from a
 * tick-start `gh issue list` snapshot), never re-read here. If the issue's
 * live label changed since then (a human, or another process, relabeled it
 * in between), `--remove-label <currentLabel>` targets a label the issue no
 * longer carries — `gh` no-ops that removal silently rather than erroring —
 * so the call still adds `newLabel`, and the issue ends up holding BOTH the
 * label it actually has now and `newLabel`. A caller that cares about that
 * external race re-checks the live label immediately before calling this
 * (see `stageLabelStillCurrent` in
 * `solutions/ontological/lib/services/orchestrator/ticks/issues.ts`, the
 * `issues` tick's guard). `currentLabel` is `null` when the issue carries no
 * prior stage label (a freshly captured issue, or one a human labeled with
 * no predecessor) — the `--remove-label` flag is then omitted rather than
 * passed empty.
 */
export function setIssueLabel(
  number: number,
  currentLabel: string | null,
  newLabel: string,
): GhVerb<void> {
  const argv = ['issue', 'edit', String(number)]
  if (currentLabel !== null) argv.push('--remove-label', currentLabel)
  argv.push('--add-label', newLabel)
  return { argv, checked: true, parse: nothing }
}

// ── helpers over the parsed rows ────────────────────────────────────────────

/**
 * The row whose `headRefName` exactly equals `branch`, or null.
 *
 * gh's `head:` search is a prefix match, so `task/foo` also returns
 * `task/foo-2`. Every caller that means one branch needs this filter.
 */
export function pickPrForBranch(rows: PullRequest[] | null, branch: string): PullRequest | null {
  if (rows === null) return null
  return rows.find((r) => r.headRefName === branch) ?? null
}

/**
 * True when GitHub has not finished computing this PR's mergeability.
 *
 * The answer is not stable on a cold query: GitHub kicks off the merge
 * computation when asked and answers `UNKNOWN` until it lands. A caller that
 * treats the first `UNKNOWN` as final will mis-triage a PR that is merely
 * slow, so re-ask a few times before believing it.
 */
export function needsMergeStateRetry(pr: PullRequest): boolean {
  return pr.mergeable === 'UNKNOWN' || pr.mergeStateStatus === 'UNKNOWN'
}
