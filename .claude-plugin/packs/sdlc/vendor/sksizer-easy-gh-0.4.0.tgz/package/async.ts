/**
 * `AsyncGh` — the awaitable GitHub client, the twin of {@link Gh}.
 *
 * Same tri-modal contract, promised: queries resolve to parsed values and
 * never reject on a gh failure, mutations reject with `CommandFailed`, and
 * `raw`/`rawChecked` are the hatches. It is driven by the same pure verb
 * table as `Gh`, so the two cannot drift on argv or parsing. Use it where the
 * sync client would block the event loop: a fan-out of per-PR queries.
 */

import {
  runCheckedAsync,
  resolveRunnerAsync,
  type AsyncCommandRunner,
  type AsyncCommandRunOptions,
  type CommandResult,
} from '@sksizer/command-seam'

import { parseOwnerRepo } from './repo.ts'
import type { IssueRow, Label, OwnerRepo, PullRequest } from './types.ts'
import * as v from './verbs.ts'
import type {
  ApiOptions,
  ApiResponse,
  AuthStatus,
  GhVerb,
  IssueListOptions,
  PrListOptions,
} from './verbs.ts'

/** Per-call options every method accepts. */
interface CallOptions {
  timeoutMs?: number | undefined
  signal?: AbortSignal | undefined
}

/** How long to wait between merge-state retries, in milliseconds. */
const MERGE_STATE_RETRY_DELAY_MS = 1_500

/** A typed, awaitable gh client bound to one working directory. */
export class AsyncGh {
  readonly cwd: string
  private readonly runner: AsyncCommandRunner

  constructor(cwd: string, opts: { runner?: AsyncCommandRunner | undefined } = {}) {
    this.cwd = cwd
    this.runner = resolveRunnerAsync('gh', opts.runner)
  }

  /** The same client rooted at a different directory (same runner). */
  at(cwd: string): AsyncGh {
    return new AsyncGh(cwd, { runner: this.runner })
  }

  // ── escape hatches ────────────────────────────────────────────────────────

  /** Unchecked passthrough for verbs not yet lifted into the API. */
  raw(argv: string[], opts: CallOptions = {}): Promise<CommandResult> {
    return this.runner.run(argv, { cwd: this.cwd, ...opts })
  }

  /** Checked passthrough — rejects with `CommandFailed` on a non-zero exit. */
  rawChecked(argv: string[], opts: CallOptions = {}): Promise<CommandResult> {
    return runCheckedAsync(this.runner, argv, { cwd: this.cwd, ...opts })
  }

  /** Run one verb from the table, honouring its checked/unchecked contract. */
  private async exec<T>(verb: GhVerb<T>, call: CallOptions = {}): Promise<T> {
    const opts: AsyncCommandRunOptions = { cwd: this.cwd }
    if (call.timeoutMs !== undefined) opts.timeoutMs = call.timeoutMs
    if (call.signal !== undefined) opts.signal = call.signal
    const result = verb.checked
      ? await runCheckedAsync(this.runner, verb.argv, opts)
      : await this.runner.run(verb.argv, opts)
    return verb.parse(result)
  }

  // ── queries ───────────────────────────────────────────────────────────────

  /** Pull requests matching `opts`, or null when gh failed. */
  prList(opts: PrListOptions & CallOptions = {}): Promise<PullRequest[] | null> {
    return this.exec(v.prList(opts), opts)
  }

  /** One PR with the heavy fields, or null when gh failed. */
  prView(
    number: number,
    opts: { fields?: readonly string[] | undefined } & CallOptions = {},
  ): Promise<PullRequest | null> {
    return this.exec(v.prView(number, opts.fields ?? v.PR_VIEW_FIELDS), opts)
  }

  /** The open PR whose head exactly equals `branch`, or null. See `Gh.openPrFor`. */
  async openPrFor(
    branch: string,
    opts: { limit?: number; fields?: readonly string[] } & CallOptions = {},
  ): Promise<PullRequest | null> {
    const rows = await this.prList({
      head: branch,
      limit: opts.limit ?? 5,
      fields: opts.fields ?? v.PR_REF_FIELDS,
      timeoutMs: opts.timeoutMs,
      signal: opts.signal,
    })
    return v.pickPrForBranch(rows, branch)
  }

  /** {@link prView}, re-asked until GitHub settles the merge state. See `Gh.prViewSettled`. */
  async prViewSettled(
    number: number,
    opts: {
      attempts?: number | undefined
      fields?: readonly string[] | undefined
      sleep?: ((ms: number) => Promise<void>) | undefined
    } & CallOptions = {},
  ): Promise<PullRequest | null> {
    const attempts = Math.max(1, opts.attempts ?? 3)
    const sleep = opts.sleep ?? sleepAsync
    let last: PullRequest | null = null
    for (let i = 0; i < attempts; i += 1) {
      last = await this.prView(number, opts)
      if (last === null || !v.needsMergeStateRetry(last)) return last
      if (i < attempts - 1) await sleep(MERGE_STATE_RETRY_DELAY_MS)
    }
    return last
  }

  /** A PR's body text, or null when gh failed. */
  prBody(number: number, opts: CallOptions = {}): Promise<string | null> {
    return this.exec(v.prBody(number), opts)
  }

  /** A REST GET through `gh api`; failure is `ok: false`, never a rejection. */
  api(endpoint: string, opts: ApiOptions & CallOptions = {}): Promise<ApiResponse> {
    return this.exec(v.api(endpoint, opts), opts)
  }

  /** Every label on the repository, or null when gh failed. */
  labelList(opts: CallOptions = {}): Promise<Label[] | null> {
    return this.exec(v.labelList(), opts)
  }

  /** Issues matching `opts`, or null when gh failed. */
  issueList(opts: IssueListOptions & CallOptions = {}): Promise<IssueRow[] | null> {
    return this.exec(v.issueList(opts), opts)
  }

  /** One issue with its labels, or null when gh failed. */
  issueView(number: number, opts: CallOptions = {}): Promise<IssueRow | null> {
    return this.exec(v.issueView(number), opts)
  }

  /** True iff the `gh` binary is on PATH and runs. */
  installed(): Promise<boolean> {
    return this.exec(v.version())
  }

  /** True iff `gh` holds credentials. */
  async authenticated(): Promise<boolean> {
    return (await this.authStatus()).ok
  }

  /** Login state and what `gh auth status` printed. */
  authStatus(): Promise<AuthStatus> {
    return this.exec(v.authStatus())
  }

  /** True iff `gh` is installed AND authenticated; short-circuits. */
  async ready(): Promise<boolean> {
    return (await this.installed()) && (await this.authenticated())
  }

  /** `{owner, repo}` for a remote URL, or null. Pure; sync on purpose. */
  ownerRepo(remoteUrl: string | null): OwnerRepo | null {
    return remoteUrl === null ? null : parseOwnerRepo(remoteUrl)
  }

  // ── mutations (checked) ───────────────────────────────────────────────────

  /** Open a PR and return the URL gh prints. */
  createPr(opts: v.CreatePrOptions): Promise<string> {
    return this.exec(v.createPr(opts))
  }

  /** Retitle or rewrite a PR body. */
  editPr(
    number: number,
    opts: { title?: string | undefined; body?: string | undefined },
  ): Promise<void> {
    return this.exec(v.editPr(number, opts))
  }

  /** Rewrite just a PR's body. */
  editPrBody(number: number, body: string): Promise<void> {
    return this.exec(v.editPrBody(number, body))
  }

  /** Post a conversation comment on a PR. */
  prComment(number: number, body: string): Promise<void> {
    return this.exec(v.prComment(number, body))
  }

  /** Bring a PR's head branch up to date with its base. */
  prUpdateBranch(number: number, style: 'merge' | 'rebase' = 'merge'): Promise<void> {
    return this.exec(v.prUpdateBranch(number, style))
  }

  /** Create a label (or force it to `opts`'s color/description if it exists). */
  createLabel(opts: v.CreateLabelOptions): Promise<void> {
    return this.exec(v.labelCreate(opts))
  }

  /** Recolor and/or redescribe an existing label. */
  editLabel(
    name: string,
    opts: { color?: string | undefined; description?: string | undefined },
  ): Promise<void> {
    return this.exec(v.labelEdit(name, opts))
  }

  /** Advance an issue's stage label in a single `gh issue edit` call. */
  setIssueLabel(number: number, currentLabel: string | null, newLabel: string): Promise<void> {
    return this.exec(v.setIssueLabel(number, currentLabel, newLabel))
  }
}

function sleepAsync(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms))
}
