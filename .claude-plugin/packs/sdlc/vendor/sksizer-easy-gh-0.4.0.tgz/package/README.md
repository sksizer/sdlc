# @sksizer/easy-gh

A typed GitHub client for TypeScript, over the `gh` CLI. The GitHub-side twin
of [`@sksizer/easy-git`](../easy-git).

```ts
import { Gh } from "@sksizer/easy-gh";

const gh = new Gh(process.cwd());

for (const pr of gh.prList({ state: "open" }) ?? []) {
  console.log(pr.number, pr.baseRefName, pr.mergeable);
}
```

## Authentication is `gh`'s

No token is read, stored, or forwarded. That is the reason this shells out to
the CLI rather than speaking REST: the credential already exists in the user's
keychain, and a library that reaches for `GITHUB_TOKEN` is a library that can
leak one.

## A total model

`gh --json` returns only the fields you asked for, so every field on
`PullRequest` has a "not known" value and none of them is `undefined`:

```ts
const pr = parsePullRequest({ number: 7 })!;
pr.mergeable;        // "UNKNOWN"  — not undefined
pr.reviewDecision;   // null
pr.checks;           // []
```

Absent and unknowable are the same answer to a caller, so they get one
representation. This is what stops a consumer reading a field it never
requested as a fact.

The enums are open — unions ending in `(string & {})` — because GitHub adds
members, and a client that crashes on an unrecognized one is worse than a
client that carries it through.

## Three modes, so failure is never ambiguous

| | on failure |
| --- | --- |
| **queries** | return the absence value — `null`. Never throw. |
| **mutations** | throw `CommandFailed`, carrying argv and the full result. |
| **`raw(argv)`** | hand back the raw `CommandResult`; you decide. |

A query returns `null`, never `[]`. `prList()` returning `[]` means *this
repository has no open PRs*; `null` means *we could not ask*. Collapsing those
turns an expired credential into "nothing to do".

## Two shape hazards it absorbs

**Author logins differ by transport.** GraphQL (`gh pr view --json`) returns a
suffix-less login (`github-actions`); REST (`gh api`) returns the suffixed one
(`github-actions[bot]`). Comparing one against the other silently never
matches — which is how bot noise gets treated as human review feedback.
Logins are normalized to the suffix-less form once, in `parseActor`.

**`statusCheckRollup` holds two node types.** A modern `CheckRun` carries
`name`/`status`/`conclusion`; a legacy `StatusContext` carries
`context`/`state`. Both are folded onto one `verdict` axis:

```ts
pr.checks.every((c) => c.verdict === "success");
anyCheckFailed(pr.checks);
```

A check still running is `pending`, never `success`. Reading "no failure yet"
as green is how a red build merges.

## The merge state is not stable on a cold query

GitHub computes mergeability lazily: the first query kicks it off and answers
`UNKNOWN` until it lands. A caller that believes that first answer mis-triages
every PR that is merely slow.

```ts
const pr = gh.prViewSettled(1491);   // re-asks up to 3 times
```

`UNKNOWN` is still a legitimate final verdict, so callers must handle it.

Note also that `mergeStateStatus: "BEHIND"` only ever appears when branch
protection *requires* an up-to-date branch. Without that rule a branch a
hundred commits behind still reports `CLEAN` — so it is a corroborating hint
about staleness, never the measure of it. Compute that from the commit graph
(`easy-git`'s `aheadBehind`).

## Pure halves, for an async fan-out

The verb table and every parser are side-effect free, so concurrent callers
drive them through their own `AsyncCommandRunner` without duplicating a line
of parsing:

```ts
import { prView, parsePullRequest } from "@sksizer/easy-gh";

const verb = prView(1491);
const result = await runner.run(verb.argv, { cwd });
const pr = verb.parse(result);
```

## `AsyncGh`

The awaitable twin of `Gh`, for a fan-out that must not block the event loop.
Same tri-modal contract (queries resolve to a value or `null` and never
reject, mutations reject with `CommandFailed`, `raw`/`rawChecked` are the
hatches), driven by the same verb table, so the two cannot drift. It takes an
`AsyncCommandRunner` and defaults to `spawnRunnerAsync("gh")`.

```ts
import { AsyncGh } from "@sksizer/easy-gh";

const gh = new AsyncGh("/repo");
const prs = await Promise.all(branches.map((b) => gh.openPrFor(b)));
const body = await gh.prBody(42); // string | null
await gh.editPrBody(42, `${body}\n\nfooter`);
await gh.prComment(42, "rebased");
await gh.prUpdateBranch(42, "rebase");
```

`api(endpoint, opts)` (on `Gh` and `AsyncGh`) is a REST GET through `gh api`.
It never throws; the result is `{ ok, status, etag, body, malformed, stderr }`.
Pass `etag` for a conditional request (`If-None-Match`; a 304 comes back as
`status: 304, body: null`), or `includeHeaders: true` to read status and ETag
without one. `{owner}` and `{repo}` in the endpoint are filled in by gh.

## Injecting the subprocess seam

`Gh` takes a `CommandRunner` from
[`@sksizer/command-seam`](../command-seam), so a suite runs offline:

```ts
const gh = new Gh("/repo", {
  runner: { run: (argv) => ({ exitCode: 0, stdout: "[]", stderr: "" }) },
});
```

## What is not here

- **Merging and closing.** `gh pr merge` / `gh pr close` are consequential
  enough that they belong to a caller's own policy layer, where the audit
  trail lives — not behind a convenience method.
- **A full REST client.** `api()` is a GET; anything else goes through
  `raw(["api", …])`.
- **Anything that reads a token.**

## License

MIT
