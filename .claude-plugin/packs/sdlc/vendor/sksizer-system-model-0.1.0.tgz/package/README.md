# @sksizer/system-model

A project's structure as it crosses the wire, plus the one-method port a host
satisfies to serve it. Types and API only — no walker, no rendering, no
runtime dependencies.

```ts
import type { SystemGraph, SystemGraphClient, SystemNode } from '@sksizer/system-model'
```

## Why it exists

Four things independently declared this shape before this package did: the
Rust schema, ontogen's generated TypeScript, the experience layer's
hand-restated copy, and the TypeScript walker. They agreed — but only because
someone kept checking, and nothing would have failed if they stopped.

## The two halves

**`./graph`** — `SystemGraph`, `SystemNode`, `SystemEdge`, and the string
unions (`NodeKind`, `DepKind`, `SpecifierKind`, `Ecosystem`) with their
`ALL_*` rosters.

Field names are snake_case because that is what crosses; the enum-shaped
fields are typed `string` rather than as those unions, deliberately, so a
consumer that meets a sixth node kind shows it instead of breaking. The unions
are exported for the places that want to narrow on purpose.

**`./client`** — `SystemGraphClient`, the port. One method, because the
surface needs one thing: the whole graph. Folding a container is an
interaction, not a query, so the aggregation runs client-side over one payload
and there is no second call for "the graph, but collapsed".

## Who is on each side

| | |
|---|---|
| **Authority on the shape** | `solutions/ontological/desktop/src-tauri/src/schema/system_graph.rs` |
| **Producers** | the `manifest-graph` crate (via SDF's service) and `@sksizer/manifest-graph` (via `buildSystemGraph`) |
| **Hosts satisfying the port** | SDF, over ontogen's generated transport; `product-system-graph`, over a Nitro route |
| **Consumer** | `@sdlc/exp-system-graph`, which knows only this contract |

Two hosts satisfy the port today and share no code, which is the property
worth protecting: it is why the same viewer runs against a Rust service and
against an in-process TypeScript call without noticing.

Changing the wire means changing the Rust schema and this package together.
The generated `src-nuxt/app/generated/types.ts` is regenerated from the Rust
and is not hand-edited.

## What is deliberately not here

The **view** model — `ViewSpec`, `select`, `encode`, `derive`, and the
layouts — lives in `@sdlc/exp-system-graph`'s `app/lib/`. It is not a contract
between components; it is one viewer's internals, and putting it here would
make every host carry a viewer's opinions.
