# @sksizer/etag-write

Atomic file writes, sha256 etags and compare-and-swap. No dependencies beyond
Node's own `fs` and `crypto`.

```ts
import { atomicWrite, etagOfFile, writeCas } from "@sksizer/etag-write";

// A reader or a crash sees the old file or the new one, never half of either.
atomicWrite("state.json", JSON.stringify(state, null, 2) + "\n");

// Refuse to overwrite a change made since we read the file.
const seen = etagOfFile("note.md"); // null when the file does not exist
writeCas("note.md", edited, seen);
```

## What a write does

`atomicWrite(path, data, { mode? })` creates the parent directories, writes
`data` to a uniquely named temp file beside `path`, fsyncs it, renames it over
`path`, then fsyncs the directory where the platform allows it. The temp file
sits in the same directory because a rename across filesystems is not atomic.
Its name is unique per write, so concurrent writers never share one. Any
failure removes the temp file and rethrows the error.

`mode` sets the file's exact permissions, ignoring the umask. Without it the
file is created the way `writeFileSync` creates one.

`atomicWriteAsync` is the same write over `fs/promises`.

## Compare-and-swap

`writeCas(path, data, expectedEtag)` takes the etag of the content the caller
read, or `null` when it read nothing, and returns the new etag:

| on disk | etag supplied | result |
|---|---|---|
| exists | matches | write |
| exists | differs | `WriteConflictError`, reason `changed` |
| exists | none | `WriteConflictError`, reason `exists-without-etag` |
| absent | none | create |
| absent | some | create (the file was deleted since it was read) |

The third row is the one that matters: no etag on an existing file is a blind
write, and blind writes lose data.

The check and the write are two steps, so this guards against a writer that
read stale content. It is not a lock between two writers that both read the
current content at the same moment.

## The rest

- `etag(data)` — lowercase hex sha256; a string hashes as UTF-8.
- `etagOfFile(path)` — the etag of a file, or `null` when it does not exist. Any
  other read error throws.
- `writeIfChanged(path, data)` — writes only when the content differs, so an
  identical write leaves mtime alone. Returns whether it wrote.

## Peer

The `etag-write` Rust crate has the same write sequence, etag format and
contract table. The `mode` option and `atomicWriteAsync` exist only here.

## License

MIT
