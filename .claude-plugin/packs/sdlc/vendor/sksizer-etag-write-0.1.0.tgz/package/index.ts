/**
 * Atomic write, sha256 etag and compare-and-swap. TypeScript peer of the
 * `etag-write` crate.
 */

import { createHash, randomBytes } from 'node:crypto'
import {
  closeSync,
  fchmodSync,
  fsyncSync,
  mkdirSync,
  openSync,
  readFileSync,
  renameSync,
  rmSync,
  writeSync,
} from 'node:fs'
import { mkdir, open, rename, rm } from 'node:fs/promises'
import { basename, dirname, join } from 'node:path'

export type WriteData = string | Uint8Array

export interface AtomicWriteOptions {
  /** Exact mode of the written file, applied regardless of umask. */
  mode?: number | undefined
}

export class WriteConflictError extends Error {
  readonly path: string
  readonly reason: 'changed' | 'exists-without-etag'

  constructor(path: string, reason: WriteConflictError['reason']) {
    super(
      reason === 'changed'
        ? `${path} changed on disk since it was read`
        : `${path} exists — send its etag to overwrite`,
    )
    this.name = 'WriteConflictError'
    this.path = path
    this.reason = reason
  }
}

const toBytes = (data: WriteData): Buffer =>
  typeof data === 'string'
    ? Buffer.from(data, 'utf8')
    : Buffer.from(data.buffer, data.byteOffset, data.byteLength)

/** Lowercase hex sha256 of `data`; a string hashes as UTF-8. */
export function etag(data: WriteData): string {
  return createHash('sha256').update(toBytes(data)).digest('hex')
}

/**
 * The etag of the file at `path`, or `null` when it does not exist.
 *
 * @throws any read error other than `ENOENT`.
 */
export function etagOfFile(path: string): string | null {
  const bytes = readOrNull(path)
  return bytes === null ? null : etag(bytes)
}

/** An unreadable file still exists; treating it as absent would allow a blind overwrite. */
function readOrNull(path: string): Buffer | null {
  try {
    return readFileSync(path)
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code === 'ENOENT') return null
    throw err
  }
}

/**
 * A fresh name beside `path`, so the rename never crosses a filesystem. Unique
 * per write: two writers sharing a temp name would rename it out from under
 * each other.
 */
function tempPath(path: string): string {
  return join(dirname(path), `.${basename(path)}.${randomBytes(6).toString('hex')}.tmp`)
}

/** Durability of the rename itself; a platform that refuses a directory fsync skips it. */
function syncDir(dir: string): void {
  let fd: number | undefined
  try {
    fd = openSync(dir, 'r')
    fsyncSync(fd)
  } catch {
    /* best-effort */
  } finally {
    if (fd !== undefined) closeSync(fd)
  }
}

async function syncDirAsync(dir: string): Promise<void> {
  const fh = await open(dir, 'r').catch(() => null)
  if (fh === null) return
  try {
    await fh.sync()
  } catch {
    /* best-effort */
  } finally {
    await fh.close()
  }
}

/**
 * Replace `path` with `data` so a reader or a crash sees the old file or the
 * new one, never part of either. Creates parent directories. The temp file is
 * fsynced before the rename and removed on any failure.
 */
export function atomicWrite(path: string, data: WriteData, opts: AtomicWriteOptions = {}): void {
  const dir = dirname(path)
  mkdirSync(dir, { recursive: true })
  const bytes = toBytes(data)
  const tmp = tempPath(path)
  try {
    const fd = openSync(tmp, 'wx', opts.mode ?? 0o666)
    try {
      if (opts.mode !== undefined) fchmodSync(fd, opts.mode)
      for (let off = 0; off < bytes.length;) off += writeSync(fd, bytes, off)
      fsyncSync(fd)
    } finally {
      closeSync(fd)
    }
    renameSync(tmp, path)
  } catch (err) {
    rmSync(tmp, { force: true })
    throw err
  }
  syncDir(dir)
}

/** {@link atomicWrite} without blocking the event loop. */
export async function atomicWriteAsync(
  path: string,
  data: WriteData,
  opts: AtomicWriteOptions = {},
): Promise<void> {
  const dir = dirname(path)
  await mkdir(dir, { recursive: true })
  const tmp = tempPath(path)
  try {
    const fh = await open(tmp, 'wx', opts.mode ?? 0o666)
    try {
      if (opts.mode !== undefined) await fh.chmod(opts.mode)
      await fh.writeFile(toBytes(data))
      await fh.sync()
    } finally {
      await fh.close()
    }
    await rename(tmp, path)
  } catch (err) {
    await rm(tmp, { force: true })
    throw err
  }
  await syncDirAsync(dir)
}

/**
 * {@link atomicWrite} behind a compare-and-swap, with the crate's contract.
 * `expectedEtag` is the etag of the content the caller read, or `null` when it
 * read nothing. Returns the new etag. The check and the write are separate
 * steps, so a writer landing between them is overwritten.
 *
 * | on disk | etag supplied | result |
 * |---|---|---|
 * | exists | matches | write |
 * | exists | differs | `WriteConflictError`, reason `changed` |
 * | exists | none | `WriteConflictError`, reason `exists-without-etag` |
 * | absent | none | create |
 * | absent | some | create (the file was deleted since it was read) |
 *
 * An existing file with no etag is refused: that would be a blind write.
 *
 * A file that exists but cannot be read is not absent: its read error is thrown.
 *
 * @throws WriteConflictError per the table.
 */
export function writeCas(
  path: string,
  data: WriteData,
  expectedEtag: string | null,
  opts: AtomicWriteOptions = {},
): string {
  const current = readOrNull(path)
  if (current !== null) {
    if (expectedEtag === null) throw new WriteConflictError(path, 'exists-without-etag')
    if (etag(current) !== expectedEtag) throw new WriteConflictError(path, 'changed')
  }
  atomicWrite(path, data, opts)
  return etag(data)
}

/**
 * Write only when the content differs, so an identical write leaves mtime
 * alone and triggers no file watchers. Returns whether it wrote. `mode` applies
 * only to a write; an unchanged file keeps its permissions.
 */
export function writeIfChanged(
  path: string,
  data: WriteData,
  opts: AtomicWriteOptions = {},
): boolean {
  const existing = readOrNull(path)
  if (existing !== null && existing.equals(toBytes(data))) return false
  atomicWrite(path, data, opts)
  return true
}
