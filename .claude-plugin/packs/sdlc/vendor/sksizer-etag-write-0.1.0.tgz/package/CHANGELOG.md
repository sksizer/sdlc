# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Version 0.1.0 has never been published.

### Changed

- Renamed from `@sksizer/atomic-write` to `@sksizer/etag-write`, matching the
  `etag-write` crate. The `atomicWrite` and `atomicWriteAsync` names stay.

### Added

- `atomicWrite` and `atomicWriteAsync`: temp file beside the target, fsync,
  rename, best-effort directory fsync, temp file removed on failure. A `mode`
  option sets the file's exact permissions.
- `etag` and `etagOfFile`: lowercase hex sha256, matching the Rust crate.
- `writeCas`: compare-and-swap under the crate's contract table, failing with
  `WriteConflictError` (`changed` or `exists-without-etag`).
- `writeIfChanged`: skips a write whose content is already on disk.
