# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Version 0.1.0 has never been published.

### Added

- Line statistics by code / comments / blank / prose and by file group, with
  generated files counted apart.
- Change categories per file, dependency-manifest changes, public API delta
  (TS entry points, Rust `pub` items) and a cyclomatic-complexity movers table.
- `pr-stats [<pr>|--base <ref>] [--write] [--detail] [--json]`, and
  `runStats` / `buildReport` / `renderReport` / `spliceBody` as a library.
- `scripts/bundle.ts` (`bun run bundle`, `bundle:check`): a single-file `pr-stats.mjs`
  for plain Node, shipped in the craft plugin's `pr-stats` skill.
- Exported-API delta now reads every changed TS module (entry points flagged), and the
  public members of exported classes and interfaces when `typescript` is found.

### Changed

- Unnamed functions are named after their nearest named enclosing scope plus an ordinal,
  and unmatched ones are shown only under `--detail`.
