/**
 * Change categories, from the diff alone. Each file lands in exactly one
 * category, first match wins:
 *
 * generated, deleted, added, renamed (any similarity), dependencies (a
 * dependency manifest whose dependency entries changed), docs, tests,
 * formatting (the changed lines are identical once ALL whitespace is removed —
 * reflows and re-indents), config (the other non-source files), comments (every changed line is a comment or blank), logic (the rest).
 *
 * Because added/deleted/renamed win over the content categories, a brand-new
 * test file is "added", not "tests". Heuristic limits: "formatting" compares
 * concatenated removed text with concatenated added text, so a pure reorder of
 * lines reads as formatting; "comments" inherits the comment heuristic's floor.
 */

import type { FileDiff } from './diff.ts'
import { isCommentOrBlank, isSource } from './heuristic.ts'
import { basename, fileGroup } from './lines.ts'
import type { Category, FileGroup } from './types.ts'

export interface DepEntry {
  name: string
  version: string
}
export interface DepChange {
  file: string
  added: DepEntry[]
  removed: DepEntry[]
  bumped: { name: string; from: string; to: string }[]
}

const VERSIONISH = /^(?:[\^~<>=*]|\d|workspace:|npm:|github:|git\+|file:|link:|catalog:)/
const PKG_LINE = /^\s*"([^"]+)"\s*:\s*"([^"]*)"\s*,?\s*$/
const CARGO_SKIP = new Set([
  'name',
  'version',
  'edition',
  'license',
  'description',
  'authors',
  'repository',
  'homepage',
  'readme',
  'rust-version',
  'resolver',
  'path',
  'publish',
])
const CARGO_LINE = /^\s*([A-Za-z0-9_-]+)\s*=\s*(?:"([^"]+)"|\{.*?version\s*=\s*"([^"]+)".*\})\s*$/

/** Dependency-looking entries in one side of a manifest diff. */
function depEntries(file: string, lines: readonly string[]): DepEntry[] {
  const base = basename(file)
  const out: DepEntry[] = []
  for (const l of lines) {
    if (base === 'package.json') {
      const m = PKG_LINE.exec(l)
      if (m !== null && m[1] !== 'version' && m[1] !== 'url' && VERSIONISH.test(m[2]!)) {
        out.push({ name: m[1]!, version: m[2]! })
      }
    } else if (base === 'Cargo.toml') {
      const m = CARGO_LINE.exec(l)
      if (m !== null && !CARGO_SKIP.has(m[1]!)) {
        out.push({ name: m[1]!, version: m[2] ?? m[3] ?? '' })
      }
    }
  }
  return out
}

/** Dependencies added, removed and bumped in a `package.json` / `Cargo.toml` diff; null for other files. */
export function dependencyChange(f: FileDiff): DepChange | null {
  const base = basename(f.path)
  if (base !== 'package.json' && base !== 'Cargo.toml') return null
  const add = depEntries(f.path, f.added)
  const rem = depEntries(f.path, f.removed)
  if (add.length === 0 && rem.length === 0) return null
  const remBy = new Map(rem.map((e) => [e.name, e.version]))
  const addBy = new Map(add.map((e) => [e.name, e.version]))
  const change: DepChange = { file: f.path, added: [], removed: [], bumped: [] }
  for (const e of add) {
    const before = remBy.get(e.name)
    if (before === undefined) change.added.push(e)
    else if (before !== e.version) change.bumped.push({ name: e.name, from: before, to: e.version })
  }
  for (const e of rem) if (!addBy.has(e.name)) change.removed.push(e)
  return change
}

const squash = (lines: readonly string[]): string => lines.join('').replace(/\s+/g, '')

export function categorize(f: FileDiff): Category {
  const group: FileGroup = fileGroup(f.path)
  if (group === 'generated') return 'generated'
  if (f.status === 'deleted') return 'deleted'
  if (f.status === 'added') return 'added'
  if (f.status === 'renamed') return 'renamed'
  if (dependencyChange(f) !== null) return 'dependencies'
  if (group === 'docs') return 'docs'
  if (group === 'tests') return 'tests'
  const changed = f.added.length + f.removed.length
  if (changed > 0 && squash(f.added) === squash(f.removed)) return 'formatting'
  if (group === 'other') return 'config'
  if (
    changed > 0 &&
    isSource(f.path) &&
    f.added.every(isCommentOrBlank) &&
    f.removed.every(isCommentOrBlank)
  ) {
    return 'comments'
  }
  return 'logic'
}
