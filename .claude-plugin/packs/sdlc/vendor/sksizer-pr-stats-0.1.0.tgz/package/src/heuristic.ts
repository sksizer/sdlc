/**
 * The line-level "is this a comment?" heuristic. `sdlc gate comment-only`
 * imports it from here too, so the gate and the stats table agree on what a
 * comment is.
 *
 * It is a FLOOR, not a parser. One table of source extensions and one table of
 * comment openers cover a dozen languages with no per-language grammar, and the
 * price is known: a line that starts like a comment but is not one is counted as
 * one (a Rust attribute `#[derive(...)]` reads as a `#` comment; a Markdown-ish
 * `* item` inside a source file reads as a block-comment continuation; `--`
 * and `;` claim SQL/Lua/Lisp comments but also some operators at line start),
 * and code that follows a block-comment opener on the same line is invisible. A
 * line that closes a block comment and then carries code counts as comment.
 * The gate tolerates that because it must produce zero noise on a real sweep;
 * the stats table tolerates it because it is descriptive.
 */

/**
 * Extensions whose lines are held to the comment rule. Markdown and other prose
 * are deliberately absent — they are not source.
 */
export const SOURCE_EXT = [
  '.ts',
  '.tsx',
  '.mts',
  '.cts',
  '.js',
  '.jsx',
  '.mjs',
  '.cjs',
  '.vue',
  '.rs',
  '.go',
  '.py',
  '.rb',
  '.java',
  '.kt',
  '.swift',
  '.c',
  '.h',
  '.cc',
  '.cpp',
  '.hpp',
  '.cs',
  '.php',
  '.scala',
  '.sh',
  '.bash',
] as const

/**
 * Comment openers across the languages above. A line is a comment when it
 * starts with one of these after indentation.
 *
 * `*` and the block-comment closer carry continuation and close lines of a
 * block comment; `#` covers Python/Ruby/shell and is why a `#`-leading line in
 * a .rs file (an attribute like `#[derive(...)]`) would slip through. That is
 * the deliberate trade: a per-language parser would catch the attribute and cost
 * a parser per language.
 */
export const COMMENT_START = ['//', '/*', '*/', '*', '#', '<!--', '-->', '--', ';'] as const

/** True when `path` has a source extension. */
export function isSource(path: string): boolean {
  return SOURCE_EXT.some((ext) => path.endsWith(ext))
}

/** True when `line` is whitespace only. */
export function isBlank(line: string): boolean {
  return line.trim() === ''
}

/** True when `line` starts with a comment opener after indentation. */
export function isCommentLine(line: string): boolean {
  const s = line.trim()
  return COMMENT_START.some((c) => s.startsWith(c))
}

/** True when `line` is blank or a comment. */
export function isCommentOrBlank(line: string): boolean {
  return isBlank(line) || isCommentLine(line)
}
