/**
 * `@sksizer/pr-stats` — descriptive statistics for a PR or branch diff.
 *
 * `runStats` is the whole pipeline over injectable git/gh runners;
 * `buildReport` + `renderReport` + `spliceBody` are the pure pieces under it.
 */

export {
  COMMENT_START,
  SOURCE_EXT,
  isBlank,
  isCommentLine,
  isCommentOrBlank,
  isSource,
} from './heuristic.ts'
export { parseDiff, type FileDiff, type FileStatus } from './diff.ts'
export { classifyLine, computeLineStats, fileGroup, isGenerated } from './lines.ts'
export { categorize, dependencyChange } from './categories.ts'
export { apiLanguage, diffApi, extractApi } from './api.ts'
export {
  defaultAnalyzers,
  lizardAnalyzer,
  parseLizardCsv,
  typescriptAnalyzer,
  type Analyzer,
} from './complexity.ts'
export { buildReport, type ReportOptions, type ReportPorts } from './report.ts'
export { renderReport, type RenderOptions } from './render.ts'
export { STATS_END, STATS_START, spliceBody } from './splice.ts'
export { StatsError, runStats, type RunArgs, type RunEnv, type RunResult } from './run.ts'
export { reportSchema, CATEGORIES, FILE_GROUPS, LINE_KINDS, type Report } from './types.ts'
