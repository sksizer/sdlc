/**
 * The git/gh-facing half: fetch the diff, resolve base/head revisions, build
 * the report, optionally write the PR body. Everything goes through the
 * easy-git / easy-gh clients over an injectable runner.
 */

import { Gh } from '@sksizer/easy-gh'
import { CommandFailed, type CommandRunner } from '@sksizer/command-seam'
import { Git } from '@sksizer/easy-git'

import { buildReport, type ReportOptions, type ReportPorts } from './report.ts'
import { renderReport } from './render.ts'
import { spliceBody } from './splice.ts'
import type { Report } from './types.ts'

/** A failure the caller should show as a message, not a stack. */
export class StatsError extends Error {}

export interface RunArgs {
  cwd: string
  /** PR number, or null to measure the current branch. */
  pr: number | null
  /** Ref to diff against; default origin/main. Not with a PR. */
  base: string | null
  write: boolean
  detail: boolean
  dryRun?: boolean
}

export interface RunEnv {
  git: CommandRunner
  gh: CommandRunner
  report?: ReportOptions
}

export interface RunResult {
  report: Report
  markdown: string
  written: boolean
}

export function runStats(args: RunArgs, env: RunEnv): RunResult {
  if (args.pr !== null && args.base !== null) {
    throw new StatsError('--base and a PR argument are mutually exclusive')
  }
  if (args.write && args.pr === null) throw new StatsError('--write needs a PR number')

  const git = new Git(args.cwd, { runner: env.git })
  const gh = new Gh(args.cwd, { runner: env.gh })

  let source: string
  let diff: string
  let ports: ReportPorts | null = null
  try {
    if (args.pr !== null) {
      source = `PR #${args.pr}`
      diff = gh.rawChecked(['pr', 'diff', String(args.pr)]).stdout
      const view = gh.prView(args.pr, { fields: ['number', 'baseRefName', 'headRefOid'] })
      const head = view?.headRefOid ?? null
      if (view !== null && head !== null && git.objectExists(head)) {
        const remoteBase = `origin/${view.baseRefName}`
        const base = git.mergeBase(remoteBase, head) ?? git.mergeBase(view.baseRefName, head)
        if (base !== null) ports = revPorts(git, base, head)
      }
    } else {
      const base = args.base ?? 'origin/main'
      source = `${base}...HEAD`
      diff = git.rawChecked(['diff', '-U0', '--no-color', '--no-ext-diff', `${base}...HEAD`]).stdout
      const mergeBase = git.mergeBase(base, 'HEAD')
      if (mergeBase !== null) ports = revPorts(git, mergeBase, 'HEAD')
    }
  } catch (e) {
    if (!(e instanceof CommandFailed)) throw e
    throw new StatsError(`could not read the diff: ${e.detail.trim().split('\n')[0]}`)
  }

  const report = buildReport(source, diff, ports, env.report)
  const markdown = renderReport(report, { detail: args.detail })

  let written = false
  if (args.write && args.pr !== null && args.dryRun !== true) {
    const view = gh.prView(args.pr, { fields: ['number', 'body'] })
    if (view === null) throw new StatsError(`could not read PR #${args.pr}`)
    // Always the compact form in the body, whatever was asked for on stdout.
    const next = spliceBody(view.body, renderReport(report))
    if (next !== view.body) gh.editPr(args.pr, { body: next })
    written = true
  }
  return { report, markdown, written }
}

function revPorts(git: Git, baseRev: string, headRev: string): ReportPorts {
  return { baseRev, headRev, showAtRev: (rev, path) => git.showAtRev(rev, path) }
}
