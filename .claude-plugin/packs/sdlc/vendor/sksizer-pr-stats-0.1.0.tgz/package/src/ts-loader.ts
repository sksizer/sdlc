/**
 * Load the `typescript` compiler API if some copy of it can be found.
 *
 * It is an optional peer: the project being measured usually has its own, so
 * resolution tries that first (from the working directory), then whatever this
 * package was installed beside. Absent both, callers fall back or skip, and say
 * so in the report.
 */

import { createRequire } from 'node:module'

export type TsModule = typeof import('typescript')

let cache: TsModule | null | undefined

export function loadTs(): TsModule | null {
  if (cache !== undefined) return cache
  cache = null
  for (const base of [`${process.cwd()}/`, import.meta.url]) {
    try {
      cache = createRequire(base)('typescript') as TsModule
      break
    } catch {
      // try the next place
    }
  }
  return cache
}
