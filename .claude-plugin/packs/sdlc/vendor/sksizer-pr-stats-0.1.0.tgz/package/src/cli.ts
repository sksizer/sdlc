/**
 * `pr-stats [<pr>|--base <ref>] [--write] [--detail] [--json]` — the
 * standalone CLI. Works in any git repository with `gh` authenticated; needs
 * no sdlc.
 *
 * Exit codes: 0 on success, 1 when the diff could not be read or the PR body
 * could not be written, 2 on a malformed command line.
 */

import { EXIT, defineCli, runMain, type CliContext } from '@sksizer/cli-tool'
import { spawnRunner } from '@sksizer/command-seam'

import { StatsError, runStats } from './run.ts'

const cli = defineCli({
  name: 'pr-stats',
  summary: 'Line, category, API and complexity statistics for a PR or branch diff.',
  positionals: [{ name: 'pr', help: 'PR number to measure. Omit to measure the current branch.' }],
  flags: {
    base: {
      kind: 'string',
      valueName: 'ref',
      help: 'Ref to diff against (`<ref>...HEAD`). Default origin/main. Not with a PR.',
    },
    write: { kind: 'boolean', help: "Write the statistics into the PR's body (needs a PR)." },
    detail: { kind: 'boolean', help: 'Long form: per-file list and every complexity mover.' },
    json: { kind: 'boolean', help: 'Print the structured report as JSON.' },
  },
})

export async function main(argv: readonly string[], ctx: CliContext): Promise<number> {
  const { io } = ctx
  const parsed = cli.parse(argv, io)
  if (parsed.status === 'help') return EXIT.ok
  if (parsed.status === 'error') {
    io.stderr(`pr-stats: ${parsed.message}\n`)
    return EXIT.usage
  }
  const v = parsed.values
  let pr: number | null = null
  const raw = parsed.positionals[0]
  if (raw !== undefined) {
    const n = Number(raw.replace(/^#/, ''))
    if (!Number.isInteger(n) || n <= 0) {
      io.stderr(`pr-stats: not a PR number: '${raw}'\n`)
      return EXIT.usage
    }
    pr = n
  }
  try {
    const out = runStats(
      { cwd: ctx.cwd, pr, base: v.base ?? null, write: v.write, detail: v.detail },
      { git: spawnRunner('git'), gh: spawnRunner('gh') },
    )
    io.stdout(v.json ? `${JSON.stringify(out.report, null, 2)}\n` : `${out.markdown}\n`)
    if (out.written) io.stderr(`pr-stats: wrote the statistics into PR #${pr}\n`)
    return EXIT.ok
  } catch (e) {
    if (!(e instanceof StatsError)) throw e
    io.stderr(`pr-stats: ${e.message}\n`)
    return e.message.includes('mutually exclusive') || e.message.includes('needs a PR')
      ? EXIT.usage
      : EXIT.error
  }
}

// Inert when imported; the published `bin/` shim calls `main` through `runMain`.
if (import.meta.main) {
  await runMain(main, { name: 'pr-stats' })
}
