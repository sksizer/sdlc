/**
 * Render a {@link Report} as the marked markdown block. Compact by default:
 * the line table, the file-group table, a category table, dependency and API
 * summaries, and a five-row complexity movers table. `detail` adds the
 * per-file list and the longer API and mover lists.
 */

import { STATS_END, STATS_START } from './splice.ts'
import { FILE_GROUPS, LINE_KINDS, type FileGroup, type LineKind, type Report } from './types.ts'

const KIND_LABEL: Record<LineKind, string> = {
  code: 'Code',
  comment: 'Comments',
  blank: 'Blank / whitespace',
  prose: 'Prose / docs',
}
const GROUP_LABEL: Record<FileGroup, string> = {
  source: 'Source',
  tests: 'Tests',
  docs: 'Docs',
  generated: 'Generated',
  other: 'Other',
}

const net = (n: number): string => (n > 0 ? `+${n}` : String(n))
const cell = (s: string): string => s.replace(/\|/g, '\\|')
const code = (s: string): string => `\`${s.replace(/`/g, "'")}\``

export interface RenderOptions {
  detail?: boolean
}

export function renderReport(r: Report, opts: RenderOptions = {}): string {
  const detail = opts.detail === true
  const out: string[] = [STATS_START, '', '| | Added | Removed | Net |', '|---|---:|---:|---:|']

  let added = 0
  let removed = 0
  for (const k of LINE_KINDS) {
    const d = r.lines.kinds[k]
    added += d.added
    removed += d.removed
    out.push(`| ${KIND_LABEL[k]} | ${d.added} | ${d.removed} | ${net(d.added - d.removed)} |`)
  }
  out.push(`| **Total** | **${added}** | **${removed}** | **${net(added - removed)}** |`)

  out.push('', '| File group | Files | Added | Removed |', '|---|---:|---:|---:|')
  for (const g of FILE_GROUPS) {
    const s = r.lines.groups[g]
    if (s.files === 0) continue
    out.push(`| ${GROUP_LABEL[g]} | ${s.files} | ${s.added} | ${s.removed} |`)
  }
  if (r.files === 0) out.push('| _no changed files_ | 0 | 0 | 0 |')
  out.push(
    '',
    '_Generated files (bundles, manifests, pack mirrors, lockfiles) are counted in the second ' +
      'table only. Comment and code rows come from a line-prefix heuristic and are approximate._',
  )

  if (r.files > 0) {
    out.push('', '### Code summary', '', '| Change category | Files | Added | Removed | Largest |')
    out.push('|---|---:|---:|---:|---|')
    for (const c of r.categories) {
      const top = c.top
        .slice(0, detail ? 5 : 2)
        .map(code)
        .join(', ')
      out.push(`| ${c.category} | ${c.files} | ${c.added} | ${c.removed} | ${cell(top)} |`)
    }

    for (const d of r.dependencies) {
      const parts: string[] = []
      if (d.added.length > 0)
        parts.push(`added ${d.added.map((e) => code(`${e.name}@${e.version}`)).join(', ')}`)
      if (d.removed.length > 0)
        parts.push(`removed ${d.removed.map((e) => code(e.name)).join(', ')}`)
      if (d.bumped.length > 0) {
        parts.push(
          `bumped ${d.bumped.map((e) => code(`${e.name} ${e.from} -> ${e.to}`)).join(', ')}`,
        )
      }
      out.push('', `**Dependencies** ${code(d.file)}: ${parts.join('; ')}`)
    }

    out.push('', '**Exported API**')
    if (r.api.status === 'skipped') out.push('', `_Skipped: ${r.api.note ?? 'unavailable'}_`)
    else if (r.api.changes.length === 0) out.push('', '_No exported-surface changes found._')
    else {
      const cap = detail ? Infinity : 6
      const rows = [...r.api.changes].sort((a, b) => Number(b.entry) - Number(a.entry))
      out.push('')
      for (const c of rows.slice(0, cap)) {
        const list = (xs: string[]): string => {
          const shown = detail ? xs : xs.slice(0, 10)
          return (
            shown.map(code).join(' ') +
            (shown.length < xs.length ? ` _+${xs.length - shown.length} more_` : '')
          )
        }
        const bits = [
          c.added.length > 0 ? `+${list(c.added)}` : '',
          c.removed.length > 0 ? `-${list(c.removed)}` : '',
          c.changed.length > 0 ? `~${list(c.changed)}` : '',
        ].filter((b) => b !== '')
        out.push(`- ${code(c.file)}${c.entry ? ' (entry point)' : ''}: ${bits.join(' ')}`)
      }
      if (rows.length > cap) out.push(`- _… ${rows.length - cap} more file(s); use --detail_`)
    }
    if (r.api.note !== null && r.api.status === 'ok') out.push('', `_${r.api.note}_`)

    out.push('', '**Complexity** (cyclomatic, per function)')
    if (r.complexity.status === 'skipped') {
      out.push('', `_Skipped: ${r.complexity.note ?? 'unavailable'}_`)
    } else {
      out.push(
        '',
        `Total ${r.complexity.totalBefore} -> ${r.complexity.totalAfter} ` +
          `(${net(r.complexity.totalAfter - r.complexity.totalBefore)}) across changed files; ` +
          `${r.complexity.functionsChanged} function(s) changed. Analyzers: ${r.complexity.analyzers.join(', ')}.`,
      )
      // Unnamed callbacks are matched by position, so one that exists on only one
      // side is noise in the short table; --detail keeps every row.
      const pool = detail
        ? r.complexity.movers
        : r.complexity.movers.filter(
            (m) => !(m.anonymous && (m.before === null || m.after === null)),
          )
      const shown = pool.slice(0, detail ? pool.length : 5)
      if (shown.length > 0) {
        out.push('', '| Function | File | Before | After | Change |', '|---|---|---:|---:|---:|')
        for (const m of shown) {
          out.push(
            `| ${cell(code(m.name))} | ${cell(code(m.path))} | ${m.before ?? '-'} | ${m.after ?? '-'} | ${net(m.delta)} |`,
          )
        }
      }
      if (r.complexity.note !== null) out.push('', `_${r.complexity.note}_`)
    }

    if (detail) {
      out.push('', '<details><summary>Per-file detail</summary>', '')
      out.push('| File | Category | Group | Added | Removed |', '|---|---|---|---:|---:|')
      for (const f of r.fileList) {
        const name =
          f.oldPath === null
            ? code(f.path)
            : `${code(f.oldPath)} -> ${code(f.path)} (${f.similarity ?? '?'}%)`
        out.push(`| ${cell(name)} | ${f.category} | ${f.group} | ${f.added} | ${f.removed} |`)
      }
      if (r.complexity.files.length > 0) {
        out.push(
          '',
          '| File | Complexity before | after | Functions before | after |',
          '|---|---:|---:|---:|---:|',
        )
        for (const f of r.complexity.files) {
          out.push(
            `| ${cell(code(f.path))} | ${f.before} | ${f.after} | ${f.functionsBefore} | ${f.functionsAfter} |`,
          )
        }
      }
      out.push('', '</details>')
    }
    for (const n of r.notes) out.push('', `_Note: ${n}_`)
  }

  out.push('', STATS_END)
  return out.join('\n')
}
