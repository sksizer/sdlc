/**
 * Cyclomatic complexity per function, behind a small analyzer interface so the
 * heavy part is optional.
 *
 * - `typescriptAnalyzer` (TS/JS): walks the TypeScript compiler AST. Accurate
 *   for decision points; needs the `typescript` package, which is an OPTIONAL
 *   peer — absent, the analyzer reports itself unavailable and is skipped.
 * - `lizardAnalyzer` (everything lizard supports: Rust, Python, Go, Java, C…):
 *   shells out to `lizard --csv` through the command seam when `lizard` is on
 *   PATH; otherwise skipped.
 *
 * Complexity = 1 + decision points: `if`, `for`, `for-in`, `for-of`, `while`,
 * `do`, non-default `case`, `catch`, `?:`, `&&`, `||`, `??`. A nested function
 * is its own entry and does not add to its parent. Optional chaining and
 * early returns are not counted. This is McCabe's metric as most linters
 * compute it, not a cognitive-complexity score.
 */

import { mkdtempSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { extname, join } from 'node:path'

import { spawnRunner, type CommandRunner } from '@sksizer/command-seam'

import { loadTs, type TsModule } from './ts-loader.ts'

/** function name -> cyclomatic complexity */
export type FnMap = Map<string, number>

export interface Analyzer {
  name: string
  /** Whether it can run at all (a binary on PATH, a module installed). */
  available(): boolean
  handles(path: string): boolean
  analyze(path: string, source: string): FnMap
}

function uniqueName(map: FnMap, name: string): string {
  if (!map.has(name)) return name
  let n = 2
  while (map.has(`${name}#${n}`)) n += 1
  return `${name}#${n}`
}

// ── TypeScript / JavaScript ───────────────────────────────────────────────────

const TS_EXT = ['.ts', '.tsx', '.mts', '.cts', '.js', '.jsx', '.mjs', '.cjs']

export const typescriptAnalyzer: Analyzer = {
  name: 'typescript',
  available: () => loadTs() !== null,
  handles: (path) => TS_EXT.some((e) => path.endsWith(e)) && !path.endsWith('.d.ts'),
  analyze(path, source) {
    const loaded = loadTs()
    const out: FnMap = new Map()
    if (loaded === null) return out
    const ts: TsModule = loaded
    const ext = extname(path)
    const kind =
      ext === '.tsx'
        ? ts.ScriptKind.TSX
        : ext === '.jsx'
          ? ts.ScriptKind.JSX
          : ext === '.ts' || ext === '.mts' || ext === '.cts'
            ? ts.ScriptKind.TS
            : ts.ScriptKind.JS
    const sf = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true, kind)
    const K = ts.SyntaxKind

    const nameOf = (n: import('typescript').Node | undefined): string | null =>
      n !== undefined && (ts.isIdentifier(n) || ts.isStringLiteral(n) || ts.isPrivateIdentifier(n))
        ? n.text
        : null

    // `scope` is the dotted name of the nearest NAMED enclosing function or
    // class; an unnamed function is `<scope>.<anonymous k>` with k counted per
    // scope, and its own children keep the same scope, so a callback inside a
    // callback is still named after the function they both sit in.
    const anon = new Map<string, number>()
    function fnName(
      node: import('typescript').Node,
      scope: string,
    ): { full: string; named: boolean } {
      let own: string | null = null
      if (ts.isFunctionDeclaration(node) || ts.isMethodDeclaration(node)) own = nameOf(node.name)
      else if (ts.isGetAccessorDeclaration(node)) own = `get ${nameOf(node.name) ?? '?'}`
      else if (ts.isSetAccessorDeclaration(node)) own = `set ${nameOf(node.name) ?? '?'}`
      else if (ts.isConstructorDeclaration(node)) own = 'constructor'
      else {
        const p = node.parent
        if (p !== undefined) {
          if (ts.isVariableDeclaration(p)) own = nameOf(p.name)
          else if (ts.isPropertyAssignment(p) || ts.isPropertyDeclaration(p)) own = nameOf(p.name)
        }
      }
      if (own === null) {
        const n = (anon.get(scope) ?? 0) + 1
        anon.set(scope, n)
        const label = `<anonymous ${n}>`
        return { full: scope === '' ? label : `${scope}.${label}`, named: false }
      }
      return { full: scope === '' ? own : `${scope}.${own}`, named: true }
    }

    function walk(node: import('typescript').Node, scope: string, acc: { cc: number } | null) {
      const fnLike =
        ts.isFunctionDeclaration(node) ||
        ts.isFunctionExpression(node) ||
        ts.isArrowFunction(node) ||
        ts.isMethodDeclaration(node) ||
        ts.isConstructorDeclaration(node) ||
        ts.isGetAccessorDeclaration(node) ||
        ts.isSetAccessorDeclaration(node)
      if (fnLike) {
        const { full, named } = fnName(node, scope)
        const mine = { cc: 1 }
        ts.forEachChild(node, (c) => walk(c, named ? full : scope, mine))
        out.set(uniqueName(out, full), mine.cc)
        return
      }
      if (ts.isClassDeclaration(node) || ts.isClassExpression(node)) {
        const cls = nameOf(node.name) ?? `<class>`
        const next = scope === '' ? cls : `${scope}.${cls}`
        ts.forEachChild(node, (c) => walk(c, next, null))
        return
      }
      if (acc !== null) {
        switch (node.kind) {
          case K.IfStatement:
          case K.ForStatement:
          case K.ForInStatement:
          case K.ForOfStatement:
          case K.WhileStatement:
          case K.DoStatement:
          case K.CaseClause:
          case K.CatchClause:
          case K.ConditionalExpression:
            acc.cc += 1
            break
          case K.BinaryExpression: {
            const op = (node as import('typescript').BinaryExpression).operatorToken.kind
            if (
              op === K.AmpersandAmpersandToken ||
              op === K.BarBarToken ||
              op === K.QuestionQuestionToken
            ) {
              acc.cc += 1
            }
            break
          }
        }
      }
      ts.forEachChild(node, (c) => walk(c, scope, acc))
    }
    walk(sf, '', null)
    return out
  },
}

// ── lizard ────────────────────────────────────────────────────────────────────

const LIZARD_EXT = [
  '.rs',
  '.py',
  '.go',
  '.java',
  '.kt',
  '.swift',
  '.c',
  '.h',
  '.cc',
  '.cpp',
  '.hpp',
  '.cs',
  '.php',
  '.rb',
  '.scala',
]

/** Split one CSV line, honouring double quotes. */
export function splitCsv(line: string): string[] {
  const out: string[] = []
  let cur = ''
  let quoted = false
  for (let i = 0; i < line.length; i++) {
    const c = line[i]!
    if (quoted) {
      if (c === '"' && line[i + 1] === '"') {
        cur += '"'
        i += 1
      } else if (c === '"') quoted = false
      else cur += c
    } else if (c === '"') quoted = true
    else if (c === ',') {
      out.push(cur)
      cur = ''
    } else cur += c
  }
  out.push(cur)
  return out
}

/** `lizard --csv` rows: NLOC,CCN,token,PARAM,length,location,file,function,long_name,start,end. */
export function parseLizardCsv(csv: string): FnMap {
  const out: FnMap = new Map()
  for (const line of csv.split('\n')) {
    if (line.trim() === '') continue
    const cols = splitCsv(line)
    const ccn = Number(cols[1])
    const name = cols[7]
    if (cols.length < 8 || !Number.isFinite(ccn) || name === undefined || name === '') continue
    out.set(uniqueName(out, name), ccn)
  }
  return out
}

export function lizardAnalyzer(runner: CommandRunner = spawnRunner('lizard')): Analyzer {
  let ok: boolean | undefined
  return {
    name: 'lizard',
    available() {
      if (ok === undefined) {
        try {
          ok = runner.run(['--version'], { cwd: tmpdir() }).exitCode === 0
        } catch {
          ok = false
        }
      }
      return ok
    },
    handles: (path) => LIZARD_EXT.some((e) => path.endsWith(e)),
    analyze(path, source) {
      const dir = mkdtempSync(join(tmpdir(), 'pr-stats-lizard-'))
      try {
        const file = join(dir, `src${extname(path)}`)
        writeFileSync(file, source)
        const r = runner.run(['--csv', file], { cwd: dir, timeoutMs: 30_000 })
        return r.exitCode === 0 ? parseLizardCsv(r.stdout) : new Map()
      } finally {
        rmSync(dir, { recursive: true, force: true })
      }
    },
  }
}

export function defaultAnalyzers(): Analyzer[] {
  return [typescriptAnalyzer, lizardAnalyzer()]
}
