/**
 * The shapes `buildReport` returns, as zod schemas so a host (sdlc's op, a
 * `--json` consumer) can reuse them as an output contract.
 */

import { z } from 'zod'

export const LINE_KINDS = ['code', 'comment', 'blank', 'prose'] as const
export type LineKind = (typeof LINE_KINDS)[number]

export const FILE_GROUPS = ['source', 'tests', 'docs', 'generated', 'other'] as const
export type FileGroup = (typeof FILE_GROUPS)[number]

export const CATEGORIES = [
  'added',
  'deleted',
  'renamed',
  'generated',
  'dependencies',
  'config',
  'docs',
  'tests',
  'formatting',
  'comments',
  'logic',
] as const
export type Category = (typeof CATEGORIES)[number]

const delta = z.object({ added: z.number(), removed: z.number() })
const groupStats = delta.extend({ files: z.number() })

export const reportSchema = z.object({
  source: z.string().describe('What was measured: `PR #N` or `<base>...HEAD`.'),
  files: z.number().describe('Files changed, generated included.'),
  lines: z.object({
    kinds: z
      .object({ code: delta, comment: delta, blank: delta, prose: delta })
      .describe('Changed lines by kind, generated files excluded.'),
    groups: z
      .object({
        source: groupStats,
        tests: groupStats,
        docs: groupStats,
        generated: groupStats,
        other: groupStats,
      })
      .describe('Changed files and lines by file group, generated included.'),
  }),
  categories: z
    .array(
      z.object({
        category: z.enum(CATEGORIES),
        files: z.number(),
        added: z.number(),
        removed: z.number(),
        top: z.array(z.string()).describe('Files with the most changed lines, at most five.'),
      }),
    )
    .describe('Every file in exactly one category; empty categories are omitted.'),
  fileList: z.array(
    z.object({
      path: z.string(),
      oldPath: z.string().nullable(),
      category: z.enum(CATEGORIES),
      group: z.enum(FILE_GROUPS),
      similarity: z.number().nullable().describe('Rename similarity, percent.'),
      added: z.number(),
      removed: z.number(),
    }),
  ),
  dependencies: z.array(
    z.object({
      file: z.string(),
      added: z.array(z.object({ name: z.string(), version: z.string() })),
      removed: z.array(z.object({ name: z.string(), version: z.string() })),
      bumped: z.array(z.object({ name: z.string(), from: z.string(), to: z.string() })),
    }),
  ),
  api: z.object({
    status: z.enum(['ok', 'skipped']),
    note: z.string().nullable(),
    changes: z.array(
      z.object({
        file: z.string(),
        language: z.enum(['ts', 'rust']),
        entry: z.boolean().describe('A package entry point (`index.*`); false for other modules.'),
        added: z.array(z.string()),
        removed: z.array(z.string()),
        changed: z.array(z.string()),
      }),
    ),
  }),
  complexity: z.object({
    status: z.enum(['ok', 'skipped']),
    note: z.string().nullable(),
    analyzers: z.array(z.string()),
    totalBefore: z.number(),
    totalAfter: z.number(),
    functionsChanged: z.number(),
    files: z.array(
      z.object({
        path: z.string(),
        before: z.number(),
        after: z.number(),
        functionsBefore: z.number(),
        functionsAfter: z.number(),
      }),
    ),
    movers: z.array(
      z.object({
        path: z.string(),
        name: z.string(),
        before: z.number().nullable(),
        after: z.number().nullable(),
        delta: z.number(),
        anonymous: z
          .boolean()
          .describe(
            'An unnamed function, matched by enclosing scope and ordinal; shown only in --detail unless it exists on both sides.',
          ),
      }),
    ),
  }),
  notes: z.array(z.string()).describe('Anything skipped or capped, and why.'),
})

export type Report = z.infer<typeof reportSchema>
