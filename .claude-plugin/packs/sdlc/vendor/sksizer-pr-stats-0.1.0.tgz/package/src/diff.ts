/**
 * Parse a unified diff (any context width) into per-file records.
 *
 * Hunk-aware: once a `@@` header announces how many old and new lines follow,
 * exactly that many `-`/`+` lines are body, so a removed line whose text begins
 * with `-- ` (rendered `--- `) is not mistaken for a file header.
 */

export type FileStatus = 'added' | 'deleted' | 'modified' | 'renamed'

export interface FileDiff {
  /** The new path; for a deleted file, the path it had. */
  path: string
  /** The path before a rename, else null. */
  oldPath: string | null
  status: FileStatus
  /** Rename similarity in percent, else null. */
  similarity: number | null
  binary: boolean
  /** Added line bodies, without the `+`. */
  added: string[]
  /** Removed line bodies, without the `-`. */
  removed: string[]
}

const HUNK = /^@@ -\d+(?:,(\d+))? \+\d+(?:,(\d+))? @@/

/** `b/<path>` out of `diff --git a/<old> b/<new>`; the fallback when no `+++` names it. */
function headerPath(line: string): string | null {
  const i = line.lastIndexOf(' b/')
  return i < 0 ? null : line.slice(i + 3)
}

export function parseDiff(diff: string): FileDiff[] {
  const files: FileDiff[] = []
  let cur: FileDiff | null = null
  let oldLeft = 0
  let newLeft = 0

  for (const raw of diff.split('\n')) {
    if (oldLeft > 0 || newLeft > 0) {
      if (raw.startsWith('\\')) continue
      const sign = raw[0]
      if (sign === '-' && oldLeft > 0) {
        oldLeft -= 1
        cur?.removed.push(raw.slice(1))
        continue
      }
      if (sign === '+' && newLeft > 0) {
        newLeft -= 1
        cur?.added.push(raw.slice(1))
        continue
      }
      if (sign === ' ') {
        oldLeft -= 1
        newLeft -= 1
        continue
      }
      // Malformed hunk: stop trusting the counts and fall through to header parsing.
      oldLeft = 0
      newLeft = 0
    }

    if (raw.startsWith('diff --git ')) {
      const path = headerPath(raw)
      cur = {
        path: path ?? '',
        oldPath: null,
        status: 'modified',
        similarity: null,
        binary: false,
        added: [],
        removed: [],
      }
      files.push(cur)
    } else if (cur === null) {
      continue
    } else if (raw.startsWith('new file mode')) {
      cur.status = 'added'
    } else if (raw.startsWith('deleted file mode')) {
      cur.status = 'deleted'
    } else if (raw.startsWith('similarity index ')) {
      cur.similarity = Number.parseInt(raw.slice('similarity index '.length), 10)
    } else if (raw.startsWith('rename from ')) {
      cur.status = 'renamed'
      cur.oldPath = raw.slice('rename from '.length)
    } else if (raw.startsWith('rename to ')) {
      cur.path = raw.slice('rename to '.length)
    } else if (raw.startsWith('Binary files ') || raw.startsWith('GIT binary patch')) {
      cur.binary = true
    } else if (raw.startsWith('+++ ') && raw !== '+++ /dev/null') {
      // The `+++` side is authoritative (paths with spaces make the header ambiguous).
      cur.path = raw.slice(6)
    } else if (raw.startsWith('--- ') && raw !== '--- /dev/null') {
      // A deleted file has `+++ /dev/null`; the `---` side then names it.
      if (cur.status === 'deleted') cur.path = raw.slice(6)
    } else {
      const m = HUNK.exec(raw)
      if (m !== null) {
        oldLeft = m[1] === undefined ? 1 : Number(m[1])
        newLeft = m[2] === undefined ? 1 : Number(m[2])
      }
    }
  }
  return files
}
