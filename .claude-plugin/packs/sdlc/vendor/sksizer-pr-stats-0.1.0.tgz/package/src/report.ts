/**
 * Assemble a {@link Report} from a unified diff. Pure apart from the
 * `showAtRev` port, which supplies file content at the base and head revisions
 * for the API and complexity passes; with no revisions those passes are
 * skipped with a note, and the line and category numbers (diff-only) still
 * come out.
 */

import {
  apiLanguage,
  diffApi,
  extractApi,
  isEntryPoint,
  membersAvailable,
  type ApiLanguage,
} from './api.ts'
import { categorize, dependencyChange } from './categories.ts'
import { defaultAnalyzers, type Analyzer, type FnMap } from './complexity.ts'
import { parseDiff, type FileDiff } from './diff.ts'
import { computeLineStats, fileGroup, isProse, isTest } from './lines.ts'
import { CATEGORIES, type Category, type Report } from './types.ts'

export interface ReportPorts {
  /** File content at a revision, or null when absent. */
  showAtRev(rev: string, path: string): string | null
  /** Revision of the "before" side; null skips the content passes. */
  baseRev: string | null
  /** Revision of the "after" side; null skips the content passes. */
  headRev: string | null
}

export interface ReportOptions {
  analyzers?: readonly Analyzer[]
  /** Most files read for API/complexity. Default 150. */
  maxFiles?: number
  /** Largest file content analysed, in bytes. Default 400_000. */
  maxBytes?: number
  /** Wall-clock budget for the content passes, ms. Default 20_000. */
  budgetMs?: number
  /** Movers listed. Default 15 (the compact render shows the first 5). */
  moverLimit?: number
  now?: () => number
}

export function buildReport(
  source: string,
  diff: string,
  ports: ReportPorts | null,
  opts: ReportOptions = {},
): Report {
  const files = parseDiff(diff)
  const notes: string[] = []
  const lines = computeLineStats(files)

  // ── categories ──────────────────────────────────────────────────────────────
  const fileList = files.map((f) => ({
    path: f.path,
    oldPath: f.oldPath,
    category: categorize(f),
    group: fileGroup(f.path),
    similarity: f.similarity,
    added: f.added.length,
    removed: f.removed.length,
  }))
  const categories = CATEGORIES.flatMap((category) => {
    const members = fileList.filter((f) => f.category === category)
    if (members.length === 0) return []
    return [
      {
        category,
        files: members.length,
        added: members.reduce((n, f) => n + f.added, 0),
        removed: members.reduce((n, f) => n + f.removed, 0),
        top: [...members]
          .sort(
            (a, b) => b.added + b.removed - (a.added + a.removed) || a.path.localeCompare(b.path),
          )
          .slice(0, 5)
          .map((f) => f.path),
      },
    ]
  })

  const dependencies = files.flatMap((f) => {
    const c = dependencyChange(f)
    return c === null ? [] : [c]
  })

  // ── content passes ─────────────────────────────────────────────────────────
  const api: Report['api'] = { status: 'skipped', note: null, changes: [] }
  const complexity: Report['complexity'] = {
    status: 'skipped',
    note: null,
    analyzers: [],
    totalBefore: 0,
    totalAfter: 0,
    functionsChanged: 0,
    files: [],
    movers: [],
  }

  if (ports === null || ports.baseRev === null || ports.headRev === null) {
    const why = 'base/head revisions not available locally; API and complexity passes skipped'
    api.note = why
    complexity.note = why
    notes.push(why)
  } else {
    const now = opts.now ?? Date.now
    const deadline = now() + (opts.budgetMs ?? 20_000)
    const maxFiles = opts.maxFiles ?? 150
    const maxBytes = opts.maxBytes ?? 400_000
    const analyzers = (opts.analyzers ?? defaultAnalyzers()).filter((a) => a.available())
    complexity.analyzers = analyzers.map((a) => a.name)

    const candidates = files.filter(
      (f) => !f.binary && fileGroup(f.path) !== 'generated' && !isProse(f.path),
    )
    let read = 0
    const skipped: string[] = []
    const content = (f: FileDiff): { before: string; after: string } | null => {
      if (read >= maxFiles) {
        skipped.push(`${f.path} (file cap ${maxFiles})`)
        return null
      }
      if (now() > deadline) {
        skipped.push(`${f.path} (time budget)`)
        return null
      }
      read += 1
      const before =
        f.status === 'added' ? '' : (ports.showAtRev(ports.baseRev!, f.oldPath ?? f.path) ?? '')
      const after = f.status === 'deleted' ? '' : (ports.showAtRev(ports.headRev!, f.path) ?? '')
      if (before.length > maxBytes || after.length > maxBytes) {
        skipped.push(`${f.path} (over ${maxBytes} bytes)`)
        return null
      }
      return { before, after }
    }

    const movers: Report['complexity']['movers'] = []

    for (const f of candidates) {
      const lang: ApiLanguage | null = isTest(f.path) ? null : apiLanguage(f.path)
      const analyzer = analyzers.find((a) => a.handles(f.path))
      if (lang === null && analyzer === undefined) continue
      const c = content(f)
      if (c === null) continue

      if (lang !== null) {
        const d = diffApi(extractApi(lang, c.before, f.path), extractApi(lang, c.after, f.path))
        if (d.added.length + d.removed.length + d.changed.length > 0) {
          api.changes.push({
            file: f.path,
            language: lang,
            entry: lang === 'ts' && isEntryPoint(f.path),
            ...d,
          })
        }
      }

      if (analyzer !== undefined) {
        const before: FnMap = analyzer.analyze(f.path, c.before)
        const after: FnMap = analyzer.analyze(f.path, c.after)
        const sum = (m: FnMap) => [...m.values()].reduce((n, v) => n + v, 0)
        let touched = 0
        for (const name of new Set([...before.keys(), ...after.keys()])) {
          const b = before.get(name) ?? null
          const a = after.get(name) ?? null
          if (b === a) continue
          touched += 1
          movers.push({
            path: f.path,
            name,
            before: b,
            after: a,
            delta: (a ?? 0) - (b ?? 0),
            anonymous: name.includes('<anonymous'),
          })
        }
        complexity.totalBefore += sum(before)
        complexity.totalAfter += sum(after)
        complexity.functionsChanged += touched
        if (touched > 0 || sum(before) !== sum(after)) {
          complexity.files.push({
            path: f.path,
            before: sum(before),
            after: sum(after),
            functionsBefore: before.size,
            functionsAfter: after.size,
          })
        }
      }
    }

    api.status = 'ok'
    api.note =
      'Exported TS declarations and re-exports, and Rust pub items, by regex on the first line; ' +
      (membersAvailable()
        ? 'public members of exported classes and interfaces via the TypeScript AST.'
        : 'class and interface members NOT scanned (typescript not found).')
    if (analyzers.length === 0) {
      complexity.note = 'no complexity analyzer available (install typescript and/or lizard)'
    } else {
      complexity.status = 'ok'
      const unhandled = candidates.some(
        (f) =>
          !analyzers.some((a) => a.handles(f.path)) &&
          /\.(rs|py|go|java|kt|c|cpp|cs)$/.test(f.path),
      )
      if (unhandled) {
        complexity.note =
          'files in languages without an available analyzer (lizard) were not scored'
        notes.push(complexity.note)
      }
    }
    movers.sort(
      (x, y) =>
        Math.abs(y.delta) - Math.abs(x.delta) ||
        x.path.localeCompare(y.path) ||
        x.name.localeCompare(y.name),
    )
    complexity.movers = movers.slice(0, opts.moverLimit ?? 60)
    if (skipped.length > 0) {
      notes.push(
        `skipped ${skipped.length} file(s) in the API/complexity passes: ${skipped.slice(0, 5).join(', ')}${skipped.length > 5 ? ', …' : ''}`,
      )
    }
  }

  return {
    source,
    files: files.length,
    lines,
    categories,
    fileList,
    dependencies,
    api,
    complexity,
    notes,
  }
}

export type { Category }
