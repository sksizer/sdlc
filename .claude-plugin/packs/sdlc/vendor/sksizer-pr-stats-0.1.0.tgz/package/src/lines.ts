/**
 * Per-line classification and file grouping.
 *
 * Classification is per CHANGED line, decided by the file it sits in and then
 * the line itself:
 *
 * 1. whitespace-only line, in any file       -> blank
 * 2. non-blank line in a prose file          -> prose (.md .mdx .txt .rst)
 * 3. non-blank line in a source file         -> comment when the shared
 *    heuristic (`./heuristic.ts`) says so, else code
 * 4. non-blank line in any other file        -> code (config, data, build files)
 *
 * Limits, inherited from that heuristic: it reads one line at a time, so a
 * block comment is recognised only by its opening, continuation and closing
 * lines; a `#[derive]` attribute counts as a `#` comment; code sharing a line
 * with a comment is whatever the line starts with; a line inside a multi-line
 * string literal is judged as if it were code. Comments in config languages
 * (yaml, toml, ini) count as code, because only the source extensions are held
 * to the comment rule. Treat the comment and code rows as good to a few
 * percent, not exact.
 *
 * GENERATED files (bundled CLIs, op manifests, pack mirrors, lockfiles,
 * minified output) are counted in the group table only, so a regenerated
 * bundle does not dwarf every real change.
 */

import type { FileDiff } from './diff.ts'
import { isBlank, isCommentLine, isSource } from './heuristic.ts'
import { FILE_GROUPS, LINE_KINDS, type FileGroup, type LineKind } from './types.ts'

export interface Delta {
  added: number
  removed: number
}
export interface GroupStats extends Delta {
  files: number
}
export interface LineStats {
  kinds: Record<LineKind, Delta>
  groups: Record<FileGroup, GroupStats>
}

const PROSE_EXT = ['.md', '.mdx', '.txt', '.rst'] as const

const LOCKFILES = new Set([
  'bun.lock',
  'bun.lockb',
  'package-lock.json',
  'yarn.lock',
  'pnpm-lock.yaml',
  'Cargo.lock',
  'Gemfile.lock',
  'poetry.lock',
  'uv.lock',
  'go.sum',
])

export function basename(path: string): string {
  return path.slice(path.lastIndexOf('/') + 1)
}

/** True for build output committed to the repo: bundles, mirrors, lockfiles. */
export function isGenerated(path: string): boolean {
  const base = basename(path)
  return (
    LOCKFILES.has(base) ||
    base.includes('.min.') ||
    base === 'list-ops.js' ||
    path === 'cli/sdlc.js' ||
    path.endsWith('/cli/sdlc.js') ||
    path.includes('/_generated/') ||
    path.startsWith('_generated/') ||
    path.includes('/packs/') ||
    path.startsWith('packs/')
  )
}

export function isProse(path: string): boolean {
  return PROSE_EXT.some((e) => path.endsWith(e))
}

export function isTest(path: string): boolean {
  return /\.(test|spec)\.[^/]+$/.test(path) || /(^|\/)(tests?|__tests__)\//.test(path)
}

/** The group a path belongs to; generated beats docs beats tests beats source. */
export function fileGroup(path: string): FileGroup {
  if (isGenerated(path)) return 'generated'
  if (isProse(path)) return 'docs'
  if (isTest(path)) return 'tests'
  if (isSource(path)) return 'source'
  return 'other'
}

/** The kind of one changed line (without its `+`/`-` marker) in `path`. */
export function classifyLine(path: string, line: string): LineKind {
  if (isBlank(line)) return 'blank'
  if (isProse(path)) return 'prose'
  if (isSource(path) && isCommentLine(line)) return 'comment'
  return 'code'
}

export function computeLineStats(files: readonly FileDiff[]): LineStats {
  const kinds = {} as Record<LineKind, Delta>
  for (const k of LINE_KINDS) kinds[k] = { added: 0, removed: 0 }
  const groups = {} as Record<FileGroup, GroupStats>
  for (const g of FILE_GROUPS) groups[g] = { files: 0, added: 0, removed: 0 }

  for (const f of files) {
    const group = fileGroup(f.path)
    const g = groups[group]
    g.files += 1
    g.added += f.added.length
    g.removed += f.removed.length
    if (group === 'generated') continue
    for (const l of f.added) kinds[classifyLine(f.path, l)].added += 1
    for (const l of f.removed) kinds[classifyLine(f.path, l)].removed += 1
  }
  return { kinds, groups }
}
