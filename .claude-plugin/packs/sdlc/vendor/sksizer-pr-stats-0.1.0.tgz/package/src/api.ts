/**
 * Public API surface delta, by regex over exported declarations — not an AST,
 * and not type-aware.
 *
 * TypeScript/JavaScript: every changed non-test file with `export`s is read;
 * `apiLanguage` marks entry points (`index.ts`, `index.tsx`, `index.mts`,
 * `index.js`, `index.mjs`) so a report can tell a package's surface from a
 * module's exports. Recognised: `export` +
 * function/class/interface/type/enum/const/let/var/namespace, `export { a, b as
 * c } [from '…']` (multi-line fine), `export * from '…'`, `export default`.
 * When the `typescript` package can be found, the public members of exported
 * classes and interfaces are listed too, as `Class.member` (methods,
 * properties, accessors; not `private`, `protected` or `#name`), with the full
 * member signature, so an added method or a changed parameter list shows up.
 * Without it members are not scanned. Rust: `pub` items (`pub(crate)` and friends excluded) in any changed `.rs`
 * file: fn, struct, enum, trait, const, static, type, mod, union.
 *
 * "Changed" means the declaration's first line differs once whitespace is
 * squashed (a `const` is cut at `=`, so a new initializer is not a change). A
 * parameter list wrapped onto later lines, or a changed type deeper than the
 * first line, is invisible. Re-exports are keyed by exported name, so
 * `export * from` is one opaque entry per source module.
 */

import { basename } from './lines.ts'
import { loadTs } from './ts-loader.ts'

export type ApiLanguage = 'ts' | 'rust'

/** name -> normalised signature */
export type ApiMap = Map<string, string>

const TS_ENTRY = /^index\.(?:ts|tsx|mts|cts|js|mjs|cjs)$/
const TS_FILE = /\.(?:ts|tsx|mts|cts|js|jsx|mjs|cjs)$/

/** Which extractor reads this path, or null. Test files and `.d.ts` are never read. */
export function apiLanguage(path: string): ApiLanguage | null {
  if (path.endsWith('.rs')) return 'rust'
  if (TS_FILE.test(path) && !path.endsWith('.d.ts') && !/\.(?:test|spec)\./.test(path)) return 'ts'
  return null
}

/** True for a package entry point (`index.*`). */
export function isEntryPoint(path: string): boolean {
  return TS_ENTRY.test(basename(path)) && !path.endsWith('.d.ts')
}

/** Whether class/interface members can be scanned (the `typescript` package was found). */
export function membersAvailable(): boolean {
  return loadTs() !== null
}

/** `Class.member` -> signature for public members of exported classes and interfaces. */
function tsMembers(path: string, source: string): ApiMap {
  const out: ApiMap = new Map()
  const ts = loadTs()
  if (ts === null || !/\bexport\b/.test(source)) return out
  const sf = ts.createSourceFile(path, source, ts.ScriptTarget.Latest, true)
  for (const st of sf.statements) {
    if (!ts.isClassDeclaration(st) && !ts.isInterfaceDeclaration(st)) continue
    const mods = ts.canHaveModifiers(st) ? ts.getModifiers(st) : undefined
    if (!mods?.some((m) => m.kind === ts.SyntaxKind.ExportKeyword) || st.name === undefined)
      continue
    for (const m of st.members) {
      const name = m.name
      if (name === undefined || ts.isPrivateIdentifier(name)) continue
      const mm = ts.canHaveModifiers(m) ? ts.getModifiers(m) : undefined
      if (
        mm?.some(
          (x) =>
            x.kind === ts.SyntaxKind.PrivateKeyword || x.kind === ts.SyntaxKind.ProtectedKeyword,
        )
      ) {
        continue
      }
      const body =
        'body' in m && m.body !== undefined ? (m.body as import('typescript').Node) : null
      const init =
        'initializer' in m && m.initializer !== undefined
          ? (m.initializer as import('typescript').Node)
          : null
      const end = body?.getStart(sf) ?? init?.getStart(sf) ?? m.end
      out.set(
        `${st.name.text}.${name.getText(sf)}`,
        norm(source.slice(m.getStart(sf), end)).replace(/[;,]$/, ''),
      )
    }
  }
  return out
}

const norm = (s: string): string => s.replace(/\s+/g, ' ').trim()

const TS_DECL =
  /^export\s+(?:declare\s+)?(?:abstract\s+)?(?:async\s+)?(function\*?|class|interface|type|enum|const enum|const|let|var|namespace)\s+([A-Za-z0-9_$]+)(.*)$/
const TS_LIST = /export\s+(type\s+)?\{([^}]*)\}(?:\s*from\s*['"]([^'"]+)['"])?/g
const TS_STAR = /export\s+\*(?:\s+as\s+([A-Za-z0-9_$]+))?\s+from\s+['"]([^'"]+)['"]/g
const RUST_DECL =
  /^\s*pub\s+(?:async\s+)?(?:unsafe\s+)?(fn|struct|enum|trait|const|static|type|mod|union)\s+([A-Za-z0-9_]+)(.*)$/

export function extractApi(language: ApiLanguage, source: string, path = 'x.ts'): ApiMap {
  const out: ApiMap = new Map()
  if (language === 'rust') {
    for (const line of source.split('\n')) {
      const m = RUST_DECL.exec(line)
      if (m === null) continue
      const rest = norm(m[3]!.split(/[{;]/)[0]!)
      out.set(`${m[1]} ${m[2]}`, norm(`${m[1]} ${m[2]}${rest}`))
    }
    return out
  }
  // Strip comments first: doc text often quotes `export { … }`.
  const stripped = source.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '')
  for (const line of stripped.split('\n')) {
    const m = TS_DECL.exec(line)
    if (m === null) continue
    const kind = m[1]!
    let rest = m[3]!
    if (kind === 'const' || kind === 'let' || kind === 'var') rest = rest.split('=')[0]!
    else if (['class', 'interface', 'enum', 'namespace'].includes(kind)) rest = rest.split('{')[0]!
    out.set(m[2]!, norm(`${kind} ${m[2]}${rest}`))
  }
  for (const m of stripped.matchAll(TS_LIST)) {
    const from = m[3] ?? ''
    for (const item of m[2]!.split(',')) {
      const part = norm(item).replace(/^type\s+/, '')
      if (part === '') continue
      const exported = part.split(/\s+as\s+/).pop()!
      out.set(exported, norm(`${m[1] ?? ''}{ ${part} } ${from}`))
    }
  }
  for (const m of stripped.matchAll(TS_STAR)) {
    out.set(m[1] ?? `* from ${m[2]}`, `export * from ${m[2]}`)
  }
  if (/^export\s+default\b/m.test(stripped)) out.set('default', 'export default')
  for (const [k, v] of tsMembers(path, source)) out.set(k, v)
  return out
}

export interface ApiDelta {
  added: string[]
  removed: string[]
  changed: string[]
}

export function diffApi(before: ApiMap, after: ApiMap): ApiDelta {
  const delta: ApiDelta = { added: [], removed: [], changed: [] }
  for (const [name, sig] of after) {
    const old = before.get(name)
    if (old === undefined) delta.added.push(name)
    else if (old !== sig) delta.changed.push(name)
  }
  for (const name of before.keys()) if (!after.has(name)) delta.removed.push(name)
  return delta
}
