/**
 * Put the rendered block into a PR body without touching any other text.
 *
 * - A body that already holds a marked block: that span is replaced in place.
 * - Else a `## Change statistics` section is inserted before the trailing
 *   `<!-- sdlc-lease: ... -->` footer, which stays the last line byte for byte.
 * - Else the section is appended.
 *
 * Idempotent: splicing the same block twice yields the same body.
 */

export const STATS_START = '<!-- sdlc-pr-stats:start -->'
export const STATS_END = '<!-- sdlc-pr-stats:end -->'

const HEADING = '## Change statistics'
const LEASE_FOOTER = /^<!-- sdlc-lease: .*-->\s*$/

export function spliceBody(body: string, block: string): string {
  const start = body.indexOf(STATS_START)
  const end = body.indexOf(STATS_END, start + 1)
  if (start >= 0 && end > start) {
    return body.slice(0, start) + block + body.slice(end + STATS_END.length)
  }

  const section = `${HEADING}\n\n${block}`
  const lines = body.split('\n')
  let last = lines.length - 1
  while (last >= 0 && lines[last]!.trim() === '') last -= 1
  if (last >= 0 && LEASE_FOOTER.test(lines[last]!)) {
    const head = lines.slice(0, last).join('\n').trimEnd()
    const tail = lines.slice(last).join('\n')
    return head === '' ? `${section}\n\n${tail}` : `${head}\n\n${section}\n\n${tail}`
  }
  const trimmed = body.trimEnd()
  return trimmed === '' ? `${section}\n` : `${trimmed}\n\n${section}\n`
}
