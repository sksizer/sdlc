# @sksizer/pr-stats

Descriptive statistics for a pull request or a branch diff, beyond GitHub's
`+N -M`: what kind of lines changed, what kind of change each file got, what
happened to the public API, and where complexity moved. Deterministic; no LLM.
Writes the result into the PR body, idempotently.

```sh
pr-stats 123                 # a PR (needs gh)
pr-stats --base origin/main  # the current branch
pr-stats 123 --write         # put the table in the PR body
pr-stats 123 --detail --json # per-file detail / structured output
```

Works in any git repository with an authenticated `gh`. No sdlc needed. Inside
sdlc the same pipeline is `sdlc pr stats`, and the task-work skill runs it after
opening a PR.

## Install

```sh
npx @sksizer/pr-stats 123            # once published
bun run packages/ts/pr-stats/src/cli.ts 123   # from a checkout of this monorepo
```

## As a skill

The craft plugin ships `/craft:pr-stats`, which runs a single-file bundle of this
package with plain Node and needs no sdlc: `node <skill-dir>/pr-stats.mjs …`.
Rebuild it with `bun run bundle` (`bun run bundle:check` fails if it is stale);
then copy it into the four craft pack mirrors the way the mirror flow does.
`typescript` is not bundled; the script finds the measured project's own copy
from the working directory.

## What it reports

One marked block, `<!-- sdlc-pr-stats:start -->` to `<!-- sdlc-pr-stats:end -->`:

1. **Lines** added / removed / net for Code, Comments, Blank / whitespace, Prose / docs.
2. **File groups**: Source, Tests, Docs, Generated, Other, with files and lines.
3. **Code summary**: a change-category table, dependency changes, public API
   delta, and the top five complexity movers. `--detail` adds the per-file list.

### Classifying a line

Whitespace-only is blank. In `.md .mdx .txt .rst` anything else is prose. In a
source file (the extension table in `src/heuristic.ts`) a line that starts with
a comment opener is a comment. Everything else, including config and data
files, is code.

Generated files (`cli/sdlc.js`, `list-ops.js`, `_generated/`, `packs/`,
lockfiles, `*.min.*`) are counted in the file-group table only, so a regenerated
bundle does not swamp the numbers.

**Limits.** The comment test is a one-line prefix check, a floor and not a
parser: a Rust `#[derive]` reads as a comment, code after a closing `*/` on the
same line counts as comment, lines inside a multi-line string are judged as
code, and `#` comments in yaml/toml count as code. Good to a few percent.

### Change categories

Each file lands in exactly one, first match wins: generated, deleted, added,
renamed (with similarity), dependencies, docs, tests, formatting, config,
comments, logic. A new test file is "added", not "tests". "Formatting" means the
changed lines are identical once all whitespace is removed, so a pure line
reorder also reads as formatting. "Dependencies" parses `package.json` and
`Cargo.toml` dependency-looking lines (name plus a version-like value), pairing
removed and added lines into added / removed / bumped.

### Public API

Heuristic, by regex over exported declarations (comments stripped), not type-aware. TypeScript:
every changed non-test module, entry points (`index.*`) flagged, reading `export function|class|
interface|type|enum|const|…`, `export { … }` lists and `export * from`. Rust:
`pub` items in changed `.rs` files. A change is a different first line of the
declaration, so a changed type below a wrapped parameter list is missed. When
`typescript` can be found, public members of exported classes and interfaces are
read from the AST as `Class.member` with their full signature.

### Complexity

Cyclomatic (McCabe): 1 plus `if`, loops, non-default `case`, `catch`, `?:`,
`&&`, `||`, `??`; a nested function scores separately. Computed per function on
the base and head versions of each changed file (`git show <rev>:<path>`), so
rows are before / after per function, with added and removed functions counted
as 0 on the missing side. Accurate for TS/JS (real AST); other languages via
`lizard` when it is on PATH, otherwise skipped with a line saying so.

Caps: at most 150 files, 400 KB each, and a 20 s budget for the content passes.
Anything skipped is listed in the report's `notes`, never silently dropped.

## Evaluation of existing tools

| Tool | Verdict |
| --- | --- |
| `tokei`, `scc`, `cloc` | Count code / comment / blank per language, but of whole files, not diffs. Getting diff numbers means running them over a before and an after tree and subtracting, which loses which lines moved, needs a checkout of both sides, and adds a hard binary dependency. None were installed on the development machine. Not used. Their per-language comment syntax is richer than our prefix table; adopting it is the upgrade path if the floor proves too coarse. |
| `cloc --diff` | Closest in spirit (compares two trees) but a Perl dependency and whole-tree cost for a per-PR number. Not used. |
| `lizard` | Multi-language cyclomatic complexity with CSV output. Used as an OPTIONAL analyzer for non-TS languages; absent, those files are skipped with a note. |
| `typescript` (compiler API) | Already in every TS repo; gives an exact AST for TS/JS complexity with no new dependency. Used, as an optional peer. |
| `ts-morph`, `typhonjs-escomplex`, oxlint/eslint `complexity` rule | Heavier wrappers over the same AST, or rule output that reports only violations over a threshold, not a per-function number. Not used. |
| `rust-code-analysis` | Accurate for Rust but a separate crate to build and run. Not used; `lizard` covers Rust coarsely. |
| `scc` complexity column | A per-file keyword-count estimate, not per function. Not used. |

Decision: the line and category passes use only the diff, so they are fast,
dependency-free and work offline; the content passes (API, complexity) read
base and head files through git and degrade to a "skipped" line when an
analyzer is missing.

## Library

```ts
import { runStats } from '@sksizer/pr-stats'
import { spawnRunner } from '@sksizer/command-seam'

const { report, markdown } = runStats(
  { cwd: process.cwd(), pr: 123, base: null, write: false, detail: false },
  { git: spawnRunner('git'), gh: spawnRunner('gh') },
)
```

`buildReport(source, diff, ports)` is the pure core (the `ports` supply file
content by revision; pass `null` to skip the API and complexity passes);
`renderReport` and `spliceBody` render and splice. `reportSchema` is the zod
schema of the structured output (`--json`).

Body splice: a body holding a marked block gets it replaced in place; otherwise
a `## Change statistics` section goes before a trailing `<!-- sdlc-lease: … -->`
footer, which stays the last line byte for byte; otherwise it is appended.
