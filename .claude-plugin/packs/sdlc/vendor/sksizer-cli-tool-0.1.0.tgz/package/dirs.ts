/**
 * Whose machine-local directories a tool's state lives under.
 *
 * A tool's machine config file and its devlink state sit in the config home
 * of its standalone tier (`<config>/<tool>/`). The vendor and the override
 * variables (`<PREFIX>_ROOT`, `<PREFIX>_<HOME>_DIR`) belong to whoever ships
 * the tool, so the tool supplies them rather than this package fixing them.
 */
import {
  type EnvVars,
  envVars,
  type SystemBaseDirsOptions,
  systemBaseDirs,
  TieredDirs,
} from '@sksizer/tiered-dirs'

export { envVars, TieredDirs }
export type { EnvVars, SystemBaseDirsOptions }

export interface VendorDirs {
  /** The vendor segment, e.g. `com.example`. */
  vendor: string
  /** The override variables, e.g. `envVars('EXAMPLE')`. */
  envVars: EnvVars
}

/** The vendor's directories, resolved from the environment. */
export function systemDirs(v: VendorDirs, opts: SystemBaseDirsOptions = {}): TieredDirs {
  return new TieredDirs(v.vendor, systemBaseDirs(v.envVars, opts))
}
