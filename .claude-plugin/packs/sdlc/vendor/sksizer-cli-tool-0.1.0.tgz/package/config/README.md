# `@sksizer/cli-tool/config`

A CLI tool's two config files, and the check a command runs before it
starts.

```ts
import { configNeeds, machineConfigFile } from '@sksizer/cli-tool/config'

const machine = machineConfigFile({ tool: 'sdlc', schema: MachineConfigSchema })
const needs = configNeeds({
  tool: 'sdlc',
  projectFile: 'sdlc.yaml',
  projectSchema: SdlcConfigSchema,
  machine,
  scaffoldHint: '`sdlc config scaffold` shows the full shape',
})

const need = { config: 'lease_authority', unlessInput: 'authority' }
if (!needs.met(need, { project: loadConfig(root), input })) {
  throw new Error(needs.message(need, { projectRoot: root, command: ['lease', 'list'] }))
}
// `sdlc lease list` needs `lease_authority`, and it is not set (or pass
// --authority). The remote leases are taken against. Set it in
// /work/app/sdlc.yaml; `sdlc config scaffold` shows the full shape.
```

## Why

A tool that runs inside a project has a committed config file there. A path
like `~/Developer` that only means something on one laptop has no honest
place in a committed file, so the same tool wants a second file that never
leaves the machine. And every command that cannot run without a setting
checks for it by hand, with its own wording and exit code, and nothing lists
which settings a command depends on.

This package is those three things once: the machine file's location and
loader, the two-schema lookup, and the one message an unmet need renders.

## The machine file

`machineConfigFile({ tool, schema, vendorDirs })` names `<config>/<tool>/config.yaml` in the tool's
standalone config home
([`@sksizer/tiered-dirs`](https://www.npmjs.com/package/@sksizer/tiered-dirs):
`~/Library/Application Support` on macOS, `${XDG_CONFIG_HOME:-~/.config}` elsewhere), the same
directory the [devlink entry](../devlink/README.md) keeps its link state in. `vendorDirs` is
`{ vendor, envVars }`: the vendor and the override variables (`<PREFIX>_ROOT`,
`<PREFIX>_CONFIG_DIR`) that move the config home, supplied by whoever ships the tool.

| Member | Does |
|---|---|
| `path()` | the file's path; `<STEM>_MACHINE_CONFIG` (`SDLC_MACHINE_CONFIG`) overrides it |
| `load()` | the file parsed through `schema`, all defaults filled; never throws |
| `loadWithIssues()` | `{ value, issues }`: `load()`'s value plus one issue per thing it dropped |
| `clearCache()` | drop the memoised value (tests) |
| `check(raw)` | the load issues `raw` would have that the file on disk does not |
| `write(text)` | replace the file: throws, writing nothing, if `check` finds a new issue; keeps `<file>.bak`; atomic |
| `migrate({ dryRun? })` | run the migrations on disk: `{ path, from, to, applied, written }`; writes only when one applied |
| `currentVersion` | the last migration's `to`, or 1 |
| `env` | the override variable's name |

The schema is the contract: every key carries a default, so `schema.parse({})` is the all-defaults
object a missing, unreadable or non-mapping file degrades to. A file that fails the schema is
salvaged: each unknown key is dropped, then each section that is still invalid takes its default,
and the rest is kept. Every drop is a `MachineConfigIssue` (`path`, `code` — `unknown_key`,
`invalid`, `unreadable`, `yaml`, `not_mapping` or `newer_version` — and `message`). The loader never
prints them; the tool decides how to show them. Options `env`, `fileName` and `dirs` change the
variable, the file name and how the directories are resolved (a test injects a rooted one).

Option `migrations` is an ordered `MachineMigration[]` (`{ from, to, run(raw) }`). The schema should
declare an optional integer `version`; a file without one is version 1. The loader runs every step
from the file's version on, in memory, before validation. A file newer than the last step is read
as-is with a `newer_version` issue. `migrate()` persists the result through `write`, which keeps a
`.bak` but not the file's comments. `migrateMachineRaw` is exported on its own. The write itself
goes through `@sksizer/etag-write`.

## Needs

A command declares what it cannot run without:

```ts
interface ConfigNeed {
  config: string       // dotted key: 'lease_authority', 'paths.dev'
  unlessInput?: string // an input that stands in: 'authority' for --authority
}
```

`configNeeds({ tool, projectFile, projectSchema, machine, scaffoldHint? })`
returns:

| Member | Does |
|---|---|
| `met(need, { project, input })` | true when the input stands in, or the key is set in the project config or the machine file |
| `message(need, { projectRoot, command })` | the one message an unmet need renders |
| `whereToSet(key, projectRoot)` | the "set it in ..." clause on its own |
| `keyScopes(key)` | which schemas carry the key: `{ project, machine }` |
| `keyExists(key)` | either does |
| `keyDescription(key)` | the first sentence of the key's `.describe()` prose, project schema first |

"Set" means not undefined, null, empty text, an empty list or an empty map,
so a schema default like `repos: []` still counts as unset.

The message says where to set the key from what the schemas allow and
where the person stands. A key only the project schema carries names the
project file. A key only the machine schema carries names the machine file
by path. A key both carry names both, the project file first when one
exists at `projectRoot`, the machine file first otherwise, with the project
file described ("an sdlc.yaml at the project root (none above /here)")
rather than pointed at.

## Named directories

Both files may carry a `paths:` map, and any other path-valued setting
refers to an entry as `{name}`:

```yaml
paths:
  dev: ~/Developer
repos:
  - '{dev}'
  - '{dev}/work'
```

```ts
const tokens = pathTokens(projectRoot, machine.load().paths, project.paths)
const dir = expandTokens(entry, tokens, 'repos:', { defineHint })
```

| Member | Does |
|---|---|
| `pathsSchema({ reserved })` | the map as a schema: a name (letters, digits, `_`, starting with a letter) → a directory, refusing any `reserved` name a consuming setting defines itself |
| `pathTokens(baseDir, machine, project)` | the effective map: project entries under machine ones, each `~`-expanded and absolute |
| `expandTokens(value, tokens, where, opts?)` | `value` with every `{name}` replaced; `TokenError` for one nothing defines, naming `where` it appeared, what is available, and `opts.defineHint` |
| `resolveConfigPath(value, baseDir)` | the one `~` and relative expansion every config path value goes through |

An unknown token is an error rather than an empty string: a setting that
quietly becomes `/repo` instead of `/Users/me/dev/repo` fails somewhere far
from the typo.

## Pieces

`valueAt(obj, key)`, `valueIsSet(value)`, `leafSchema(schema, key)`,
`keyExists(schema, key)`, `keyDescription(schema, key)`, `unwrapSchema`,
`shapeOf` and `envStem(tool)` are exported for a tool that needs one of them
without the rest. `leafSchema` walks a Zod object by dotted key, keeps the
outermost wrapper (that is where `.describe()` sits), and resolves a key
under a record to the record itself.

The schema walk reads Zod's private `_def` layout by tag name rather than
`instanceof`, so a second copy of zod in a consumer's tree still resolves.
A tripwire test fails loudly if a zod release moves that layout.

## Runtime

`node:` APIs only; runs under Bun and Node. Dependencies: `@sksizer/tiered-dirs`,
`yaml`, `zod`.

## Rust twin

`cli-config` (`packages/rust/cli-config`) ports the `paths:`/`{name}` token
model, the dotted-key value lookup, and the machine file/needs check to
Rust. It has no zod to introspect, so its `needs` module asks a tool to
declare a static `KeySpec` table (key, scope, one-sentence description)
instead of deriving that from a schema at runtime. The two are not held to a
shared parity fixture the way `tiered-dirs`/`@sksizer/tiered-dirs` are.
