/**
 * `@sksizer/cli-tool/config` — a CLI tool's two config files and the check a
 * command runs before it starts.
 *
 * A tool has a committed project file (`sdlc.yaml`) and a per-machine file in
 * the config home of its standalone tier (`<config>/<tool>/config.yaml`), each read through a
 * Zod schema. {@link machineConfigFile} is the machine loader: never throws,
 * keeps the valid sections and reports what it dropped, relocates through an
 * env var, migrates older files in memory, and writes the file atomically.
 * {@link configNeeds} takes both schemas and answers, for a command that
 * declares `{ config: 'dotted.key' }`, whether the setting is set in either
 * file and, if not, one message saying what the key is for and where to set
 * it. {@link valueAt}, {@link valueIsSet} and {@link keyDescription} are the
 * pieces underneath, exported for a tool that only needs one of them.
 *
 * {@link pathsSchema} and {@link expandTokens} are the third piece both
 * files share: a `paths:` map of named directories, and the `{name}`
 * expansion any other path-valued setting refers to them by.
 */

export { valueAt, valueIsSet } from './value.ts'

export {
  PATH_NAME,
  TokenError,
  expandTokens,
  pathTokens,
  pathsSchema,
  resolveConfigPath,
} from './paths.ts'
export type { ExpandOptions, PathTokens, PathsSchemaOptions } from './paths.ts'

export { keyDescription, keyExists, leafSchema, shapeOf, unwrapSchema } from './schema.ts'

export { MACHINE_CONFIG_ISSUE_CODES, envStem, machineConfigFile } from './machine.ts'
export type {
  MachineConfigFile,
  MachineConfigFileOptions,
  MachineConfigIssue,
  MachineConfigLoad,
  MachineMigrateResult,
} from './machine.ts'

export { currentMachineVersion, migrateMachineRaw } from './machine-migrate.ts'
export type { MachineMigration } from './machine-migrate.ts'

export { configNeeds } from './needs.ts'
export type {
  ConfigNeed,
  ConfigNeeds,
  ConfigNeedsOptions,
  KeyScopes,
  MessageOptions,
  MetOptions,
} from './needs.ts'
