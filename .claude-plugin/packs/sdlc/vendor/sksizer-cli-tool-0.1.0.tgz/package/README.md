# @sksizer/cli-tool

What a standalone CLI needs before it does anything of its own.

```ts
import { defineCli, runMain, EXIT, type CliContext } from '@sksizer/cli-tool'

const cli = defineCli({
  name: 'sweep',
  summary: 'Say what has been merged and can go away.',
  flags: {
    all: { kind: 'boolean', help: 'every repository in the config file' },
    gh: { kind: 'boolean', negatable: true, help: 'use GitHub evidence' },
    output: { kind: 'enum', choices: ['text', 'json'], default: 'text', help: 'report format' },
  },
  positionals: [{ name: 'path', variadic: true, help: 'a checkout, or a directory of them' }],
})

export function main(argv: readonly string[], ctx: CliContext): number {
  const parsed = cli.parse(argv, ctx.io)
  if (parsed.status === 'help') return EXIT.ok
  if (parsed.status === 'error') {
    ctx.io.stderr(`sweep: ${parsed.message}\n\n${cli.help()}`)
    return EXIT.error
  }
  const { all, gh, output } = parsed.values // boolean, boolean, 'text' | 'json'
  ctx.io.stdout(sweep(parsed.positionals, { all, gh, output }))
  return EXIT.ok
}
```

The bin shim is the only thing that touches the process:

```js
#!/usr/bin/env node
import { runMain } from '@sksizer/cli-tool'
import { main } from '../dist/cli.js'

await runMain(main, { name: 'sweep' })
```

## Four entries

| Import | What it holds |
|---|---|
| `@sksizer/cli-tool` | The substrate below — output seam, context, exit codes, flag declaration, bin shim |
| [`@sksizer/cli-tool/config`](./config/README.md) | The tool's project and machine config files, the `paths:` map, and the check a command runs before it starts |
| [`@sksizer/cli-tool/devlink`](./devlink/README.md) | Running a system-installed tool from a development checkout, with link history |
| [`@sksizer/cli-tool/trust`](./trust/README.md) | Per-repository consent to run a repository's own scripts, remembered across runs |

They are one package because a tool reaches for all four at once. A bin shim
asks devlink which checkout should answer and then hands control to `main`;
`main` reads its config, gates project-sourced behaviour on trust, and writes
through the io seam. Four packages bought four manifests, not four ideas.

## The substrate

### Output goes through `CliIo`

```ts
export interface CliIo {
  stdout(text: string): void
  stderr(text: string): void
}
```

`processIo` writes to the real streams and is the only thing that names one.
`captureIo()` accumulates instead, so a test asserts on output without
monkeypatching a global — a patch that leaks on a missed `finally` corrupts
every other test in the process.

Exit codes are not part of this seam; they are return values. There is no
`stdin` member. Ambient values a command needs beyond output travel in
`CliContext`:

```ts
export interface CliContext {
  io: CliIo
  cwd: string
  env: Record<string, string | undefined>
}
```

`cwd` and `env` arrive as values rather than being read from the process,
which is what lets a test drive a whole command against a temporary
directory. `processContext()` is the real one; `captureContext()` is the
test one.

### Exit codes

| Code | Meaning |
|---|---|
| `EXIT.ok` (0) | The command did what it was asked |
| `EXIT.error` (1) | A well-formed command that failed against the state it found |
| `EXIT.usage` (2) | The command cannot run as typed |
| 10-63 | This tool's own outcomes — `isDomainExit` checks the band |
| 64+ | Not available: `sysexits.h` claims 64-78, the shell claims 126+ |

A script can act on the split: 2 means fix the command line, 1 means look at
the state. A malformed command — an unknown flag or subcommand, a wrong
argument count, a wrong-typed value — is decided from the argument list and
the tool's own schema with nothing read, so re-running it can only fail the
same way. It is the same 2 in every tool, and 2 is the conventional choice:
argparse and most GNU tools already use it.

The band is for outcomes of the work — "nothing to sweep" as against
"something failed to delete" — declared by the tool and documented at its own
`main`. It is not a second spelling of the three universal codes above.

### Flags are declared, not parsed

`defineCli` builds a [commander](https://github.com/tj/commander.js) command
underneath, so `--flag=value`, short flags, `--no-x` negation and
required-value checking are not reimplemented here. What it adds is the house
contract: nothing writes to a process stream, nothing calls `process.exit`,
and a usage error comes back as a value.

| Kind | Parses to | Notes |
|---|---|---|
| `boolean` | `boolean` | `negatable: true` starts it at `true` and spells it `--no-<name>` |
| `string` | `string`, or `string \| undefined` with no default | `required: true` refuses the run when absent |
| `enum` | one of `choices` | commander rejects anything else |
| `list` | `string[]` | comma-separated and repeatable |
| `count` | `number` | `-vv` is 2 |
| `tristate` | `boolean \| undefined` | `--x`, `--no-x`, or neither |

Keys are camelCase and the flag is the kebab of the key: `binDir` is
`--bin-dir`. `parse` returns one of three states — `ok` with typed values and
positionals, `help` when `--help` was asked for and already written, or
`error` carrying commander's own wording with no prefix, so the caller
decides how to present it.

A flag with no default parses to `undefined` when the command line does not
mention it, and that is load-bearing: a `tristate` or an undefaulted `list` is
how a configuration layer underneath the flags gets to answer. A flag that is
always present would overwrite the configured value on every run.

The declaration is also the help text. A hand-written usage string beside a
hand-rolled `switch` is two things to keep in step, and they drift.

### Two help tiers

A tool with more surface than a first-time reader needs prints a short help by
default and a complete one on request. Both render from the one declaration,
so a flag cannot be in the parser and missing from the complete help.

| Piece | Effect |
|---|---|
| `hidden: true` on a flag | Left out of the short help. Still parsed, and still shown by `help({ all: true })` |
| `shortEpilogue` | Used instead of `epilogue` in the short tier |
| `autoHelp: false` | Commander stops owning `-h, --help`, so the tool can render the tier itself |

`autoHelp: false` is what makes the second tier reachable at all. Commander
acts the moment it reads `--help`, so it can never see `--help --all` as one
thing; a two-tier tool turns it off, declares `help` and its modifier as
ordinary flags, and picks the tier after parsing:

```ts
const cli = defineCli({ name: 'way', autoHelp: false, flags: {
  help: { kind: 'boolean', short: 'h', help: 'the short form' },
  all: { kind: 'boolean', help: 'with --help: every flag and every note' },
  // …
}})
const USAGE = cli.help()
const SHORT_USAGE = cli.help({ all: false })
```

`waypost` is the worked example: `way --help` is the ways in and the common
flags, `way --help --all` is every flag and every note. A usage error prints
the short tier, because answering a mistyped flag with the whole surface makes
the reader hunt for the error. A one-tier tool declares neither and lets
commander own `--help`.

### `runMain`

Assigns `process.exitCode` rather than calling `process.exit`, because
exiting outright truncates buffered stdout and the bug only shows under a
pipe. A thrown error becomes one line on stderr and exit 1; a stack trace
says where the code was, not what the person who typed the command should do.

### Asking yes or no

`askYesNo(question, { defaultYes })` writes the question to stderr with a
`[y/N]` or `[Y/n]` hint and reads one line from stdin. An empty answer takes
the default; otherwise only `y` or `yes` is yes. It is synchronous, so a
caller inside a synchronous loop can ask between two steps. Check
`canPrompt()` first: it is true only when stdin and stderr are both terminals.

### Whose directories

A tool's machine config file and its devlink state live in the config home of
its standalone tier. The vendor and the override variables that move that home
belong to whoever ships the tool, so the tool passes them as a `VendorDirs`:

```ts
import { envVars } from '@sksizer/cli-tool'

const vendorDirs = { vendor: 'com.example', envVars: envVars('EXAMPLE') }
```

`systemDirs(vendorDirs)` resolves them through `@sksizer/tiered-dirs`.

## Runtime

The bin of a CLI built on this runs under **node** over its built `dist/`,
with `engines.node` declared. Bun stays the development runtime, and the
package's `bun` export condition still hands a bun program the TypeScript
source when it imports the library.

Nothing in this package touches a `Bun.*` global, because every node-run bin
imports it.

## See also

- `S-0015-standalone-cli-shape` — the rules this enforces
- `D-LLJY-cli-tool-substrate` — why one package
