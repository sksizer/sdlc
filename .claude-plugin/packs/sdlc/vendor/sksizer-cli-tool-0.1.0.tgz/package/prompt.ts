/** Synchronous yes/no prompt, so a caller inside a synchronous loop can ask between two steps. */

import { readSync } from 'node:fs'
import { isatty } from 'node:tty'

/** Only `y` or `yes`, in any case, means yes. */
export function isYes(answer: string): boolean {
  return /^y(es)?$/i.test(answer.trim())
}

const PAUSE = new Int32Array(new SharedArrayBuffer(4))

/** Up to the first newline from `fd`; empty at end of input. */
export function readLine(fd = 0): string {
  const buf = Buffer.alloc(1024)
  let text = ''
  for (;;) {
    let n: number
    try {
      n = readSync(fd, buf, 0, buf.length, null)
    } catch (e) {
      if ((e as NodeJS.ErrnoException).code !== 'EAGAIN') throw e
      // EAGAIN: stdin is non-blocking and has no input yet; wait and retry.
      Atomics.wait(PAUSE, 0, 0, 50)
      continue
    }
    text += buf.toString('utf8', 0, n)
    if (n === 0 || text.includes('\n')) return text.split('\n')[0]!
  }
}

/** True when stdin and stderr are both terminals, so someone can see a question and answer it. */
export function canPrompt(): boolean {
  // `isatty`, not `process.stdin.isTTY`: touching `process.stdin` makes fd 0 non-blocking.
  return isatty(0) && isatty(2)
}

export interface AskYesNoOptions {
  /** The answer an empty line gives. */
  defaultYes?: boolean
  /** Receives the question text. */
  write?: (text: string) => void
  /** File descriptor the answer is read from. */
  fd?: number
}

/**
 * Write `question` with a `[y/N]` or `[Y/n]` hint and read one line. An empty
 * answer takes `defaultYes`; otherwise only `y`/`yes` is yes.
 */
export function askYesNo(question: string, opts: AskYesNoOptions = {}): boolean {
  const defaultYes = opts.defaultYes ?? false
  const write = opts.write ?? ((text: string) => process.stderr.write(text))
  write(`${question} ${defaultYes ? '[Y/n]' : '[y/N]'} `)
  const answer = readLine(opts.fd ?? 0).trim()
  return answer === '' ? defaultYes : isYes(answer)
}
