# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Version 0.1.0 has never been published. The package merges two implementations
of the same idea that had drifted apart inside one monorepo — a subprocess-free
single-root detector serving a quality-check op, and a monorepo-wide catalog
serving an interactive browser — into one library with a provider contract.

### Changed

- **Trust moves to `@sksizer/cli-tool`'s store and `@sksizer/sdlc-tool`'s
  policy.** `src/trust.ts` — the marker store, `resolveExecGate` and
  `execWithheldHint` — is deleted outright; both CLIs now mount
  `@sksizer/cli-tool/trust`'s `trustStore({ tool: 'waypost' })` (same
  directory, same marker names, so an existing grant keeps working) and
  `@sksizer/sdlc-tool/trust`'s `policyExecGate`. A new USER-layer `trust`
  config block (`trust.paths`/`trust.owners`) lets a person pre-authorize a
  class of repositories with no per-repository marker at all — rejected from
  the project layer the same way `allowExec: true` is, since a repository
  must not be able to grant itself trust. `trust --show`/`--json` gain `by`
  (`"marker" | "path" | "owner" | null`) and `rule`, and `--untrust` now says
  when a policy still covers a root after its marker is removed. See "The
  policy" in `README.md` and `packages/ts/sdlc-tool/README.md` for the glob
  dialect and the origin-remote threat model.

- **Flags are declared, not hand-parsed.** The `for`+`switch` loop and the
  usage string beside it are gone; `src/cli.ts` declares its flags to
  `defineCli` from
  [`@sksizer/cli-tool`](https://www.npmjs.com/package/@sksizer/cli-tool) and
  the help text is rendered from that declaration, so the parser and the help
  cannot disagree. Commander now owns `--flag=value`, short flags and
  required-value checking, and an argument the tool never declared is a usage
  error rather than something quietly dropped.

- **`--output list|json|table` is the format flag.** `--json`, `--list` and
  `--table` keep working as aliases for the three values; nothing that already
  passes them changes.

- **Exit codes are the house set.** `0` succeeded, `2` means the command
  cannot run as typed, `1` means a well-formed command failed against the
  state it found. The `config`, `trust` and `clean` subcommands already split
  their failures that way; the top-level parser did not, and now does — every
  site says `EXIT.usage` or `EXIT.error` rather than a literal.
  S-0015-standalone-cli-shape makes the split universal and reserves `10`-`63`
  for a tool that numbers its own outcomes, which this one does not.

- **Sources moved under `src/`.** 22 modules and `providers/` sat at the
  package root beside `package.json`, `moon.yml` and `README.md`, shipped by a
  bare `*.ts` glob in `files`. Nothing about the published surface changes:
  the export names are the same (`.`, `./duration`, `./match`, `./params`),
  and `rootDir: "src"` keeps `dist/` flat, so `dist/index.js` is still
  `dist/index.js` and every export target resolves as before. Done now because
  the layout is published contract — after a first release, moving these
  breaks anyone who deep-imported, and before one it costs nothing.

### Fixed

- **The `node` bin works.** `bin/detect-runners.js` runs under node, but the
  PATH lookup in `collect.ts` and `cached.ts` defaulted to `Bun.which`, so a
  bare `node bin/detect-runners.js` died with `ReferenceError: Bun is not
  defined` before printing anything. The default is now a portable PATH scan
  over `node:fs` (`src/which.ts`), honouring `PATHEXT` on Windows. The
  injectable `which` option is unchanged.

### Added

- **`trust --json` and `clean --json`.** The two subcommands whose answers were
  human-only now have a machine form, so a script or an agent can read them
  without parsing a paragraph.

  `trust` answers in ONE shape across its three root-scoped modes —
  `{"root": …, "trusted": …, "changed": …}` for the bare grant, `--untrust` and
  `--show` — because a caller that had to branch on the flag it just passed to
  know which shape came back would be doing the tool's job for it. `--list`
  answers a different question and gets `{"trusted": [paths]}`, which is `[]`
  rather than no output when nothing is trusted. `--json` is not a fourth mode:
  it combines with each of the three rather than contradicting them.

  An `--untrust` that found nothing still prints its document and reports the
  miss through exit 1 and a line on stderr — a parser handed exit 1 and an
  empty stdout would have to guess what the store held.

  `clean` answers with a `stores` array of
  `{key, flag, what, path, bytes, removed}`: all three stores on a bare report,
  only the ones you named on a removal. `bytes` is null when nothing was
  stored, which is what separates "there was nothing to remove" from "it would
  not delete" — both are `removed: false`. The document is printed once, at the
  end, so a run that stopped on a failure is still one object. The closing note
  about trust being asked for again is an aside, not the answer, so under
  `--json` it goes to stderr.

- **`paramShape`, on a `./params` export subpath.** A task's parameters in
  just's own notation — `<required>`, `[optional]`, `+`/`*` for a variadic that
  does and does not need an argument. Display only, never executable: `<name>`
  is a shell redirection and `*` globs, which is the whole reason `argv` and
  `display` are separate fields.

  Its own subpath rather than the package entry, for the same reason `duration`
  and `match` have one: the consumer that needs it most is a browser bundle,
  and importing from the entry drags `node:fs` and `child_process` in with it.
  There were two copies of this spelling before — the just provider's and the
  terminal UI's — and the second had already been written a third time.

- **`excludePaths` — naming a tree that is data rather than project structure.**
  A config key and a repeatable `--exclude-path` flag on both CLIs. The case it
  exists for is a test-fixture repository: it holds real manifests, a detector
  is right to find them and right to report a broken one, and none of them is a
  task anyone can run. Turning off the runner was the only answer available
  before, and it would also have hidden the tasks you do have.

  Two forms, and deliberately not glob. A bare name matches any path segment at
  any depth, which is the only useful reading for `node_modules`. A value
  containing a slash matches from the root, segment by segment — so `src/app`
  does not take `src/application` with it, and naming one fixture tree does not
  exclude every directory in the repository called `tests`.

- **A `clean` subcommand, on both CLIs.** Three things live outside your
  repositories — the cache, the trust store, and your user configuration — and
  until now nothing in either tool would tell you where they were, let alone
  remove them. Bare `clean` reports each store and removes nothing: a command
  whose subject is deleting should not delete by default, and putting the safe
  behaviour behind a `--dry-run` only means forgetting to pass it. `--cache`,
  `--trust`, `--config` and `--all` name what to remove.

  `--config` and `--all` additionally want `--yes`, because the three are not
  equally replaceable: the cache is derived and costs one slow probe, trust
  costs re-answering a question per repository, and the configuration is the
  only one a person wrote by hand. Nothing inside a repository is ever touched.

- **`docker-compose` and `github-actions` providers — the two `Task.executes` was added for.** The
  axis had carried a single value since it was introduced; its docblock names a compose service and
  an Actions workflow as the motivating cases, and these are those cases. Both are `kind: "parse"` —
  their definitions are plain data on disk — and neither emits a task that runs on this machine, so
  `executes` now carries all three of its values across the built-in roster instead of one.

  `docker-compose` detects the four Compose config filenames and picks one winner per directory in
  Compose's own precedence order,
  `compose.yaml > compose.yml > docker-compose.yml > docker-compose.yaml`. That order was verified
  empirically against Docker 29.6.2 rather than assumed, and the asymmetry is real: the `compose`
  prefix prefers `.yaml` while the `docker-compose` prefix prefers `.yml`. A directory carrying more
  than one raises a warning naming the shadowed siblings. Each key under `services:` becomes
  `docker compose -f <file> up <service>` with `executes: "container"` and
  `persistent: { value: true, declared: false }` — `up` rather than `run` because a catalog entry
  means "start this service", not "run a one-off command in it". `value: true` is the right default
  and is inferred from the `up` verb rather than from the service's name, so `looksPersistent` is
  deliberately unused; `declared` stays `false` because Compose states nothing about persistence
  anywhere in the file, and a one-shot service (`command: echo hello`) does exit immediately, so
  this is the package's inference and a consumer filtering for authoritative answers must not be
  told otherwise.

  `github-actions` detects `.github/workflows/*.yml|yaml` at the repository root only —
  `ctx.files()` matches basenames, so the directory filter is applied on the returned paths, and a
  nested `.github/workflows/` or a subdirectory under the real one is rejected the way GitHub
  rejects it. Each workflow becomes `gh workflow run <file>` with `executes: "remote"`, but ONLY
  where an `on.workflow_dispatch` trigger is declared: `gh` cannot dispatch a workflow without one,
  so a task for it would be a row that always fails. Those are withheld and reported in a diagnostic
  carrying the count and the names. Only a workflow whose `on:` was read cleanly is counted there:
  an empty file gets its own warning instead, since it has no trigger declaration that could be
  missing, and an `on:` the reader cannot interpret fails OPEN — the task is emitted with a warning,
  because suppressing hides a task the user knows exists while emitting at worst yields a row `gh`
  rejects with its own clear message. The provider's docblock states the ceiling rather than leaving
  a user to find it — this builds nothing locally, spends real CI minutes, needs an authenticated
  `gh` with write access, and returns a run URL instead of output.

  Neither provider adds a YAML dependency. Each hand-writes a narrow reader for exactly the keys it
  needs, following `go-task.ts` in approach and in honesty: the ceiling is declared in the module
  docblock, and anything that reader declines to interpret raises a warning naming the file, the
  limitation and its consequence rather than being silently under-reported. The two ceilings are not
  the same, and each docblock is the authority on its own — docker-compose declines a flow-style
  `services:` mapping, which github-actions reads happily; both decline anchors and aliases, merge
  keys and multi-document `---`. Both readers strip a leading UTF-8 BOM and track open block
  scalars, so a `---` indented inside a `run: |` or a `command: |` is content rather than a document
  separator, and neither a BOM nor such a line can silently swallow the rest of a file.
  github-actions scopes its anchor and merge warnings to the `on:` declaration, where the limitation
  can actually change the answer, rather than warning on the `&defaults` job pattern that appears in
  ordinary repositories. Neither provider calls `ctx.runner()` at all.

  `tests/providers.test.ts` now holds the roster's declared `executes` intent as a map, asserts it
  covers `builtinProviders` exactly, and checks that no provider emits a value it did not intend —
  so a new provider cannot land without someone stating what its tasks do when run.

- **A `CliIo` output seam, so no command writes to a process stream directly.**
  `main(argv, env, home, io)` in both CLIs takes the sink it prints to. It hands
  that sink on to the `config` and `trust` subcommands, whose `ConfigCommandIO`
  and `TrustCommandIO` are views of the one interface. This is the house pattern
  `OpIo` follows in the ontological registry. Tests capture output through
  `captureIo()`. Exit codes stay outside the seam as ordinary return values, and
  there is no `stdin` member.

- **A `guide` command on both CLIs: the instructions, without the README.**
  `--help` answers only "what are the flags". `guide` prints Markdown on stdout
  covering five topics: `usage`, `config`, `json`, `trust`, `extend`. Each is
  printable alone. `guide topics` lists them, and an unknown topic exits 2. The
  sections are data rather than one blob, so `waypost` wraps the same text with its
  own usage. An anti-drift suite asserts on no wording: it derives the runner
  roster from `builtinProviders`, the settable keys from a new `CONFIG_KEYS`
  export, and the documented flags from the literals each `parseArgs` accepts,
  checked in both directions over the whole document. Adding a provider or a
  setting and forgetting the guide fails the suite. The provider example lives
  twice, once as the printed string and once as a real module inside the package
  `tsconfig.json`, with a test asserting the two are identical.

- **Per-repository trust, and a `trust` command that records it.** Some runners
  can only be read by running them — `moon query tasks` evaluates the target
  repository's toolchain configuration, and `mise tasks` can fire its `[hooks]`
  — so pointing this at a repository you did not write is code execution.
  Browsing is not running: a person may look at a catalog and choose to run
  nothing, and merely looking already executed that repository's code. Consent
  is now asked once, per repository, and remembered in
  `$XDG_STATE_HOME/waypost/trusted/` (else `~/.local/state/waypost/trusted/`) as one
  marker file per trusted root. XDG state rather than config, because trust is
  state a program maintains and a consent record that travels in a dotfiles repo
  onto a new machine has stopped being consent; one file per root rather than one
  document, because creating and unlinking a file are atomic and a lost trust
  record is a bad failure to debug. `trust`, `trust --untrust`, `trust --show`
  and `trust --list` are the surface, `-C` reaches all of them, and both CLIs
  share one store and one implementation so a repository trusted with one tool is
  trusted by the other in the same words. The key is the absolute,
  symlink-resolved path, which is the same tradeoff mise makes: a trusted
  repository that later pulls hostile changes stays trusted, and `--untrust` is
  the remedy. Content-hashing every runner config instead would re-prompt on
  ordinary edits, and a prompt that fires on every edit trains people to approve
  without reading. `--exec` remains the escape hatch and records nothing — one
  deliberate run must not become a standing grant nobody remembers giving. Trust
  is one of two conditions here, not the whole gate: `detect-runners` leaves
  execution off by default, so a trusted repository still collects nothing until
  `--exec` or a user-file `allowExec: true` supplies the other half. `waypost`
  supplies that half from its own default, which is why trust alone is enough
  there. When runners are withheld in a non-`--json` run, stderr now names the
  half that is missing rather than staying silent or naming trust when trust is
  not the blocker. An empty or blank marker file is not a grant, so `isTrusted`
  and `trust --list` agree on what the store holds.

- **`ctx.which(binary)`, a PATH lookup with no subprocess.** It exists
  separately from `ctx.runner`, which spawns, so it is safe under
  `allowExec: false`. A provider declares a static `binary?: string` — it
  only names its tool — and `collect()` fills `RunnerReport.tool = { binary,
  found, path? }` by calling `which()` on that name, so a provider cannot
  misreport whether its own tool is installed. Presence is filled even when
  the provider was skipped for exec or threw, since it is a fact about the
  binary, not about how collection went. Fourteen of the sixteen built-ins
  declare a `binary`; `node-scripts` and `python` abstain because their real
  binary is resolved per directory (npm/pnpm/bun, uv/poetry). The `just`
  provider dropped its `just --version` subprocess probe in favor of
  `ctx.which("just")` — the same question, no subprocess.
  `CollectOptions.which` overrides the lookup for tests.
  `detect-runners` now emits a `warning` diagnostic on stderr when a runner
  is configured (its marker file is present) but its declared binary is
  missing from PATH, naming the binary. A runner that is simply absent stays
  silent — `tool.found === false` alone is true of every non-project
  directory and would nag on all of them. `--json` carries `tool` for free;
  `--table` is unchanged.

- **`Task.executes: "local" | "remote" | "container"`, required.**
  `RunnerProvider.kind` (`parse`/`exec`) is a detection posture — what this
  package must do to read the repo. `executes` is a different axis: what
  running the task does. A GitHub Actions workflow file is parse-detected
  but remote to run; a docker-compose service is `container` regardless of
  how it was read. Every built-in task is `"local"` today; the `quality
  detect` op's zod schema mirrors the field. `--json` carries `executes` for
  free; `--table` is unchanged.

- **A layered configuration file, and a `config` command that edits it.** The
  collection options that matter to a person are the same few every time —
  which runners to skip, whether execution is allowed, how files are discovered
  — and typing them as flags on every invocation is how a tool stops being
  used. They are now settable once: built-in defaults, then
  `$XDG_CONFIG_HOME/waypost/config.json`, then `waypost.config.json` at the project
  root, then the flags. Project beats user because which runners a repository
  has is a fact about the repository, true for everyone who checks it out,
  while the user file is a preference that should not follow someone into a
  project that already answered. Objects merge key-wise and everything else,
  arrays included, replaces wholesale: an array here answers "which ones, in
  what order", so a project naming one runner means that one, not that one
  appended to whatever the user happened to have. An unknown key warns and the
  rest of the file still loads, so a config written for a newer version cannot
  brick an older one; a malformed file is an error naming the file and the
  problem, never a silent fallback. `config list` names the layer each value
  came from, which is the question you ask when a setting is not what you
  expected. Both CLIs share one file and one implementation of the command, so
  the key names and messages cannot drift apart; a calling tool passes its own
  defaults in, so `list` and `get` report the value that tool will run with
  rather than the library's. `config` exits 2 when the command as typed cannot
  run — an unknown setting name, a wrong-typed value, a bad option — and 1 when
  a well-formed command failed against the state it found, so a script can tell
  "fix the command" from "look at the files".

- **`--no-exec` on `detect-runners`.** The tool had `--exec` only, which was
  enough while the default was fixed at `false`; once a configuration file could
  set `allowExec: true`, there was no way to turn it back off for one run. Both
  tools now take both flags, so a flag is the last word on the trust gate in
  either direction.

- **An optional `brand` per provider** — `{ icon, color }`, copied onto the
  `RunnerReport` so UIs can show a mark and a tint next to each runner. It sits
  on the report rather than on each task because a catalog carries thousands of
  tasks and a handful of runners. Optional end to end: a provider without one
  is complete, and a brandless report serializes without the key. The built-ins
  ship each tool's own mark (or its ecosystem's) as CC0 path data from
  simple-icons, used nominatively, falling back to a small original glyph where
  simple-icons carries no CC0 icon for the tool; brand colors are verified
  against each project's own site or simple-icons' canonical hex.

- **A provider contract as the extension point.** `RunnerProvider` declares an
  `id`, a `kind`, a `chain` describing what each position of a task's path
  means, and one `collect(ctx)`. The built-ins hold no privileges a caller's own
  provider lacks: `collect(root, { providers: [...builtinProviders, mine] })`.
  Providers receive an injected runner and file lister rather than spawning or
  reading directly, which is what makes them testable without the binaries
  installed.

- **Sixteen built-in runners** — `moon`, `mise`, `just`, `node-scripts`,
  `make`, `cargo`, `sbt`, `python`, `composer`, `deno-tasks`, `turbo`, `maven`,
  `swiftpm`, `gradle`, `go-task` and `rake`. `moon` and `mise` are read by asking the tool rather
  than by parsing its files: moon inherits tasks through `.moon/tasks/*.yml` by
  language, layer, stack and tag, and mise merges `[tasks.*]` across several
  config files plus executable file tasks under `mise-tasks/`. Reimplementing
  either merge would get it subtly wrong.

- **`sbt`**, read by asking sbt. An sbt build is a Scala program and its task
  set comes from plugins, so there is nothing to parse; sbt also offers no
  machine-readable listing, so the provider scrapes one `sbt -batch projects
  tasks` session. It asks once because sbt boots a JVM and compiles the build
  definition, which is the first provider here whose probe costs seconds.

- **`gradle`, `go-task` and `rake`, each with two paths like `just`.** All three
  are `parse` providers: they read files and answer without running anything,
  which is the floor and never gets worse. When execution is allowed and the
  binary is there, each asks its own tool instead, and the diagnostics say which
  path ran.

  `gradle` can't parse `build.gradle`/`build.gradle.kts` — Gradle task
  definitions are Groovy or Kotlin code, a language rather than a data format —
  so the file-only path offers the conventional lifecycle tasks (`build`,
  `test`, `clean`, `assemble`, `check`), like `cargo` and `maven`. Asking is the
  only way to learn a build's real tasks, so `gradle tasks --all` replaces them
  with the declared set and their descriptions. That probe starts a daemon and
  compiles the build script, so it runs once per collection, through `./gradlew`
  when a wrapper is present.

  `go-task` reads a Taskfile's `tasks:` map with a narrow hand-written reader
  instead of taking on a YAML dependency, and emits a `warning` naming each
  construct it declines to interpret — anchors, merge keys, flow-style mappings,
  additional YAML documents, and `includes:` pulling in other Taskfiles.
  `task --list-all --json` resolves all five, so none of those warnings is
  emitted on that path.

  `rake` scans a Rakefile's source with a regex, and says in a diagnostic that
  tasks built dynamically — by a loop, by metaprogramming, by `Rake::*Task.new`,
  or by `import`/`load`/`Dir.glob` pulling in other files — are invisible to a
  parser. `rake -AT` sees them, at the cost of evaluating the Rakefile as Ruby,
  which is what allowing execution against a trusted repository consents to; the
  parser's warning is not emitted once rake itself has enumerated the tasks.

- **`allowExec` as a trust boundary.** Providers declare `kind: "parse" | "exec"`
  and only `parse` providers run by default, because `moon query tasks`
  evaluates the target repository's toolchain configuration and `mise tasks`
  can run its `[hooks]` — pointing this at a repository you did not write is
  code execution. A withheld runner is reported with a diagnostic rather than
  silently omitted.

- **A `detect-runners` CLI** — `--json`, `--list`, `--table`, with `--config` to
  merge in providers without writing a program. The directory argument resolves
  upward to the project root, matching what `moon` and `just` already do for
  their own config.

- **Structured diagnostics.** `{ severity, message, source }` per provider,
  because "just is not installed" and "this justfile is broken" want different
  treatment.

- **Aspects with tiered evidence** on each provider result — `manifest`,
  `dependency`, `files`, `content` — recording not just which runner was found
  but what observation supports the claim.

- **A result cache, and `--cached` to read it.** Some runners are slow to ask —
  moon starts its toolchain, sbt starts a JVM — and an interactive surface that
  waits for them looks broken. The store keeps the last answer per (root,
  runner) under `$XDG_CACHE_HOME/waypost/`, or `~/.cache/waypost/`; one file per
  runner, written temp-then-rename, format-versioned in the path and inside each
  file.

  XDG **cache**, deliberately not the `~/.local/state/waypost/` the trust store
  uses. Losing this costs one slow probe; losing the trust store would silently
  un-trust repositories, and a consent record a cache sweep can erase is not a
  consent record. The cache is no part of the execution gate: a cached answer is
  never a trust grant, clearing it never changes what is trusted, and
  `writeEntry` refuses to store an errored report or one withheld for want of
  execution.

  The data surfaces stay FRESH by default. `--json`, `--list` and `--table`
  re-probe every run — a script or an agent must get what the repository has
  right now — and also write the store, so an interactive surface started
  afterwards has something to paint. `--cached` inverts it for one run, probing
  only the runners the store has nothing for. `--cached` against an empty store
  is not an error: it probes, stores, and says so on stderr.

  Staleness is reported on stderr only, so `--list` stays pipeable and `--json`
  stays parseable. `--json --cached` gains a `cache` array beside the catalog,
  one `{ runner, state, reason?, ageMs?, estimateMs, slow }` per selected runner;
  plain `--json` does not, because a key that is always present and always says
  `fresh` teaches a consumer to ignore it. Under `--cached`, `generatedAt` is the
  oldest contributing probe time — a catalog is only as fresh as its stalest row.

  Refresh cost and slowness are MEASURED per repository, from a rolling window of
  the last five probe durations reported as their median, and never declared by a
  provider — there is no `slow` field on the contract. Where a repository has no
  measurement the output says so rather than inventing a number.

- **`RunnerProvider.watch` — basenames whose contents decide whether a cached
  answer still holds.** Invalidation is a content hash, never an mtime: a `touch`
  does not invalidate, and neither does a rewrite to identical bytes. For a
  `parse` provider the coverage is exact and free, because `ProviderContext`
  mediates every read it makes. For an `exec` provider it is deliberately
  incomplete — the provider reads only its markers while its tool merges files it
  never opens — so `watch` closes the part a basename can express and a four-hour
  max age backstops the rest. `moon`, `mise`, `sbt` and `gradle` declare one.

  Even then it is a good signal rather than a proof. A task set can change with
  no watched file changing: a plugin version, a global config, an environment
  variable a build script reads. A fingerprint also hashes at most 256 paths, and
  a run that hits that cap adds an `info` diagnostic rather than letting the
  entry look fresher than it is.

- **`CollectOptions.probeObserver`** — called once per provider that actually
  ran, with what the run measured and touched. The seam the cache rides on, an
  option on the caller rather than a field on the provider contract: a provider
  that could observe its own timings could behave differently when watched.

- **`humanMs` and `humanAge` are exported.** The two formatters every surface
  reporting on the cache needs, in their own `./duration` subpath alongside
  `./match` so a browser bundle can take them without dragging in `node:fs`.

### Changed

- **Git discovery runs on `@sksizer/easy-git`, and a failing `git ls-files` no
  longer reads as an empty repository.** The two git calls — the
  `--is-inside-work-tree` probe and the file listing — go through the typed
  client instead of hand-built argv. The probe still answers `false` outside a
  repository and without git on PATH. The listing now throws: it runs only
  after the probe said yes, so a failure is a broken repository, and folding
  that into "no files" reported every runner as absent from a project that has
  them. `collect()` turns the throw into a per-provider error report, and the
  cached path treats it as a cache miss.

  `@sksizer/easy-git/client` — the subpath without the git-reference parser —
  so the package's module graph stays free of `hosted-git-info`. The published
  signatures are unchanged: `gitAvailable`, `resolveDiscovery` and
  `createLister` still take an `AsyncCommandRunner`.

- **`CollectOptions.exclude_dirs` is now `excludePaths`, and matches paths.**
  Renamed on all three counts that were wrong: it was never limited to `walk`
  mode as its documentation claimed, it now matches files as readily as
  directories, and it is not the sibling of `exclude`, which takes runner ids.

- **`--exec` is documented as consent for one run.** It always was: nothing was
  persisted. The usage text said so nowhere, which mattered little while it was
  the only way to allow execution and matters now that there is a way to record
  the answer.

### Fixed

- **`node-scripts` addressed every nested package with `--cwd`, which only bun
  and yarn classic accept.** npm took it as an unknown config key and ran the
  ROOT package's script — wrong output, exit 0, no error — and pnpm rejected it.
  Each manager now carries its own directory flag: `npm run --prefix <dir>`,
  `pnpm run --dir <dir>`, `yarn --cwd <dir>`, `bun run --cwd <dir>`.

- **A `vite build` script was reported as persistent.** The body heuristic
  matched a bare `vite` anywhere, so essentially every Vite project's build
  looked like a dev server to a consumer that detaches persistent tasks. `vite
  build` is now excluded; `--watch` still wins, `vite build --watch` included.

- **A go-task Taskfile that loses its directory's priority race was addressed
  with `--dir`, which cannot reach it.** go-task reads exactly one Taskfile per
  directory, so `Taskfile.dist.yml` beside a `Taskfile.yml` emitted commands
  that exit with `Task "…" does not exist`. Such a file is now pinned with
  `--taskfile`; the directory's priority winner is unchanged.

- **A nested `turbo.json`'s tasks addressed the root turbo project.** argv
  carried no directory at all, so `frontend/turbo.json` emitted `turbo run
  build` — "Could not find turbo.json" with no root config, and every package's
  build with one. It now uses turbo's global `--cwd <dir>`, which also scopes
  the run to that package.

- **A failed `just --dump` dropped the justfile's recipes.** A justfile whose
  `import` target is missing exits non-zero, and the file's recipes vanished
  from the catalog — turning execution ON made the list thinner. It now falls
  back to the scan for that file, with a warning, the way go-task and rake do.

- **`tierOf` ate the leading dot of a dot-directory.** `.github/actions/x`
  grouped under `github/actions`, a directory that does not exist, so a filter
  or search on `.github` never matched it. Only a `./` prefix is stripped now.

- **A deleted repository's trust marker became unreachable.** The not-found
  fallback in `resolveTrustRoot` expanded no symlinks, so a root under a
  symlinked ancestor (`/var` -> `/private/var`, every `$TMPDIR` path) keyed on a
  different string than `trust` had hashed: `untrust` reported nothing to
  remove and left the grant standing. The fallback now resolves the deepest
  existing ancestor and re-attaches the missing tail.

- **Two concurrent `trust()` calls for one root failed with `ENOENT`.** The temp
  file the marker is renamed from was named per PROCESS, not per call, so
  overlapping calls in one process — `Promise.all` over a path list where two
  entries resolve to the same repository — shared a temp name and all but the
  first renamed a file that was already gone. The name now carries a per-call
  counter as well as the pid.

- **A path in the exclusion list never excluded anything.** Membership was
  tested one path segment at a time, so no entry containing a slash could match.
  `.moon/cache` had shipped in the built-in list without effect since the list
  was written.

- **Changing the exclusion set left the cache serving what it excluded.** The
  set lives in a config file outside the tree, so excluding a directory changes
  nothing on disk: every recorded path still existed with the same bytes, the
  fingerprint matched, and the entry read fresh. A stored entry now records the
  exclusions it was probed under, and a mismatch stales it with a new
  `reason: "excludes"` — named separately from `"changed"`, which would have
  sent someone looking through their repository for an edit that was in their
  config file. `CACHE_FORMAT_VERSION` is 3.

- **A cached entry went stale-blind to a newly added file.** A fingerprint built
  only from the paths a provider READ describes the world as it was. A provider
  that discovers by listing — `github-actions` over `.github/workflows/*.yml`,
  `docker-compose` over its four filenames, `node-scripts` over every
  `package.json` — depends on the answer to its query, not only on the files that
  answer happened to name. Adding a workflow left every recorded hash untouched,
  so the entry stayed `fresh` and the new task never appeared. For a `parse`
  provider there is no max-age backstop, so nothing would have corrected it.

  The patterns a provider passes to `ctx.files()` are now recorded beside the
  paths and re-expanded on every cache read, exactly as a declared `watch` is —
  they are watch patterns a provider never had to write down. `ProbeRecord` gains
  `queries`, `Fingerprint` gains `patterns`, and `fingerprint()`'s `watch`
  argument becomes `patterns`, since a declared watch and a made query want
  identical treatment. `CACHE_FORMAT_VERSION` is 2: entries written before this
  carry no patterns and are abandoned rather than trusted.

  Documentation on three surfaces said a `parse` provider's coverage was "exact"
  and that its recorded reads were sufficient. That was the belief the gap hid
  behind, and it is corrected wherever it appeared.

- **Security: a scanned repository could authorize the execution of its own
  code.** `waypost.config.json` lives INSIDE the repository being scanned, and
  `allowExec: true` there was honoured like any other project-layer value — so a
  repository could ship a two-line file that turned on the very gate that existed
  to protect the person reading it, and running `detect-runners --list` in a
  fresh clone ran that repository's toolchain configuration. The project layer
  can no longer raise `allowExec`; a `true` there is stripped before the merge
  and warns, naming the file. Lowering it to `false` is still honoured, because a
  repository asking not to be shelled out for is asking for less than it was
  already given. Raising it is now the user file's job, or `--exec`'s, and
  neither can be written by the repository being read. **If you relied on a
  project-layer `allowExec: true`** — in your own repository, where it was doing
  no harm — replace it with `detect-runners trust` in that repository, or move
  the setting to the user file. `config list` will show the value attributed to
  the layer that really supplied it, which is how you can tell.

Three further defects were carried by the code this was extracted from, each
found by the extraction rather than in use:

- **A python task in a subdirectory failed when its `display` command was
  pasted at the repository root.** `uv run mycli` for a project at `sub/`
  carried `cwd: "sub"`, so the printed command only worked from inside
  `sub` — run from the root, `uv` resolved the wrong project. The task's
  directory now rides in `argv` via the tool's own flag instead: `uv run
  --project sub mycli`, `poetry --directory sub run mycli`, and the
  synthesized `[tool.*]` verbs take a path argument (`ruff check sub`,
  `mypy sub`, `black --check sub`, `pytest sub`, `pyright sub`). `cwd` is now
  `"."` for every python task, matching the policy `just`, `make` and
  `composer` already followed: a provider expresses the directory in argv
  wherever the tool has a flag for it, and `cwd` is a last resort for tools
  that have none.

Three defects carried by the code this was extracted from, each found by the
extraction rather than in use:

- **Commands are no longer shell strings.** `Task.argv` is executable and
  carries no placeholders; `Task.display` is for showing and copying and may
  contain `<required>` / `[optional]` / `*variadic` markers; `Task.parameters`
  is data. The previous model conflated all three and then executed the result
  with `shell: true`, so `just release-lib <lib> <bump> *flags` was a shell
  **syntax error** — `<lib>` is an input redirection — and any `*args` recipe
  globbed.

- **The package manager is derived, not assumed.** The run verb comes from the
  nearest `packageManager` field or lockfile, searching **upward** from each
  manifest. One ancestor hardcoded `bun run --cwd`; the other looked only at the
  directory it was handed, so every nested package in a workspace resolved to
  the npm default even in a bun repository.

- **The justfile scan reads two shapes it used to miss.** Recipes with a
  variadic parameter (`release-lib lib bump *flags:`) and recipes with
  dependencies after the colon (`ci base="main": ci-guards`) both defeated the
  ported expression, which found 91 of one repository's 110 recipes. The scan
  now matches `just --dump` exactly on that repository.

Two defects in the go-task reader, both found by consolidating the three
providers that read YAML onto one lexer:

- **A Taskfile beginning with a UTF-8 BOM read as having no tasks at all.**
  JS `\s` matches U+FEFF, so the byte bound to the first key and a BOM'd
  `tasks:` never matched `tasks`. The whole file was lost, and nothing was
  reported: the result was indistinguishable from a Taskfile that declares
  nothing. `version:` is optional in Task v3, so `tasks:` genuinely is the
  first line of real Taskfiles and this was not a corner case. The BOM is now
  stripped before anything else reads the text, as it already was for
  `docker-compose` and `github-actions`.

- **A `---` inside a `cmds:` block scalar truncated the Taskfile and then
  warned that it had done so correctly.** The reader had no block-scalar
  tracking, so a shell heredoc containing a `---` line was read as a YAML
  document separator: every task declared after it was dropped, and the
  emitted warning said a second document existed. A diagnostic asserting the
  opposite of what happened is the worst failure this package can produce,
  because a user reads it and believes the file was understood. A block
  scalar's body is now literal text — a `---`, an `&`, a `<<:` or a `#` in
  there means nothing.

Two more, in the document handling all three YAML readers share:

- **A comment before a leading `---` cost the whole file.** A `---` was read as
  a document separator whenever it was not on line 1, but before any document
  content it is the directives-end marker opening the FIRST document, and YAML
  allows comments and blank lines ahead of it. A compose file or Taskfile with
  a comment header therefore read as empty, with a warning blaming a second
  document that was never there. Opener versus separator is now decided on
  whether content has been seen, not on the line number.

- **A trailing `---` or `...` warned that a later document had been dropped.**
  Nothing followed it. `docker-compose`'s wording went as far as "services
  declared in a later document are missing", of a file that declares one
  document and was read in full. The warning now fires only when real content
  actually follows the marker — a tail of blank lines or comments, including a
  commented-out second document, is not a document.

- **A `%YAML` or `%TAG` directive cost the whole file.** A directive line is
  the one thing YAML permits ahead of a directives-end `---`, and is what that
  marker is named for, but it counted as document content — so the `---` it
  introduces read as a separator and everything after it was dropped, with the
  same false warning. A directive is no longer content.

A `...` YAML end marker at column zero now ends the first document for
`docker-compose` and `go-task`, as it already did for `github-actions`;
previously both read on into the next document and reported its keys as the
first document's. Their multi-document warnings name `...` alongside `---`
accordingly.

### Known limitations

- mise's **global** tasks are omitted. They are real, but they live in the
  user's own config and follow them between repositories; listing them would
  make the catalog a description of the machine rather than of the project.
  The count is reported as a diagnostic.
- `make` targets are scanned, not evaluated. `include`d makefiles, pattern
  rules and generated targets are invisible. Running `make --print-data-base`
  would be authoritative but evaluates the makefile, which a `parse` provider
  must not do.
- `python` and `cargo` tasks are synthesized from convention rather than read
  from configuration. They carry `origin: "synthesized"` so a consumer can drop
  them.
- Discovery walks a tree per `collect()`. On a very large repository outside git
  this is the dominant cost.
