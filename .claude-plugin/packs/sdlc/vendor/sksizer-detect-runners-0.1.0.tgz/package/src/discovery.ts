/**
 * File discovery — the one place that decides which files exist.
 *
 * Two strategies, because neither is right everywhere:
 *
 *   git   `git ls-files` — fast, respects .gitignore, and skips build output
 *         and vendored trees without needing a list of their names. Sees
 *         tracked files plus untracked-but-not-ignored ones, so a justfile
 *         written a minute ago counts before it is added.
 *   walk  a directory walk excluding well-known names. Works in any directory,
 *         including one that is not a repository at all, at the cost of picking
 *         up whatever the exclude list does not name.
 *
 * They genuinely disagree — a .gitignore'd project directory is invisible to
 * git and visible to the walk — so the resolved mode is recorded on the
 * catalog rather than left implicit.
 *
 * This module is a candidate for extraction: `@sksizer/manifest-graph` walks
 * the same trees with the same intent and hardcodes the `walk` strategy. One
 * shared walker with two strategies is the right end state; it is not done here
 * because that package is being rewritten concurrently.
 */

import { readdir, stat } from 'node:fs/promises'
import { join, relative, sep } from 'node:path'

import { runCheckedAsync, type AsyncCommandRunner } from '@sksizer/command-seam'

import type { DiscoveryMode } from './model.ts'

/**
 * Paths never worth walking into. Build output, dependency trees and tool
 * caches — all of which contain manifests that are not this project's.
 *
 * Two forms, per {@link matchesExclude}: a bare name matches any path segment,
 * and a value containing `/` matches a root-relative path prefix.
 */
export const DEFAULT_EXCLUDES: readonly string[] = [
  'node_modules',
  '.git',
  'target',
  'dist',
  'build',
  '.nuxt',
  '.output',
  '.astro',
  '.venv',
  'venv',
  '__pycache__',
  '.sdlc',
  '.claude',
  // Test-fixture trees are data, not project structure: without this a repo's
  // catalog picks up the manifests its own test suites keep around, which are
  // not tasks anyone can run.
  //
  // These two names are the CONVENTIONAL place for such a tree, not a complete
  // answer. A fixture tree named anything else — `tests/mini-repo`, `testdata`,
  // `example-repo` — is invisible to a name list, and adding those names here
  // would exclude directories that hold real tasks in some other repository.
  // Naming one by path is what `excludePaths` is for.
  'fixtures',
  '__fixtures__',
  '.moon/cache',
  'vendor',
]

/** Whether `root` is inside a git working tree AND git can be run. */
export async function gitAvailable(root: string, git: AsyncCommandRunner): Promise<boolean> {
  // Failure IS the answer here: outside a repository git exits 128, and a
  // missing binary reaches the seam as a non-zero exit too. Both mean "not
  // usable", which is what this probe asks — so the exit code is read rather
  // than thrown on.
  const res = await git.run(['rev-parse', '--is-inside-work-tree'], { cwd: root })
  return res.exitCode === 0 && res.stdout.trim() === 'true'
}

export async function resolveDiscovery(
  root: string,
  requested: DiscoveryMode | 'auto',
  git: AsyncCommandRunner,
): Promise<DiscoveryMode> {
  if (requested !== 'auto') return requested
  return (await gitAvailable(root, git)) ? 'git' : 'walk'
}

/**
 * Every file git knows about, root-relative and posix-separated.
 *
 * `--cached --others --exclude-standard` is deliberate: tracked files PLUS
 * untracked-but-not-ignored ones. A justfile written a minute ago and not yet
 * `git add`ed is still a justfile, and a tool that cannot see it looks broken.
 */
async function gitFiles(root: string, git: AsyncCommandRunner): Promise<string[]> {
  // Throws rather than degrading to `[]`. This runs only after
  // {@link gitAvailable} said yes, so a failure here is a broken repository,
  // and "no files" is a lie that reports every runner as absent. `collect()`
  // turns the throw into a per-provider error report; the cached path treats
  // it as a miss.
  // The CHECKED door: a non-zero exit raises `CommandFailed` with the argv and
  // the full result attached, which is what callers already catch.
  //
  // `-z` because without it git applies `core.quotePath`, wrapping any path
  // holding a space, a quote or a non-ASCII byte in escaped quotes — a
  // manifest under such a path would then be looked up by a name that does
  // not exist.
  const res = await runCheckedAsync(
    git,
    ['ls-files', '-z', '--cached', '--others', '--exclude-standard'],
    { cwd: root },
  )
  return res.stdout.split('\0').filter((f) => f !== '')
}

/**
 * An exclusion set split by how each entry has to be matched.
 *
 * Names and paths cannot share one lookup. A name is compared against every
 * segment of a candidate; a path is compared against its leading segments in
 * order. A single set tested one segment at a time can express the first and
 * silently ignores the second: no path segment is ever equal to `.moon/cache`,
 * so that entry of {@link DEFAULT_EXCLUDES} would exclude nothing.
 */
export interface ExcludeSet {
  /** Bare names, matched against any single path segment. */
  names: Set<string>
  /** Root-relative paths, matched as a segment prefix. Pre-split. */
  paths: string[][]
}

/**
 * Sort raw exclusion strings into the two kinds, dropping what a hand-written
 * config carries: surrounding whitespace, a leading `./`, and leading or
 * trailing slashes.
 *
 * `src/`, `/src` and `./src` all mean `src`. A setting whose effect depends on
 * which of those spellings someone reached for is a setting people get wrong
 * once and never trust again.
 */
export function normalizeExcludes(raw: readonly string[]): ExcludeSet {
  const names = new Set<string>()
  const paths: string[][] = []
  for (const entry of raw) {
    const segments = entry
      .trim()
      .split('/')
      .filter((segment) => segment !== '' && segment !== '.')
    if (segments.length === 0) continue
    if (segments.length === 1) names.add(segments[0] as string)
    else paths.push(segments)
  }
  return { names, paths }
}

/**
 * Whether a root-relative path is excluded.
 *
 * A name matches ANY segment — `node_modules` has to hit at every depth, which
 * is the only useful reading for a dependency tree. A path matches the LEADING
 * segments, so naming a directory takes the whole tree beneath it, and naming a
 * file takes that file.
 *
 * The prefix is compared segment by segment rather than as a string, so `src/app`
 * does not also take `src/application`. The one-line string test is a trap that
 * surfaces only on the repository that happens to have both.
 */
export function matchesExclude(path: string, excludes: ExcludeSet): boolean {
  const segments = path.split('/')
  if (segments.some((segment) => excludes.names.has(segment))) return true
  return excludes.paths.some(
    (prefix) => prefix.length <= segments.length && prefix.every((seg, i) => segments[i] === seg),
  )
}

/**
 * The walk prunes on BOTH kinds, rather than listing everything and filtering
 * after. An excluded directory is the expensive case — `node_modules` is most
 * of the files on the disk — and descending into one to throw its contents away
 * is the cost this walk exists to avoid.
 */
async function walkFiles(root: string, excludes: ExcludeSet): Promise<string[]> {
  const out: string[] = []
  async function walk(dir: string): Promise<void> {
    let entries
    try {
      entries = await readdir(dir, { withFileTypes: true })
    } catch {
      return
    }
    for (const entry of entries) {
      const full = join(dir, entry.name)
      const rel = relative(root, full).split(sep).join('/')
      if (matchesExclude(rel, excludes)) continue
      // Symlinks are not followed: a link into a parent directory turns the
      // walk into an infinite one, and a link out of the tree reports files
      // that are not this project's.
      if (entry.isSymbolicLink()) continue
      if (entry.isDirectory()) await walk(full)
      else if (entry.isFile()) out.push(rel)
    }
  }
  await walk(root)
  return out
}

/**
 * A file lister for one root, resolved once and memoized. The full list is
 * gathered on first use and filtered per pattern — one `git ls-files` beats one
 * per provider, and the walk is far more expensive than the filtering.
 */
export function createLister(
  root: string,
  mode: DiscoveryMode,
  git: AsyncCommandRunner,
  extraExcludes: string[] = [],
): (pattern: string) => Promise<string[]> {
  const excludes = normalizeExcludes([...DEFAULT_EXCLUDES, ...extraExcludes])
  let all: Promise<string[]> | null = null

  return async (pattern: string) => {
    // The exclusions are applied to BOTH strategies, not just the walk. `git
    // ls-files` already skips ignored paths, but filtering the walk's list
    // alone would exclude a `fixtures/` tree in a plain directory and not in a
    // repository, leaving the two modes disagreeing about which files exist.
    all ??= (mode === 'git' ? gitFiles(root, git) : walkFiles(root, excludes)).then((files) =>
      files.filter((f) => !matchesExclude(f, excludes)),
    )
    const files = await all
    // `*suffix` matches any path whose basename ends with `suffix`; anything
    // else matches a basename exactly. Deliberately not glob syntax — a
    // provider asking for "justfile" should never accidentally match
    // "myjustfile.bak", which a naive `*justfile` pattern would.
    if (pattern.startsWith('*')) {
      const suffix = pattern.slice(1)
      return files.filter((f) => basename(f).endsWith(suffix))
    }
    return files.filter((f) => basename(f) === pattern)
  }
}

function basename(p: string): string {
  const at = p.lastIndexOf('/')
  return at === -1 ? p : p.slice(at + 1)
}

/** True when a root-relative path exists on disk. */
export async function pathExists(root: string, relPath: string): Promise<boolean> {
  try {
    await stat(join(root, relPath))
    return true
  } catch {
    return false
  }
}
