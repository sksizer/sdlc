/**
 * Package-manager resolution — which manager a directory uses, and the verb
 * that runs one of its scripts.
 *
 * Two rules that are easy to get backwards:
 *
 *   1. `nodeManagerFor` walks UP to the nearest lockfile. A root-only lookup
 *      resolves every nested package in a workspace to the npm default, because
 *      the lockfile lives at the workspace root — `packages/ts/foo` in a bun
 *      repo would report `npm run build`.
 *   2. The `packageManager` manifest field wins over the lockfile when present.
 *      It is an explicit declaration (corepack reads it); a lockfile is a
 *      side effect.
 *
 * `resolveProjectManagers` returns the UNION of every ecosystem present, never
 * "one effective manager", because a repo with both `bun.lock` and `Cargo.toml`
 * genuinely uses both.
 */

import { dirname, join } from 'node:path'

/**
 * A node manager: its canonical kind, the verb that runs a script, and the
 * flag that points that verb at another directory.
 *
 * `dirFlag` is per-manager because the managers do NOT share one: `--cwd` is
 * bun's and yarn classic's, npm's is `--prefix` and pnpm's is `--dir`. Each
 * takes the directory as the next argument and goes between `runVerb` and the
 * script name. Verified by running each against a two-package fixture: npm 11
 * `npm run --prefix <dir> <script>`, pnpm 10 `pnpm run --dir <dir> <script>`,
 * bun 1.3 `bun run --cwd <dir> <script>`. yarn's is the documented classic
 * form `yarn --cwd <dir> <script>` (yarn 1 CLI docs); Berry dropped `--cwd` in
 * favour of `yarn workspace <name> run`, which this table cannot express
 * because a lockfile does not say which yarn wrote it.
 */
export interface NodeManager {
  kind: string
  runVerb: string[]
  dirFlag: string
}

/**
 * Ordered node lockfile → manager mapping, the single source of truth for
 * these literals. Precedence is first match: bun beats pnpm beats yarn beats
 * npm, for a repo that has drifted into holding more than one lockfile.
 */
export const NODE_LOCKFILE_MANAGERS: ReadonlyArray<{
  files: readonly string[]
  manager: NodeManager
}> = [
  {
    files: ['bun.lock', 'bun.lockb'],
    manager: { kind: 'bun', runVerb: ['bun', 'run'], dirFlag: '--cwd' },
  },
  {
    files: ['pnpm-lock.yaml', 'pnpm-workspace.yaml'],
    manager: { kind: 'pnpm', runVerb: ['pnpm', 'run'], dirFlag: '--dir' },
  },
  { files: ['yarn.lock'], manager: { kind: 'yarn', runVerb: ['yarn'], dirFlag: '--cwd' } },
  {
    files: ['package-lock.json'],
    manager: { kind: 'npm', runVerb: ['npm', 'run'], dirFlag: '--prefix' },
  },
]

/** The manager a `packageManager: "pnpm@9.0.0"` field names, if recognised. */
export function managerFromField(field: unknown): NodeManager | null {
  if (typeof field !== 'string') return null
  const name = field.trim().split('@')[0]?.toLowerCase()
  if (name === undefined || name === '') return null
  for (const { manager } of NODE_LOCKFILE_MANAGERS) {
    if (manager.kind === name) return manager
  }
  return null
}

/**
 * The node manager for a directory: the nearest `packageManager` field or
 * lockfile, searching from `dir` up to (and including) `root`.
 *
 * Returns `null` when nothing is found — the npm default for a bare
 * `package.json` is the caller's policy, not this function's.
 */
export function nodeManagerFor(
  root: string,
  dir: string,
  has: (absPath: string) => boolean,
  readPackageManagerField: (absPath: string) => unknown,
): NodeManager | null {
  let current = dir
  for (;;) {
    const field = managerFromField(readPackageManagerField(join(current, 'package.json')))
    if (field !== null) return field
    for (const { files, manager } of NODE_LOCKFILE_MANAGERS) {
      if (files.some((f) => has(join(current, f)))) return manager
    }
    if (current === root) return null
    const parent = dirname(current)
    // Defensive: a `dir` outside `root` would otherwise walk to the filesystem
    // root. Stop when the parent stops changing.
    if (parent === current) return null
    current = parent
  }
}

/**
 * Marker → manager, spanning node (reusing the lockfile literals above), Rust,
 * Python and Go. Extensible by one row.
 */
export const MARKER_TABLE: ReadonlyArray<{ marker: string; manager: string }> = [
  ...NODE_LOCKFILE_MANAGERS.flatMap(({ files, manager }) =>
    files.map((marker) => ({ marker, manager: manager.kind })),
  ),
  { marker: 'Cargo.toml', manager: 'cargo' },
  { marker: 'uv.lock', manager: 'uv' },
  { marker: 'poetry.lock', manager: 'poetry' },
  { marker: 'requirements.txt', manager: 'pip' },
  { marker: 'go.mod', manager: 'go' },
]

/**
 * Leading-token → canonical manager, for reading a declared command back into
 * the manager that runs it. Unrecognised leading tokens (`just`, `make`,
 * `tsc`, `mise`, `node`, `npx`) contribute nothing.
 */
export const VERB_TOKEN_MANAGERS: Readonly<Record<string, string>> = {
  bun: 'bun',
  bunx: 'bun',
  npm: 'npm',
  pnpm: 'pnpm',
  yarn: 'yarn',
  cargo: 'cargo',
  uv: 'uv',
  uvx: 'uv',
  poetry: 'poetry',
  pip: 'pip',
  pip3: 'pip',
  go: 'go',
}

/**
 * Every package manager a project uses: the union of every `MARKER_TABLE`
 * marker present at `projectRoot`, plus the leading-token manager of each
 * declared verb.
 *
 * Pure — the caller supplies the existence check, so this is testable without
 * a filesystem and callable from an async context without becoming async.
 */
export function resolveProjectManagers(
  projectRoot: string,
  declaredVerbs: string[],
  has: (absPath: string) => boolean,
): Set<string> {
  const resolved = new Set<string>()

  for (const { marker, manager } of MARKER_TABLE) {
    if (has(join(projectRoot, marker))) resolved.add(manager)
  }

  for (const verb of declaredVerbs) {
    const token = verb.trim().split(/\s+/)[0]
    if (token === undefined || token === '') continue
    const manager = VERB_TOKEN_MANAGERS[token]
    if (manager !== undefined) resolved.add(manager)
  }

  return resolved
}
