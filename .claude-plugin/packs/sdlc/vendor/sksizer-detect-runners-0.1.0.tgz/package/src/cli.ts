/**
 * `detect-runners` — the data tool.
 *
 * Deliberately not interactive: this is what you pipe, what CI calls, and what
 * proves the library works with no UI in the way. Anything that wants to draw
 * something reads `--json`.
 *
 * Execution is opt-in (`--exec`) rather than on by default, because pointing
 * this at a repository you did not write should not run that repository's
 * toolchain configuration. `waypost`, the interactive tool built on top, is
 * willing in principle — its own default is `allowExec: true` — because you
 * reach for a task browser standing in your own repo. Neither default is the
 * gate: per-repository TRUST is, and both tools resolve it the same way through
 * `@sksizer/sdlc-tool`'s `policyExecGate` — the marker store
 * (`@sksizer/cli-tool/trust`) layered with the user file's `trust.paths`/
 * `trust.owners` policy — so willingness only becomes execution once a
 * person, or a policy they configured, has said yes to this repository.
 *
 * Flags are declared to `@sksizer/cli-tool`'s `defineCli`, so `--help` renders
 * from the same declaration the parser reads, per
 * [[S-0015-standalone-cli-shape]].
 */

import { resolve } from 'node:path'

import { homedir } from 'node:os'

import { cacheDir } from './cache.ts'
import { collectAndCache, readCachedCatalog, type RunnerCacheState } from './cached.ts'
import { humanAge, humanMs } from './duration.ts'
import { selectProviders } from './collect.ts'
import { runGuideCommand, type GuideTool } from './guide.ts'
import {
  collectOptionsFromConfig,
  ConfigError,
  expandTrustPath,
  loadConfig,
  trustPolicyFromConfig,
  TRUST_STORE_TOOL,
} from './config.ts'
import { orderedCatalog, runConfigCommand, takeConfigDir } from './config-command.ts'
import type { CollectOptions, RunnerProvider } from './contract.ts'
import { EXIT, defineCli, processIo, type CliIo } from '@sksizer/cli-tool'
import { trustStore, withheldHint } from '@sksizer/cli-tool/trust'
import { policyExecGate } from '@sksizer/sdlc-tool/trust'
import { diagnostics, tasks, type Catalog, type Diagnostic, type Task } from './model.ts'
import { findRoot } from './root.ts'
import { runCleanCommand } from './clean-command.ts'
import { runTrustCommand } from './trust-command.ts'

/**
 * Help text below the flag list. Kept out of the per-flag help because it
 * explains the tool, not any one option.
 */
const PROSE = `Runners are found by their marker files; "detect-runners guide usage" names the
built-ins. A runner that can only be read by running it is reported absent, with
a diagnostic saying so.

Collecting those runners needs BOTH halves, and detect-runners has neither by
default. Execution must be enabled — --exec for one run, or allowExec: true in
the user file "detect-runners config path" names — AND this repository must be
trusted, which "detect-runners trust" records once, per repository. Trust on its
own collects nothing here; that is the deliberate difference from waypost, whose
own default supplies the first half. A repository cannot trust itself: allowExec
in waypost.config.json cannot raise the gate.

Defaults come from waypost.config.json in the project root and from the user file
"detect-runners config path" names; a flag given here beats both. --exclude
REPLACES the configured runners.disabled rather than adding to it, matching the
merge rule that an array answers "which ones" wholesale.

Every run re-probes, so what you read is what the repository currently has; it
also stores each probe, so an interactive surface can start instantly. --cached
inverts that for one run: it answers from the store, names on stderr which
runners are stale and how old they are, and adds a "cache" array to --json.
Runners the store has nothing for are still probed — a gap in the cache is not
a reason to show less.`

/**
 * `--output` is the format flag; `--json`, `--list` and `--table` are aliases
 * for its three values and mean nothing else.
 */
const cli = defineCli({
  name: 'detect-runners',
  summary: 'Find every task a repository can run.',
  flags: {
    output: {
      kind: 'enum',
      choices: ['list', 'json', 'table'] as const,
      valueName: 'form',
      help: 'list (one command per line, for piping), json (the whole catalog, with diagnostics and evidence), or table (aligned, for reading). Default: list',
    },
    json: { kind: 'boolean', help: 'alias for --output json' },
    list: { kind: 'boolean', help: 'alias for --output list' },
    table: { kind: 'boolean', help: 'alias for --output table' },
    cached: {
      kind: 'boolean',
      help: 'answer from the last stored probe instead of re-probing',
    },
    exec: {
      kind: 'tristate',
      help: 'allow providers that must run a subprocess (moon), this run only',
      offHelp: 'forbid them, overriding a configured allowExec: true',
    },
    only: { kind: 'list', valueName: 'a,b', help: 'restrict to these runners' },
    exclude: {
      kind: 'list',
      valueName: 'a,b',
      help: 'skip these runners, REPLACING the configured runners.disabled',
    },
    excludePath: {
      kind: 'list',
      valueName: 'P',
      commaSeparated: false,
      help: 'skip a path; repeatable. A bare name matches any segment, a value with a slash matches a path from the root',
    },
    declared: {
      kind: 'boolean',
      help: 'only tasks a config file declares, dropping synthesized ones',
    },
    discovery: {
      kind: 'enum',
      choices: ['git', 'walk', 'auto'] as const,
      valueName: 'M',
      help: 'how to find directories. Default: auto',
    },
    config: {
      kind: 'string',
      valueName: 'PATH',
      help: 'a module exporting { providers } to merge with the built-ins',
    },
    dir: {
      kind: 'string',
      short: 'C',
      valueName: 'PATH',
      help: 'the directory to inspect (default: cwd)',
    },
  },
  positionals: [{ name: 'dir', help: 'the directory to inspect' }],
  epilogue: `subcommands
  config   read and write the layered settings file; see config --help
  trust    record that this repository may be read by running it; see trust --help
  guide    how to use and extend this tool, in Markdown; see guide --help
  clean    remove the data this tool stores outside your repositories; see clean --help

${PROSE}`,
})

const USAGE = cli.help()

/**
 * What the `guide` command needs to know about this tool.
 *
 * `usage` is the same {@link USAGE} string `--help` prints, handed over rather
 * than restated, so the guide's flag list cannot drift from the help text.
 * Exported because `tests/guide.test.ts` cross-checks the rendered guide
 * against this parser's accepted flags.
 */
export const GUIDE_TOOL: GuideTool = { name: 'detect-runners', usage: USAGE }

/**
 * What to say when runners were withheld because execution is not enabled.
 *
 * Separate from `withheldHint` (`@sksizer/cli-tool/trust`), which names trust, because this tool
 * reaches this state first: its configured `allowExec` is `false` by default, so
 * a user told to trust the repository would trust it and see the same silence.
 * Trust is named as the second half rather than the remedy.
 */
const EXEC_OFF_HINT =
  'execution is not enabled — pass --exec for this run, or set allowExec in the user file "detect-runners config path" names; the repository must also be trusted'

/**
 * The optional fields are absent unless their flag was given. A default here
 * would overwrite the configuration file on every run, since the flag would
 * always be "present"; absence is what lets the config layer answer instead.
 */
interface Flags {
  format: 'json' | 'list' | 'table'
  dir: string
  cached: boolean
  allowExec?: boolean
  declaredOnly: boolean
  only?: string[]
  exclude?: string[]
  /**
   * Absent when never passed, which is what lets the config layer answer;
   * passing any at all replaces the configured list, matching how every other
   * array setting merges.
   */
  excludePaths?: string[]
  discovery?: 'git' | 'walk' | 'auto'
  config?: string
}

/**
 * Resolve the declared flags into the shape the rest of this file reads.
 *
 * The format is resolved here: `--output` wins when given, otherwise
 * the first alias that is set, otherwise `list`. Precedence is fixed rather
 * than last-wins, because two aliases on one command line is a mistake worth
 * resolving the same way every time.
 */
export function parseArgs(
  argv: readonly string[],
  io: CliIo,
  cwd: string = process.cwd(),
): Flags | { error: string } | { help: true } {
  const parsed = cli.parse(argv, io)
  if (parsed.status === 'help') return { help: true }
  if (parsed.status === 'error') return { error: parsed.message }

  const v = parsed.values
  const format: Flags['format'] =
    v.output ?? (v.json ? 'json' : v.table ? 'table' : v.list ? 'list' : 'list')

  const flags: Flags = {
    format,
    // A positional directory beats -C.
    dir: parsed.positionals[0] ?? v.dir ?? cwd,
    cached: v.cached,
    declaredOnly: v.declared,
  }
  if (v.exec !== undefined) flags.allowExec = v.exec
  if (v.only !== undefined) flags.only = v.only.filter(Boolean)
  if (v.exclude !== undefined) flags.exclude = v.exclude.filter(Boolean)
  if (v.excludePath !== undefined) flags.excludePaths = v.excludePath
  if (v.discovery !== undefined) flags.discovery = v.discovery
  if (v.config !== undefined) flags.config = v.config
  return flags
}

/** Load `{ providers }` from a `--config` module and merge it with the built-ins. */
async function loadProviderModule(path: string): Promise<RunnerProvider[]> {
  const mod = (await import(resolve(path))) as {
    default?: { providers?: RunnerProvider[] }
    providers?: RunnerProvider[]
  }
  const providers = mod.providers ?? mod.default?.providers
  if (!Array.isArray(providers)) {
    throw new Error(`${path} must export \`providers\` (an array), or a default with one`)
  }
  return providers
}

function selected(catalog: Catalog, declaredOnly: boolean): Task[] {
  const all = tasks(catalog)
  return declaredOnly ? all.filter((t) => t.origin === 'declared') : all
}

/**
 * A runner that IS configured (its marker is here, `status: "ok"`) but whose
 * declared binary is missing from PATH — the pairing worth a warning. A
 * runner that is simply absent stays silent: `tool.found === false` alone is
 * true of every non-project directory and would nag on all of them.
 */
export function missingToolDiagnostics(catalog: Catalog): Array<Diagnostic & { runner: string }> {
  return catalog.reports
    .filter((r) => r.status === 'ok' && r.tool !== undefined && !r.tool.found)
    .map((r) => ({
      severity: 'warning' as const,
      runner: r.runner,
      message: `${r.runner} is configured here but its binary ("${r.tool!.binary}") is not on the PATH`,
    }))
}

function renderTable(list: Task[]): string {
  const width = Math.min(
    60,
    list.reduce((n, t) => Math.max(n, t.path.join(' › ').length), 0),
  )
  return list.map((t) => `${t.path.join(' › ').padEnd(width)}  ${t.display}`).join('\n')
}

/**
 * One runner's staleness, with the refresh cost where this repo has measured
 * one — and saying so where it has not. An unmeasured cost is not zero, and
 * inventing a number would be worse than the silence it replaced.
 */
function stalePart(row: RunnerCacheState): string {
  const cost =
    row.estimateMs === null
      ? 'refresh cost not measured here yet'
      : `refresh usually about ${humanMs(row.estimateMs)}`
  return `${row.runner} (${humanAge(row.ageMs)}, ${cost})`
}

/**
 * The single stderr line `--cached` prints, or null when there is nothing to
 * say. One line for every runner rather than one line each: the reader is
 * scanning a pipe's stderr, and the action — drop the flag — is the same for
 * all of them.
 */
export function cacheNote(tool: string, rows: readonly RunnerCacheState[]): string | null {
  const stale = rows.filter((r) => r.state === 'stale')
  const missed = rows.filter((r) => r.state === 'miss')
  if (stale.length === 0 && missed.length === 0) return null
  const parts: string[] = []
  if (stale.length > 0) parts.push(`stale: ${stale.map(stalePart).join(', ')}`)
  // Named too, because these rows did NOT come out of the store: this run paid
  // for them, and a reader comparing timings deserves to know which.
  if (missed.length > 0)
    parts.push(`not cached, probed now: ${missed.map((r) => r.runner).join(', ')}`)
  return `${tool}: --cached: ${parts.join('; ')}\n`
}

/**
 * The cache verdict for a catalog that was just probed for real: every selected
 * runner is fresh, because it was measured this instant. Ages and estimates are
 * absent for the same reason — there is no cached answer being described.
 */
export function freshStates(options: CollectOptions): RunnerCacheState[] {
  return selectProviders(options).map((p) => ({
    runner: p.id,
    state: 'fresh' as const,
    estimateMs: null,
    slow: false,
  }))
}

/**
 * `env` and `home` are injectable for the same reason `loadConfig` takes them:
 * an integration test that let them default would read the developer's own
 * `~/.config/waypost/config.json` and pass or fail according to what is in it.
 * Nothing but a test ever passes them.
 */
export async function main(
  argv: string[],
  env: Record<string, string | undefined> = process.env,
  home: string = homedir(),
  // Only a test passes anything else — a capturing `CliIo`, per `captureIo`.
  io: CliIo = processIo,
): Promise<number> {
  // `config` is claimed before the flag parse, because its own arguments are
  // not this parser's flags — `config set --user` would otherwise be rejected.
  if (argv[0] === 'config') {
    // -C is documented as a global flag, so it has to work here too: pointing
    // the tool at another directory must show THAT directory's configuration.
    const taken = takeConfigDir(argv.slice(1))
    if ('error' in taken) {
      io.stderr(`detect-runners: ${taken.error}\n\n${USAGE}`)
      return EXIT.usage
    }
    const root = await findRoot(taken.dir ?? process.cwd())
    return runConfigCommand('detect-runners', root, taken.rest, { ...io, env, home })
  }

  // `trust` is claimed the same way and for the same reason: --untrust, --show
  // and --list are its arguments, not this parser's flags.
  if (argv[0] === 'trust') {
    // -C works here too: trusting another directory must key the grant on THAT
    // directory's root.
    const taken = takeConfigDir(argv.slice(1))
    if ('error' in taken) {
      io.stderr(`detect-runners: ${taken.error}\n\n${USAGE}`)
      return EXIT.usage
    }
    const root = await findRoot(taken.dir ?? process.cwd())
    return runTrustCommand('detect-runners', root, taken.rest, { ...io, env, home })
  }

  // `clean` needs no root and no config layers: every path it touches is
  // resolved from the environment and the home directory, never from where the
  // command was run. -C would be meaningless here, so it is not accepted.
  if (argv[0] === 'clean') {
    return runCleanCommand('detect-runners', argv.slice(1), { ...io, env, home })
  }

  // `guide` is claimed the same way: its argument is a topic name, not a flag,
  // and it needs neither a root nor the config layers to answer.
  if (argv[0] === 'guide') {
    return runGuideCommand(GUIDE_TOOL, argv.slice(1), io)
  }

  const parsed = parseArgs(argv, io)
  // `--help` has already been written by the parser.
  if ('help' in parsed) return EXIT.ok
  if ('error' in parsed) {
    io.stderr(`detect-runners: ${parsed.error}\n\n${USAGE}`)
    return EXIT.usage
  }

  const root = await findRoot(parsed.dir)

  let cfg
  try {
    cfg = await loadConfig(root, env, home, 'detect-runners')
  } catch (err) {
    if (err instanceof ConfigError) {
      io.stderr(`detect-runners: ${err.message}\n`)
      return EXIT.error
    }
    throw err
  }
  for (const warning of cfg.warnings) io.stderr(`warning: ${warning}\n`)

  // The trust seam. `collect()` stays trust-agnostic and never reads the store,
  // so a programmatic consumer passing `allowExec: false` is never affected by a
  // trust decision it did not ask about. Resolving trust belongs here, in a CLI
  // that knows it is acting for a human who can be asked.
  //
  // The literal tool name 'waypost', not 'detect-runners' — the marker store
  // is shared between both CLIs; see `trust-command.ts`'s module docblock.
  const trustStoreInstance = trustStore({ tool: TRUST_STORE_TOOL, env, home })
  const gate = await policyExecGate(
    trustStoreInstance,
    trustPolicyFromConfig(cfg.effective),
    { root, configured: cfg.effective.allowExec ?? false, flag: parsed.allowExec },
    { expandPath: (raw) => expandTrustPath(raw, home) },
  )

  // Config first, flags second, so a flag that was not given leaves the file's
  // answer standing. --exclude REPLACES runners.disabled, matching the merge
  // rule that an array answers "which ones" wholesale.
  const options: CollectOptions = {
    ...collectOptionsFromConfig(cfg.effective),
    allowExec: gate.allowExec,
    // Only when trust is what is missing. When execution is off because a file
    // said so, telling the user to trust the repository would be a wrong
    // instruction — trusting it would change nothing.
    ...(gate.reason === 'untrusted' ? { execWithheldHint: withheldHint('detect-runners') } : {}),
    ...(parsed.discovery !== undefined ? { discovery: parsed.discovery } : {}),
    ...(parsed.only ? { only: parsed.only } : {}),
    ...(parsed.exclude ? { exclude: parsed.exclude } : {}),
    ...(parsed.excludePaths ? { excludePaths: parsed.excludePaths } : {}),
  }

  if (parsed.config !== undefined) {
    try {
      const { builtinProviders } = await import('./providers/index.ts')
      options.providers = [...builtinProviders, ...(await loadProviderModule(parsed.config))]
    } catch (err) {
      io.stderr(`detect-runners: ${err instanceof Error ? err.message : String(err)}\n`)
      return EXIT.error
    }
  }

  // The store lives under the INJECTED env and home, exactly as `loadConfig`
  // and the trust store do — a test that let these default would read and write
  // the developer's own `~/.cache/waypost`.
  const store = cacheDir(env, home)

  // Fresh by default. This is the data surface: a script or an agent reading it
  // must get what the repository has right now unless it says otherwise. The
  // default path still WRITES the store, so an interactive surface started
  // afterwards has something to paint instantly.
  let cache: RunnerCacheState[] | undefined
  let collected: Catalog
  if (!parsed.cached) {
    collected = await collectAndCache(root, options, store)
  } else {
    const stored = await readCachedCatalog(root, options, store)
    // "Cold" means nothing came out of the STORE, which is not the same as a
    // null catalog: a run with execution off already carries a withheld report
    // per exec provider, so the catalog is non-null before a single entry has
    // ever been written. An age is what only a stored entry has.
    const fromStore = stored.runners.some((r) => r.ageMs !== undefined)
    if (stored.catalog === null || !fromStore) {
      // Not an error. --cached asks for the cheap answer; when there is no
      // cheap answer the expensive one is still the right thing to return, and
      // saying so on stderr is what keeps that honest.
      io.stderr(
        'detect-runners: --cached: nothing cached for this repository yet — probed it fresh, and this run stores the result\n',
      )
      collected = await collectAndCache(root, options, store)
      cache = freshStates(options)
    } else {
      const missing = stored.runners.filter((r) => r.state === 'miss').map((r) => r.runner)
      // A miss is a gap in the cache, not a reason to show nothing: the missing
      // providers alone are probed and merged in. `orderedCatalog` below puts
      // the merged reports back into configured order.
      collected =
        missing.length === 0
          ? stored.catalog
          : {
              ...stored.catalog,
              reports: [
                ...stored.catalog.reports,
                ...(await collectAndCache(root, { ...options, only: missing }, store)).reports,
              ],
            }
      cache = stored.runners
      // stderr, never stdout: --list stays pipeable and --json stays parseable.
      const note = cacheNote('detect-runners', stored.runners)
      if (note !== null) io.stderr(note)
    }
  }
  const catalog = orderedCatalog(collected, cfg.effective.runners?.order)

  if (parsed.format === 'json') {
    // `cache` rides alongside the catalog only under --cached. A freshly probed
    // catalog has no staleness to describe, and a key that is always there but
    // always says "fresh" teaches a consumer to ignore it.
    io.stdout(`${JSON.stringify(cache === undefined ? catalog : { ...catalog, cache }, null, 2)}\n`)
  } else {
    const list = selected(catalog, parsed.declaredOnly)
    if (list.length > 0) {
      io.stdout(
        `${parsed.format === 'table' ? renderTable(list) : list.map((t) => t.display).join('\n')}\n`,
      )
    }
    // Diagnostics go to stderr so `--list` stays pipeable.
    for (const d of [...diagnostics(catalog), ...missingToolDiagnostics(catalog)]) {
      if (d.severity === 'info') continue
      io.stderr(`${d.severity}: ${d.runner}: ${d.message}\n`)
    }
    // Said once, not once per runner: the answer is the same for all of them,
    // and the action is one command. --json carries a diagnostic inside each
    // withheld report instead, so it is not repeated there.
    //
    // Printed for EVERY reason, not just `untrusted`. detect-runners' own
    // default leaves execution off, so `untrusted` is the reason a user rarely
    // reaches; staying silent on the common one would leave --list and --table
    // withholding runners without a word, the per-report diagnostic being
    // severity "info" and filtered above.
    const withheld = catalog.reports.filter((r) => r.skippedForExec).length
    if (withheld > 0) {
      const remedy =
        gate.reason === 'untrusted'
          ? withheldHint('detect-runners')
          : parsed.allowExec === false
            ? '--no-exec was given, which forbids them however trusted this repository is'
            : EXEC_OFF_HINT
      io.stderr(
        `detect-runners: ${withheld} runner${withheld === 1 ? '' : 's'} not collected — ${remedy}\n`,
      )
    }
  }

  // Non-zero only when a runner was present and failed — "nothing here" is not
  // an error, or every non-project directory would look broken.
  return catalog.reports.some((r) => r.status === 'error') ? 1 : 0
}

// Runs when executed directly (`bun run cli.ts`), stays inert when imported —
// the published `bin/` shim imports `main` and calls it itself, and the tests
// import `parseArgs` without wanting a process to start.
if (import.meta.main) {
  process.exitCode = await main(process.argv.slice(2))
}
