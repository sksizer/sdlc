/**
 * The `guide` subcommand, shared by both CLIs.
 *
 * What it is for: a person — or a model — who has the binary and not the
 * README. `--help` answers "what are the flags"; this answers "how do I use
 * this, what will `--json` hand me, why is a runner missing, and how do I add
 * one". It prints Markdown on stdout through the `CliIo` seam, so it pipes
 * into a file, a pager, or an agent's context.
 *
 * Sections are DATA, not one blob. `waypost` wraps the same sections with its own
 * usage text, and `tests/guide.test.ts` cross-checks each section against the
 * code it describes — neither is possible if the guide is a single string.
 *
 * NOTHING here hardcodes a roster. The built-in runners come from
 * `builtinProviders` and the settable keys from `CONFIG_KEYS`, because a list
 * retyped into prose is a list that is wrong the day after the next provider
 * lands.
 */

import { CONFIG_KEYS } from './config.ts'
import { EXIT, type CliIo } from '@sksizer/cli-tool'
import { builtinProviders } from './providers/index.ts'

/** One section of the guide. The document is these, in this order. */
export type GuideTopic = 'usage' | 'config' | 'json' | 'trust' | 'extend'

export const GUIDE_TOPICS: readonly GuideTopic[] = ['usage', 'config', 'json', 'trust', 'extend']

/**
 * What differs between the two CLIs the guide runs under.
 *
 * `usage` is the SAME string the tool's `--help` prints, passed in rather than
 * restated, so the guide's flag list and the help text cannot drift.
 * `extraUsage` covers surface one tool has and the other does not.
 */
export interface GuideTool {
  name: 'detect-runners' | 'waypost'
  usage: string
  extraUsage?: string | undefined
}

function isGuideTopic(value: string): value is GuideTopic {
  return (GUIDE_TOPICS as readonly string[]).includes(value)
}

const code = '```'

/** `id`s of the built-in providers, formatted as an inline list. */
function runnerRoster(): string {
  return builtinProviders.map((p) => `\`${p.id}\``).join(', ')
}

/** `id`s of the built-ins that must shell out to be read. */
function execRoster(): string {
  const ids = builtinProviders.filter((p) => p.kind === 'exec').map((p) => `\`${p.id}\``)
  return ids.length > 0 ? ids.join(', ') : '(none)'
}

function configKeyList(): string {
  return CONFIG_KEYS.map((k) => `\`${k}\``).join(', ')
}

/**
 * The provider example, as a string.
 *
 * It is kept in TWO places on purpose. `tests/guide-example.ts` holds the same
 * code as a real module, inside the package `tsconfig.json`, so the root
 * `tsc --noEmit` typechecks it for real; `tests/guide.test.ts` then asserts the
 * two are identical. An example that only ever exists inside a string is an
 * example nothing proves still compiles.
 *
 * The ONLY permitted difference is the import line: a consumer writes the
 * package name, and the in-repo copy cannot — the package does not self-link
 * under its own name.
 */
export const EXTEND_EXAMPLE = `import type { ProviderContext, RunnerProvider } from '@sksizer/detect-runners'

export const acmeProvider: RunnerProvider = {
  id: 'acme',
  kind: 'parse',
  binary: 'acme',
  chain: [{ label: 'task', hint: 'the acme task to run' }],

  async collect(ctx: ProviderContext) {
    // Discovery goes through ctx, never through node:fs.
    const [marker] = await ctx.files('acme.json')
    if (marker === undefined || !(await ctx.exists(marker))) {
      // Not an error, and not a separate lifecycle phase. Bail cheaply.
      return { status: 'absent', tasks: [], diagnostics: [] }
    }

    return {
      status: 'ok',
      aspect: { id: 'acme', evidence: [{ kind: 'files', detail: marker }] },
      tasks: [
        {
          id: 'acme:build',
          runner: 'acme',
          path: ['acme', 'build'],
          argv: ['acme', 'run', 'build'],
          cwd: '.',
          display: 'acme run build',
          parameters: [],
          source: marker,
          origin: 'declared',
          tags: [],
          persistent: { value: false, declared: false },
          executes: 'local',
        },
      ],
      diagnostics: [],
    }
  },
}
`

const JSON_EXAMPLE = `{
  "root": "/home/you/repo",
  "generatedAt": "2026-01-01T00:00:00.000Z",
  "discovery": "git",
  "allowExec": false,
  "reports": [
    {
      "runner": "just",
      "status": "ok",
      "chain": [{ "label": "recipe", "hint": "the recipe to run" }],
      "aspect": { "id": "just", "evidence": [{ "kind": "files", "detail": "justfile" }] },
      "tasks": [
        {
          "id": "just:build",
          "runner": "just",
          "path": ["just", "build"],
          "argv": ["just", "build"],
          "cwd": ".",
          "display": "just build <target>",
          "parameters": [{ "name": "target", "required": true, "variadic": false }],
          "source": "justfile",
          "origin": "declared",
          "doc": "build one crate",
          "tags": [],
          "persistent": { "value": false, "declared": false },
          "executes": "local"
        }
      ],
      "diagnostics": [],
      "tool": { "binary": "just", "found": true, "path": "/usr/bin/just" },
      "skippedForExec": false
    }
  ]
}`

function usageSection(tool: GuideTool): string {
  const extra = tool.extraUsage === undefined ? '' : `\n${tool.extraUsage.trim()}\n`
  return `## usage

\`${tool.name}\` inventories every task this repository can run.

Point it at a directory; the directory is resolved upward to the project root,
so running from a subdirectory still inspects the whole repository.

${code}text
${tool.usage.trim()}
${code}
${extra}
Built-in runners: ${runnerRoster()}.

Subcommands: \`config\` reads and writes the layered settings, \`trust\` records
that this repository may be read by running it, \`clean\` removes the data this
tool stores outside your repositories, \`guide\` prints this document.
Each takes \`--help\`. They are claimed before the flag parse, so their own
arguments are not read as this tool's flags.
`
}

function configSection(tool: GuideTool): string {
  const ownDefaults =
    tool.name === 'waypost'
      ? "waypost's own defaults: `allowExec: true` — willing in principle, still gated on trust."
      : "detect-runners adds no defaults of its own, so the library's `allowExec: false` stands."
  return `## config

Layers, lowest precedence first:

1. The library's built-in defaults.
2. The calling tool's own defaults. detect-runners adds none; waypost adds
   allowExec true.
3. The user file.
4. The project file.
5. Flags on this command line.

${ownDefaults}

Files. The project file is \`waypost.config.json\` at the project root — the root
this tool resolved, not the working directory. The user file is
\`$XDG_CONFIG_HOME/waypost/config.json\`, or \`~/.config/waypost/config.json\` when
that variable is unset. Both tools read the same two files under the same
names.

\`WAYPOST_CONFIG\` replaces the USER file's location and nothing else. It does not
move the project file and it does not add a layer. A path in it may start with
a tilde, which is expanded, and a relative path resolves against the project
root rather than the working directory.

Settable keys: ${configKeyList()}.

Merging. Objects merge key by key. An ARRAY answers "which ones" wholesale, so
a later layer replaces it rather than appending to it. The consequence worth
knowing: \`--exclude\` REPLACES \`runners.disabled\`; it does not add to it, and
\`--exclude-path\` likewise replaces \`excludePaths\`.

Two settings turn things off and they are not the same one. \`runners.disabled\`
turns a RUNNER off: it is never probed anywhere in this project. \`excludePaths\`
leaves every runner on and narrows WHERE they look, which is what a repository
wants for a tree that holds real manifests belonging to nobody — a test-fixture
repo, a vendored sample. Those manifests are found correctly and reported
correctly; they are simply not tasks anyone can run.

An exclusion is a bare name or a path. A bare name matches any path segment at
any depth, so \`node_modules\` hits everywhere. A value containing a slash
matches from the root and takes the tree beneath it, so
\`crates/mg/tests/mini-repo\` excludes that fixture without also excluding every
directory in the repository that happens to be named \`tests/\`. Not glob syntax:
the built-in list already covers build output and dependency trees, and this is
for naming one tree of your own.

Exit codes. 2 means the command cannot be run as typed — an unknown
subcommand, a wrong argument count, an unknown setting name, a value of the
wrong type. Every one of those is decided from the argument list and the static
schema alone, so re-running it can only produce the same answer. 1 means a
well-formed command that failed against the state: a file that will not parse,
a key that is not set where you asked to unset it, a lookup that found nothing.
2 means fix the command; 1 means look at the state.

The allowExec exception. A project file may LOWER \`allowExec\` to false, never
raise it, because \`waypost.config.json\` lives inside the repository being
scanned, and a setting a repository can write is a setting a repository can
grant itself. A project file's \`allowExec: true\` is dropped before the merge
and reported as a warning, so it is never silently believed. A project file's
\`allowExec: false\` is honoured like any other setting.

The effective gate is not the configured value alone. \`--no-exec\` forbids
execution whatever is configured; \`--exec\` allows it for that one run, again
whatever is configured; with neither flag, execution needs both a configured
\`allowExec\` of true and a trusted repository.
`
}

function jsonSection(): string {
  return `## json

The catalog is one JSON document. Field by field:

\`Catalog\`
- \`root\` — absolute path the collection ran against. Every \`cwd\` and
  \`source\` below is relative to it.
- \`generatedAt\` — ISO timestamp of this collection.
- \`discovery\` — "git" or "walk", how file discovery actually resolved.
  Recorded because it changes which files are found.
- \`allowExec\` — whether providers were permitted to run subprocesses.
- \`reports\` — one entry per runner, in configured order.

\`Task\`
- \`id\` — stable across a re-collect, so a UI can keep its selection and a
  caller can hold a reference rather than an index.
- \`runner\` — the owning runner's id.
- \`path\` — display and search chain, root-first, with \`runner\` at index 0.
- \`argv\` — EXECUTABLE. Spawn it directly. Never through a shell, and never
  after re-joining it into a string. It carries no parameter placeholders.
- \`display\` — for showing and copying. It may carry \`<required>\`,
  \`[optional]\` and \`*variadic\` markers, so it is NOT executable. Never build
  one of these two fields from the other.
- \`cwd\` — directory the command expects, relative to the root ("." = root).
- \`parameters\` — each \`{ name, required, variadic, default? }\`.
- \`source\` — the file that declares the task, relative to the root.
- \`origin\` — "declared" means written in a config file; "synthesized" means
  invented from a convention, the way \`cargo clippy\` is what you run when a
  Cargo.toml exists rather than something anyone wrote down. Filter on this for
  "what did this repository actually define".
- \`doc\` — summary where the runner supplies one. Absent otherwise.
- \`detail\` — what the task actually executes, when that differs from
  \`display\`.
- \`tags\` — free-text facets for search and filtering.
- \`persistent\` — \`{ value, declared }\`. \`declared\` separates the runner
  stating it from this package guessing from the task name, so a consumer may
  choose to trust only the former.
- \`executes\` — "local", "remote" or "container": what running the task does.
  This is INDEPENDENT of a provider's \`kind\`, which is only what this package
  had to do to find the task. Every built-in produces "local" today; do not
  assume that stays true.

\`RunnerReport\`
- \`runner\` — the runner id.
- \`status\` — "absent", "ok" or "error".
- \`chain\` — one \`{ label, hint }\` per position of \`Task.path\`.
- \`aspect\` — the claim that this directory uses this runner, plus the
  evidence for it.
- \`tasks\` — the tasks found.
- \`diagnostics\` — each \`{ severity, message, source? }\` with severity
  "info", "warning" or "error".
- \`brand\` — optional visual identity. On the report, not on each task.
- \`tool\` — \`{ binary, found, path? }\`, filled by the collector via its PATH
  lookup and never by the provider, so a provider cannot misreport its own
  presence. Absent entirely when the provider declares no binary.
- \`skippedForExec\` — true when the provider was withheld because it needed to
  shell out.

\`cache\` — present only when \`--cached\` was passed, and over HTTP always. One
entry per selected runner, describing where that runner's rows came from:
- \`runner\` — the runner id.
- \`state\` — "fresh" (the stored answer still holds), "stale" (it was used and
  is out of date), or "miss" (nothing was stored, so this runner was probed for
  real and its rows are current).
- \`reason\` — "changed", "max-age" or "excludes", on a stale row only.
  "changed" means the files the probe read have moved since; "max-age" means an
  exec provider's entry outlived the window a fingerprint cannot vouch for;
  "excludes" means the exclusion set moved, which no amount of hashing the
  repository would notice because the setting lives outside it.
- \`ageMs\` — how old the stored answer is. Absent on a miss, which has no age.
- \`estimateMs\` — the median cost of re-probing this runner, from THIS repo's
  own measurements, or null when it has never been measured. Null is not zero:
  a consumer must not print a cost it does not have.
- \`slow\` — true when those measurements say this runner is slow to probe here.
  Measured, never declared, so a runner that is fast in your repository is not
  labelled slow because it is slow in someone else's.

A cached \`generatedAt\` is the OLDEST contributing probe time, not the moment
the answer was assembled: a catalog is only as fresh as its stalest row.

One extra field exists only over HTTP: \`waypost --serve\` adds \`trustable\` (a
boolean) to its catalog response — the server's own reading of the gate it
resolved. The CLI JSON does not carry it.

Trimmed example:

${code}json
${JSON_EXAMPLE}
${code}
`
}

function trustSection(tool: GuideTool): string {
  return `## trust

The threat. Reading some runners means RUNNING them. Asking moon for its task
graph evaluates the target repository's toolchain configuration, and asking
mise for its tasks can fire that repository's hooks. Pointing a tool at a
repository you did not write is therefore code execution, before you have run
anything from the list.

Built-ins that must shell out: ${execRoster()}.

The store. \`$XDG_STATE_HOME/waypost/trusted/\`, or
\`~/.local/state/waypost/trusted/\` when that variable is unset. XDG STATE, not
config: a consent record that travels in a dotfiles repository onto a new
machine has stopped being consent. One marker file per trusted root, because
creating and unlinking a file are atomic and independent, so two processes
trusting two repositories at once cannot lose each other's write. Both tools
share the one store.

It is PATH-KEYED. The key is the absolute, symlink-resolved root, not a hash of
the repository's contents. State the tradeoff plainly: a repository you trusted
that later pulls hostile changes STAYS trusted, and \`${tool.name} trust
--untrust\` is the only remedy. The alternative is worse — content-hashing
every runner config would re-prompt on ordinary edits, and a prompt that fires
on every edit trains people to approve without reading.

How the gate resolves. One function combines the flag, the configured value and
the store, so the two tools cannot drift:

${code}text
flag        configured  trusted  effective allowExec  reason
--no-exec   any         any      false               configured-off
--exec      any         any      true                allowed-by-flag
(none)      false       any      false               configured-off
(none)      true        false    false               untrusted
(none)      true        true     true                allowed
${code}

The exec flag grants execution for ONE run and records nothing. A human typed
it, with intent, at the moment of running; persisting that would turn one
deliberate run into a standing grant nobody remembers giving. It is the escape
hatch for scripts and CI.

The command: \`${tool.name} trust\` grants, \`--untrust\` revokes, \`--show\`
reports this root, \`--list\` prints every trusted path. \`-C PATH\` reaches all
of them.

A root can also be trusted with NO marker at all, by a \`trust\` block in the
USER layer of the config file — \`trust.paths\` (a glob over the resolved
root) and \`trust.owners\` (the \`origin\` remote's owner), decided in that
order after the marker. A project-layer \`trust\` block is rejected the same
way a project-layer \`allowExec: true\` is: a repository cannot pre-authorize
itself. \`--show\`/\`--json\` name which layer decided (\`by\`:
\`marker\`/\`path\`/\`owner\`, plus the matching \`rule\` for a policy hit).
`
}

function extendSection(tool: GuideTool): string {
  // The CLI hook point is NOT the same on both tools: `--config PATH` exists on
  // detect-runners only. Saying "from either CLI" told waypost users to pass a
  // flag that tool does not accept.
  const cliHook =
    tool.name === 'detect-runners'
      ? `- From this CLI — \`--config PATH\` imports a module that must export
  \`providers\` (an array), or a default with one. What it exports is MERGED
  with the built-ins, not substituted for them.`
      : `- waypost has no flag for this. It loads the built-ins and nothing else, so a
  third-party provider reaches a run either by embedding the library and
  passing \`CollectOptions.providers\`, or through \`detect-runners\`, whose
  own CLI takes a module path.`
  return `## extend

A provider adapts one runner to the shared model. The built-ins have no
privileges yours lacks — they are ordinary providers in an array.

Two rules.

1. A provider NEVER spawns. \`ctx.runner(binary)\` hands back an injected
   runner, so a test supplies canned output instead of needing the tool on the
   PATH.
2. A provider NEVER reads the filesystem for discovery. \`ctx.files()\` applies
   the caller's chosen strategy — git-tracked versus directory walk — and a
   provider reaching past it would silently disagree with every other provider
   about which files exist.

\`kind\` is "parse" or "exec". This is a TRUST BOUNDARY, not an optimization. A
parse provider reads files and nothing else; an exec provider runs the target
repository's code to be read at all. Collecting with execution off runs only
the parse providers, and that is the whole reason the field exists.

\`ProviderContext\` members:

- \`root\` — absolute. Every path you return is relative to it.
- \`runner(binary)\` — the injected command runner for one binary. A factory,
  not a single runner, because providers need different binaries.
- \`files(pattern)\` — root-relative paths matching a basename or a
  \`*\`-prefixed suffix. Memoized for the life of one collection.
- \`readJson(relPath)\` — read and parse JSON, root-relative. Memoized.
- \`readText(relPath)\` — read text, root-relative, null when absent. Memoized.
- \`exists(relPath)\` — true when a root-relative path exists.
- \`which(binary)\` — PATH lookup, no subprocess. Safe with execution off,
  which is exactly why it is separate from \`runner\`.
- \`allowExec\` — whether subprocesses are permitted. A parse provider never
  sees false.
- \`discovery\` — how discovery resolved, for a provider that wants to explain
  itself.
- \`signal\` — aborted when the caller cancels. Pass it to long-running work.

A minimal, complete provider:

${code}ts
${EXTEND_EXAMPLE.trim()}
${code}

Hook points:

- Programmatic — pass your provider alongside the built-ins:
  \`collect(root, { providers: [...builtinProviders, mine] })\`.
${cliHook}
`
}

/** One section, rendered for one tool. Always ends with a newline. */
export function guideSection(topic: GuideTopic, tool: GuideTool): string {
  switch (topic) {
    case 'usage':
      return usageSection(tool)
    case 'config':
      return configSection(tool)
    case 'json':
      return jsonSection()
    case 'trust':
      return trustSection(tool)
    case 'extend':
      return extendSection(tool)
  }
}

/** Every section, in {@link GUIDE_TOPICS} order, under one title. */
export function guideDocument(tool: GuideTool): string {
  const header = `# ${tool.name} guide

Instructions for using and extending this tool without the README. Topics:
${GUIDE_TOPICS.join(', ')}. Print one with \`${tool.name} guide <topic>\`.
`
  return [header, ...GUIDE_TOPICS.map((t) => guideSection(t, tool))].join('\n')
}

/** `<tool> guide --help`. Short on purpose: the document is the real help. */
function guideUsage(tool: GuideTool): string {
  return `${tool.name} guide — how to use and extend ${tool.name}, without the README

usage: ${tool.name} guide [topic]

  (no topic)          the whole document
  topics              the topic names, one per line
  <topic>             one section: ${GUIDE_TOPICS.join(', ')}
  -h, --help          this text
`
}

/**
 * `<tool> guide …`. Returns the exit code.
 *
 * Shared by both CLIs so argument handling is identical in both. 2 follows the
 * rule the config command documents: the command as typed cannot be run,
 * decided from the argument list alone.
 */
export function runGuideCommand(tool: GuideTool, argv: string[], io: CliIo): number {
  if (argv.length === 0) {
    io.stdout(guideDocument(tool))
    return EXIT.ok
  }

  const [first, ...rest] = argv as [string, ...string[]]
  if (first === '-h' || first === '--help') {
    io.stdout(guideUsage(tool))
    return EXIT.ok
  }

  const bad = (what: string): number => {
    io.stderr(
      `${tool.name}: guide: ${what} — topics are: ${GUIDE_TOPICS.join(', ')} (or "topics")\n`,
    )
    return EXIT.usage
  }

  if (rest.length > 0) return bad('expected at most one topic')
  if (first === 'topics') {
    io.stdout(`${GUIDE_TOPICS.join('\n')}\n`)
    return EXIT.ok
  }
  if (isGuideTopic(first)) {
    io.stdout(guideSection(first, tool))
    return EXIT.ok
  }
  return bad(`unknown topic "${first}"`)
}
