/**
 * Home-relative path resolution, shared.
 *
 * ## Why the tilde is expanded at all
 *
 * A shell expands `~` before exec, so a path that arrives through the
 * environment has usually been expanded already. The cases that matter are the
 * ones where nothing did: direnv, `.env` loaders and CI YAML hand the LITERAL
 * tilde through. `XDG_STATE_HOME=~/.local/state` set in a `.env` file then
 * becomes `<cwd>/~/.local/state` — a real directory, created without
 * complaint, in the wrong place. Expanding here is what stops that being the
 * silent wrong answer.
 *
 * ## Why it is shared
 *
 * Both call sites need it — the config layer (`config.ts`, including its
 * `trust.paths` expansion) and the cache store. The trust store's own copy
 * now lives in `@sksizer/cli-tool/trust`'s `xdg.ts`, ported rather than
 * imported back here, so this package stays free to change its config/cache
 * layout without touching a shared substrate two other tools also mount. A
 * private copy per site is how `startsWith("~")` gets written instead of
 * `startsWith("~/")`, which would expand `~user/x` into `<home>ser/x`.
 *
 * `home` is a parameter, never read from `node:os` here: every caller injects
 * it so a test cannot read or write the developer's real home directory.
 */

import { join, resolve } from 'node:path'

/** Expand a leading `~` against `home`; anything else is returned unchanged. */
export function expandTilde(path: string, home: string): string {
  if (path === '~') return home
  if (path.startsWith('~/')) return join(home, path.slice(2))
  return path
}

/**
 * An XDG base directory out of the environment, with a home-relative fallback.
 *
 * `env[varName]` wins when it is set and non-blank; it is tilde-expanded and
 * `resolve()`d, so a relative value becomes absolute rather than being joined
 * onto something later and landing somewhere nobody predicted. Otherwise the
 * fallback segments are joined onto `home` — `xdgHome(env, home,
 * "XDG_CACHE_HOME", ".cache")` is `~/.cache`.
 *
 * ## XDG on every platform, macOS included
 *
 * This is a CHOICE, not a convention every macOS tool follows: "macOS CLI tools
 * use XDG" is not true. `gh` is fully XDG on macOS — `~/.config/gh`,
 * `~/.cache/gh`, `~/.local/state/gh` — and that is the layout copied here.
 * `mise` splits: XDG for config, data and state, but `~/Library/Caches/mise`
 * for its cache. `bun` and `cargo` follow neither.
 *
 * We take gh's: one story on every platform, no storage-related branch on
 * `process.platform` anywhere in the package, and paths a developer with a
 * dotfiles repository already knows.
 *
 * What that gives up on macOS, measured rather than assumed: `~/Library/Caches`
 * is excluded from Time Machine and `~/.cache` is not, so the cache is backed
 * up despite being wholly regenerable. That is the whole cost. The other half
 * of the usual argument — that macOS purges `~/Library/Caches` — does not hold:
 * thousands of files older than six months sit there untouched on a working
 * machine, because the OS's purgeable-space machinery covers APFS snapshots,
 * iCloud-offloadable files and caches an app enrolls through the system
 * frameworks, not a directory a CLI created.
 *
 * An explicitly set `XDG_CACHE_HOME` or `XDG_STATE_HOME` still wins everywhere,
 * so anyone who wants the platform-native location can say so.
 */
export function xdgHome(
  env: Record<string, string | undefined>,
  home: string,
  varName: string,
  ...fallbackSegments: string[]
): string {
  const raw = env[varName]?.trim()
  if (raw !== undefined && raw !== '') return resolve(expandTilde(raw, home))
  return join(home, ...fallbackSegments)
}
