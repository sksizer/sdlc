/**
 * The stored probe results — an optimization layer above `collect()`.
 *
 * Some runners are slow to ask. moon starts its toolchain, sbt starts a JVM,
 * mise reads and merges a config tree; a probe that costs several seconds makes
 * an interactive surface feel broken even though it is working. This module
 * stores the last answer per (root, provider) so a surface can show something
 * immediately, say how old it is, and refresh in the background.
 *
 * `collect()` caches nothing across calls. This is a LAYER a caller opts into,
 * never something the library does behind a caller's back — a programmatic
 * consumer that asked for a probe gets a probe.
 *
 * ## Cache, not state — and why that differs from the trust store
 *
 * `$XDG_CACHE_HOME/waypost/`, or `~/.cache/waypost/`. The trust store deliberately
 * lives in `~/.local/state/waypost/` instead, and the split is not cosmetic:
 *
 *   - Losing this directory costs TIME and nothing else. A user who clears
 *     their caches, or a distro that sweeps `~/.cache`, pays one slow probe.
 *   - Losing the trust store would silently UN-TRUST repositories. Trust is
 *     consent a person gave; a consent record that a cache sweep can erase is
 *     not a consent record. It belongs in state, and state is not swept.
 *
 * ## Layout: one file per (root, provider)
 *
 * `<cacheDir>/reports/v<CACHE_FORMAT_VERSION>/<basename>-<hash>/<providerId>.json`
 *
 * One file per provider, not one document per root. A background refresh writes
 * while another process may be reading, and different providers finish at
 * different times — with one file per provider every write is a single atomic
 * rename that cannot lose another provider's concurrent write. A single
 * per-root document would need read-modify-write under a lock, and the failure
 * mode of getting that lock wrong is a runner's entry silently disappearing,
 * which looks exactly like the runner not being there.
 *
 * The directory name mirrors the trust store's marker naming
 * (`basename(root)-sha256(root).slice(0,16)`): the hash disambiguates
 * same-named repositories, and the basename keeps an `ls` of the store legible.
 *
 * ## Versioned in the path AND in the file
 *
 * Both, because they fail differently. The version in the path means a format
 * bump abandons the old tree wholesale, so old entries are never even opened.
 * The version inside each file means an entry that arrives by some other route
 * — a copied directory, a rolled-back binary — is still rejected. A cache that
 * outlives a change to `Task` would otherwise hand a consumer a shape it cannot
 * parse, and that failure would surface far away from here.
 *
 * ## A broken cache is a miss, never an error
 *
 * {@link readEntry} returns `null` for a missing file, a truncated one, a parse
 * failure, or a version mismatch. Nothing here throws on the read path: the
 * fallback is always "probe it", which is what would have happened with no
 * cache at all.
 */

import { createHash, randomBytes } from 'node:crypto'
import { mkdir, readFile, rename, writeFile } from 'node:fs/promises'
import { homedir } from 'node:os'
import { basename, dirname, join } from 'node:path'

import type { ProviderKind } from './contract.ts'
import type { Fingerprint } from './fingerprint.ts'
import type { RunnerReport } from './model.ts'
import { xdgHome } from './xdg.ts'

/** Bumped whenever a stored entry's shape — including `Task`'s — changes. */
export const CACHE_FORMAT_VERSION = 3

/** Directory under the XDG cache home. Matches the trust store's `waypost`. */
export const CACHE_DIR_NAME = 'waypost'

/** How many probe durations are kept per entry. */
export const DURATION_WINDOW = 5

/**
 * A repo-measured probe at or above this is "slow" for that repo.
 *
 * Measured, never declared. The same provider is fast against a small
 * repository and slow against a large one, so a per-provider constant would be
 * wrong for half its users; what matters is how long it took HERE.
 */
export const SLOW_PROBE_MS = 1500

/**
 * Backstop for exec entries whose fingerprint cannot see the merge inputs.
 *
 * An exec provider reads its markers, not the files its tool merges (see
 * `fingerprint.ts`), so a matching fingerprint is a good signal rather than a
 * proof. Four hours bounds how long a change the fingerprint cannot see can go
 * unnoticed, without re-paying a JVM start every few minutes.
 */
export const EXEC_MAX_AGE_MS = 4 * 60 * 60 * 1000

export interface CacheEntry {
  version: number
  /** The resolved absolute repository root this was probed against. */
  root: string
  provider: string
  kind: ProviderKind
  /** ISO timestamp of the probe. */
  takenAt: string
  /** Wall time of this probe alone. */
  probeMs: number
  /** Rolling window of recent probe durations, oldest first. */
  durations: number[]
  fingerprint: Fingerprint
  report: RunnerReport
}

/** `$XDG_CACHE_HOME/waypost`, else `~/.cache/waypost`. */
export function cacheDir(
  env: Record<string, string | undefined> = process.env,
  home: string = homedir(),
): string {
  return join(xdgHome(env, home, 'XDG_CACHE_HOME', '.cache'), CACHE_DIR_NAME)
}

/** Where one (root, provider) entry lives under `dir`. */
export function entryPath(dir: string, root: string, providerId: string): string {
  return join(dir, 'reports', `v${CACHE_FORMAT_VERSION}`, rootKey(root), `${providerId}.json`)
}

/** `basename-hash`, mirroring the trust store's marker names. */
function rootKey(root: string): string {
  const digest = createHash('sha256').update(root).digest('hex').slice(0, 16)
  const raw = basename(root)
  const name = (raw === '' ? 'root' : raw).replace(/[^A-Za-z0-9._-]/g, '-')
  return `${name}-${digest}`
}

export async function readEntry(
  dir: string,
  root: string,
  providerId: string,
): Promise<CacheEntry | null> {
  let text: string
  try {
    text = await readFile(entryPath(dir, root, providerId), 'utf-8')
  } catch {
    return null
  }

  let parsed: unknown
  try {
    parsed = JSON.parse(text)
  } catch {
    return null
  }

  if (typeof parsed !== 'object' || parsed === null) return null
  const entry = parsed as CacheEntry
  if (entry.version !== CACHE_FORMAT_VERSION) return null
  return entry
}

/**
 * Store one entry, or refuse to.
 *
 * Two reports are never stored, and the refusal lives HERE rather than in each
 * caller so it cannot be forgotten by the next surface that adds caching:
 *
 *   - `status: "error"`. Serving an error out of a cache turns a transient
 *     failure — a tool mid-upgrade, a lock held for a second — into a sticky
 *     one that outlives its cause and that nobody can explain.
 *   - `skippedForExec: true`. A report withheld for want of execution is not a
 *     probe result at all; nothing was measured, and storing it would let an
 *     untrusted run poison the answer a later trusted run should have given.
 *
 * Returns whether anything was written. A write failure — read-only home, full
 * disk — is also `false` rather than a throw: failing to cache must never fail
 * the collection the cache was meant to speed up.
 */
export async function writeEntry(dir: string, entry: CacheEntry): Promise<boolean> {
  if (entry.report.status === 'error') return false
  if (entry.report.skippedForExec === true) return false

  const path = entryPath(dir, entry.root, entry.provider)
  try {
    await mkdir(dirname(path), { recursive: true })
    // Temp file then rename, in the same directory so the rename is atomic: a
    // partial write must never be readable as an entry, and a background
    // refresh writes while another process may be reading this very path.
    const temp = `${path}.${randomBytes(6).toString('hex')}.tmp`
    await writeFile(temp, `${JSON.stringify(entry)}\n`, 'utf-8')
    await rename(temp, path)
    return true
  } catch {
    return false
  }
}

/**
 * The expected probe cost, as the MEDIAN of the window.
 *
 * A median, not a mean: one cold JVM start is several times a warm probe, and a
 * mean lets that single outlier dominate the estimate for as long as it stays
 * in the window. `null` when nothing has been measured — an unknown cost is not
 * a cost of zero, and a caller must be able to tell the difference.
 */
export function estimateMs(durations: readonly number[]): number | null {
  if (durations.length === 0) return null
  const sorted = [...durations].sort((a, b) => a - b)
  const mid = sorted.length >> 1
  const lo = sorted[mid - 1]
  const hi = sorted[mid]
  if (hi === undefined) return null
  if (sorted.length % 2 === 1) return hi
  return lo === undefined ? hi : (lo + hi) / 2
}

/** Whether this repo's own measurements say the provider is slow to probe. */
export function isSlow(durations: readonly number[]): boolean {
  const estimate = estimateMs(durations)
  return estimate !== null && estimate >= SLOW_PROBE_MS
}

/** The previous entry's window with `ms` appended, capped at {@link DURATION_WINDOW}. */
export function pushDuration(previous: CacheEntry | null, ms: number): number[] {
  const window = [...(previous?.durations ?? []), ms]
  return window.slice(-DURATION_WINDOW)
}
