/**
 * The normalized model every provider produces.
 *
 * VOCABULARY:
 *
 *   Runner   a TOOL that runs things — moon, just, cargo, make.
 *   Task     ONE runnable command a runner exposes — `moon run web:dev`.
 *   Provider the adapter that finds a runner and enumerates its tasks.
 */

/**
 * A task parameter, as DATA rather than as text baked into a command line.
 *
 * This is why `argv` and `display` are separate fields. just renders
 * parameters as `<required>`, `[optional]` and `*variadic`; concatenating
 * those into a string handed to a shell makes
 * `just release-lib <lib> <bump> *flags` a shell SYNTAX ERROR (`<lib>` is an
 * input redirection) and globs `*flags`.
 */
export interface Param {
  name: string
  required: boolean
  variadic: boolean
  /** Literal default where the runner declares one. */
  default?: string | undefined
}

/** Where a task came from: declared in config, or synthesized by a convention. */
export type TaskOrigin = 'declared' | 'synthesized'

/**
 * Where a task's command actually runs, as distinct from how this package
 * found it.
 *
 * `ProviderKind` (`parse`/`exec`) is a DETECTION posture — what this package
 * must do to READ the repo and learn the task exists. `executes` is a
 * property of the task ITSELF — what happens when a caller RUNS it. The two
 * axes are independent: a GitHub Actions workflow file is `parse`-detected
 * (reading YAML) but `remote` to run, because GitHub's runners execute it and
 * not this machine; a docker-compose service is `container` regardless of
 * whether its definition was parsed or shelled out to.
 *
 * A consumer must NOT assume every task is `"local"`: a UI that offers to run
 * a task in this terminal is wrong for github-actions and docker-compose, and
 * `executes` is the field that says so.
 */
export type TaskExecutionTarget = 'local' | 'remote' | 'container'

/**
 * One runnable command.
 *
 * `argv` is what you execute. `display` is what you show. They are different
 * strings on purpose and a consumer should never build one from the other.
 */
export interface Task {
  /**
   * Stable across a re-collect, so a UI can keep its selection when the
   * catalog refreshes and a caller can hold a reference rather than an index
   * into a list that is about to change.
   */
  id: string
  /** The runner that owns it — `provider.id`. */
  runner: string
  /** Display and search chain, root-first, with `runner` at index 0. */
  path: string[]
  /**
   * EXECUTABLE form. Spawn this directly — never through a shell, and never
   * after re-joining it into a string. Contains no parameter placeholders.
   */
  argv: string[]
  /**
   * Directory the command expects, relative to the catalog root ("." = root).
   * A last resort, not a convenience: a provider expresses the directory in
   * `argv` via the tool's own flag wherever one exists, so `display` is
   * correct when pasted from the repository root. `cwd` stays non-"." only
   * when the tool has no such flag.
   */
  cwd: string
  /**
   * Human form, for showing and for copy-paste. Includes parameter
   * placeholders, so it is NOT executable.
   */
  display: string
  parameters: Param[]
  /** File that declares it, relative to the catalog root. */
  source: string
  /**
   * `declared` — the task exists in a config file (a moon task, a just recipe).
   * `synthesized` — the provider invented it from a convention: `cargo clippy`
   * is not written down anywhere, it is what you run when a Cargo.toml exists.
   * Consumers that want "what did this repo actually define" filter on this.
   */
  origin: TaskOrigin
  /** Summary where the runner supplies one (just's `[doc]`); else absent. */
  doc?: string | undefined
  /** What the task actually executes, when that differs from `display`. */
  detail?: string | undefined
  /** Free-text facets for search and filtering (layer, stack, language, …). */
  tags: string[]
  /**
   * Whether this keeps running until stopped — a dev server, a watcher.
   * `declared` distinguishes a runner stating it (moon's `persistent` option)
   * from this package guessing from the name, so a consumer can choose to
   * trust only the former.
   */
  persistent: { value: boolean; declared: boolean }
  /** What running this task does — see {@link TaskExecutionTarget}. */
  executes: TaskExecutionTarget
}

/** What one position in a runner's call chain selects. */
export interface ChainSegment {
  /** One-word column name: "project", "recipe", "script". */
  label: string
  /** A sentence explaining what that position selects, for tooltips and help. */
  hint: string
}

/**
 * How directly a piece of evidence observes the thing it claims. Mirrors the
 * tiers of the system-graph aspect model: `manifest` reads a declaration,
 * `dependency` infers from a declared dependency, `files` observes the
 * filesystem, `content` reads inside files.
 *
 * Runner detection is almost entirely `files` — `.moon/` and `justfile` are
 * marks on disk, not statements in a manifest.
 */
export type EvidenceKind = 'manifest' | 'dependency' | 'files' | 'content'

export interface Evidence {
  kind: EvidenceKind
  /** What was observed, e.g. `.moon/workspace.yml` or `package.json#scripts`. */
  detail: string
}

/** A claim that a directory is a particular kind of thing, and why. */
export interface Aspect {
  /** The runner id this aspect asserts — "moon", "just", … */
  id: string
  evidence: Evidence[]
}

export type Severity = 'info' | 'warning' | 'error'

/**
 * Something the caller should know that is not a task. Structured rather than
 * a joined string because "just is not installed" and "this justfile is
 * broken" want different treatment in a UI.
 */
export interface Diagnostic {
  severity: Severity
  message: string
  /** File the diagnostic is about, relative to the catalog root, when there is one. */
  source?: string | undefined
}

/**
 * A runner's visual identity, for surfaces that show more than text.
 *
 * This lives on the REPORT, not on each task: a catalog carries thousands of
 * tasks and eight runners, and an SVG repeated per task would multiply every
 * `--json` dump by the size of the artwork for no information gained. It is
 * optional end to end — a provider without one renders as plain text.
 */
export interface RunnerBrand {
  /**
   * Inline SVG markup: viewBox'd, no fixed width/height so the consumer sizes
   * it, `fill="currentColor"` where the mark is monochrome so it inherits the
   * surrounding text color. Kept small on purpose — this ships in every
   * catalog serialization.
   */
  icon?: string | undefined
  /** The project's brand color, as a `#rrggbb` hex string. */
  color?: string | undefined
}

/** Whether a provider found its runner, and what it produced. */
export interface ProviderResult {
  status: 'absent' | 'ok' | 'error'
  aspect?: Aspect | undefined
  tasks: Task[]
  diagnostics: Diagnostic[]
}

/** One runner's slice of a catalog, plus how to read its call chain. */
export interface RunnerReport extends ProviderResult {
  runner: string
  chain: ChainSegment[]
  /** The provider's visual identity, copied verbatim when it declares one. */
  brand?: RunnerBrand | undefined
  /**
   * Whether the provider's declared binary is on the PATH, filled by
   * `collect()` via `ctx.which()` — never by the provider itself, so a
   * provider cannot misreport its own presence. Absent entirely when the
   * provider declares no `binary` (see `RunnerProvider.binary`). Filled
   * independently of whether the provider actually ran: a report skipped for
   * exec or one that errored still carries an honest presence fact.
   */
  tool?: { binary: string; found: boolean; path?: string } | undefined
  /** True when the provider was skipped because it needed to shell out. */
  skippedForExec: boolean
}

/** How file discovery resolved for this run — recorded because it changes results. */
export type DiscoveryMode = 'git' | 'walk'

export interface Catalog {
  /** Absolute path the collection ran against. Every `cwd`/`source` is relative to it. */
  root: string
  generatedAt: string
  discovery: DiscoveryMode
  /** Whether providers were permitted to run subprocesses. */
  allowExec: boolean
  reports: RunnerReport[]
}

/** Every task in a catalog, across runners, in report order. */
export function tasks(catalog: Catalog): Task[] {
  return catalog.reports.flatMap((r) => r.tasks)
}

/** Every diagnostic in a catalog, tagged with the runner that raised it. */
export function diagnostics(catalog: Catalog): Array<Diagnostic & { runner: string }> {
  return catalog.reports.flatMap((r) => r.diagnostics.map((d) => ({ ...d, runner: r.runner })))
}
