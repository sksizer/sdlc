/**
 * Project-root resolution.
 *
 * Every entry point needs this and none of them should own it: inspecting a
 * subdirectory instead of the repository means finding a fraction of what is
 * there, and each caller inventing its own rule would make them disagree.
 */

import { resolve } from 'node:path'

import { pathExists } from './discovery.ts'

/** A repository. Checked first, and across the whole ancestor chain. */
const REPO_MARKERS = ['.git', '.moon']

/** A single project. Only consulted when there is no repository anywhere above. */
const PACKAGE_MARKERS = [
  'justfile',
  'Justfile',
  'package.json',
  'Cargo.toml',
  'pyproject.toml',
  'Makefile',
]

/**
 * The project root to inspect, found by walking up from `from`.
 *
 * Repository markers are checked across the WHOLE ancestor chain before any
 * package marker is considered. Checking both together at each level fails in
 * exactly the case that matters: every package in a monorepo has a
 * `package.json`, so running from `packages/ts/thing` would stop there and
 * report that one package's scripts as if they were the repository's.
 *
 * The NEAREST repository marker wins rather than the highest, so a nested
 * checkout — a git worktree living inside its parent repo, a vendored clone —
 * resolves to itself instead of escaping upward into the parent.
 *
 * `moon` and `just` already search upward for their own configuration, so this
 * makes discovery agree with the runners rather than fighting them.
 */
export async function findRoot(from: string): Promise<string> {
  const start = resolve(from)
  const chain: string[] = []
  for (let dir = start; ;) {
    chain.push(dir)
    const parent = resolve(dir, '..')
    if (parent === dir) break
    dir = parent
  }

  for (const dir of chain) {
    for (const marker of REPO_MARKERS) {
      if (await pathExists(dir, marker)) return dir
    }
  }
  for (const dir of chain) {
    for (const marker of PACKAGE_MARKERS) {
      if (await pathExists(dir, marker)) return dir
    }
  }
  return start
}
