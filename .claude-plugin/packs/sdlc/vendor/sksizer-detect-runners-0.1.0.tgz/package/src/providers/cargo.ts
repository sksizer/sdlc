/**
 * cargo — the conventional verbs a Rust crate answers to.
 *
 * The clearest example of `origin: "synthesized"` in the package. Nothing in a
 * Cargo.toml declares `cargo test` or `cargo clippy`; they are what a crate
 * runs because it is a crate.
 *
 * A consumer that only wants what a repo actually wrote down filters these out
 * with `origin === "declared"`, which is why the field exists.
 */

import type { ProviderContext, RunnerProvider } from '../contract.ts'
import type { ProviderResult, RunnerBrand, Task } from '../model.ts'
import { dirOf, taskId } from './shared.ts'

const CHAIN = [
  { label: 'runner', hint: 'cargo builds, tests and lints Rust crates.' },
  { label: 'crate', hint: 'The directory holding the Cargo.toml. `.` is the root manifest.' },
  { label: 'verb', hint: 'A conventional cargo verb. Synthesized — not declared in the manifest.' },
]

/** The verbs worth offering. Deliberately short: these are conventions, not config. */
const VERBS: ReadonlyArray<{ name: string; args: string[] }> = [
  { name: 'test', args: ['test'] },
  { name: 'clippy', args: ['clippy'] },
]

/**
 * A shipping crate — cargo ships crates. A substitute glyph, kept after
 * checking simple-icons: its `rust` icon is CC-BY-SA-4.0, not CC0 (the Rust
 * logo's own license), which an MIT package cannot pass on — and its path is
 * ~4.1KB besides. Color is GitHub Linguist's rust-orange for the language.
 */
const BRAND: RunnerBrand = {
  icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M12 2.9 20.4 7v10L12 21.1 3.6 17V7Z"/><path d="M3.6 7 12 11.2 20.4 7M12 11.2V21"/></svg>',
  color: '#dea584',
}

export const cargoProvider: RunnerProvider = {
  id: 'cargo',
  kind: 'parse',
  chain: CHAIN,
  brand: BRAND,
  binary: 'cargo',

  async collect(ctx: ProviderContext): Promise<ProviderResult> {
    const manifests = (await ctx.files('Cargo.toml')).sort()
    if (manifests.length === 0) return { status: 'absent', tasks: [], diagnostics: [] }

    const tasks: Task[] = []
    for (const file of manifests) {
      const dir = dirOf(file)
      for (const verb of VERBS) {
        const argv =
          dir === '.' ? ['cargo', ...verb.args] : ['cargo', ...verb.args, '--manifest-path', file]
        tasks.push({
          id: taskId('cargo', file, verb.name),
          runner: 'cargo',
          path: ['cargo', dir, verb.name],
          argv,
          cwd: '.',
          display: argv.join(' '),
          parameters: [],
          source: file,
          origin: 'synthesized',
          tags: ['cargo', 'rust', dir],
          persistent: { value: false, declared: false },
          executes: 'local',
        })
      }
    }

    return {
      status: 'ok',
      aspect: {
        id: 'cargo',
        evidence: manifests.map((f) => ({ kind: 'manifest' as const, detail: f })),
      },
      tasks,
      diagnostics: [],
    }
  },
}
