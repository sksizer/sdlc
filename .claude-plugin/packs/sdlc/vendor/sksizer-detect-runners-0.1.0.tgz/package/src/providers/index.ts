/**
 * The built-in providers, in report order.
 *
 * They have no privileges a caller's own provider lacks — this array is just a
 * default. Order is the order results appear in, and callers who care about
 * determinism depend on it.
 *
 * Adding a runner is one file plus one line here, or zero changes to this
 * package if you register it from outside:
 *
 *   collect(root, { providers: [...builtinProviders, mine] })
 */

import type { RunnerProvider } from '../contract.ts'
import { cargoProvider } from './cargo.ts'
import { composerProvider } from './composer.ts'
import { denoTasksProvider } from './deno-tasks.ts'
import { dockerComposeProvider } from './docker-compose.ts'
import { githubActionsProvider } from './github-actions.ts'
import { goTaskProvider } from './go-task.ts'
import { gradleProvider } from './gradle.ts'
import { justProvider } from './just.ts'
import { makeProvider } from './make.ts'
import { mavenProvider } from './maven.ts'
import { miseProvider } from './mise.ts'
import { moonProvider } from './moon.ts'
import { nodeScriptsProvider } from './node-scripts.ts'
import { pythonProvider } from './python.ts'
import { rakeProvider } from './rake.ts'
import { sbtProvider } from './sbt.ts'
import { swiftpmProvider } from './swiftpm.ts'
import { turboProvider } from './turbo.ts'

export {
  cargoProvider,
  composerProvider,
  denoTasksProvider,
  dockerComposeProvider,
  githubActionsProvider,
  goTaskProvider,
  gradleProvider,
  justProvider,
  makeProvider,
  mavenProvider,
  miseProvider,
  moonProvider,
  nodeScriptsProvider,
  pythonProvider,
  rakeProvider,
  sbtProvider,
  swiftpmProvider,
  turboProvider,
}

export const builtinProviders: RunnerProvider[] = [
  moonProvider,
  miseProvider,
  justProvider,
  nodeScriptsProvider,
  makeProvider,
  cargoProvider,
  sbtProvider,
  pythonProvider,
  composerProvider,
  denoTasksProvider,
  turboProvider,
  mavenProvider,
  swiftpmProvider,
  gradleProvider,
  goTaskProvider,
  rakeProvider,
  // Last, and together, because they are the two whose TASKS do not run on
  // this machine — `container` and `remote` rather than `local`. Report order
  // is part of the contract, so the local runners keep the positions they
  // already had and these are appended rather than interleaved.
  dockerComposeProvider,
  githubActionsProvider,
]
