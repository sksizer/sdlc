/**
 * Turborepo — `turbo.json` (v1 `pipeline`, v2 `tasks`).
 *
 * Turborepo 2.0 renamed the top-level `pipeline` key to `tasks`; the value
 * shape under each key is otherwise the same. Both are read here — `tasks`
 * wins when a file somehow carries both, with a diagnostic noting it.
 *
 * `kind: "parse"`: turbo.json is plain data, so there is nothing to shell out
 * for.
 */

import type { ProviderContext, RunnerProvider } from '../contract.ts'
import type { Diagnostic, ProviderResult, RunnerBrand, Task } from '../model.ts'
import { dirOf, looksPersistent, taskId } from './shared.ts'

const CHAIN = [
  {
    label: 'runner',
    hint: "turbo runs tasks declared in turbo.json's `tasks` (v2) or `pipeline` (v1) map.",
  },
  { label: 'project', hint: 'The directory holding the turbo.json. `.` is the workspace root.' },
  {
    label: 'task',
    hint: 'The key under `tasks`/`pipeline` — often `workspace#task` for a package-scoped override, or a bare task name applying to every workspace.',
  },
]

/**
 * Turborepo's mark. Turborepo is a trademark of Vercel; used here
 * nominatively, to identify the tool. Icon path and color: simple-icons
 * (CC0-1.0), slug `turborepo`, fetched from
 * cdn.jsdelivr.net/npm/simple-icons@latest/icons/turborepo.svg and its data
 * file (hex `#EF4444`).
 */
const BRAND: RunnerBrand = {
  icon: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M11.9906 4.1957c-4.2998 0-7.7981 3.501-7.7981 7.8043s3.4983 7.8043 7.7981 7.8043c4.2999 0 7.7982-3.501 7.7982-7.8043s-3.4983-7.8043-7.7982-7.8043m0 11.843c-2.229 0-4.0356-1.8079-4.0356-4.0387s1.8065-4.0387 4.0356-4.0387S16.0262 9.7692 16.0262 12s-1.8065 4.0388-4.0356 4.0388m.6534-13.1249V0C18.9726.3386 24 5.5822 24 12s-5.0274 11.66-11.356 12v-2.9139c4.7167-.3372 8.4516-4.2814 8.4516-9.0861s-3.735-8.749-8.4516-9.0861M5.113 17.9586c-1.2502-1.4446-2.0562-3.2845-2.2-5.3046H0c.151 2.8266 1.2808 5.3917 3.051 7.3668l2.0606-2.0622zM11.3372 24v-2.9139c-2.02-.1439-3.8584-.949-5.3019-2.2018l-2.0606 2.0623c1.975 1.773 4.538 2.9022 7.361 3.0534z"/></svg>',
  color: '#ef4444',
}

interface TurboTaskConfig {
  dependsOn?: unknown
  outputs?: unknown
  cache?: unknown
  persistent?: unknown
}

export const turboProvider: RunnerProvider = {
  id: 'turbo',
  kind: 'parse',
  chain: CHAIN,
  brand: BRAND,
  binary: 'turbo',

  async collect(ctx: ProviderContext): Promise<ProviderResult> {
    const jsonFiles = await ctx.files('turbo.json')
    // turbo.jsonc is a newer, best-effort addition: it needs comment-stripping
    // to parse as JSON, and `ctx.readJson` does not tolerate comments.
    // Providers stay independent, so the stripper below is local rather than
    // shared with deno's; a file that still fails to parse becomes a diagnostic.
    const jsoncFiles = await ctx.files('turbo.jsonc')
    const files = [...jsonFiles, ...jsoncFiles].sort()
    if (files.length === 0) return { status: 'absent', tasks: [], diagnostics: [] }

    const diagnostics: Diagnostic[] = []
    const tasks: Task[] = []

    for (const file of files) {
      const parsed = await readTurboConfig(ctx, file)
      if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
        diagnostics.push({ severity: 'warning', message: 'unparseable turbo.json', source: file })
        continue
      }

      const config = parsed as { tasks?: unknown; pipeline?: unknown }
      let map: Record<string, unknown> | null = null
      if (
        config.tasks !== null &&
        typeof config.tasks === 'object' &&
        !Array.isArray(config.tasks)
      ) {
        map = config.tasks as Record<string, unknown>
        if (config.pipeline !== undefined) {
          diagnostics.push({
            severity: 'info',
            message:
              'turbo.json declares both `tasks` and `pipeline` — `tasks` (v2) was read, `pipeline` ignored',
            source: file,
          })
        }
      } else if (
        config.pipeline !== null &&
        typeof config.pipeline === 'object' &&
        !Array.isArray(config.pipeline)
      ) {
        map = config.pipeline as Record<string, unknown>
        diagnostics.push({
          severity: 'info',
          message: 'turbo.json uses the v1 pipeline key',
          source: file,
        })
      }
      if (map === null) continue

      const dir = dirOf(file)

      for (const [key, value] of Object.entries(map)) {
        if (value === null || typeof value !== 'object' || Array.isArray(value)) continue
        const task = value as TurboTaskConfig

        // A bare key runs on every workspace: `["turbo", "run", key]`. A
        // `workspace#task` key is split — turbo's `--filter` flag scopes a
        // run to one workspace, so `web#build` becomes
        // `turbo run build --filter web`. This assumes `workspacePart` is
        // already a valid turbo package name/filter expression; the
        // provider does not validate it further.
        //
        // A turbo.json below the root is named by turbo's own global
        // working-directory flag, `--cwd <path>`, which precedes the command
        // (`turbo --skip-infer --cwd ../.. get-mfe-port`, turborepo.dev
        // microfrontends guide) — so `cwd` stays ".". Without it argv would
        // address the ROOT turbo project instead of the declaring one. Turbo
        // scopes a run to the package it is invoked inside
        // (turborepo.dev/docs/crafting-your-repository/running-tasks,
        // "Automatic Package Scoping"), so this is right both for a package
        // configuration extending a root turbo.json and for a standalone
        // nested turbo project.
        const head = dir === '.' ? ['turbo'] : ['turbo', '--cwd', dir]
        const hashAt = key.indexOf('#')
        const argv =
          hashAt === -1
            ? [...head, 'run', key]
            : [...head, 'run', key.slice(hashAt + 1), '--filter', key.slice(0, hashAt)]
        const taskName = hashAt === -1 ? key : key.slice(hashAt + 1)

        const detailParts: string[] = []
        if (Array.isArray(task.dependsOn) && task.dependsOn.length > 0) {
          detailParts.push(`depends on: ${task.dependsOn.join(', ')}`)
        }
        if (Array.isArray(task.outputs) && task.outputs.length > 0) {
          detailParts.push(`outputs: ${task.outputs.join(', ')}`)
        }

        const declaredPersistent = task.persistent === true
        const cacheDisabled = task.cache === false

        tasks.push({
          id: taskId('turbo', file, key),
          runner: 'turbo',
          path: ['turbo', dir, key],
          argv,
          cwd: '.',
          display: argv.join(' '),
          parameters: [],
          source: file,
          origin: 'declared',
          ...(detailParts.length > 0 ? { detail: detailParts.join('; ') } : {}),
          tags: ['turbo', dir, ...(cacheDisabled ? ['cache-disabled'] : [])],
          persistent: {
            value: declaredPersistent || (cacheDisabled && looksPersistent(taskName)),
            declared: declaredPersistent,
          },
          executes: 'local',
        })
      }
    }

    return {
      status: tasks.length > 0 ? 'ok' : 'absent',
      aspect: {
        id: 'turbo',
        evidence: [{ kind: 'manifest', detail: 'turbo.json#tasks' }],
      },
      tasks,
      diagnostics,
    }
  },
}

/**
 * Reads a turbo config file. `.json` files go straight through
 * `ctx.readJson`. `.jsonc` files get a minimal comment strip first — turbo
 * accepts `//` and `/* *\/` comments there — because `ctx.readJson` parses
 * strict JSON. Best-effort: enough for real-world turbo.jsonc, not a full
 * JSONC parser.
 */
async function readTurboConfig(ctx: ProviderContext, file: string): Promise<unknown> {
  if (!file.endsWith('.jsonc')) return ctx.readJson(file)

  const text = await ctx.readText(file)
  if (text === null) return null
  try {
    return JSON.parse(stripJsonComments(text))
  } catch {
    return null
  }
}

/** Strips `//` line comments and `/* *\/` block comments outside of strings. */
function stripJsonComments(text: string): string {
  let out = ''
  let inString = false
  let escaped = false
  for (let i = 0; i < text.length; i++) {
    const ch = text[i]
    const next = text[i + 1]
    if (inString) {
      out += ch
      if (escaped) {
        escaped = false
      } else if (ch === '\\') {
        escaped = true
      } else if (ch === '"') {
        inString = false
      }
      continue
    }
    if (ch === '"') {
      inString = true
      out += ch
      continue
    }
    if (ch === '/' && next === '/') {
      while (i < text.length && text[i] !== '\n') i++
      out += '\n'
      continue
    }
    if (ch === '/' && next === '*') {
      i += 2
      while (i < text.length && !(text[i] === '*' && text[i + 1] === '/')) i++
      i++ // consumes the trailing '/'
      continue
    }
    out += ch
  }
  return out
}
