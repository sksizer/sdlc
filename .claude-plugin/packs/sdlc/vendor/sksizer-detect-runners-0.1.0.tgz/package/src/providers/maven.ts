/**
 * maven — the conventional lifecycle phases a Maven module answers to.
 *
 * Presence-only, mirroring cargo.ts: nothing about `mvn test` or `mvn install`
 * is declared inside a pom.xml — those phases are what a module runs because
 * it is a Maven module. This provider never parses the pom.xml's XML; the
 * file's existence is the only signal.
 */

import type { ProviderContext, RunnerProvider } from '../contract.ts'
import type { ProviderResult, RunnerBrand, Task } from '../model.ts'
import { dirOf, taskId } from './shared.ts'

const CHAIN = [
  { label: 'runner', hint: 'mvn builds, tests and packages Java projects.' },
  { label: 'project', hint: 'The directory holding the pom.xml. `.` is the root manifest.' },
  {
    label: 'verb',
    hint: 'A conventional Maven lifecycle phase. Synthesized — not declared in the manifest.',
  },
]

/** The standard lifecycle phases worth offering. Conventions, not config. */
const VERBS: ReadonlyArray<{ name: string }> = [
  { name: 'test' },
  { name: 'package' },
  { name: 'install' },
  { name: 'verify' },
]

/**
 * A stack of layers — Maven runs the build through an ordered lifecycle of
 * phases, which this substitute glyph gestures at. Checked against
 * simple-icons before use: its `apachemaven` entry carries a per-icon
 * `license` override of `Apache-2.0`, not the aggregate package's CC0-1.0
 * (`data/simple-icons.json`, slug `apachemaven`) — the same shape as `rust`
 * in cargo.ts's precedent, and an MIT package cannot pass that on. Color
 * (`#C71A36`) is Apache Maven's own brand red, independently attested across
 * brand-asset references (e.g. Wikipedia's Maven logo file) rather than
 * copied from the encumbered icon entry.
 */
const BRAND: RunnerBrand = {
  icon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" aria-hidden="true"><path d="M12 3 21 8l-9 5-9-5Z"/><path d="M3 12l9 5 9-5M3 16l9 5 9-5"/></svg>',
  color: '#C71A36',
}

export const mavenProvider: RunnerProvider = {
  id: 'maven',
  kind: 'parse',
  chain: CHAIN,
  brand: BRAND,
  binary: 'mvn',

  async collect(ctx: ProviderContext): Promise<ProviderResult> {
    const manifests = (await ctx.files('pom.xml')).sort()
    if (manifests.length === 0) return { status: 'absent', tasks: [], diagnostics: [] }

    const tasks: Task[] = []
    for (const file of manifests) {
      const dir = dirOf(file)
      for (const verb of VERBS) {
        const argv = dir === '.' ? ['mvn', verb.name] : ['mvn', '-f', file, verb.name]
        tasks.push({
          id: taskId('maven', file, verb.name),
          runner: 'maven',
          path: ['maven', dir, verb.name],
          argv,
          cwd: '.',
          display: argv.join(' '),
          parameters: [],
          source: file,
          origin: 'synthesized',
          tags: ['maven', 'java', dir],
          persistent: { value: false, declared: false },
          executes: 'local',
        })
      }
    }

    return {
      status: 'ok',
      aspect: {
        id: 'maven',
        evidence: manifests.map((f) => ({ kind: 'manifest' as const, detail: f })),
      },
      tasks,
      diagnostics: [],
    }
  },
}
