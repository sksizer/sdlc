/**
 * swiftpm — the conventional verbs a Swift package answers to.
 *
 * Package.swift is Swift source code, not data: a manifest that runs
 * arbitrary top-level statements to build its `Package` value. This provider
 * never parses it — presence alone is the signal, exactly like cargo.ts never
 * parses Cargo.toml for its verb list. `origin: "synthesized"` because
 * nothing in the file declares `swift build`/`test`/`run`; they are what you
 * run because it is a Swift package.
 */

import type { ProviderContext, RunnerProvider } from '../contract.ts'
import type { ProviderResult, RunnerBrand, Task } from '../model.ts'
import { dirOf, taskId } from './shared.ts'

const CHAIN = [
  { label: 'runner', hint: 'swift builds, tests and runs packages described by a Package.swift.' },
  { label: 'package', hint: 'The directory holding the Package.swift. `.` is the root package.' },
  {
    label: 'verb',
    hint: 'A conventional SwiftPM verb. Synthesized — not declared in the manifest.',
  },
]

/** The verbs worth offering. Deliberately short: these are conventions, not config. */
const VERBS: ReadonlyArray<{ name: string; args: string[] }> = [
  { name: 'build', args: ['build'] },
  { name: 'test', args: ['test'] },
  { name: 'run', args: ['run'] },
]

/**
 * A bird in flight — swift as in the bird, and as in the build. Checked
 * against simple-icons' data before use: its `swift` entry carries no
 * `license` override, only a `guidelines` link to Apple's brand page — the
 * same shape as the `python` and `nodedotjs` entries this package already
 * ships icons for, and unlike `rust`, whose entry overrides the set's default
 * CC0-1.0 with `CC-BY-SA-4.0` (the reason cargo.ts substitutes a plain glyph
 * instead). Color is simple-icons' canonical Swift orange.
 */
const BRAND: RunnerBrand = {
  icon: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M7.508 0c-.287 0-.573 0-.86.002-.241.002-.483.003-.724.01-.132.003-.263.009-.395.015A9.154 9.154 0 0 0 4.348.15 5.492 5.492 0 0 0 2.85.645 5.04 5.04 0 0 0 .645 2.848c-.245.48-.4.972-.495 1.5-.093.52-.122 1.05-.136 1.576a35.2 35.2 0 0 0-.012.724C0 6.935 0 7.221 0 7.508v8.984c0 .287 0 .575.002.862.002.24.005.481.012.722.014.526.043 1.057.136 1.576.095.528.25 1.02.495 1.5a5.03 5.03 0 0 0 2.205 2.203c.48.244.97.4 1.498.495.52.093 1.05.124 1.576.138.241.007.483.009.724.01.287.002.573.002.86.002h8.984c.287 0 .573 0 .86-.002.241-.001.483-.003.724-.01a10.523 10.523 0 0 0 1.578-.138 5.322 5.322 0 0 0 1.498-.495 5.035 5.035 0 0 0 2.203-2.203c.245-.48.4-.972.495-1.5.093-.52.124-1.05.138-1.576.007-.241.009-.481.01-.722.002-.287.002-.575.002-.862V7.508c0-.287 0-.573-.002-.86a33.662 33.662 0 0 0-.01-.724 10.5 10.5 0 0 0-.138-1.576 5.328 5.328 0 0 0-.495-1.5A5.039 5.039 0 0 0 21.152.645 5.32 5.32 0 0 0 19.654.15a10.493 10.493 0 0 0-1.578-.138 34.98 34.98 0 0 0-.722-.01C17.067 0 16.779 0 16.492 0H7.508zm6.035 3.41c4.114 2.47 6.545 7.162 5.549 11.131-.024.093-.05.181-.076.272l.002.001c2.062 2.538 1.5 5.258 1.236 4.745-1.072-2.086-3.066-1.568-4.088-1.043a6.803 6.803 0 0 1-.281.158l-.02.012-.002.002c-2.115 1.123-4.957 1.205-7.812-.022a12.568 12.568 0 0 1-5.64-4.838c.649.48 1.35.902 2.097 1.252 3.019 1.414 6.051 1.311 8.197-.002C9.651 12.73 7.101 9.67 5.146 7.191a10.628 10.628 0 0 1-1.005-1.384c2.34 2.142 6.038 4.83 7.365 5.576C8.69 8.408 6.208 4.743 6.324 4.86c4.436 4.47 8.528 6.996 8.528 6.996.154.085.27.154.36.213.085-.215.16-.437.224-.668.708-2.588-.09-5.548-1.893-7.992z"/></svg>',
  color: '#F05138',
}

export const swiftpmProvider: RunnerProvider = {
  id: 'swiftpm',
  kind: 'parse',
  chain: CHAIN,
  brand: BRAND,
  binary: 'swift',

  async collect(ctx: ProviderContext): Promise<ProviderResult> {
    const manifests = (await ctx.files('Package.swift')).sort()
    if (manifests.length === 0) return { status: 'absent', tasks: [], diagnostics: [] }

    const tasks: Task[] = []
    for (const file of manifests) {
      const dir = dirOf(file)
      for (const verb of VERBS) {
        // SwiftPM's `--package-path` takes the PACKAGE DIRECTORY, not the
        // manifest file — unlike cargo's `--manifest-path`, which points at
        // Cargo.toml itself. `swift build`/`test`/`run --package-path <dir>`
        // resolves `<dir>/Package.swift`; passing the file path would fail.
        const argv =
          dir === '.' ? ['swift', ...verb.args] : ['swift', ...verb.args, '--package-path', dir]
        tasks.push({
          id: taskId('swiftpm', file, verb.name),
          runner: 'swiftpm',
          path: ['swiftpm', dir, verb.name],
          argv,
          cwd: '.',
          display: argv.join(' '),
          parameters: [],
          source: file,
          origin: 'synthesized',
          tags: ['swiftpm', 'swift', dir],
          persistent: { value: false, declared: false },
          executes: 'local',
        })
      }
    }

    return {
      status: 'ok',
      aspect: {
        id: 'swiftpm',
        evidence: manifests.map((f) => ({ kind: 'manifest' as const, detail: f })),
      },
      tasks,
      diagnostics: [],
    }
  },
}
