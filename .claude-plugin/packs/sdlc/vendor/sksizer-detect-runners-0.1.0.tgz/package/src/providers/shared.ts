/**
 * Helpers every provider wants, kept in one place so the heuristics do not
 * drift apart per runner.
 */

/**
 * Names that start something you then look at or interact with.
 *
 * The negative half matters as much as the positive: `storybook-build` and
 * `dev-check` both open with a runnable word and are neither. This is a GUESS —
 * `Task.persistent.declared` records whether the runner said so itself, so a
 * consumer that wants only authoritative answers can ignore this function's
 * output entirely.
 */
const RUNNABLE_NAME = /^(dev|web|serve|start|run|preview|watch|tauri|storybook)\b/
const NOT_RUNNABLE_NAME = /\b(build|check|test|lint|fmt|format|typecheck|generate|clean)\b/

export function looksPersistent(name: string): boolean {
  return RUNNABLE_NAME.test(name) && !NOT_RUNNABLE_NAME.test(name)
}

/**
 * A task's stable identity: runner, declaring file, and name.
 *
 * Stable across a re-collect so a UI keeps its selection through a refresh, and
 * so callers hold a reference rather than an index into a list that is about to
 * be rebuilt. Includes `source` because the same recipe name legitimately
 * appears in several justfiles.
 */
export function taskId(runner: string, source: string, name: string): string {
  return `${runner}:${source}:${name}`
}

/**
 * The grouping tier a source path belongs to — its parent directory.
 *
 * What makes a large monorepo scannable: `solutions/determined/apps` collects
 * that fleet under one heading instead of ninety-five names in a flat list.
 * The root itself groups under ".".
 *
 * Only a `./` prefix is stripped, never a bare leading dot: `.github/actions/x`
 * is a real directory and must group under `.github/actions`.
 */
export function tierOf(source: string): string {
  const norm = source.replace(/^\.\//, '')
  if (norm === '' || norm === '.') return '.'
  const at = norm.lastIndexOf('/')
  return at === -1 ? '.' : norm.slice(0, at)
}

/** The directory part of a root-relative file path, "." for the root. */
export function dirOf(relPath: string): string {
  const at = relPath.lastIndexOf('/')
  return at === -1 ? '.' : relPath.slice(0, at)
}
