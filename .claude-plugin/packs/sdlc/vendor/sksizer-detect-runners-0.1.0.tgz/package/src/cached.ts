/**
 * The collection layer a surface consumes: read what is stored, judge it, and
 * refresh it.
 *
 * `cache.ts` is the store — where an entry lives, how it is written, how old it
 * is. This module is the pair of verbs above it:
 *
 *   - {@link readCachedCatalog} paints something NOW. It probes nothing at all,
 *     so it costs a few file hashes and returns whatever was last measured,
 *     labelled per runner with whether it is still good.
 *   - {@link collectAndCache} probes for real and stores what came back.
 *
 * A surface runs the first, paints, then runs the second in the background and
 * repaints. That split is why `readCachedCatalog` reports a `state` per runner
 * rather than silently dropping stale rows: a stale row is the whole point —
 * an answer that was true an hour ago beats an empty screen, as long as the
 * screen says which it is.
 *
 * Nothing here is on `collect()`'s path. A caller that never reaches for these
 * two functions still gets a fresh probe every time.
 */

import { resolve } from 'node:path'

import { spawnRunnerAsync } from '@sksizer/command-seam'

import {
  CACHE_FORMAT_VERSION,
  EXEC_MAX_AGE_MS,
  estimateMs,
  isSlow,
  pushDuration,
  readEntry,
  writeEntry,
  type CacheEntry,
} from './cache.ts'
import { collect, execWithheldReport, selectProviders } from './collect.ts'
import type { CollectOptions, ProbeRecord } from './contract.ts'
import { createLister, resolveDiscovery } from './discovery.ts'
import { MAX_FINGERPRINT_FILES, fingerprint } from './fingerprint.ts'
import type { Catalog, RunnerReport } from './model.ts'
import { which as whichOnPath } from './which.ts'

/** Why a cached entry was not usable as-is. */
export type StaleReason = 'changed' | 'max-age' | 'excludes'

/**
 * Whether two recorded exclusion sets are the same. Both are sorted when
 * written, so this is an ordered comparison.
 *
 * `undefined` — an entry written before this was recorded — is NOT treated as
 * "no exclusions". That reading would call an old entry fresh under whatever
 * exclusions happen to be in force now, which is precisely the stale answer
 * this exists to prevent. It is unknown, so it does not match, so the entry is
 * re-probed once. The version bump makes this unreachable for stored entries;
 * it stays because an unknown provenance must not default to a claim.
 */
function sameExcludes(current: string[], stored: string[] | undefined): boolean {
  if (stored === undefined) return false
  return current.length === stored.length && current.every((value, i) => stored[i] === value)
}

export interface RunnerCacheState {
  runner: string
  state: 'fresh' | 'stale' | 'miss'
  /** Present only when `state` is "stale". */
  reason?: StaleReason | undefined
  /** Age of the cached probe in ms; absent on a miss. */
  ageMs?: number | undefined
  /** Expected refresh time from this repo's measured window; null when never measured. */
  estimateMs: number | null
  /** True when this repo has MEASURED this runner as slow. Never declared. */
  slow: boolean
}

export interface CachedCatalog {
  /** Paintable now. null when nothing usable was cached at all. */
  catalog: Catalog | null
  /** One per selected provider, in provider order. */
  runners: RunnerCacheState[]
  /** True when every selected provider was fresh — a refresh would change nothing. */
  allFresh: boolean
}

/**
 * Read what is cached and judge it, without probing anything.
 *
 * Never throws. Every failure below — an unreadable store, a root that cannot
 * be listed, a fingerprint that cannot be computed — degrades to a miss, which
 * is exactly the state a caller would have been in with no cache at all.
 */
export async function readCachedCatalog(
  root: string,
  options: CollectOptions,
  cacheDir: string,
): Promise<CachedCatalog> {
  const selected = selectProviders(options)
  const allMiss = (): CachedCatalog => ({
    catalog: null,
    runners: selected.map((p) => ({ runner: p.id, state: 'miss', estimateMs: null, slow: false })),
    allFresh: false,
  })

  try {
    const absRoot = resolve(root)
    const allowExec = options.allowExec ?? false
    const makeRunner = options.makeRunner ?? ((binary: string) => spawnRunnerAsync(binary))
    const which = options.which ?? whichOnPath

    // Resolved the way `collect()` resolves it, and built once: the lister is
    // memoized, so the fingerprints below share a single listing of the root
    // rather than re-walking it per provider.
    const discovery = await resolveDiscovery(
      absRoot,
      options.discovery ?? 'auto',
      makeRunner('git'),
    )
    const files = createLister(absRoot, discovery, makeRunner('git'), options.excludePaths ?? [])

    const now = Date.now()
    const runners: RunnerCacheState[] = []
    const reports: RunnerReport[] = []
    /** The `takenAt` of every CACHED report used, so the catalog can be stamped. */
    const takenAts: number[] = []

    for (const provider of selected) {
      // An exec provider under `allowExec: false` never probed and never will
      // this run, so there is nothing about it that could go stale. It is fresh
      // and carries the same withheld report `collect()` would have produced,
      // from the same helper, so the two paths cannot describe it differently.
      if (provider.kind === 'exec' && !allowExec) {
        runners.push({ runner: provider.id, state: 'fresh', estimateMs: null, slow: false })
        reports.push(execWithheldReport(provider, options.execWithheldHint, which))
        continue
      }

      const entry = await readEntry(cacheDir, absRoot, provider.id)
      if (entry === null) {
        runners.push({ runner: provider.id, state: 'miss', estimateMs: null, slow: false })
        continue
      }

      const takenAt = Date.parse(entry.takenAt)
      const ageMs = Number.isNaN(takenAt) ? 0 : now - takenAt
      const measured = {
        estimateMs: estimateMs(entry.durations ?? []),
        slow: isSlow(entry.durations ?? []),
      }

      // Recomputed against the LIVE lister from the stored path set plus every
      // pattern that built it — the provider's CURRENT watch, and the queries it
      // made on the run that produced this entry. Never the stored EXPANSION of
      // those patterns, which can only describe the world as it was.
      const current = await fingerprint({
        root: absRoot,
        paths: entry.fingerprint?.paths ?? [],
        patterns: [...(provider.watch ?? []), ...(entry.fingerprint?.patterns ?? [])],
        excludes: options.excludePaths ?? [],
        files,
      })

      let state: RunnerCacheState['state'] = 'fresh'
      let reason: StaleReason | undefined
      // Checked BEFORE the digest, because it explains the digest. Narrowing
      // the exclusions usually moves the digest too, and reporting "changed"
      // would point the user at their repository when the thing that changed
      // was their config file.
      //
      // Widening them is the case that needs this at all: excluding a tree the
      // provider had read leaves every recorded path in place with its bytes
      // untouched, so the digest matches, the entry reads fresh, and the tasks
      // just excluded keep being served until something unrelated moves.
      if (!sameExcludes(current.excludes, entry.fingerprint?.excludes)) {
        state = 'stale'
        reason = 'excludes'
      } else if (current.digest !== entry.fingerprint?.digest) {
        state = 'stale'
        reason = 'changed'
      } else if (provider.kind === 'exec' && ageMs > EXEC_MAX_AGE_MS) {
        // Only exec entries get a max age. A parse provider reads every byte it
        // depends on through `ctx`, and its queried patterns are re-expanded on
        // every read, so the digest covers both the files it opened and files
        // that have appeared since matching the same query; expiring such an
        // entry would re-pay a probe for an answer that is almost always
        // identical. An exec provider's tool merges files it never opens, so a
        // matching digest is a signal rather than a proof — the age is the
        // backstop for what the fingerprint cannot see.
        state = 'stale'
        reason = 'max-age'
      }

      runners.push({ runner: provider.id, state, reason, ageMs, ...measured })

      // Stale reports are kept, not dropped. A row a caller is told is stale is
      // the reason this function exists.
      reports.push(entry.report)
      if (!Number.isNaN(takenAt)) takenAts.push(takenAt)
    }

    // The catalog is only as fresh as its STALEST row. Stamping `now` would
    // claim a freshness the oldest contributing probe does not have, and every
    // UI that prints `generatedAt` would repeat that claim. `now` is used only
    // when nothing cached contributed a time at all — a catalog of withheld
    // rows, which really was synthesized this instant.
    const oldest = takenAts.length === 0 ? now : Math.min(...takenAts)

    return {
      catalog:
        reports.length === 0
          ? null
          : {
              root: absRoot,
              generatedAt: new Date(oldest).toISOString(),
              discovery,
              allowExec,
              reports,
            },
      runners,
      allFresh: runners.every((r) => r.state === 'fresh'),
    }
  } catch {
    return allMiss()
  }
}

/**
 * Probe for real and write what came back to the cache.
 *
 * The returned catalog is `collect()`'s, untouched but for a truncation
 * diagnostic: caching is a side effect here, never a filter on the answer.
 */
export async function collectAndCache(
  root: string,
  options: CollectOptions,
  cacheDir: string,
): Promise<Catalog> {
  const probes: ProbeRecord[] = []
  const callerObserver = options.probeObserver

  const catalog = await collect(root, {
    ...options,
    probeObserver: (probe) => {
      probes.push(probe)
      // Chained, not replaced: a caller that wanted the probe records asked
      // first, and this layer must not eat their seam.
      callerObserver?.(probe)
    },
  })

  const truncated = new Set<string>()
  for (const probe of probes) {
    // Cache writes are BEST-EFFORT and never fail the collect. A store that
    // cannot be written — read-only home, full disk, a racing sweep — costs the
    // next run some time and nothing else; the catalog in hand is already
    // correct, and throwing here would turn a lost optimization into a lost
    // answer.
    try {
      // `probe.files` is the run's own memoized lister, so re-expanding the
      // patterns here costs no second walk of the root.
      const print = await fingerprint({
        root: catalog.root,
        paths: probe.reads,
        patterns: [...probe.watch, ...probe.queries],
        excludes: options.excludePaths ?? [],
        files: probe.files,
      })
      if (print.truncated) truncated.add(probe.runner)

      const previous = await readEntry(cacheDir, catalog.root, probe.runner)
      const entry: CacheEntry = {
        version: CACHE_FORMAT_VERSION,
        root: catalog.root,
        provider: probe.runner,
        kind: probe.kind,
        takenAt: new Date().toISOString(),
        probeMs: probe.durationMs,
        durations: pushDuration(previous, probe.durationMs),
        fingerprint: print,
        report: probe.report,
      }
      // `writeEntry` already refuses errored and withheld reports.
      await writeEntry(cacheDir, entry)
    } catch {
      // Deliberately empty — see above.
    }
  }

  if (truncated.size === 0) return catalog

  // A truncated fingerprint can miss a change beyond the cap, so a later read
  // would call this entry fresh when it is not. Saying so is the difference
  // between a known limit and an unexplained wrong answer.
  return {
    ...catalog,
    reports: catalog.reports.map((report) =>
      truncated.has(report.runner)
        ? {
            ...report,
            diagnostics: [
              ...report.diagnostics,
              {
                severity: 'info' as const,
                message:
                  `${report.runner}: fingerprint covers only the first ` +
                  `${MAX_FINGERPRINT_FILES} files, so a later change beyond that ` +
                  `cap may leave the cached result looking fresh`,
              },
            ],
          }
        : report,
    ),
  }
}
