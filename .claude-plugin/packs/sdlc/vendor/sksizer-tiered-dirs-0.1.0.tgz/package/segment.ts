import { TieredDirsError } from './errors.ts'

/** A path segment: a letter/digit, then letters/digits and `._-`. */
const SEGMENT = /^[a-z0-9][a-z0-9._-]*$/i

/**
 * Whether `key` is a safe single path segment.
 *
 * The regex alone still admits `a..b`, so the separator and `..` rejections
 * stay explicit. The Rust twin's `is_valid_segment` is the same predicate.
 */
export function isValidSegment(key: string): boolean {
  if (key === '') return false
  if (key.includes('/') || key.includes('\\') || key.includes('..')) return false
  return SEGMENT.test(key)
}

/**
 * Throw unless `key` is a safe single path segment. `kind` names the argument
 * in the message — `vendor`, `suite`, `scope kind`, `scope`, `app` — matching
 * the Rust twin's `check_key`.
 */
export function assertSegment(kind: string, key: string): void {
  if (!isValidSegment(key)) {
    throw new TieredDirsError(
      `invalid ${kind} key ${JSON.stringify(key)}: want a leading letter/digit ` +
        'then ._-, no path separator or ".."',
    )
  }
}
