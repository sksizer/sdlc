import { homedir, tmpdir, userInfo } from 'node:os'
import { join } from 'node:path'

import { TieredDirsError } from './errors.ts'

/**
 * The horizontal axis: how durable a piece of state is. The vertical axis —
 * who shares it — is the tier (see `tiered-dirs.ts`).
 *
 * A caller names both: `suite('notes').cache()`.
 */
export type Home = 'durable' | 'config' | 'cache' | 'logs' | 'runtime'

/** Every {@link Home}, in table order. */
export const HOMES: readonly Home[] = ['durable', 'config', 'cache', 'logs', 'runtime']

/**
 * The per-OS roots the whole package is built on.
 *
 * This is the injectable seam. Nothing below it reads the environment: a
 * `TieredDirs` resolves its roots once, at construction, and every path after that
 * is pure string work. That is what lets the two arms of a nitro app share one
 * SDK call — the CLI arm builds these from the environment, the server arm
 * hands in roots it got from `useRuntimeConfig()`, because nitro breaks
 * `import.meta.url` and the server arm has no environment to read.
 */
export interface BaseDirs {
  /** Long-lived state that must survive a cache purge. */
  durable: string
  /** User-editable configuration. */
  config: string
  /** Regenerable data. The OS may delete this at any time. */
  cache: string
  /** Log files. Never folded into `cache` — the OS purges cache. */
  logs: string
  /** Pidfiles, sockets, locks. Never under `cache`; see {@link systemBaseDirs}. */
  runtime: string
  /**
   * The platform temp directory. Not a {@link Home}: nothing here outlives the
   * call that wrote it, so it is untiered and reached through `TieredDirs.scratch()`
   * rather than through a tier.
   */
  scratch: string
}

/** Every key of {@link BaseDirs}: the five homes plus `scratch`. */
const BASE_DIR_KEYS: readonly (keyof BaseDirs)[] = [...HOMES, 'scratch']

/** Directory name for runtime state where the platform offers none (trap 2). */
const RUNTIME_FALLBACK_SEGMENT = 'run'

/**
 * The names of the environment variables that move base directories. Build one
 * with {@link envVars}, which derives every name from a prefix.
 */
export interface EnvVars {
  /**
   * Moves every base directory not moved by its own variable into the
   * {@link rootedBaseDirs} layout under the named root.
   */
  readonly root: string
  /** The variable that moves one base directory. */
  readonly dirs: Readonly<Record<keyof BaseDirs, string>>
  /**
   * When set (non-empty), {@link systemBaseDirs} throws instead of falling back
   * to an OS home. A test runner sets it, and a child process inherits it.
   */
  readonly requireOverride: string
}

/**
 * {@link EnvVars} named from one prefix: `<P>_ROOT`, `<P>_DURABLE_DIR`,
 * `<P>_CONFIG_DIR`, `<P>_CACHE_DIR`, `<P>_LOGS_DIR`, `<P>_RUNTIME_DIR`,
 * `<P>_SCRATCH_DIR` and `<P>_REQUIRE_OVERRIDE`. The Rust twin's `env_vars!`
 * derives the same names.
 */
export function envVars(prefix: string): EnvVars {
  return Object.freeze({
    root: `${prefix}_ROOT`,
    dirs: Object.freeze({
      durable: `${prefix}_DURABLE_DIR`,
      config: `${prefix}_CONFIG_DIR`,
      cache: `${prefix}_CACHE_DIR`,
      logs: `${prefix}_LOGS_DIR`,
      runtime: `${prefix}_RUNTIME_DIR`,
      scratch: `${prefix}_SCRATCH_DIR`,
    }),
    requireOverride: `${prefix}_REQUIRE_OVERRIDE`,
  })
}

/**
 * Every variable that moves a base directory: the root and the six
 * per-directory names. Excludes {@link EnvVars.requireOverride}, which moves
 * nothing.
 */
export function overrideVars(vars: EnvVars): readonly string[] {
  return [vars.root, ...BASE_DIR_KEYS.map((key) => vars.dirs[key])]
}

/**
 * Every base directory under one stub root: `<root>/durable`, `<root>/config`,
 * `<root>/cache`, `<root>/logs`, `<root>/scratch`, and runtime at
 * `<root>/durable/run`.
 *
 * The test and parity-fixture seam, and the layout {@link EnvVars.root} selects. The
 * Rust twin's `BaseDirs::rooted` has the same layout, so a fixture row asserts
 * identical absolute paths on both arms.
 */
export function rootedBaseDirs(root: string): BaseDirs {
  const durable = join(root, 'durable')
  return {
    durable,
    config: join(root, 'config'),
    cache: join(root, 'cache'),
    logs: join(root, 'logs'),
    runtime: join(durable, RUNTIME_FALLBACK_SEGMENT),
    scratch: join(root, 'scratch'),
  }
}

/** Inputs for {@link systemBaseDirs}. Every one is optional and injectable. */
export interface SystemBaseDirsOptions {
  /** Defaults to `process.platform`. */
  platform?: string
  /**
   * Defaults to `process.env`. Injecting this means the supplied environment
   * is the whole story: the host's real home directory is not consulted. The
   * override variables are read from it too.
   */
  env?: Record<string, string | undefined>
  /** Home directory. Overrides `HOME` / `USERPROFILE` when given. */
  home?: string
  /**
   * Replace individual roots, ahead of the environment. An overridden root is
   * taken as-is and needs no home directory. It is not a base for the others:
   * overriding `durable` here leaves `runtime` and `logs` where the
   * environment and the per-OS table put them.
   */
  overrides?: Partial<BaseDirs>
}

/**
 * Resolve the base directories. Each takes the first answer in this order:
 *
 * 1. `opts.overrides`.
 * 2. The root's own variable, `vars.dirs[key]` ({@link EnvVars.dirs}).
 * 3. `vars.root` ({@link EnvVars.root}) — the {@link rootedBaseDirs} layout.
 * 4. The per-OS table below.
 *
 * Runtime follows durable: when the runtime variable is unset but durable is
 * moved by step 2 or 3, runtime is `<durable>/run`, never the OS runtime
 * directory. An empty variable counts as unset; a relative one throws. The
 * Rust twin's `BaseDirs::from_env` resolves steps 2–4 the same way, held to it
 * by the parity fixture's `env_cases`.
 *
 * The per-OS table this package owns so no caller has to.
 *
 * | home    | macOS                          | Linux/other                     | Windows              |
 * |---------|--------------------------------|---------------------------------|----------------------|
 * | durable | `~/Library/Application Support`| `$XDG_DATA_HOME`, `~/.local/share` | `%APPDATA%`, `<home>/AppData/Roaming` |
 * | config  | `~/Library/Application Support`| `$XDG_CONFIG_HOME`, `~/.config` | `%APPDATA%`, `<home>/AppData/Roaming` |
 * | cache   | `~/Library/Caches`             | `$XDG_CACHE_HOME`, `~/.cache`   | `%LOCALAPPDATA%`, `<home>/AppData/Local` |
 * | logs    | `~/Library/Logs`               | `$XDG_STATE_HOME`, `~/.local/state` | `<durable>/logs` |
 * | runtime | `<durable>/run`                | `$XDG_RUNTIME_DIR`, `<durable>/run` | `<durable>/run`  |
 * | scratch | `$TMPDIR`, `/tmp`              | `$TMPDIR`, `/tmp`               | `%TEMP%`, `%TMP%`, `<home>/AppData/Local/Temp` |
 *
 * Two of those cells are traps the table exists to absorb:
 *
 * - `logs` has no cross-platform library equivalent. macOS wants
 *   `~/Library/Logs`; where the OS offers nothing, logs land at
 *   `<durable>/logs`. They are never folded into `cache`.
 * - `runtime` only exists on Linux, and only when `XDG_RUNTIME_DIR` is set.
 *   Everywhere else it resolves under `<durable>/run` — deliberately not under
 *   cache, because the OS may purge cache while the process a pidfile
 *   describes is still alive.
 *
 * `scratch` is resolved from the injected environment rather than by calling
 * `os.tmpdir()`, which reads the real `process.env` and would make an injected
 * environment stop being the whole story. The Rust twin asks its own platform
 * the same question; the two roots need not match, because parity pins only
 * what sits below a root.
 *
 * Throws {@link TieredDirsError} when a root falls back to the home directory and
 * none can be found, or when an override variable is not absolute. Headless
 * CI and sandboxes do not always have a home directory.
 *
 * Two test rules run first, and only when neither `env` nor `home` is
 * injected (an injected environment is the whole story):
 *
 * - In a test runner process with the root variable unset and `HOME` not
 *   moved, the root reads as `<tmp>/tiered-dirs-test-<pid>-<start ms>`, unique per
 *   process. A test runner process has a test file as its entry point and runs
 *   under bun, `NODE_ENV=test` or `NODE_TEST_CONTEXT` (set by `node --test`).
 *   Bun counts on its own because `bun test` keeps a `NODE_ENV` that is already
 *   set. A child a test spawns has a different entry point, so it gets no
 *   default. A test that points `HOME` at a fixture, in-process or for a child,
 *   keeps it.
 * - With {@link EnvVars.requireOverride} set, a root that would fall back to
 *   the per-OS table throws a {@link TieredDirsError} naming the fix.
 *
 * The Rust twin's `BaseDirs::from_env` applies the same two rules; it detects a
 * test by its cargo test binary rather than by the environment.
 */
export function systemBaseDirs(vars: EnvVars, opts: SystemBaseDirsOptions = {}): BaseDirs {
  const platform = opts.platform ?? process.platform
  const over = stripUndefined(opts.overrides ?? {})
  const env =
    opts.env === undefined && opts.home === undefined
      ? guardedEnv(vars, process.env, over)
      : (opts.env ?? process.env)

  let cachedHome: string | undefined
  const home = (): string => (cachedHome ??= resolveHome(opts, platform, env))

  const fromEnv = envOverrides(vars, env, platform)
  const table = platformTable(platform, env, home)
  const roots = {} as BaseDirs
  for (const key of BASE_DIR_KEYS) {
    roots[key] = over[key] ?? fromEnv[key] ?? table[key]()
  }
  return roots
}

/**
 * The process environment with the test rules of {@link systemBaseDirs}
 * applied: the root variable filled in for a test, or a throw when
 * {@link EnvVars.requireOverride} forbids an OS fallback.
 */
function guardedEnv(
  vars: EnvVars,
  env: Record<string, string | undefined>,
  overrides: Partial<BaseDirs>,
): Record<string, string | undefined> {
  if (env[vars.root]) return env
  if (isTestRunnerProcess(env) && !homeMoved(env)) {
    return { ...env, [vars.root]: testRoot() }
  }
  if (env[vars.requireOverride]) {
    // Runtime follows a moved durable, so it needs no variable of its own.
    const required = BASE_DIR_KEYS.filter((key) => key !== 'runtime' && !overrides[key])
    const missing = required.find((key) => !env[vars.dirs[key]])
    if (missing !== undefined) {
      throw new TieredDirsError(
        `${vars.requireOverride} is set but neither ${vars.root} nor ${vars.dirs[missing]} is: ` +
          `set ${vars.root} to a scratch directory, or build from rootedBaseDirs`,
      )
    }
  }
  return env
}

/**
 * This process's scratch root. The start time keeps a later process that
 * reuses the pid off this one's leftover state.
 */
let processTestRoot: string | undefined
function testRoot(): string {
  return (processTestRoot ??= join(tmpdir(), `tiered-dirs-test-${process.pid}-${Date.now()}`))
}

/** A test file name: `*.test.ts`, `*_spec.mjs`, and the like. */
const TEST_FILE = /[._](test|spec)\.[cm]?[jt]sx?$/

/** Whether this process is a test runner running a test file (see {@link systemBaseDirs}). */
function isTestRunnerProcess(env: Record<string, string | undefined>): boolean {
  const runner =
    process.versions.bun !== undefined ||
    env['NODE_ENV'] === 'test' ||
    Boolean(env['NODE_TEST_CONTEXT'])
  return runner && TEST_FILE.test(process.argv[1] ?? '')
}

/**
 * Whether `HOME` differs from the user's home as the runtime reports it: the
 * passwd entry under node, the `HOME` the process started with under bun.
 */
function homeMoved(env: Record<string, string | undefined>): boolean {
  const home = env['HOME']
  if (!home) return false
  try {
    return home !== userInfo().homedir
  } catch {
    return false
  }
}

/** Steps 2 and 3 of {@link systemBaseDirs}: the roots the environment moves. */
function envOverrides(
  vars: EnvVars,
  env: Record<string, string | undefined>,
  platform: string,
): Partial<BaseDirs> {
  const read = (name: string): string | undefined => {
    const value = env[name]
    if (!value) return undefined
    if (!isAbsolutePath(value, platform)) {
      throw new TieredDirsError(`${name} must be an absolute path`)
    }
    return value
  }
  const rootValue = read(vars.root)
  const rooted = rootValue === undefined ? undefined : rootedBaseDirs(rootValue)
  const out: Partial<BaseDirs> = {}
  for (const key of BASE_DIR_KEYS) {
    if (key === 'runtime') continue
    const value = read(vars.dirs[key]) ?? rooted?.[key]
    if (value !== undefined) out[key] = value
  }
  const runtime =
    read(vars.dirs.runtime) ??
    (out.durable === undefined ? undefined : join(out.durable, RUNTIME_FALLBACK_SEGMENT))
  if (runtime !== undefined) out.runtime = runtime
  return out
}

/**
 * The per-OS table, one thunk per root. Deferred so that an overridden root
 * skips its cell, and with it the home lookup that cell would have made.
 */
function platformTable(
  platform: string,
  env: Record<string, string | undefined>,
  home: () => string,
): Record<keyof BaseDirs, () => string> {
  const posixScratch = (): string => absoluteEnv(env, 'TMPDIR', platform) ?? '/tmp'

  if (platform === 'darwin') {
    const support = (): string => join(home(), 'Library', 'Application Support')
    return {
      durable: support,
      config: support,
      cache: () => join(home(), 'Library', 'Caches'),
      logs: () => join(home(), 'Library', 'Logs'),
      runtime: () => join(support(), RUNTIME_FALLBACK_SEGMENT),
      scratch: posixScratch,
    }
  }

  if (platform === 'win32') {
    const roaming = (): string =>
      absoluteEnv(env, 'APPDATA', platform) ?? join(home(), 'AppData', 'Roaming')
    return {
      durable: roaming,
      config: roaming,
      cache: () => absoluteEnv(env, 'LOCALAPPDATA', platform) ?? join(home(), 'AppData', 'Local'),
      logs: () => join(roaming(), 'logs'),
      runtime: () => join(roaming(), RUNTIME_FALLBACK_SEGMENT),
      scratch: () =>
        absoluteEnv(env, 'TEMP', platform) ??
        absoluteEnv(env, 'TMP', platform) ??
        join(home(), 'AppData', 'Local', 'Temp'),
    }
  }

  const durable = (): string =>
    absoluteEnv(env, 'XDG_DATA_HOME', platform) ?? join(home(), '.local', 'share')
  return {
    durable,
    config: () => absoluteEnv(env, 'XDG_CONFIG_HOME', platform) ?? join(home(), '.config'),
    cache: () => absoluteEnv(env, 'XDG_CACHE_HOME', platform) ?? join(home(), '.cache'),
    logs: () => absoluteEnv(env, 'XDG_STATE_HOME', platform) ?? join(home(), '.local', 'state'),
    runtime: () =>
      absoluteEnv(env, 'XDG_RUNTIME_DIR', platform) ?? join(durable(), RUNTIME_FALLBACK_SEGMENT),
    scratch: posixScratch,
  }
}

function resolveHome(
  opts: SystemBaseDirsOptions,
  platform: string,
  env: Record<string, string | undefined>,
): string {
  if (opts.home !== undefined) {
    if (opts.home === '') {
      throw new TieredDirsError('home must be a non-empty path')
    }
    return opts.home
  }

  const fromEnv = env['HOME'] || (platform === 'win32' ? env['USERPROFILE'] : undefined)
  if (fromEnv) return fromEnv

  // An injected environment is the whole story — falling back to the host's
  // real home here would make a test's paths depend on the machine running it.
  if (opts.env !== undefined) {
    throw new TieredDirsError(
      'no home directory: the supplied environment sets neither HOME nor USERPROFILE',
    )
  }

  let host = ''
  try {
    host = homedir()
  } catch {
    host = ''
  }
  if (host) return host

  throw new TieredDirsError(
    'no home directory: HOME is unset and the OS reports none — pass `home` or `overrides`',
  )
}

/**
 * An environment variable, honoured only when it names an absolute path.
 * The XDG spec says a relative value is invalid and must be ignored.
 */
function absoluteEnv(
  env: Record<string, string | undefined>,
  key: string,
  platform: string,
): string | undefined {
  const value = env[key]
  if (!value) return undefined
  return isAbsolutePath(value, platform) ? value : undefined
}

/** `path.isAbsolute` for a named platform rather than the host's. */
function isAbsolutePath(value: string, platform: string): boolean {
  if (platform === 'win32') {
    return /^[a-z]:[\\/]/i.test(value) || value.startsWith('\\\\') || value.startsWith('//')
  }
  return value.startsWith('/')
}

/** Drop explicit `undefined` entries so an override cannot blank out a root. */
function stripUndefined(overrides: Partial<BaseDirs>): Partial<BaseDirs> {
  const out: Partial<BaseDirs> = {}
  for (const key of BASE_DIR_KEYS) {
    const value = overrides[key]
    if (value !== undefined) out[key] = value
  }
  return out
}
