# @sksizer/tiered-dirs

One answer to "where does this state live?" for every product a vendor ships.

Two axes. The **tier** says who shares the state. The **home** says how durable
it is. A caller names both.

```ts
import { TieredDirs, envVars } from '@sksizer/tiered-dirs';

const dirs = TieredDirs.fromEnv('com.example', envVars('EXAMPLE'));

dirs.vendor().config().path;
// ~/Library/Application Support/com.example

dirs.suite('notes').cache().scoped('vaults', vaultId).app('search').path;
// ~/Library/Caches/com.example.notes/vaults/<vaultId>/search
```

## Tiers

| tier | segment | shared by |
|---|---|---|
| vendor | `<vendor>` | every product line the vendor ships |
| suite | `<vendor>.<suiteKey>` | the products that share user data |
| standalone | `<tool>` | one general tool, shipped outside the suite |

The vendor is the one segment the caller fixes up front. The suite segment is
composed from it. `suiteKey` is a caller-supplied constant, not derived from a
bundle identifier, because bundle identifiers carry brand and product segments
that change on their own schedule. `Tier.kind` reports which constructor
produced a tier.

The product tier — one product's own directory, keyed by bundle identifier — is
not here. An app framework such as Tauri usually resolves it, and this package
takes no framework dependency. `TieredDirs.isVendorBundleId(bundleId)` lets a
layer above check that a product's bundle id sits under the vendor.

**Tiers are distinct addresses and there is no merge.** `vendor().durable()`,
`suite(k).durable()` and `standalone(t).durable()` are different locations. This
package never reads two and merges them. A given piece of state lives at
exactly one tier and the caller names the tier it means.

### A general tool supplies its own root

The vendor and suite tiers govern a SUITE: products that share one owner. A
general tool the vendor ships into other people's repositories is not in that
suite, and `suite('tool')` would write the vendor's namespace onto a stranger's
machine.

`standalone(tool)` is the tier for that tool. Its segment is the bare tool name
— `~/.config/<tool>`, what a general CLI idiomatically owns — with no vendor
composition.

```ts
dirs.standalone('tool').config().path; // ~/.config/tool
```

## Homes

| home | macOS | Linux/other | Windows |
|---|---|---|---|
| durable | `~/Library/Application Support` | `$XDG_DATA_HOME`, `~/.local/share` | `%APPDATA%` |
| config | `~/Library/Application Support` | `$XDG_CONFIG_HOME`, `~/.config` | `%APPDATA%` |
| cache | `~/Library/Caches` | `$XDG_CACHE_HOME`, `~/.cache` | `%LOCALAPPDATA%` |
| logs | `~/Library/Logs` | `$XDG_STATE_HOME`, `~/.local/state` | `<durable>/logs` |
| runtime | `<durable>/run` | `$XDG_RUNTIME_DIR`, `<durable>/run` | `<durable>/run` |

`logs` never falls back to `cache` — the OS purges cache. `runtime` sits under
`durable` for the same reason: the OS may purge cache while the process a
pidfile describes is still alive.

## Overrides and scratch roots

Every base directory can be moved by environment variable, so a test or harness
can run a whole app inside one scratch root. The caller picks the names:
`envVars('EXAMPLE')` reads `EXAMPLE_ROOT`, `EXAMPLE_<HOME>_DIR`,
`EXAMPLE_SCRATCH_DIR` and `EXAMPLE_REQUIRE_OVERRIDE`. Per base directory, the
first answer wins:

| order | source | effect |
|---|---|---|
| 1 | `<P>_<HOME>_DIR` | moves one: `<P>_DURABLE_DIR`, `<P>_CONFIG_DIR`, `<P>_CACHE_DIR`, `<P>_LOGS_DIR`, `<P>_RUNTIME_DIR`, `<P>_SCRATCH_DIR` |
| 2 | `<P>_ROOT` | the rooted layout: `<root>/durable`, `<root>/config`, `<root>/cache`, `<root>/logs`, `<root>/scratch`, runtime at `<root>/durable/run` |
| 3 | the OS default | the table above |

Runtime follows durable: when `<P>_RUNTIME_DIR` is unset but durable is moved by
step 1 or 2, runtime is `<durable>/run`. An empty variable counts as unset; a
relative one is an error. `opts.overrides` on `systemBaseDirs` sits ahead of all
three.

### Tests never resolve a real home

When neither `env` nor `home` is injected, `systemBaseDirs` applies two rules
first:

- In a test runner process (a test file as its entry point, under bun,
  `NODE_ENV=test` or `NODE_TEST_CONTEXT`) where `<P>_ROOT` is unset and `HOME`
  is not moved, `<P>_ROOT` reads as `<tmp>/tiered-dirs-test-<pid>-<start ms>`.
  Plain `bun test` needs no setup, and a test that points `HOME` at a fixture
  keeps it. A child a test spawns gets no default.
- With `<P>_REQUIRE_OVERRIDE` set, a root that would fall back to the per-OS
  table throws a `TieredDirsError` naming the fix.

## Scratch

`scratch()` returns the platform temp directory: `$TMPDIR` or `/tmp`, and
`%TEMP%` / `%TMP%` on Windows. It adds nothing to the platform answer, which is
the point — "no direct OS path call outside this package" becomes greppable
instead of a rule with exceptions.

Scratch is not a `Home` and not a tier. It holds state that does not outlive a
single call; the `runtime` home holds state that does and describes a live
process — a pidfile, a socket, a lock.

## Injectable roots

Nothing below `systemBaseDirs` reads the environment. A `TieredDirs` resolves
its roots once, at construction, and every path after that is pure string
work. A server that cannot read the environment hands in roots from its own
config:

```ts
const dirs = new TieredDirs('com.example', config.bases);
```

Tests use the same seam to assert exact paths without touching a real home
directory.

## Failure

Every base directory can fail to resolve; headless CI and sandboxes do not
always have a home. `systemBaseDirs` and `TieredDirs.fromEnv` throw
`TieredDirsError` rather than assert, and `overrides` rescues an environment
with no home at all.

## Parity

This package is the twin of the Rust `tiered-dirs` crate. `tests/fixtures/parity.json`
is the contract between them: a table of (tier, home, scope, app) to expected
relative path, a `scratch_cases` list for the scratch root, and `env_cases` for
the override order, read by both with base directories stubbed —
`rootedBaseDirs('/stub')` here, `BaseDirs::rooted("/stub")` there. Neither twin
may add a path shape the other lacks.

## API

```ts
function envVars(prefix: string): EnvVars;
function overrideVars(vars: EnvVars): readonly string[];
interface EnvVars {
  root: string;
  dirs: Record<keyof BaseDirs, string>;
  requireOverride: string;
}

function isValidSegment(key: string): boolean;

type Home = 'durable' | 'config' | 'cache' | 'logs' | 'runtime';
const HOMES: readonly Home[];
type TierKind = 'vendor' | 'suite' | 'standalone';
const TIER_KINDS: readonly TierKind[];
interface BaseDirs { durable; config; cache; logs; runtime; scratch: string }
interface SystemBaseDirsOptions {
  platform?: string;
  env?: Record<string, string | undefined>;
  home?: string;
  overrides?: Partial<BaseDirs>;
}
function systemBaseDirs(vars: EnvVars, opts?: SystemBaseDirsOptions): BaseDirs;
function rootedBaseDirs(root: string): BaseDirs;

class TieredDirs {
  constructor(vendor: string, bases: BaseDirs);
  static fromEnv(vendor: string, vars: EnvVars, opts?: SystemBaseDirsOptions): TieredDirs;
  readonly vendorName: string;
  readonly bases: Readonly<BaseDirs>;
  vendor(): Tier;
  suite(suiteKey: string): Tier;
  standalone(tool: string): Tier;
  scratch(): Dir;
}

class Tier {
  readonly segment: string;
  readonly kind: TierKind;
  durable(): Dir;
  config(): Dir;
  cache(): Dir;
  logs(): Dir;
  runtime(): Dir;
  home(home: Home): Dir;
}

class Dir {
  readonly base: string;
  readonly segments: readonly string[];
  get path(): string;      // absolute, host separator
  get relative(): string;  // below the base, always "/"-separated
  scoped(kind: string, key: string): Dir;
  app(app: string): Dir;
}

class TieredDirsError extends Error {}
```

`vendor`, `suiteKey`, `tool`, `kind`, `key` and `app` are each validated as a
single path segment: non-empty, no separator, no `..`, matching
`^[a-z0-9][a-z0-9._-]*$/i`. An invalid one throws `TieredDirsError`.

## Resolving the package

```json
"exports": { ".": { "bun": "./index.ts", "node": "./index.ts",
                    "types": "./dist/index.d.ts", "default": "./dist/index.js" } }
```

Both `bun` and `node` resolve the TypeScript source. Bun runs it directly; node
strips the types (on by default since 23.6). `default` keeps the compiled
output for bundlers and for any consumer that is neither.
