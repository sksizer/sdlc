/**
 * Helpers over the shared result vocabulary — the reads every caller of a
 * capture door otherwise re-derives from {@link CommandResult}: "did it run
 * and succeed", "what do I tell a human", "give me its stdout as JSON".
 *
 * Everything here is non-throwing, matching the capture doors: a failure
 * stays a value the caller reads. Use `runChecked` when abort-on-failure is
 * the only sane handling.
 */

import type { AsyncCommandRunner, AsyncCommandRunOptions } from './async.ts'
import type { CommandResult, CommandRunner, CommandRunOptions } from './sync.ts'

/**
 * The process actually started and exited 0. `exitCode` alone is not enough:
 * a spawn failure, timeout or abort reports the seam's stand-in `1`, and a
 * caller that reads exit codes as answers must rule that out first.
 */
export function ran(result: CommandResult): boolean {
  return result.neverExited !== true && result.exitCode === 0
}

/**
 * The failure text to show a human: trimmed stderr, else trimmed stdout (some
 * commands explain a failure there), else `exit N`. Unlike
 * `CommandFailed.detail` it picks ONE stream — the right shape for a
 * one-line message; use `detail` when both halves matter.
 */
export function failureText(result: CommandResult): string {
  return result.stderr.trim() || result.stdout.trim() || `exit ${result.exitCode}`
}

/**
 * The first non-blank line of `text`, trimmed; `fallback` when there is
 * none. For compact diagnostics from multi-line tool output.
 */
export function firstLine(text: string, fallback = ''): string {
  return (
    text
      .split('\n')
      .map((l) => l.trim())
      .find((l) => l !== '') ?? fallback
  )
}

/** Outcome of {@link runJson}: a parsed value, or why there is none. */
export type JsonRun<T> =
  | { ok: true; value: T; result: CommandResult }
  | {
      ok: false
      /** `failed`: did not run or exited non-zero. `unparseable`: ran, stdout was not JSON. */
      reason: 'failed' | 'unparseable'
      /** A human-readable explanation (the failure text, or the parse error). */
      message: string
      result: CommandResult
    }

/** Options for {@link runJson}. */
export interface RunJsonOptions {
  /**
   * Skip LEADING non-JSON output (log lines, banners). Tries each line that
   * starts at column 0 with `{` or `[`, in order, and takes the first suffix
   * of stdout that parses, so a `[INFO] ...` prefix is skipped too. Trailing
   * output is not handled. Off by default: strict `JSON.parse` of the whole
   * stdout.
   */
  tolerateLeadingLog?: boolean | undefined
}

/**
 * Parse a finished run's stdout as JSON, gated on {@link ran}. `T` is the
 * caller's claim about the shape — it is NOT validated; run the value through
 * a schema when the producer is not trusted.
 */
export function parseJsonResult<T = unknown>(
  result: CommandResult,
  opts: RunJsonOptions = {},
): JsonRun<T> {
  if (!ran(result)) {
    return { ok: false, reason: 'failed', message: failureText(result), result }
  }
  const parsed = tryParse<T>(result.stdout, opts.tolerateLeadingLog === true)
  if (parsed.ok) return { ok: true, value: parsed.value, result }
  return {
    ok: false,
    reason: 'unparseable',
    message: `stdout is not JSON: ${parsed.error}`,
    result,
  }
}

function tryParse<T>(
  stdout: string,
  tolerateLeadingLog: boolean,
): { ok: true; value: T } | { ok: false; error: string } {
  const starts = [0]
  if (tolerateLeadingLog) {
    for (const m of stdout.matchAll(/^[{[]/gm)) if (m.index > 0) starts.push(m.index)
  }
  let error = ''
  for (const start of starts) {
    try {
      return { ok: true, value: JSON.parse(stdout.slice(start)) as T }
    } catch (e) {
      if (start === 0) error = (e as Error).message
    }
  }
  return { ok: false, error }
}

/** Run on the sync door, then {@link parseJsonResult}. Never throws. */
export function runJson<T = unknown>(
  runner: CommandRunner,
  argv: string[],
  opts: CommandRunOptions & RunJsonOptions,
): JsonRun<T> {
  const { tolerateLeadingLog, ...run } = opts
  return parseJsonResult<T>(runner.run(argv, run), { tolerateLeadingLog })
}

/** Async twin of {@link runJson}. */
export async function runJsonAsync<T = unknown>(
  runner: AsyncCommandRunner,
  argv: string[],
  opts: AsyncCommandRunOptions & RunJsonOptions,
): Promise<JsonRun<T>> {
  const { tolerateLeadingLog, ...run } = opts
  return parseJsonResult<T>(await runner.run(argv, run), { tolerateLeadingLog })
}
