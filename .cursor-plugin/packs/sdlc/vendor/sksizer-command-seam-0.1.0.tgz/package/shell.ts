/**
 * The shell door — the ONE place a shell string is executed.
 *
 * Every other door passes argv straight to a binary, so nothing is ever parsed
 * as shell. A configured verb (`bun install --filter '@x/y'`, `a && b`) is the
 * exception: it is a shell string by construction, and it runs as
 * `sh -c <verb>`. That call used to be hand-built at each site; it lives here
 * so "which callers interpret a string as shell" is one grep, and so the
 * invocation (binary, flag, positional-arg layout) cannot drift between them.
 *
 * Built on the capture doors, so it shares their vocabulary
 * ({@link CommandResult}, {@link CommandRunOptions}, `CommandFailed`) and
 * inherits their timeout, env and stdin handling.
 */

import { spawnRunnerAsync, type AsyncCommandRunner, type AsyncCommandRunOptions } from './async.ts'
import {
  spawnRunner,
  type CommandResult,
  type CommandRunner,
  type CommandRunOptions,
} from './sync.ts'

/**
 * Positional parameters for the verb. `args` are visible to it as `$1`, `$2`,
 * …; `name` is its `$0` (default `sh`). Both ride as separate argv entries,
 * never spliced into the string, so they are inert data.
 */
export interface ShellPositionals {
  name?: string | undefined
  args?: readonly string[] | undefined
}

/** {@link CommandRunOptions} plus {@link ShellPositionals}. */
export interface ShellRunOptions extends CommandRunOptions, ShellPositionals {}

/** {@link ShellPositionals} plus the async door's options and cancellation hooks. */
export interface AsyncShellRunOptions extends AsyncCommandRunOptions, ShellPositionals {}

/** Runs a shell string. `verb` is interpreted by `sh`, so quote data with `shellQuote`. */
export interface ShellRunner {
  run(verb: string, opts: ShellRunOptions): CommandResult
}

/** The async twin of {@link ShellRunner}. */
export interface AsyncShellRunner {
  run(verb: string, opts: AsyncShellRunOptions): Promise<CommandResult>
}

/** The `sh -c` argv for `verb`; `$0`/`$1…` are appended only when given. */
function shellArgv(
  verb: string,
  name: string | undefined,
  args: readonly string[] | undefined,
): string[] {
  const rest = args ?? []
  if (name === undefined && rest.length === 0) return ['-c', verb]
  return ['-c', verb, name ?? 'sh', ...rest]
}

/**
 * A {@link ShellRunner} over `sh`. Pass `sh` to run through a different
 * {@link CommandRunner} — tests inject a recording fake, a host injects its
 * own supervised runner.
 */
export function shellRunner(sh: CommandRunner = spawnRunner('sh')): ShellRunner {
  return {
    run: (verb, { name, args, ...opts }) => sh.run(shellArgv(verb, name, args), opts),
  }
}

/** The async twin of {@link shellRunner}; wrap a sync fake with `asAsync` to inject it. */
export function shellRunnerAsync(
  sh: AsyncCommandRunner = spawnRunnerAsync('sh'),
): AsyncShellRunner {
  return {
    run: (verb, { name, args, ...opts }) => sh.run(shellArgv(verb, name, args), opts),
  }
}

/** Run `verb` once through `sh -c` and capture the result. */
export function runShell(verb: string, opts: ShellRunOptions): CommandResult {
  return shellRunner().run(verb, opts)
}

/** Async twin of {@link runShell}. */
export function runShellAsync(verb: string, opts: AsyncShellRunOptions): Promise<CommandResult> {
  return shellRunnerAsync().run(verb, opts)
}
