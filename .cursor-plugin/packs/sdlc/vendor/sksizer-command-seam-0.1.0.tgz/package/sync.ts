/**
 * The synchronous subprocess seam — an injectable run-and-capture contract
 * plus one spawnSync-backed default implementation.
 *
 * `spawnRunner(binary)` is the production spawnSync call site for
 * run-and-capture work; everything else — library clients built on the seam,
 * and hosts that wire it into their own DI container — takes a
 * {@link CommandRunner} built here (tests inject fakes). The seam is
 * deliberately capture-only: sites that stream live output
 * (`stdio: "inherit"`) or manage long-lived processes stay on their own
 * spawns.
 *
 * Two doors, mirroring the safeParse/parse convention:
 *   - `runner.run(...)` — non-throwing; the caller reads `exitCode`.
 *   - `runChecked(runner, ...)` — throws {@link CommandFailed} on a non-zero
 *     exit, for call sites whose only sane failure handling is to abort.
 */

import { spawnSync } from 'node:child_process'
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

/** Result of running an external command through a `CommandRunner`. */
export interface CommandResult {
  exitCode: number
  stdout: string
  stderr: string
  /**
   * The child never reported an exit status — the spawn failed, a timeout or
   * an abort killed it, a signal took it down — so `exitCode` is this seam's
   * stand-in `1` rather than anything the command said. Absent otherwise.
   *
   * Failures stay flattened into the result; this only names which ones are
   * the seam's own. A caller that reads particular exit codes as answers
   * (`grep` exits 1 for "no matches", `git config --get` for an unset key)
   * must check this first, or it reads a `git` missing from PATH as a
   * confident "not there".
   */
  neverExited?: boolean | undefined
}

/**
 * Per-call options for a {@link CommandRunner}. `cwd` is mandatory — the
 * runner has no ambient default. `timeoutMs`, when set, hard-caps the child
 * process (a non-zero exit on expiry) so a call that could hang on an
 * unreachable remote cannot block its caller. `input`, when set, is written
 * to the child's stdin. `env` entries merge over the parent environment; an
 * `undefined` entry removes that variable from the child's environment.
 */
export interface CommandRunOptions {
  cwd: string
  // Optional fields are `?: T | undefined` rather than `?: T`: options are
  // normally built by spreading a caller's own optionals, and under
  // `exactOptionalPropertyTypes` a present-but-undefined property is not the
  // same as an absent one. Both mean "not given" here.
  timeoutMs?: number | undefined
  input?: string | undefined
  env?: EnvOverrides | undefined
}

/** Env vars to set on a child, merged over the parent's; an `undefined` value unsets that var. */
export type EnvOverrides = Record<string, string | undefined>

/**
 * Seam for external binaries (`git`, `gh`, …). `argv` excludes the binary
 * name; everything else a call needs lives in its own
 * {@link CommandRunOptions}.
 */
export interface CommandRunner {
  run(argv: string[], opts: CommandRunOptions): CommandResult
}

/**
 * `{ env }`: `process.env` merged with `opts.env`, minus any key whose
 * override is `undefined`. ALWAYS an explicit object built from the CURRENT
 * `process.env` at call time — never `undefined`, never an omitted key, and
 * never `process.env` handed through verbatim either.
 *
 * Node's `child_process.spawnSync` inherits live `process.env` whether
 * `env` is omitted, `undefined`, or `process.env` itself. Bun's does not:
 * all three instead take a snapshot — of exactly when is unclear, but
 * empirically it MISSES anything set on `process.env` after the process
 * started, even as the very first spawn — so a test that points an env var
 * at a fresh temp dir right before spawning would silently see the real,
 * unwritten default instead. Only spreading `process.env`'s CURRENT
 * key/values into a brand-new plain object at the call site sidesteps
 * whatever Bun is snapshotting.
 */
export function mergedEnv(opts: Pick<CommandRunOptions, 'env'>): { env: NodeJS.ProcessEnv } {
  const env: NodeJS.ProcessEnv = { ...process.env, ...opts.env }
  for (const [key, value] of Object.entries(env)) if (value === undefined) delete env[key]
  return { env }
}

/**
 * Thrown by {@link runChecked} on a non-zero exit. Carries the argv and the
 * full {@link CommandResult} so callers surface the output without re-running.
 */
export class CommandFailed extends Error {
  readonly argv: string[]
  readonly result: CommandResult

  /**
   * The failure text to show a human: both streams, trimmed, newline-joined,
   * empty ones dropped.
   *
   * `message` interpolates stderr only, and several commands write the
   * sentence that explains the failure to stdout instead — a rejecting git
   * hook, `git commit` on a clean tree, `git apply --check`. Read this rather
   * than picking a stream at the call site.
   *
   * Both are joined rather than one preferred, because a rejecting hook is
   * the case where both carry a distinct half: git's own "commit failed" on
   * stderr, the hook's reason on stdout. Preferring either drops the half
   * the reader needs.
   */
  get detail(): string {
    return [this.result.stderr.trim(), this.result.stdout.trim()].filter(Boolean).join('\n')
  }

  constructor(argv: string[], result: CommandResult) {
    const stderr = result.stderr.trim()
    super(
      `command failed (exit ${result.exitCode}): ${argv.join(' ')}` + (stderr ? `\n${stderr}` : ''),
    )
    this.name = 'CommandFailed'
    this.argv = argv
    this.result = result
  }
}

/**
 * Run through the seam and throw {@link CommandFailed} on a non-zero exit —
 * the checked door for call sites whose only sane handling of failure is to
 * abort. The default seam stays non-throwing; use this instead of
 * hand-rolling `if (r.exitCode !== 0) throw` at every site.
 */
export function runChecked(
  runner: CommandRunner,
  argv: string[],
  opts: CommandRunOptions,
): CommandResult {
  const result = runner.run(argv, opts)
  if (result.exitCode !== 0) throw new CommandFailed(argv, result)
  return result
}

/**
 * Run `fn`; if it throws {@link CommandFailed}, throw `mapper(e)` instead.
 * Any other error propagates untouched, as does `fn`'s return value. Removes
 * the `catch (e) { if (e instanceof CommandFailed) throw new X(...); throw e }`
 * boilerplate around a checked run or a typed client verb.
 *
 * `mapper` may have side effects (print the output, say) before returning the
 * error to throw. Async twin: {@link mapFailedAsync}.
 */
export function mapFailed<T>(fn: () => T, mapper: (failed: CommandFailed) => Error): T {
  try {
    return fn()
  } catch (e) {
    if (e instanceof CommandFailed) throw mapper(e)
    throw e
  }
}

/**
 * Run `fn`; if it throws {@link CommandFailed}, return `onFailed(e)` instead —
 * the swallow-only-CommandFailed variant. Any other error propagates
 * untouched. Async twin: {@link catchFailedAsync}.
 */
export function catchFailed<T, R>(fn: () => T, onFailed: (failed: CommandFailed) => R): T | R {
  try {
    return fn()
  } catch (e) {
    if (e instanceof CommandFailed) return onFailed(e)
    throw e
  }
}

// Bun's `bun test` runtime mis-wires child-process stdio once a large module
// graph is loaded in the test process: the child runs — its own `<in >out`
// redirects work, filesystem side effects land — but the stdin/stdout/stderr
// the parent hands it come back empty. Confirmed for sync and async spawns,
// pipes and parent-opened fds, across every Bun 1.2.x-1.3.x; not reproducible
// under `bun run`. Any test that shells to a binary after importing a heavy
// graph (e.g. the entity model, which loads remark) hits it, so a suite that
// shells out after loading one could never be a green gate.
// `NODE_ENV=test` (which `bun test` sets) is the signal; the production
// CLI/binary never sets it and keeps the fast pipe path below untouched.
const CHILD_STDIO_CORRUPTED = process.env['NODE_ENV'] === 'test'

/**
 * Capture output the one way Bun does not corrupt: let the child do its own
 * `<in >out 2>err` redirects to temp files, then read the files back. `binary`
 * and `argv` ride as separate `sh` positional args — never parsed as shell — so
 * arguments containing spaces, metacharacters, or `$()` are inert. `exec`
 * replaces `sh`, so the reported exit status (and the cwd/env/timeout) all
 * belong to the child, matching the pipe path's contract exactly.
 */
function runViaChildRedirect(
  binary: string,
  argv: string[],
  opts: CommandRunOptions,
): CommandResult {
  const dir = mkdtempSync(join(tmpdir(), 'command-seam-'))
  try {
    const inFile = join(dir, 'in')
    const outFile = join(dir, 'out')
    const errFile = join(dir, 'err')
    writeFileSync(inFile, opts.input ?? '')
    const proc = spawnSync(
      'sh',
      [
        '-c',
        'i="$1"; o="$2"; e="$3"; shift 3; exec "$@" <"$i" >"$o" 2>"$e"',
        'sh', // $0
        inFile,
        outFile,
        errFile,
        binary,
        ...argv,
      ],
      {
        cwd: opts.cwd,
        timeout: opts.timeoutMs,
        // SIGKILL, not spawnSync's default SIGTERM: the contract is a hard
        // cap, and a child that ignores TERM is left to run to completion —
        // spawnSync signals on expiry and then keeps waiting for an exit.
        killSignal: 'SIGKILL',
        ...mergedEnv(opts),
      },
    )
    // The redirect files are created by the child's `>` / `2>`, so neither
    // exists when `sh` itself never ran — a spawn that fails with EAGAIN under
    // a saturated process table is the case that matters, and it must not turn
    // into an ENOENT thrown from the capture layer. Missing reads as empty,
    // matching what the pipe path reports for a child that produced nothing.
    const readOrEmpty = (p: string): string => {
      try {
        return readFileSync(p, 'utf-8')
      } catch {
        return ''
      }
    }
    const stdout = readOrEmpty(outFile)
    const stderr = readOrEmpty(errFile)
    return {
      // A failed `exec` (missing binary) exits sh 127 with its message on
      // errFile; a timeout leaves proc.status null → the 1 fallback. Output to
      // a file needs no maxBuffer — it is bounded only by disk.
      exitCode: proc.status ?? 1,
      ...(proc.status == null ? { neverExited: true as const } : {}),
      stdout,
      // `proc.error` is set when the spawn itself failed rather than the
      // command exiting non-zero. Left dropped, that case is indistinguishable
      // from a genuine exit 1 with no output, which is how a resource-starved
      // spawn reaches an assertion as a silent, irreproducible failure. The
      // async door already reports `stderr || err.message`; this matches it.
      stderr: proc.error ? stderr || proc.error.message : stderr,
    }
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
}

/**
 * The injected runner when there is one, else the spawnSync-backed default for
 * `binary`.
 */
export function resolveRunner(binary: string, injected?: CommandRunner | undefined): CommandRunner {
  return injected ?? spawnRunner(binary)
}

/**
 * A spawnSync-backed {@link CommandRunner} for `binary` — the default for
 * every standalone consumer (typed clients, CLI tails, probes); hosts with their
 * own runner inject it instead.
 */
export function spawnRunner(binary: string): CommandRunner {
  return {
    run(argv: string[], opts: CommandRunOptions): CommandResult {
      if (CHILD_STDIO_CORRUPTED) return runViaChildRedirect(binary, argv, opts)
      const proc = spawnSync(binary, argv, {
        cwd: opts.cwd,
        maxBuffer: 256 * 1024 * 1024,
        timeout: opts.timeoutMs,
        // See `runViaChildRedirect`: the default SIGTERM is not a hard cap.
        killSignal: 'SIGKILL',
        input: opts.input,
        ...mergedEnv(opts),
      })
      const stderr = proc.stderr?.toString() ?? ''
      return {
        exitCode: proc.status ?? 1,
        ...(proc.status == null ? { neverExited: true as const } : {}),
        stdout: proc.stdout?.toString() ?? '',
        // `proc.error` is set when the spawn itself failed rather than the
        // command exiting non-zero; folded into stderr for the reason
        // `runViaChildRedirect` above gives.
        stderr: proc.error ? stderr || proc.error.message : stderr,
      }
    },
  }
}
