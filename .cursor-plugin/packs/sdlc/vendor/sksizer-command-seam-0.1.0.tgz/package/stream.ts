/**
 * The streaming subprocess seam — an injectable run-with-inherited-stdio
 * contract plus one spawnSync-backed default implementation.
 *
 * `streamRunner(binary)` is the production spawnSync call site for a command
 * whose output must reach the operator LIVE — a build, a test run, an
 * interactive handoff to a real terminal session — cases where the capture
 * doors (`sync.ts`) would withhold everything until the child exited. It
 * shares {@link CommandRunOptions}'s shape minus `input` (there is nothing to
 * write to a stdin that is inherited from the parent, not piped), and a
 * consumer built on the seam takes a {@link StreamRunner} the same way it
 * takes a {@link CommandRunner} from `sync.ts` — tests inject a fake, and a
 * genuinely unrepresentable site (one that needs non-uniform stdio, e.g. a
 * child's stdout redirected to the parent's OWN stderr) keeps
 * `@sdlc:ignore-spawn` instead.
 *
 * No async twin yet: every current streaming call site blocks until the
 * child exits, the same way `spawnRunner` callers do. Add
 * `streamRunnerAsync` (mirroring `async.ts`'s relationship to `sync.ts`) if a
 * caller ever needs a non-blocking stream.
 */

import { spawnSync } from 'node:child_process'

import { mergedEnv, type CommandRunOptions } from './sync.ts'

/**
 * Per-call options for a {@link StreamRunner}. Same as {@link
 * CommandRunOptions} minus `input`: stdin is inherited from the parent
 * process, not fed programmatically, so there is nothing to write to.
 */
export type StreamRunOptions = Omit<CommandRunOptions, 'input'>

/**
 * Result of a streamed run — there is no output to report (it already went
 * straight to the inherited stdio), only how the child ended.
 */
export interface StreamResult {
  exitCode: number
  /**
   * The child never reported an exit status (spawn failed, a timeout or an
   * abort killed it). Mirrors `CommandResult.neverExited` (`sync.ts`).
   */
  neverExited?: boolean | undefined
}

/** Seam for a command whose stdio is inherited rather than captured. */
export interface StreamRunner {
  run(argv: string[], opts: StreamRunOptions): StreamResult
}

/**
 * A spawnSync-backed {@link StreamRunner} for `binary`, stdio fully inherited
 * (stdin, stdout, stderr) so the child's own prompts, progress and output
 * reach the operator directly — no different from a raw `spawnSync(binary,
 * argv, {stdio: "inherit"})`, except this factory is an INJECTABLE
 * dependency a call site takes, rather than a spawn it hand-rolls, mirroring
 * `spawnRunner` (`sync.ts`).
 */
export function streamRunner(binary: string): StreamRunner {
  return {
    run(argv: string[], opts: StreamRunOptions): StreamResult {
      const proc = spawnSync(binary, argv, {
        cwd: opts.cwd,
        stdio: 'inherit',
        timeout: opts.timeoutMs,
        // See `sync.ts`'s `runViaChildRedirect`: the default SIGTERM is not a
        // hard cap.
        killSignal: 'SIGKILL',
        ...mergedEnv(opts),
      })
      if (proc.error !== undefined) return { exitCode: 1, neverExited: true }
      return {
        exitCode: proc.status ?? 1,
        ...(proc.status == null ? { neverExited: true as const } : {}),
      }
    },
  }
}
