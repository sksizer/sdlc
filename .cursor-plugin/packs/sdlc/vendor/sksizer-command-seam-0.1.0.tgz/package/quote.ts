/**
 * POSIX shell quoting, for a command line printed for a person to paste or
 * handed to `sh -c`. A runner never needs it: the seam passes argv straight
 * to the binary.
 */

/** Characters no POSIX shell treats specially. */
const INERT = /^[A-Za-z0-9_@%+=:,./-]+$/

/** `word` as one shell word: bare when inert, single-quoted otherwise. */
export function shellQuote(word: string): string {
  if (INERT.test(word)) return word
  return `'${word.replaceAll("'", `'\\''`)}'`
}

/** `argv` as one shell command line. */
export function shellJoin(argv: readonly string[]): string {
  return argv.map(shellQuote).join(' ')
}
