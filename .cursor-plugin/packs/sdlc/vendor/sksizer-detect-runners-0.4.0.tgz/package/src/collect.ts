/**
 * The orchestrator — build a {@link ProviderContext}, run the providers, and
 * assemble the catalog.
 *
 * Collection is a FUNCTION, never a build step or a cached snapshot. Every call
 * re-probes, so a catalog cannot silently go stale after someone adds a task.
 * Memoization exists (one file listing, one read per file) but is scoped to a
 * single call and dies with it — a module-level cache here would quietly break
 * that promise.
 *
 * Caching is a LAYER above this function (`cache.ts`), never inside it, and
 * opt-in by the caller — which is what keeps a programmatic consumer's answer a
 * fact about the repository right now rather than about whatever a store
 * happened to remember. `options.probeObserver` is the seam that layer reads
 * through: it is told what each provider touched and how long it took, and it
 * decides — here, nothing is decided at all.
 *
 * Providers run CONCURRENTLY. That is the reason this API is async rather than
 * offering a sync door: probing moon costs ~700ms and probing just costs ~5ms,
 * and serially those add up while in parallel the slowest one sets the pace.
 */

import { resolve } from 'node:path'

import { spawnRunnerAsync } from '@sksizer/command-seam'

import type { AspectCatalog, AspectKind } from './aspects.ts'
import { collectAspectsFrom } from './aspects.ts'
import { createContext } from './context.ts'
import type { CollectOptions, ProviderContext, RunnerProvider } from './contract.ts'
import { resolveDiscovery } from './discovery.ts'
import type { Catalog, RunnerReport } from './model.ts'
import { builtinProviders } from './providers/index.ts'
import { which as whichOnPath } from './which.ts'

/**
 * Providers whose job is manifest presence/content — the ones `collect()`
 * computes an `AspectFacts` catalog for, keyed to the ONE manifest kind each
 * used to read directly. `moon` is deliberately excluded despite also being
 * manifest-adjacent: see its own file for why folding it in would cost a
 * second `moon query projects` call.
 *
 * Scoped to exactly one kind per provider, not the whole catalog: a
 * provider's cache fingerprint (`fingerprint.ts`'s "exactly what was read"
 * contract) must stay precise to what IT depends on — editing a justfile
 * must not stale cargo's cache entry too. A provider NOT in this map gets an
 * empty, ctx-free placeholder catalog, never a real one.
 */
const ASPECT_FACTS_CONSUMERS: Readonly<Record<string, AspectKind>> = {
  cargo: 'cargo',
  'node-scripts': 'packageJson',
  just: 'justfile',
  mise: 'mise',
  make: 'makefile',
}

/** Which runners are present, without enumerating their tasks. */
export async function discover(root: string, options: CollectOptions = {}): Promise<string[]> {
  const catalog = await collect(root, options)
  return catalog.reports.filter((r) => r.status === 'ok').map((r) => r.runner)
}

export async function collect(root: string, options: CollectOptions = {}): Promise<Catalog> {
  const absRoot = resolve(root)
  const allowExec = options.allowExec ?? false
  const makeRunner = options.makeRunner ?? ((binary: string) => spawnRunnerAsync(binary))
  const which = options.which ?? whichOnPath
  const signal = options.signal ?? new AbortController().signal

  const selected = selectProviders(options)
  const discovery = await resolveDiscovery(absRoot, options.discovery ?? 'auto', makeRunner('git'))
  const ctx = createContext({
    absRoot,
    allowExec,
    makeRunner,
    which,
    signal,
    discovery,
    excludePaths: options.excludePaths,
  })
  const observer = options.probeObserver
  const emptyAspectCatalog: AspectCatalog = {
    root: absRoot,
    generatedAt: new Date().toISOString(),
    units: [],
    malformed: [],
  }

  const reports = await Promise.all(
    selected.map(async (provider): Promise<RunnerReport> => {
      // A provider that must shell out simply does not run when execution is
      // withheld. The synthesis lives in `execWithheldReport` because the
      // cached path (`cached.ts`) must describe a withheld runner in exactly
      // the same words this one does — two copies would drift, and a UI would
      // then explain the same withheld runner differently depending on whether
      // a cache happened to exist.
      if (provider.kind === 'exec' && !allowExec) {
        return execWithheldReport(provider, options.execWithheldHint, which)
      }

      const base = providerBase(provider, which)

      // Per-provider read recording. The context's caches stay SHARED — two
      // providers reading the same package.json still cost one read — and only
      // the recording set is per provider, so a fingerprint describes what this
      // provider depends on rather than what the whole run happened to touch.
      const reads = new Set<string>()
      const queries = new Set<string>()
      const recording = observer === undefined ? ctx : recordReads(ctx, reads, queries)

      // Computed through `recording`, not the bare `ctx`, and scoped to the
      // ONE kind this provider needs (`only`): a provider that consumes this
      // catalog instead of reading manifests itself must still fingerprint
      // correctly and precisely, so exactly what `collectAspectsFrom` reads
      // on its behalf — nothing another consuming provider's own kind
      // touched — is recorded into THIS provider's own `reads`/`queries`.
      // The underlying files/JSON caches are shared with `ctx`, so this costs
      // no second read even though it runs once per consuming provider.
      const aspectKind = ASPECT_FACTS_CONSUMERS[provider.id]
      const facts =
        aspectKind === undefined
          ? emptyAspectCatalog
          : await collectAspectsFrom(recording, { skipMoon: true, only: [aspectKind] })

      const startedAt = performance.now()
      let report: RunnerReport
      try {
        const result = await provider.collect(recording, facts)
        report = { ...base, ...result, skippedForExec: false }
      } catch (err) {
        // One provider throwing must not lose the others' work.
        report = {
          ...base,
          status: 'error',
          tasks: [],
          skippedForExec: false,
          diagnostics: [{ severity: 'error', message: describe(err) }],
        }
      }

      // The error path is observed too: the observer's job is to report what
      // happened, and refusing to STORE a failure belongs to the cache writer.
      observer?.({
        runner: provider.id,
        kind: provider.kind,
        durationMs: performance.now() - startedAt,
        reads: [...reads],
        queries: [...queries],
        watch: provider.watch ?? [],
        report,
        files: ctx.files,
      })

      return report
    }),
  )

  return {
    root: absRoot,
    generatedAt: new Date().toISOString(),
    discovery,
    allowExec,
    reports,
  }
}

/**
 * The `runner`/`chain`/`brand`/`tool` prefix every report carries.
 *
 * Spread rather than `brand: provider.brand` so a brandless provider's report
 * serializes without the key at all — `"brand": undefined` is not JSON, and an
 * absent key is the honest shape for "never declared".
 *
 * `tool` is filled here, independent of whether the provider runs at all —
 * presence is a fact about the binary, not about the collection outcome, so it
 * must survive both the exec-skip and error paths.
 */
function providerBase(
  provider: RunnerProvider,
  which: (binary: string) => string | null,
): Pick<RunnerReport, 'runner' | 'chain' | 'brand' | 'tool'> {
  return {
    runner: provider.id,
    chain: provider.chain,
    ...(provider.brand ? { brand: provider.brand } : {}),
    ...(provider.binary ? { tool: toolStatus(provider.binary, which) } : {}),
  }
}

/**
 * The report an `exec` provider gets when execution is withheld.
 *
 * Reported rather than dropped, so a UI can say why moon is missing instead of
 * implying the repo has none. Exported because `cached.ts` synthesizes the same
 * row without probing: a withheld runner never probed and never will this run,
 * so its "cached" answer is this, and it must be this exactly.
 *
 * This stays TRUST-AGNOSTIC. `collect` takes `allowExec` and obeys it; it never
 * reads the trust store. Trust is consent a person gave, so resolving it
 * belongs to the CLIs, which know they are acting for a human. A programmatic
 * consumer passing `allowExec: false` must not have its answer changed by a
 * store it never asked about — which is why the actionable sentence arrives as
 * data in `execWithheldHint`.
 */
export function execWithheldReport(
  provider: RunnerProvider,
  hint: string | undefined,
  which: (binary: string) => string | null,
): RunnerReport {
  return {
    ...providerBase(provider, which),
    status: 'absent',
    tasks: [],
    skippedForExec: true,
    diagnostics: [
      {
        severity: 'info',
        message: `${provider.id} needs to run a subprocess; ${
          hint ?? 're-run with execution allowed to include it'
        }`,
      },
    ],
  }
}

/**
 * A view of one context that notes every path read through it.
 *
 * A thin wrapper, not a second context: the memoized caches and the lister
 * behind it are the shared ones, so recording costs no extra read and no extra
 * walk. `files()` records what it RETURNS rather than the pattern it was asked
 * for — the pattern is a question, and the paths are the answer the provider
 * actually depended on.
 */
function recordReads(
  ctx: ProviderContext,
  reads: Set<string>,
  queries: Set<string>,
): ProviderContext {
  return {
    ...ctx,
    files: async (pattern) => {
      const found = await ctx.files(pattern)
      // The pattern as well as its answer. A path set records the world as it
      // was; the pattern is what lets the cache ask the same question again and
      // notice a file that has appeared since.
      queries.add(pattern)
      for (const path of found) reads.add(path)
      return found
    },
    readText: (relPath) => {
      reads.add(relPath)
      return ctx.readText(relPath)
    },
    readJson: (relPath) => {
      reads.add(relPath)
      return ctx.readJson(relPath)
    },
    exists: (relPath) => {
      reads.add(relPath)
      return ctx.exists(relPath)
    },
  }
}

function toolStatus(
  binary: string,
  which: (binary: string) => string | null,
): { binary: string; found: boolean; path?: string } {
  const path = which(binary)
  return path === null ? { binary, found: false } : { binary, found: true, path }
}

/**
 * The providers one call runs, after `only`/`exclude`.
 *
 * Exported so the cached layer selects the same set by the same rule: a second
 * copy of this filtering would eventually disagree with this one, and a caller
 * would get a cached catalog covering different runners than a live one.
 */
export function selectProviders(options: CollectOptions): RunnerProvider[] {
  let providers = options.providers ?? builtinProviders
  if (options.only) {
    const wanted = new Set(options.only)
    providers = providers.filter((p) => wanted.has(p.id))
  }
  if (options.exclude) {
    const unwanted = new Set(options.exclude)
    providers = providers.filter((p) => !unwanted.has(p.id))
  }
  return providers
}

function describe(err: unknown): string {
  return err instanceof Error ? err.message : String(err)
}
