/**
 * The provider contract — the extension point.
 *
 * A provider adapts one runner (moon, just, cargo, …) to the shared model. The
 * built-ins are ordinary providers with no privileges, so anything they can do
 * a caller's own provider can do:
 *
 *   collect(root, { providers: [...builtinProviders, mine] })
 *
 * Two rules keep providers honest and testable:
 *
 *   1. They never spawn. `ctx.runner(binary)` hands back an injected runner, so
 *      a test supplies canned output instead of needing moon on the PATH.
 *   2. They never read the filesystem for discovery. `ctx.files()` applies the
 *      caller's chosen strategy (git-tracked vs directory walk); a provider
 *      reaching past it would silently disagree with every other provider
 *      about which files exist.
 */

import type { AsyncCommandRunner } from '@sksizer/command-seam'

import type { AspectCatalog } from './aspects.ts'
import type {
  ChainSegment,
  DiscoveryMode,
  ProviderResult,
  RunnerBrand,
  RunnerReport,
} from './model.ts'

/**
 * Whether a provider must run subprocesses to do its job.
 *
 * This is a trust boundary, not an optimization. `moon query tasks` in an
 * arbitrary directory executes that repo's toolchain configuration, so
 * pointing this package at a repository you did not write is code execution.
 * `collect(root, { allowExec: false })` runs only `parse` providers, and they
 * answer from files alone.
 *
 * `parse` is a floor, not a promise never to spawn: a parse provider may take a
 * better answer from its own tool when `allowExec` is on and the binary is
 * there (just, rake, go-task, gradle all do). What the kind guarantees is that
 * with execution off the provider still has something honest to report.
 */
export type ProviderKind = 'parse' | 'exec'

export interface ProviderContext {
  /** Absolute. Every path a provider returns is relative to this. */
  root: string
  /**
   * A runner for one binary, injected. Providers need different binaries
   * (`moon`, `just`, `git`), which is why this is a factory and not a single
   * `CommandRunner` — `spawnRunner` closes over the binary it was built with.
   */
  runner(binary: string): AsyncCommandRunner
  /**
   * Root-relative paths matching a basename or a `*`-prefixed suffix
   * (`"justfile"`, `"*.mk"`). Honours the resolved discovery mode; results are
   * memoized for the life of one `collect()` call.
   */
  files(pattern: string): Promise<string[]>
  /** Read and parse a JSON file, root-relative. Memoized per `collect()` run. */
  readJson(relPath: string): Promise<unknown>
  /** Read a text file, root-relative. Memoized per `collect()` run. */
  readText(relPath: string): Promise<string | null>
  /** True when a root-relative path exists. */
  exists(relPath: string): Promise<boolean>
  /**
   * PATH lookup for a binary — no subprocess. Safe under `allowExec: false`:
   * that is the whole point of this existing separately from `ctx.runner`,
   * which spawns. Returns the resolved path, or `null` when the binary is
   * not found.
   */
  which(binary: string): string | null
  /**
   * Whether subprocesses are permitted. An `exec` provider never sees `false` —
   * it is skipped outright. A `parse` provider does see it, and a dual-path one
   * (just, rake, go-task, gradle) branches on it: files when execution is off,
   * the tool's own listing when it is on and `which()` finds the binary.
   */
  allowExec: boolean
  /** How discovery resolved, for providers that want to explain themselves. */
  discovery: DiscoveryMode
  /** Aborted when the caller cancels — pass it to long-running work. */
  signal: AbortSignal
}

export interface RunnerProvider {
  /** Stable id; becomes `Task.runner` and `path[0]`. */
  id: string
  kind: ProviderKind
  /** What each position of this runner's `Task.path` means. */
  chain: ChainSegment[]
  /**
   * Visual identity, copied onto the {@link RunnerReport}. Optional and stays
   * that way: a provider is complete without one, and no consumer may require
   * it — the value is polish for UIs, not part of the detection contract.
   */
  brand?: RunnerBrand | undefined
  /**
   * The binary this runner's tasks execute through, e.g. `"moon"`, `"just"`.
   * A static declaration, like `brand` — the provider only NAMES it; it
   * never reports presence itself. `collect()` fills `RunnerReport.tool` by
   * running `ctx.which()` on this name, so a provider cannot lie about
   * whether its tool is installed. Omitted by a provider whose binary is
   * resolved per-directory rather than fixed (node-scripts, python) — a
   * single static name would be wrong for those.
   */
  binary?: string | undefined
  /**
   * Basenames whose contents decide whether a cached result is still good.
   * Only needed when the tool merges files this provider never reads.
   *
   * A `parse` provider needs none: every read it makes goes through `ctx`, so
   * recording what it touched already covers exactly what it read. An `exec`
   * provider does need them, because it reads only its markers while its TOOL
   * merges files it never opens — moon's per-project `moon.yml`, mise's nested
   * `mise.toml`, a newly added `*.sbt`.
   *
   * Basenames only, in the same pattern language `ctx.files()` speaks: an exact
   * basename, or `*suffix` matched against the basename. Not a path glob. One
   * pattern language shared with discovery is worth more than exact
   * invalidation for a rare edit, and the cost is stated rather than hidden —
   * a directory whose contents matter but whose filenames are not distinctive
   * is simply not covered.
   *
   * Deliberately the ONLY cache-related field on this contract. There is no
   * `slow`: slowness is MEASURED per repository, and a static default would
   * only ever apply on the very first run, when there is no cached answer to be
   * stale about. No TTL or invalidation knob either — `kind` already separates
   * the exec providers, whose fingerprint cannot see their tool's merge inputs
   * and which therefore need the max-age backstop, from the parse providers,
   * whose fingerprint is exact.
   */
  watch?: string[] | undefined
  /**
   * Find the runner and enumerate its tasks.
   *
   * Returns `status: "absent"` when the runner is not present — that is a
   * value, not an error, and not a separate lifecycle phase. Providers are
   * expected to bail cheaply: check the marker file first, before any real
   * work.
   *
   * `facts` is the `AspectFacts` catalog `collect()` (`collect.ts`) computes
   * for this provider — manifest presence and content, already parsed, and
   * scoped to the one manifest kind this provider's own id names (so its
   * cache fingerprint stays exact, see `collect.ts`'s own
   * `ASPECT_FACTS_CONSUMERS`). A provider whose job is manifest
   * presence/content (cargo, node-scripts, just, mise, make) reads it
   * instead of calling `ctx.files()`/`ctx.readJson()` itself; one that needs
   * neither (an `exec` provider answering from a live tool query, e.g. moon)
   * can ignore the parameter entirely — TypeScript accepts a `collect(ctx)`
   * implementation here since every caller still supplies both arguments.
   */
  collect(ctx: ProviderContext, facts: AspectCatalog): Promise<ProviderResult>
}

export interface CollectOptions {
  /** Defaults to `builtinProviders`. Pass your own to add or replace. */
  providers?: RunnerProvider[] | undefined
  /** Restrict to these provider ids. */
  only?: string[] | undefined
  /** Skip these provider ids. */
  exclude?: string[] | undefined
  /**
   * Permit subprocesses. Defaults to `false`: a library that shells out by
   * default is a library that runs unknown code when pointed somewhere new.
   * The interactive CLI opts in; `quality detect` does not.
   */
  allowExec?: boolean | undefined
  /**
   * `"git"` lists tracked plus untracked-but-not-ignored files (fast, respects
   * .gitignore); `"walk"` walks the
   * tree excluding well-known directories. `"auto"` picks git when the root is
   * a repository and git is on the PATH. The resolved mode is recorded on the
   * catalog because it changes which files are found.
   */
  discovery?: DiscoveryMode | 'auto' | undefined
  /**
   * Appended to the diagnostic on a runner withheld for want of execution.
   * The library does not know what trust is; a CLI that resolved a trust gate
   * passes the sentence it wants the user to read, and the catalog carries it
   * into --json as well as onto the screen.
   */
  execWithheldHint?: string | undefined
  /**
   * Extra paths to skip, on top of the built-in list, in both discovery modes.
   *
   * A bare name matches any path segment at any depth (`node_modules`); a value
   * containing a slash matches a root-relative path prefix, taking the whole
   * tree beneath it (`crates/mg/tests/mini-repo`). Not glob syntax, and
   * deliberately so — the same restraint `ctx.files()` patterns are held to.
   *
   * This is what a repository uses to say that a tree is DATA rather than
   * project structure: a test-fixture repo, a vendored sample, a scratch
   * directory. Those hold real manifests, so a detector is right to find them
   * and right to report a broken one; they are simply not tasks anyone can run.
   *
   * Not the sibling of `exclude`, which takes runner ids.
   */
  excludePaths?: string[] | undefined
  /** Build the runner for a binary. Defaults to the real subprocess seam. */
  makeRunner?: ((binary: string) => AsyncCommandRunner) | undefined
  /**
   * PATH lookup for a binary. Defaults to `which()` in `which.ts`, which
   * walks PATH with `node:fs` — the published bin runs under node, where
   * `Bun.which` does not exist. Tests inject this to control tool presence
   * deterministically without touching the actual PATH.
   */
  which?: ((binary: string) => string | null) | undefined
  /**
   * Called once per provider that actually ran, with what the run measured and
   * touched. Never called for a provider skipped for want of execution, which
   * probed nothing; called for a provider that THREW, because the observer
   * sees the truth and refusing to store a failure is the cache writer's job,
   * not this seam's.
   *
   * This is the seam `cache.ts` rides on, and it is deliberately an option on
   * the CALLER rather than a field on the provider contract. A provider must
   * not know it is being cached — a provider that could observe its own timings
   * could behave differently when watched — and a caller that never opts in
   * pays nothing.
   */
  probeObserver?: ((probe: ProbeRecord) => void) | undefined
  signal?: AbortSignal | undefined
}

/** What one provider's run measured and touched. See `CollectOptions.probeObserver`. */
export interface ProbeRecord {
  runner: string
  kind: ProviderKind
  /** Wall time of `provider.collect()` alone. */
  durationMs: number
  /** Root-relative paths this provider read through `ctx`, in touch order. */
  reads: string[]
  /**
   * Every pattern this provider passed to `ctx.files()`, deduplicated.
   *
   * These are watch patterns the provider never had to declare. A provider
   * that discovers by listing depends on the ANSWER to its query, not only on
   * the files that answer happened to name — so a file matching the same
   * pattern that appears later is a change to its task set, and `reads` alone
   * can never show that, having been recorded before the file existed.
   */
  queries: string[]
  /** The provider's declared `watch`, or `[]`. */
  watch: string[]
  report: RunnerReport
  /** The run's memoized lister, so a fingerprint costs no second walk. */
  files: (pattern: string) => Promise<string[]>
}
