/**
 * Aspect facts — what a directory IS, read from its manifests exactly once.
 *
 * `collect()`/`tasks()` answer "what can I run here." `collectAspects()`
 * answers a narrower, cheaper question underneath that: "what manifests does
 * this directory have, and what do they say about it." Every provider in
 * `providers/` independently calls `ctx.files()`/`ctx.readJson()` for its own
 * manifest kind today; this module is the other caller of those same
 * memoized `ProviderContext` primitives (`context.ts`), for callers that want
 * the raw facts without pulling in task enumeration — a dependency-graph
 * builder (`@sksizer/manifest-graph`) or an installer that needs "which
 * package manager does this directory use" and nothing else.
 *
 * Pure facts. No task enumeration, no graph edges, and no execution beyond
 * what one fact itself requires: `moon.role` comes from `moon query
 * projects`, gated on `allowExec` the same way `providers/moon.ts` gates
 * itself, and nothing else here shells out.
 */

import { readFile } from 'node:fs/promises'
import { join } from 'node:path'

import type { AsyncCommandRunner } from '@sksizer/command-seam'
import { spawnRunnerAsync } from '@sksizer/command-seam'
import { parse as parseToml } from 'smol-toml'

import { createContext } from './context.ts'
import type { ProviderContext } from './contract.ts'
import { resolveDiscovery } from './discovery.ts'
import { managerFromField, NODE_LOCKFILE_MANAGERS } from './managers.ts'
import type { DiscoveryMode, Evidence } from './model.ts'
import { MAKEFILE_NAMES } from './providers/make.ts'
import { CONFIGS as MISE_CONFIGS } from './providers/mise.ts'
import { dirOf } from './providers/shared.ts'
import { which as whichOnPath } from './which.ts'

/** The node package managers `NODE_LOCKFILE_MANAGERS` can ever name. */
const NODE_PACKAGE_MANAGER_KINDS = ['bun', 'pnpm', 'yarn', 'npm'] as const
export type NodePackageManagerKind = (typeof NODE_PACKAGE_MANAGER_KINDS)[number]

function isNodePackageManagerKind(kind: string): kind is NodePackageManagerKind {
  return (NODE_PACKAGE_MANAGER_KINDS as readonly string[]).includes(kind)
}

/** Basenames that arm a project's git hooks, keyed to the manager that owns them. */
const HOOK_MANAGER_MARKERS: ReadonlyArray<{ files: readonly string[]; manager: string }> = [
  {
    files: ['lefthook.yml', 'lefthook.yaml', '.lefthook.yml', '.lefthook.yaml'],
    manager: 'lefthook',
  },
  { files: ['.pre-commit-config.yaml', '.pre-commit-config.yml'], manager: 'pre-commit' },
  { files: ['.husky'], manager: 'husky' },
]

/** Basenames that need a one-time trust grant before their tool reads them. */
const TOOL_TRUST_MARKERS: ReadonlyArray<{ files: readonly string[]; tool: string }> = [
  {
    files: ['.mise.toml', 'mise.toml', '.config/mise/config.toml', '.tool-versions'],
    tool: 'mise',
  },
  { files: ['.envrc'], tool: 'direnv' },
]

/**
 * How a manifest declares one dependency, and what its specifier points at.
 *
 * Mirrors `@sksizer/manifest-graph`'s own `DepKind`/`SpecifierKind`/`DepDecl`
 * field-for-field, duplicated rather than imported: that package depends on
 * THIS one for its manifest facts, so the reverse import would be a cycle.
 * Structurally identical on purpose — a consumer assigns one straight into
 * the other's shape with no mapping step.
 */
export type DepFactKind = 'prod' | 'dev' | 'peer' | 'optional' | 'build'
export type DepFactSpecifierKind = 'workspace' | 'file' | 'path' | 'registry' | 'other'

export interface DepFact {
  /** The depended-on package's real name (a cargo rename's `package = "…"`, not its alias). */
  name: string
  kind: DepFactKind
  /** The raw specifier text, verbatim. */
  specifier: string
  specifierKind: DepFactSpecifierKind
}

/**
 * A `package.json` found on disk but too malformed to become a
 * {@link PackageJsonFact} — invalid JSON, or valid JSON that is not an
 * object. Recorded on {@link AspectCatalog} rather than on a unit: the
 * directory gets no unit at all when this is its only manifest (see
 * `readPackageJsonManifests`), so there is nowhere on the per-directory shape
 * to hang the error. A consumer that must still account for the file (a
 * dependency-graph walk that reports every manifest it finds, broken ones
 * included) reads this list; `node-scripts`'s own provider already treats
 * "listed by `ctx.files()`, absent from `units[].packageJson`" as this same
 * case, so this list is additive, not a behavior change for it.
 */
export interface MalformedPackageJson {
  /** Root-relative path of the `package.json`. */
  path: string
  /** Human-readable cause, in the same `"parse failed: …"` / `"unreadable: …"` shape a thrown error would carry. */
  error: string
}

/** A Cargo crate or workspace root, found by `Cargo.toml`'s presence. */
export interface CargoFact {
  /** Root-relative path of the `Cargo.toml`. */
  manifestPath: string
  /** Whether this manifest declares a `[workspace]` table. */
  workspace: boolean
  /** `[package].name`. Absent for a virtual workspace root, which has no `[package]` table. */
  name?: string | undefined
  /** `[package].version`, when it is a plain string. */
  version?: string | undefined
  /** `[package].publish = false`. Omitted (never `false`) when not declared. */
  private?: boolean | undefined
  description?: string | undefined
  /** `[workspace].members`. Omitted when this manifest has no `[workspace]` table, or an empty one. */
  workspaceMembers?: string[] | undefined
  /** `[[bin]]` sections present. Omitted (never `false`) when there are none. */
  hasBin?: boolean | undefined
  /** Every dependency this manifest declares, in `[dependencies]`/`[dev-dependencies]`/`[build-dependencies]` order, each table's own entries key-sorted. Omitted when there are none. */
  deps?: DepFact[] | undefined
  /**
   * Set when the TOML failed to parse — `workspace`/`manifestPath` above are
   * still the regex-derived facts every consumer already reads; none of this
   * interface's other new fields are populated alongside this one.
   */
  error?: string | undefined
}

/** A `package.json`, found by its presence in this directory. */
export interface PackageJsonFact {
  /** Root-relative path of the `package.json`. */
  manifestPath: string
  name?: string | undefined
  main?: string | undefined
  types?: string | undefined
  /** String-valued `scripts` entries — a non-string value is never a command. */
  scripts: Record<string, string>
  /**
   * Every name under `dependencies`, `devDependencies`, `peerDependencies`
   * and `optionalDependencies`, unioned and deduplicated — a dependency
   * graph asking "does this depend on vue/vitest/wasm-bindgen" does not care
   * which of the four tables named it.
   */
  dependencies: string[]
  /**
   * This manifest's own `packageManager` field, parsed, independent of
   * whether a lockfile sits in the SAME directory — unlike
   * {@link PackageManagerFact}, which `attachPackageManager` only records
   * alongside a same-directory lockfile. A nested package can declare the
   * field with its lockfile living at a workspace root; a consumer walking
   * up the tree for "which manager does this directory effectively use"
   * (`node-scripts`'s own `managerFor`) needs the field independent of that.
   */
  packageManagerPin?: { manager: string; version: string } | undefined
  version?: string | undefined
  /** Node `"private": true`. Omitted (never `false`) when not declared. */
  private?: boolean | undefined
  description?: string | undefined
  /** `workspaces` globs, or `workspaces.packages` globs. Omitted when empty. */
  workspaces?: string[] | undefined
  /** A string or non-empty object `bin` field. Omitted (never `false`) when there is none. */
  hasBin?: boolean | undefined
  /** Every dependency this manifest declares, field-then-key ordered exactly like {@link CargoFact.deps}. Omitted when there are none. */
  deps?: DepFact[] | undefined
}

/** moon's own opinion of a project directory, from `moon query projects`. */
export interface MoonRole {
  layer?: string | undefined
  stack?: string | undefined
  language?: string | undefined
}

export interface MoonFact {
  /** True for every directory `moon query projects` reports as a project. */
  present: boolean
  /**
   * moon's own project id for this directory — e.g. `agent-adapt` where the
   * directory's node id (a manifest's own name) is `@sksizer/agent-adapt`.
   * Not `AspectFacts.dir`, and not a graph node's own id; a consumer joining
   * this fact to something else's nodes still joins by `dir`.
   */
  id: string
  role?: MoonRole | undefined
}

/** The node package manager a directory's own lockfile names. */
export interface PackageManagerFact {
  kind: NodePackageManagerKind
  /** Root-relative path of the lockfile that decided `kind`. */
  lockfile: string
  /**
   * What this directory's own `package.json#packageManager` field declares,
   * independent of `kind`/`lockfile` — a corepack pin can name a manager the
   * lockfile disagrees with, and a consumer that wants to flag the mismatch
   * needs both facts, not one collapsed into the other.
   */
  pin?: { manager: string; version: string } | undefined
}

/**
 * Everything read about one directory, in one pass over its manifests.
 *
 * `hookManagers`/`toolTrust` are repository-wide, so only the root unit
 * (`dir: "."`) ever carries them — every other unit reports `[]`, not a
 * repeated copy of the root's answer.
 */
export interface AspectFacts {
  /** Root-relative; `"."` for the catalog root. */
  dir: string
  cargo?: CargoFact | undefined
  packageJson?: PackageJsonFact | undefined
  moon?: MoonFact | undefined
  justfile?: { path: string } | undefined
  makefile?: { path: string } | undefined
  mise?: { path: string } | undefined
  packageManager?: PackageManagerFact | undefined
  hookManagers: string[]
  toolTrust: string[]
  evidence: Evidence[]
}

export interface AspectCatalog {
  /** Absolute path the collection ran against. Every `dir` is relative to it. */
  root: string
  generatedAt: string
  units: AspectFacts[]
  /** Every `package.json` found but too malformed to become a unit's fact. See {@link MalformedPackageJson}. */
  malformed: MalformedPackageJson[]
}

export interface CollectAspectsOptions {
  /**
   * Permit the one subprocess this module can make: `moon query projects`,
   * to fill `moon.role`. Defaults to `false`, matching every other exec
   * posture in this package — a library that shells out by default runs
   * unknown code the moment it is pointed somewhere new.
   */
  allowExec?: boolean | undefined
  discovery?: DiscoveryMode | 'auto' | undefined
  excludePaths?: string[] | undefined
  /**
   * Union this package's own built-in exclude list into `excludePaths`
   * (default `true`). A caller with its own, different default-exclude
   * contract to hold to exactly — `@sksizer/manifest-graph`'s Rust-parity
   * walker — passes `false` so `excludePaths` is the whole exclude list,
   * not an addition to this package's broader one. See
   * {@link createContext}'s `useBuiltinExcludes`.
   */
  useBuiltinExcludes?: boolean | undefined
  /** Build the runner for a binary. Defaults to the real subprocess seam. */
  makeRunner?: ((binary: string) => AsyncCommandRunner) | undefined
  /** PATH lookup for a binary. Defaults to `which()` in `which.ts`. */
  which?: ((binary: string) => string | null) | undefined
  signal?: AbortSignal | undefined
}

/** One unit under construction — mutated while its manifests are read, then frozen. */
interface UnitBuilder {
  dir: string
  cargo?: CargoFact | undefined
  packageJson?: PackageJsonFact | undefined
  moon?: MoonFact | undefined
  justfile?: { path: string } | undefined
  makefile?: { path: string } | undefined
  mise?: { path: string } | undefined
  packageManager?: PackageManagerFact | undefined
  hookManagers: string[]
  toolTrust: string[]
  evidence: Evidence[]
}

function unitFor(units: Map<string, UnitBuilder>, dir: string): UnitBuilder {
  let unit = units.get(dir)
  if (unit === undefined) {
    unit = { dir, hookManagers: [], toolTrust: [], evidence: [] }
    units.set(dir, unit)
  }
  return unit
}

export async function collectAspects(
  root: string,
  opts: CollectAspectsOptions = {},
): Promise<AspectCatalog> {
  const allowExec = opts.allowExec ?? false
  const makeRunner = opts.makeRunner ?? ((binary: string) => spawnRunnerAsync(binary))
  const which = opts.which ?? whichOnPath
  const signal = opts.signal ?? new AbortController().signal

  const absRoot = root
  const discovery = await resolveDiscovery(absRoot, opts.discovery ?? 'auto', makeRunner('git'))
  const ctx = createContext({
    absRoot,
    allowExec,
    makeRunner,
    which,
    signal,
    discovery,
    excludePaths: opts.excludePaths,
    useBuiltinExcludes: opts.useBuiltinExcludes,
  })

  return collectAspectsFrom(ctx)
}

/** One manifest kind this module reads. Mirrors {@link AspectFacts}'s own fields. */
export type AspectKind =
  'cargo' | 'packageJson' | 'justfile' | 'makefile' | 'mise' | 'hookManagers' | 'toolTrust'

export interface CollectAspectsFromOptions {
  /**
   * Skip the `moon query projects` step. `collect()` (Layer 2a) sets this
   * when it computes facts for its OWN providers, none of which need
   * `moon.role` — the moon provider answers project-role questions from its
   * own `query projects` call, already required for task grouping, which
   * this module's own version cannot safely replace (see `providers/moon.ts`).
   * Running both on every `collect()` call would silently double the one
   * subprocess this package's docs call out as the slow one. Defaults to
   * `false`: the public {@link collectAspects} entry point, used by
   * consumers outside this package (`manifest-graph`, System Graph) that
   * have no OTHER moon query of their own to fold this into, keeps its full
   * behavior.
   */
  skipMoon?: boolean | undefined
  /**
   * Restrict to these manifest kinds. `collect()` passes exactly the one
   * kind a given provider's own presence/content used to read directly
   * (`cargo` for the cargo provider, `packageJson` for node-scripts, …) —
   * each provider's own probe recording (`fingerprint.ts`'s "exactly what
   * was read" contract) must stay precise to THAT provider, and running
   * every reader for every consuming provider would attribute, say, a
   * justfile edit to cargo's cache entry too. Omit for every kind (the
   * default): {@link collectAspects}'s own public behavior, for a caller
   * that wants the full catalog rather than one provider's slice of it.
   */
  only?: readonly AspectKind[] | undefined
}

/**
 * `collectAspects`'s own logic, taking an already-built {@link ProviderContext}
 * instead of building one — so a caller that already has one (`collect()`,
 * Layer 2a) reads every manifest through the SAME memoized
 * `files()`/`readJson()`/`readText()`/`exists()` primitives its providers do,
 * rather than a second, independently-memoized copy. `collectAspects` above
 * is the standalone door: it builds its own context and delegates here.
 *
 * Exported for this package's OWN internal callers (`collect()`) that
 * already hold a `ProviderContext` — not a second public entry point.
 * Nothing that builds one (`createContext`, `context.ts`) is exported from
 * this package, so an outside caller has no supported way to construct the
 * argument this takes; such a caller wants {@link collectAspects} instead,
 * which does that part for you.
 */
export async function collectAspectsFrom(
  ctx: ProviderContext,
  opts: CollectAspectsFromOptions = {},
): Promise<AspectCatalog> {
  const units = new Map<string, UnitBuilder>()
  // The root always gets a unit, even an empty one: it is where the
  // repository-wide facts (hook managers, tool trust) attach.
  unitFor(units, '.')
  const malformed: MalformedPackageJson[] = []

  const wants = (kind: AspectKind): boolean => opts.only === undefined || opts.only.includes(kind)

  await Promise.all([
    wants('cargo') ? readCargoManifests(ctx, units) : Promise.resolve(),
    wants('packageJson') ? readPackageJsonManifests(ctx, units, malformed) : Promise.resolve(),
    wants('justfile') ? readJustfiles(ctx, units) : Promise.resolve(),
    wants('makefile') ? readMakefiles(ctx, units) : Promise.resolve(),
    wants('mise') ? readMiseConfig(ctx, units) : Promise.resolve(),
    wants('hookManagers') ? readHookManagers(ctx, units) : Promise.resolve(),
    wants('toolTrust') ? readToolTrust(ctx, units) : Promise.resolve(),
  ])

  if (!opts.skipMoon) {
    await readMoonProjects(ctx, units, ctx.allowExec)
  }

  const sorted = [...units.values()].sort((a, b) => a.dir.localeCompare(b.dir))
  return {
    root: ctx.root,
    generatedAt: new Date().toISOString(),
    malformed,
    units: sorted.map((u): AspectFacts => ({
      dir: u.dir,
      ...(u.cargo ? { cargo: u.cargo } : {}),
      ...(u.packageJson ? { packageJson: u.packageJson } : {}),
      ...(u.moon ? { moon: u.moon } : {}),
      ...(u.justfile ? { justfile: u.justfile } : {}),
      ...(u.makefile ? { makefile: u.makefile } : {}),
      ...(u.mise ? { mise: u.mise } : {}),
      ...(u.packageManager ? { packageManager: u.packageManager } : {}),
      hookManagers: u.hookManagers,
      toolTrust: u.toolTrust,
      evidence: u.evidence,
    })),
  }
}

async function readCargoManifests(
  ctx: ProviderContext,
  units: Map<string, UnitBuilder>,
): Promise<void> {
  const manifests = (await ctx.files('Cargo.toml')).sort()
  for (const file of manifests) {
    const read = await readManifestText(ctx, file)
    const unit = unitFor(units, dirOf(file))
    unit.evidence.push({ kind: 'manifest', detail: file })

    if ('error' in read) {
      // `workspace` is a literal `false`, not the regex run against an empty
      // string: a file that happens to be unreadable is not evidence one way
      // or the other about whether it declares `[workspace]`, so this must
      // not look like a regex-derived answer to a consumer that reads
      // `workspace` without checking `.error` first.
      unit.cargo = { manifestPath: file, workspace: false, error: `unreadable: ${read.error}` }
      continue
    }
    unit.cargo = { manifestPath: file, workspace: hasWorkspaceTable(read.text) }
    try {
      Object.assign(unit.cargo, parseCargoRich(read.text))
    } catch (e) {
      unit.cargo.error = `parse failed: ${message(e)}`
    }
  }
}

/** A `[workspace]` table header at column 0 — TOML's own table syntax. */
function hasWorkspaceTable(text: string): boolean {
  return /^\[workspace\]/m.test(text)
}

/** Byte-wise comparison, matching `@sksizer/manifest-graph`'s own `byteCompare` — dependency order is part of the payload the two are diffed on. */
function compareUtf8(a: string, b: string): number {
  return Buffer.from(a, 'utf8').compare(Buffer.from(b, 'utf8'))
}

/** A real key/value table, not an array — `typeof [] === 'object'`, so the array check is load-bearing. */
function isTable(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value)
}

/** A dependency table's entries, key-sorted — the reference order both the cargo and node table readers use. */
function sortedTableEntries(table: unknown): Array<[string, unknown]> {
  return Object.entries(table as Record<string, unknown>).sort(([a], [b]) => compareUtf8(a, b))
}

const CARGO_DEP_TABLES: ReadonlyArray<[string, DepFactKind]> = [
  ['dependencies', 'prod'],
  ['dev-dependencies', 'dev'],
  ['dev_dependencies', 'dev'], // deprecated cargo alias, still accepted
  ['build-dependencies', 'build'],
  ['build_dependencies', 'build'],
]

function cargoDepFact(key: string, spec: unknown, kind: DepFactKind): DepFact {
  if (typeof spec === 'string') {
    return { name: key, kind, specifier: spec, specifierKind: 'registry' }
  }
  const t = (typeof spec === 'object' && spec !== null ? spec : {}) as Record<string, unknown>
  // A renamed dep (`alias = { package = "real" }`) matches by its real name.
  const name = typeof t['package'] === 'string' ? t['package'] : key
  if (typeof t['path'] === 'string') {
    return { name, kind, specifier: t['path'], specifierKind: 'path' }
  }
  if (t['workspace'] === true) {
    return { name, kind, specifier: 'workspace', specifierKind: 'workspace' }
  }
  if (typeof t['git'] === 'string') {
    return { name, kind, specifier: t['git'], specifierKind: 'other' }
  }
  if (typeof t['version'] === 'string') {
    return { name, kind, specifier: t['version'], specifierKind: 'registry' }
  }
  return { name, kind, specifier: '', specifierKind: 'other' }
}

/**
 * The `CargoFact` fields a dependency-graph consumer needs, beyond the
 * `manifestPath`/`workspace` every consumer already gets — name, version,
 * description, `publish = false`, `[workspace].members`, `[[bin]]` presence,
 * and every declared dependency. Throws on invalid TOML; the caller decides
 * what a throw means for the surrounding fact.
 */
function parseCargoRich(
  raw: string,
): Pick<
  CargoFact,
  'name' | 'version' | 'private' | 'description' | 'workspaceMembers' | 'hasBin' | 'deps'
> {
  const doc = parseToml(raw) as Record<string, unknown>

  const deps: DepFact[] = []
  for (const [table, kind] of CARGO_DEP_TABLES) {
    const t = doc[table]
    if (!isTable(t)) continue
    for (const [key, spec] of sortedTableEntries(t)) deps.push(cargoDepFact(key, spec, kind))
  }

  const pkg = (
    typeof doc['package'] === 'object' && doc['package'] !== null ? doc['package'] : {}
  ) as Record<string, unknown>
  const workspace = (
    typeof doc['workspace'] === 'object' && doc['workspace'] !== null ? doc['workspace'] : {}
  ) as Record<string, unknown>
  const members = workspace['members']
  const workspaceMembers = Array.isArray(members)
    ? members.filter((m): m is string => typeof m === 'string')
    : []

  return {
    ...(typeof pkg['name'] === 'string' ? { name: pkg['name'] } : {}),
    ...(typeof pkg['version'] === 'string' ? { version: pkg['version'] } : {}),
    ...(pkg['publish'] === false ? { private: true } : {}),
    ...(typeof pkg['description'] === 'string' ? { description: pkg['description'] } : {}),
    ...(workspaceMembers.length > 0 ? { workspaceMembers } : {}),
    ...(Array.isArray(doc['bin']) && doc['bin'].length > 0 ? { hasBin: true } : {}),
    ...(deps.length > 0 ? { deps } : {}),
  }
}

/**
 * `package.json` is read through {@link readManifestText} plus our own
 * `JSON.parse` here, not `ctx.readJson`/`ctx.readText` (which the rest of
 * this package still uses elsewhere) — both swallow a read or parse failure
 * into a bare `null`, discarding the thrown error's own message, and this
 * function needs that message to report a malformed manifest the same way a
 * direct `JSON.parse` caller always has. No other reader in this package
 * asks for a `package.json`'s content once this module exists (every
 * provider reads it as a fact instead), so reading it independently here
 * costs no second read of the same file.
 */
async function readPackageJsonManifests(
  ctx: ProviderContext,
  units: Map<string, UnitBuilder>,
  malformed: MalformedPackageJson[],
): Promise<void> {
  const manifests = (await ctx.files('package.json')).sort()
  for (const file of manifests) {
    const read = await readManifestText(ctx, file)
    if ('error' in read) {
      malformed.push({ path: file, error: `unreadable: ${read.error}` })
      continue
    }

    const text = read.text
    let parsed: unknown
    try {
      parsed = JSON.parse(text)
    } catch (e) {
      malformed.push({ path: file, error: `parse failed: ${message(e)}` })
      continue
    }
    if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
      malformed.push({ path: file, error: 'parse failed: package.json is not a JSON object' })
      continue
    }

    const pkg = parsed as {
      name?: unknown
      main?: unknown
      types?: unknown
      scripts?: unknown
      dependencies?: unknown
      devDependencies?: unknown
      peerDependencies?: unknown
      optionalDependencies?: unknown
      packageManager?: unknown
      version?: unknown
      private?: unknown
      description?: unknown
      workspaces?: unknown
      bin?: unknown
    }

    const dir = dirOf(file)
    const unit = unitFor(units, dir)
    const packageManagerPin = parsePackageManagerPin(pkg.packageManager)
    const deps = nodeDeps(pkg)
    const workspaces = nodeWorkspaces(pkg.workspaces)
    unit.packageJson = {
      manifestPath: file,
      ...(typeof pkg.name === 'string' ? { name: pkg.name } : {}),
      ...(typeof pkg.main === 'string' ? { main: pkg.main } : {}),
      ...(typeof pkg.types === 'string' ? { types: pkg.types } : {}),
      scripts: stringEntries(pkg.scripts),
      dependencies: unionDependencyNames(
        pkg.dependencies,
        pkg.devDependencies,
        pkg.peerDependencies,
        pkg.optionalDependencies,
      ),
      ...(packageManagerPin ? { packageManagerPin } : {}),
      ...(typeof pkg.version === 'string' ? { version: pkg.version } : {}),
      ...(pkg.private === true ? { private: true } : {}),
      ...(typeof pkg.description === 'string' ? { description: pkg.description } : {}),
      ...(workspaces.length > 0 ? { workspaces } : {}),
      ...(nodeHasBin(pkg.bin) ? { hasBin: true } : {}),
      ...(deps.length > 0 ? { deps } : {}),
    }
    unit.evidence.push({ kind: 'manifest', detail: file })

    await attachPackageManager(ctx, unit, dir, pkg.packageManager)
  }
}

function message(e: unknown): string {
  return e instanceof Error ? e.message : String(e)
}

/**
 * Reads a manifest's own content directly, preserving the thrown error's real
 * message. `ctx.readText`'s shared, memoized cache (`context.ts`) exists so
 * several providers reading the SAME file cost one read; it does that by
 * collapsing every failure into a bare `null`, discarding the cause, which is
 * fine for a caller that only needs to know "unreadable," but `readCargoManifests`
 * and `readPackageJsonManifests` promise the real OS error text in their
 * `unreadable: …` diagnostic. Reading independently here does not reintroduce
 * a double read: this module is the only place in the package that reads a
 * `Cargo.toml`/`package.json`'s content at all — every provider now reads
 * the parsed fact instead.
 */
async function readManifestText(
  ctx: ProviderContext,
  relPath: string,
): Promise<{ text: string } | { error: string }> {
  try {
    return { text: await readFile(join(ctx.root, relPath), 'utf-8') }
  } catch (e) {
    return { error: message(e) }
  }
}

const NODE_DEP_FIELDS: ReadonlyArray<[string, DepFactKind]> = [
  ['dependencies', 'prod'],
  ['devDependencies', 'dev'],
  ['peerDependencies', 'peer'],
  ['optionalDependencies', 'optional'],
]

function classifyNodeSpecifier(spec: string): DepFactSpecifierKind {
  if (spec.startsWith('workspace:')) return 'workspace'
  if (spec.startsWith('file:')) return 'file'
  // git/github/http/npm-alias/link specifiers all carry a ':' or start like a
  // path; a plain registry range or dist-tag never does.
  if (spec.includes(':') || spec.startsWith('.') || spec.startsWith('/')) return 'other'
  return 'registry'
}

function nodeDeps(pkg: Record<string, unknown>): DepFact[] {
  const deps: DepFact[] = []
  for (const [field, kind] of NODE_DEP_FIELDS) {
    const table = pkg[field]
    if (!isTable(table)) continue
    for (const [name, spec] of sortedTableEntries(table)) {
      const specifier = typeof spec === 'string' ? spec : String(spec)
      deps.push({ name, kind, specifier, specifierKind: classifyNodeSpecifier(specifier) })
    }
  }
  return deps
}

/** node `workspaces` is either an array of globs or `{ packages: [...] }`. */
function nodeWorkspaces(ws: unknown): string[] {
  if (Array.isArray(ws)) return ws.filter((g): g is string => typeof g === 'string')
  if (isTable(ws) && Array.isArray(ws['packages'])) {
    return (ws['packages'] as unknown[]).filter((g): g is string => typeof g === 'string')
  }
  return []
}

function nodeHasBin(bin: unknown): boolean {
  return typeof bin === 'string' || (isTable(bin) && Object.keys(bin).length > 0)
}

function stringEntries(value: unknown): Record<string, string> {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return {}
  const out: Record<string, string> = {}
  for (const [key, val] of Object.entries(value as Record<string, unknown>)) {
    if (typeof val === 'string') out[key] = val
  }
  return out
}

function dependencyNames(value: unknown): string[] {
  if (value === null || typeof value !== 'object' || Array.isArray(value)) return []
  return Object.keys(value as Record<string, unknown>)
}

function unionDependencyNames(...tables: unknown[]): string[] {
  const names = new Set<string>()
  for (const table of tables) {
    for (const name of dependencyNames(table)) names.add(name)
  }
  return [...names].sort()
}

/**
 * The node package manager THIS directory's own files name — never resolved
 * by walking up to a parent's lockfile. A nested package's own facts must
 * describe only what is actually in that directory; a consumer that wants
 * "which manager does this nested package effectively use" walks the
 * catalog's units itself (Layer 2a's `resolveInstall`, PR 2).
 */
async function attachPackageManager(
  ctx: ProviderContext,
  unit: UnitBuilder,
  dir: string,
  packageManagerField: unknown,
): Promise<void> {
  const lockfileFact = await findLockfile(ctx, dir)
  if (lockfileFact === undefined) return

  const pin = parsePackageManagerPin(packageManagerField)
  unit.packageManager = { ...lockfileFact, ...(pin ? { pin } : {}) }
  unit.evidence.push({ kind: 'files', detail: lockfileFact.lockfile })
}

/** The first `NODE_LOCKFILE_MANAGERS` lockfile actually present in `dir` — never a parent's. */
async function findLockfile(
  ctx: ProviderContext,
  dir: string,
): Promise<{ kind: NodePackageManagerKind; lockfile: string } | undefined> {
  for (const { files, manager } of NODE_LOCKFILE_MANAGERS) {
    if (!isNodePackageManagerKind(manager.kind)) continue
    for (const name of files) {
      const rel = dir === '.' ? name : `${dir}/${name}`
      if (await ctx.exists(rel)) return { kind: manager.kind, lockfile: rel }
    }
  }
  return undefined
}

/**
 * `"pnpm@9.0.0"` → `{ manager: "pnpm", version: "9.0.0" }`. Prefers
 * `managers.ts`'s `managerFromField` for the canonical (trimmed, lower-cased)
 * name, but still records a pin whose manager that function does not
 * recognise — a project can pin `packageManager` to anything, and dropping
 * the fact entirely would hide a real declaration from a doctor-style
 * consumer.
 */
function parsePackageManagerPin(field: unknown): { manager: string; version: string } | undefined {
  if (typeof field !== 'string') return undefined
  const at = field.indexOf('@')
  if (at <= 0) return undefined
  const loose = field.slice(0, at).trim().toLowerCase()
  const version = field.slice(at + 1).trim()
  if (loose === '' || version === '') return undefined
  return { manager: managerFromField(field)?.kind ?? loose, version }
}

async function readJustfiles(ctx: ProviderContext, units: Map<string, UnitBuilder>): Promise<void> {
  const files = [
    ...(await ctx.files('justfile')),
    ...(await ctx.files('Justfile')),
    ...(await ctx.files('.justfile')),
  ].sort()
  for (const file of files) {
    const unit = unitFor(units, dirOf(file))
    unit.justfile = { path: file }
    unit.evidence.push({ kind: 'files', detail: file })
  }
}

/**
 * `Makefile`/`makefile`/`GNUmakefile`, mirroring `readJustfiles` — presence
 * only. `providers/make.ts` still reads each file's TEXT itself to scan
 * targets, since that parsing is provider-specific and not a fact any other
 * consumer wants.
 */
async function readMakefiles(ctx: ProviderContext, units: Map<string, UnitBuilder>): Promise<void> {
  const files = (await Promise.all(MAKEFILE_NAMES.map((name) => ctx.files(name)))).flat().sort()
  for (const file of files) {
    const unit = unitFor(units, dirOf(file))
    unit.makefile = { path: file }
    unit.evidence.push({ kind: 'files', detail: file })
  }
}

/**
 * Root-only, mirroring `providers/mise.ts`'s own scope: mise merges configs
 * at any depth, but this checks the same root-level list that provider does,
 * not a full-tree scan it does not do either.
 */
async function readMiseConfig(
  ctx: ProviderContext,
  units: Map<string, UnitBuilder>,
): Promise<void> {
  const unit = unitFor(units, '.')
  // `unit.mise` stays singular (first match wins, per `AspectFacts.mise`'s
  // pinned `{path: string}` shape) but evidence is pushed for EVERY present
  // config, not just the first — a repo with both `mise.toml` and
  // `mise.local.toml` (the local-override pattern `MISE_CONFIGS` itself
  // anticipates) genuinely has both backing the fact, and a consumer of
  // `AspectFacts.evidence` should see both, not lose one to an early return.
  for (const config of MISE_CONFIGS) {
    if (await ctx.exists(config)) {
      unit.mise ??= { path: config }
      unit.evidence.push({ kind: 'files', detail: config })
    }
  }
}

/** Repository-wide: which hook manager(s) a fresh worktree needs armed. */
async function readHookManagers(
  ctx: ProviderContext,
  units: Map<string, UnitBuilder>,
): Promise<void> {
  const unit = unitFor(units, '.')
  for (const { files, manager } of HOOK_MANAGER_MARKERS) {
    for (const file of files) {
      if (await ctx.exists(file)) {
        unit.hookManagers.push(manager)
        unit.evidence.push({ kind: 'files', detail: file })
        break
      }
    }
  }
}

/** Repository-wide: which per-directory tool/env trust a fresh checkout needs. */
async function readToolTrust(ctx: ProviderContext, units: Map<string, UnitBuilder>): Promise<void> {
  const unit = unitFor(units, '.')
  for (const { files, tool } of TOOL_TRUST_MARKERS) {
    for (const file of files) {
      if (await ctx.exists(file)) {
        unit.toolTrust.push(tool)
        unit.evidence.push({ kind: 'files', detail: file })
        break
      }
    }
  }
}

interface MoonProject {
  id: string
  source: string
  layer?: string
  stack?: string
  language?: string
}

/**
 * `moon.present`/`moon.role`, gated on `allowExec` exactly the way
 * `providers/moon.ts` gates itself: a `moon`-kind provider never even sees
 * `allowExec: false`, so this checks nothing and calls nothing when it is
 * off, rather than reporting a marker-only, role-less half-answer that
 * provider does not report either.
 */
async function readMoonProjects(
  ctx: ProviderContext,
  units: Map<string, UnitBuilder>,
  allowExec: boolean,
): Promise<void> {
  if (!allowExec) return
  const marker =
    (await ctx.exists('.moon/workspace.yml')) || (await ctx.exists('.moon/workspace.yaml'))
  if (!marker) return

  const res = await ctx
    .runner('moon')
    .run(['query', 'projects'], { cwd: ctx.root, env: { MOON_JSON: 'true' } })
  if (res.exitCode !== 0) return

  let parsed: { projects?: MoonProject[] }
  try {
    parsed = JSON.parse(res.stdout) as { projects?: MoonProject[] }
  } catch {
    return
  }

  for (const project of parsed.projects ?? []) {
    const dir = normalizeMoonSource(project.source)
    const unit = unitFor(units, dir)
    const role: MoonRole = {
      ...(project.layer !== undefined ? { layer: project.layer } : {}),
      ...(project.stack !== undefined ? { stack: project.stack } : {}),
      ...(project.language !== undefined ? { language: project.language } : {}),
    }
    unit.moon = { present: true, id: project.id, ...(Object.keys(role).length > 0 ? { role } : {}) }
    unit.evidence.push({ kind: 'files', detail: '.moon/workspace.yml' })
  }
}

/** moon reports the root project's own source as `"."` already; guard the empty string too. */
function normalizeMoonSource(source: string): string {
  return source === '' ? '.' : source
}
