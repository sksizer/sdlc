/**
 * The lockfile-driven dependency-install ladder — moved here (from sdlc's
 * `solutions/ontological/lib/config/detect-deps.ts`) as part of consolidating
 * manifest/ecosystem detection into this package: `setup`'s own default
 * heuristic ("what installs this project's dependencies") belongs beside the
 * task/runner detection it already falls back from, not as sdlc-local code
 * duplicating a table this package half of already owns
 * (`NODE_LOCKFILE_MANAGERS`).
 *
 * One dependency-install verb per detected ecosystem. For JavaScript a single
 * command is emitted, the strongest lockfile signal winning (bun → pnpm →
 * yarn → npm); `package.json` must be present for any JS detection. Other
 * ecosystems (Rust, Go, Ruby, Python) are independent and each emit at most
 * one verb.
 *
 * `resolveInstall` takes an optional `facts` — the `AspectFacts` for
 * `projectRoot`'s own directory (`AspectCatalog.units` entry for `dir: "."`),
 * already computed by a caller that has one (`collect()`'s own consumers,
 * `@sksizer/detect-runners`'s vocabulary resolver). When supplied, it answers
 * the JavaScript and Rust checks from those already-parsed facts instead of
 * re-reading `package.json`/`Cargo.toml`; Go, Ruby and Python have no
 * `AspectFacts` field (out of this consolidation's scope — see `detection.md`
 * §2's Layer 1 interface), so those four checks always read the filesystem
 * directly, exactly as before. Omitting `facts` falls back to reading
 * `package.json`/`Cargo.toml` too, so a caller with no catalog in hand yet
 * gets the identical answer this module always gave.
 *
 * Pure: best-effort. An absent marker yields no candidate, never an error.
 *
 * {@link hasMissingDeps} / {@link missingDeps} answer the follow-up question —
 * which detected ecosystem has no installed deps dir yet — for a `hooks:`
 * step's `when: deps-missing` condition.
 *
 * `SetupCandidate` is its own small shape, not the `Task` model this
 * package's `collect()`/`tasks()` return: these are one-off bootstrap verbs
 * with no runner, no parameters and nothing to enumerate.
 */

import { existsSync, statSync } from 'node:fs'
import { join } from 'node:path'

import type { AspectFacts } from './aspects.ts'
import { NODE_LOCKFILE_MANAGERS } from './managers.ts'

export interface SetupCandidate {
  /** Family: `deps` | `git-hooks` | `tool-trust`. Drives a caller's own KIND_ORDER. */
  kind: string
  /** The specific tool (e.g. `bun`, `lefthook`, `mise`). */
  name: string
  /** The shell verb a user would type (e.g. `bun install`). */
  command: string
  /** The project-relative file the candidate was inferred from. */
  source: string
}

/**
 * Install verb per package manager. Deliberately NOT folded into
 * `NODE_LOCKFILE_MANAGERS`: that table owns the lockfile→manager mapping and
 * the verb that RUNS a script, and installing is a different question with a
 * different answer. Exported so a pinned-manager resolver can derive its own
 * frozen-lockfile variant from this same table instead of re-declaring the
 * manager→verb mapping.
 */
export const INSTALL_VERBS: Readonly<Record<string, string>> = {
  bun: 'bun install',
  pnpm: 'pnpm install',
  yarn: 'yarn install',
  npm: 'npm ci',
}

function isFile(p: string): boolean {
  try {
    return statSync(p).isFile()
  } catch {
    return false
  }
}

/**
 * One dependency-install verb per detected ecosystem at `projectRoot`. See
 * the module docblock for what `facts` changes and what it never can (Go,
 * Ruby, Python have no `AspectFacts` field).
 */
export function resolveInstall(projectRoot: string, facts?: AspectFacts): SetupCandidate[] {
  const out: SetupCandidate[] = []

  // JavaScript — the lockfile picks the package manager. The precedence and
  // the lockfile names come from `NODE_LOCKFILE_MANAGERS`, this package's own
  // table.
  //
  // The INSTALL verb stays here. The lockfile table maps a lockfile to the
  // verb that RUNS a script, which is a different question — and `npm ci`
  // versus `npm install` turns on whether a lockfile exists at all, which is
  // install-specific and has no meaning for running one.
  const hasPackageJson =
    facts?.packageJson !== undefined ? true : isFile(join(projectRoot, 'package.json'))
  if (hasPackageJson) {
    const matched =
      facts?.packageManager !== undefined
        ? { file: facts.packageManager.lockfile, kind: facts.packageManager.kind }
        : NODE_LOCKFILE_MANAGERS.flatMap(({ files, manager }) =>
            files.map((file) => ({ file, kind: manager.kind })),
          ).find(({ file }) => isFile(join(projectRoot, file)))

    const [name, command, source] =
      matched === undefined
        ? ['npm', 'npm install', 'package.json']
        : [matched.kind, INSTALL_VERBS[matched.kind] ?? `${matched.kind} install`, matched.file]
    out.push({ kind: 'deps', name, command, source })
  }

  // Rust.
  const hasCargoToml = facts?.cargo !== undefined ? true : isFile(join(projectRoot, 'Cargo.toml'))
  if (hasCargoToml) {
    out.push({ kind: 'deps', name: 'cargo', command: 'cargo fetch', source: 'Cargo.toml' })
  }

  // Go.
  if (isFile(join(projectRoot, 'go.mod'))) {
    out.push({ kind: 'deps', name: 'go', command: 'go mod download', source: 'go.mod' })
  }

  // Ruby.
  if (isFile(join(projectRoot, 'Gemfile'))) {
    out.push({ kind: 'deps', name: 'bundler', command: 'bundle install', source: 'Gemfile' })
  }

  // Python — one verb, strongest signal first (uv lock → poetry lock →
  // requirements.txt).
  if (isFile(join(projectRoot, 'uv.lock'))) {
    out.push({ kind: 'deps', name: 'uv', command: 'uv sync', source: 'uv.lock' })
  } else if (isFile(join(projectRoot, 'poetry.lock'))) {
    out.push({ kind: 'deps', name: 'poetry', command: 'poetry install', source: 'poetry.lock' })
  } else if (isFile(join(projectRoot, 'requirements.txt'))) {
    out.push({
      kind: 'deps',
      name: 'pip',
      command: 'pip install -r requirements.txt',
      source: 'requirements.txt',
    })
  }

  return out
}

/**
 * The project-local directory (or file) an installed ecosystem leaves behind,
 * per {@link SetupCandidate.name}. Any one present means "installed". An
 * ecosystem absent here (cargo, go, bundler, poetry, pip) installs into a
 * machine-wide cache or an environment this package cannot locate, so it
 * never counts as missing: guessing wrong there would re-run an install on
 * every commit.
 */
const DEPS_DIRS: Readonly<Record<string, readonly string[]>> = {
  bun: ['node_modules'],
  pnpm: ['node_modules'],
  npm: ['node_modules'],
  // Yarn Plug'n'Play installs no `node_modules`; its `.pnp.cjs` is the marker.
  yarn: ['node_modules', '.pnp.cjs'],
  uv: ['.venv'],
}

/**
 * The {@link resolveInstall} candidates at `projectRoot` whose project-local
 * deps dir is absent — the install verbs a fresh checkout still needs. Empty
 * when every detected ecosystem is installed or none has a local deps dir.
 *
 * A `package.json` with no lockfile never counts: nothing says it has
 * dependencies at all, and an install with none creates no `node_modules`,
 * so the step would re-run forever.
 */
export function missingDeps(projectRoot: string, facts?: AspectFacts): SetupCandidate[] {
  return resolveInstall(projectRoot, facts).filter((c) => {
    if (c.source === 'package.json') return false
    const markers = DEPS_DIRS[c.name]
    return markers !== undefined && !markers.some((m) => existsSync(join(projectRoot, m)))
  })
}

/**
 * Whether `projectRoot` has a dependency manifest whose deps dir is absent
 * (`bun.lock` + `package.json` with no `node_modules`, `uv.lock` with no
 * `.venv`, …) — a `hooks:` step's `when: deps-missing` condition, and the
 * question a setup resolver asks before re-running an install.
 */
export function hasMissingDeps(projectRoot: string, facts?: AspectFacts): boolean {
  return missingDeps(projectRoot, facts).length > 0
}
