/**
 * Pinned package-manager resolution for `resolveInstall`'s JS candidate —
 * moved here (from sdlc's `solutions/ontological/lib/config/pinned-manager.ts`)
 * alongside `install.ts`, for the same reason: this is "how to install it,"
 * which this package already owns for every other runner.
 *
 * `resolveInstall`'s node-manager candidates (`bun install`, `pnpm install`,
 * …) assume whatever `<pm>` a shell finds on PATH is the right one. A repo
 * that pins `packageManager: "<pm>@<version>"` in `package.json` (the field
 * corepack reads) wants THAT version specifically — a stale `bun` on PATH can
 * silently rewrite a lockfile the pinned `bun` authored. This module resolves
 * a general, repo-shape-agnostic ladder: try PATH first, then
 * `proto run <pm> --`, then `mise exec -- <pm>` (mise's trust scoped to this
 * one call via `env MISE_TRUSTED_CONFIG_PATHS=<root>`, since a freshly
 * created worktree path isn't yet a trusted mise config location) —
 * stopping at the first executable whose reported version matches the pin,
 * falling back to the first executable found at all when none match.
 *
 * Probing goes through `@sksizer/command-seam`'s `spawnRunner`, so tests
 * inject a fake `CommandRunner` instead of touching real PATH/proto/mise
 * state. A version mismatch does not block resolution: the resolved command
 * is still used, but the returned command STRING is prefixed with an
 * `echo ... >&2;` warning, since resolution happens once and whoever runs the
 * returned verb later has no other hook to surface the mismatch.
 *
 * `allowExec` (the caller's OWN trust decision, e.g. sdlc's `defaultSetup`'s
 * `trust || isRepoTrusted(repoRoot)`) gates the proto/mise probes: both
 * execute config the REPOSITORY under resolution controls (`.prototools`,
 * `mise.toml`), the mise probe additionally forcing `MISE_TRUSTED_CONFIG_PATHS`
 * so a freshly created worktree isn't refused by mise's own trust store. Doing
 * either before this caller's own trust gate would let an untrusted repo's
 * config execute merely by being probed for a package-manager version — the
 * resolution ladder degrades to PATH-only until `allowExec` is true. The PATH
 * probe always runs regardless of `allowExec` — but "PATH is host-controlled"
 * is only mostly true: a corepack-wrapped `<pm>` on PATH reads the CURRENT
 * DIRECTORY's own `package.json` to decide what to actually exec, so probing
 * it from inside an untrusted repo can still run that repo's own pinned
 * version. {@link resolvePinnedManagerInstall} therefore runs the PATH probe
 * from a neutral cwd (`os.tmpdir()`), never `projectRoot`, so a corepack shim
 * has nothing repo-controlled to read; the proto/mise probes below, already
 * gated on `allowExec`, keep running from `projectRoot` since resolving their
 * OWN pin (`.prototools`/`mise.toml`) is the point of asking them at all.
 */

import { readFileSync, statSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { type CommandRunner, spawnRunner } from '@sksizer/command-seam'

import type { AspectFacts } from './aspects.ts'
import { INSTALL_VERBS, type SetupCandidate } from './install.ts'
import { NODE_LOCKFILE_MANAGERS } from './managers.ts'

function isFile(p: string): boolean {
  try {
    return statSync(p).isFile()
  } catch {
    return false
  }
}

/** Node package-manager kinds `resolveInstall`/`NODE_LOCKFILE_MANAGERS` know. */
const NODE_MANAGER_KINDS: ReadonlySet<string> = new Set(
  NODE_LOCKFILE_MANAGERS.map(({ manager }) => manager.kind),
)

/**
 * The install argv per manager, WITH the frozen-lockfile flag applied,
 * derived from `install.ts`'s own `INSTALL_VERBS` table rather than
 * re-declaring the manager→verb mapping here. `npm ci` is already frozen by
 * definition (it refuses to touch the lockfile) — no extra flag exists to
 * add, so `npm` is the one manager this leaves unmodified.
 */
function frozenInstallArgv(manager: string): readonly string[] | undefined {
  const verb = INSTALL_VERBS[manager]
  if (verb === undefined) return undefined
  const [, ...argv] = verb.split(' ')
  return manager === 'npm' ? argv : [...argv, '--frozen-lockfile']
}

/** Where a resolved executable was found. */
export type PinnedManagerSource = 'path' | 'proto' | 'mise'

export interface PackageManagerPin {
  manager: string
  version: string
}

export interface PinnedManagerResolution {
  /**
   * The shell command to run, e.g. `"bun install --frozen-lockfile"` — or,
   * on a version mismatch, that command prefixed with an `echo ... >&2;`
   * warning clause.
   */
  command: string
  source: PinnedManagerSource
  /** The resolved executable's own reported version (trimmed stdout). */
  resolvedVersion: string
  /** `true` when `resolvedVersion` didn't match the pin. */
  versionMismatch: boolean
}

export interface ResolvePinnedManagerOptions {
  /** Defaults to `spawnRunner`. Tests inject a fake per binary. */
  runnerFor?: (binary: string) => CommandRunner
  /**
   * `projectRoot`'s own `AspectFacts` (the catalog's `dir: "."` unit), when
   * the caller already has one — avoids re-reading `package.json` for the
   * pin. Omit to fall back to {@link readPackageManagerPin}'s own file read.
   */
  facts?: AspectFacts
}

/**
 * Safe to interpolate, unquoted, into a double-quoted `sh` string: a
 * corepack-style version (`1.4.2`, or `1.4.2+sha512-...`). Guards both
 * {@link readPackageManagerPin} (a malformed pin is declined, same as a
 * missing one) and a facts-supplied pin (`../aspects.ts`'s own parsing does
 * not apply this shell-safety check, only shape validation) — an unexpected
 * version string is treated as "no match" rather than embedded verbatim in
 * the warning `echo`, which would otherwise let a crafted version string
 * break out of the double quotes via `$()`/backticks/`"`.
 */
const SAFE_VERSION_RE = /^[A-Za-z0-9_.+-]+$/

/**
 * `package.json`'s `packageManager` field at `projectRoot`, parsed into
 * `{manager, version}`. `null` when the file is absent/unparseable, the
 * field is missing or malformed (no `@`, empty version), or its manager name
 * isn't one `NODE_LOCKFILE_MANAGERS` recognises — a repo can pin a tool this
 * ladder doesn't resolve (e.g. a future manager); that's not this function's
 * problem, it just declines to match.
 */
export function readPackageManagerPin(projectRoot: string): PackageManagerPin | null {
  const path = join(projectRoot, 'package.json')
  if (!isFile(path)) return null

  let parsed: unknown
  try {
    parsed = JSON.parse(readFileSync(path, 'utf-8'))
  } catch {
    return null
  }
  if (typeof parsed !== 'object' || parsed === null) return null

  const field = (parsed as Record<string, unknown>)['packageManager']
  if (typeof field !== 'string') return null

  const at = field.indexOf('@')
  if (at <= 0) return null
  const manager = field.slice(0, at).trim().toLowerCase()
  const version = field.slice(at + 1).trim()
  if (version === '' || !NODE_MANAGER_KINDS.has(manager)) return null
  // A version with characters outside SAFE_VERSION_RE can never be safely
  // interpolated into the warning `echo` below — decline rather than risk it
  // later, same as any other malformed pin.
  if (!SAFE_VERSION_RE.test(version)) return null

  return { manager, version }
}

interface ProbeSpec {
  source: PinnedManagerSource
  /** The binary `spawnRunner`/`runnerFor` is bound to for this probe. */
  binary: string
  /** Args (excluding `binary`) that print the manager's own version. */
  versionArgs: string[]
  /** Argv PREFIX that invokes the manager itself; the install argv follows. */
  prefix: string[]
  /**
   * Working directory the version probe itself runs from. The PATH probe
   * uses a neutral directory (module docblock: a corepack-wrapped `<pm>`
   * reads the CWD's own `package.json`, so probing from `projectRoot` would
   * still let an untrusted repo steer which version runs); proto/mise
   * deliberately run from `projectRoot` since resolving that repo's own
   * `.prototools`/`mise.toml` pin is the point of asking them.
   */
  cwd: string
}

/**
 * The resolution ladder for `pm`, in probe order. proto/mise are omitted
 * entirely when `!allowExec` — see the module docblock — leaving only the
 * PATH probe, which runs from a neutral cwd rather than `projectRoot` (see
 * {@link ProbeSpec.cwd}).
 */
function probesFor(pm: string, projectRoot: string, allowExec: boolean): ProbeSpec[] {
  const pathProbe: ProbeSpec = {
    source: 'path',
    binary: pm,
    versionArgs: ['--version'],
    prefix: [pm],
    cwd: tmpdir(),
  }
  if (!allowExec) return [pathProbe]

  const miseTrust = `MISE_TRUSTED_CONFIG_PATHS=${projectRoot}`
  return [
    pathProbe,
    {
      source: 'proto',
      binary: 'proto',
      versionArgs: ['run', pm, '--', '--version'],
      prefix: ['proto', 'run', pm, '--'],
      cwd: projectRoot,
    },
    {
      source: 'mise',
      // `env VAR=val <cmd>` scopes the trust grant to this one call rather
      // than exporting it into the whole shell — see the module docblock.
      binary: 'env',
      versionArgs: [miseTrust, 'mise', 'exec', '--', pm, '--version'],
      prefix: ['env', miseTrust, 'mise', 'exec', '--', pm],
      cwd: projectRoot,
    },
  ]
}

/** `1.4.2+sha512-...` → `1.4.2`: corepack's optional integrity suffix never appears in `--version` output, so it must be stripped before comparing. */
function stripHashSuffix(version: string): string {
  const plus = version.indexOf('+')
  return plus === -1 ? version : version.slice(0, plus)
}

/**
 * Resolve `candidate` (one of `resolveInstall`'s candidates) against
 * `projectRoot`'s `packageManager` pin, per the module docblock's ladder.
 *
 * `allowExec` gates the proto/mise probes (module docblock) — pass the SAME
 * value the caller used to decide whether it may execute this repository's
 * own task runners at all, never `true` unconditionally.
 *
 * `null` when: `candidate` isn't a node-package-manager `deps` candidate; no
 * pin is declared (or it's malformed, or not a safely-quotable version); or
 * every probe fails outright (PATH, proto, and mise all absent/erroring, or
 * `!allowExec` and PATH alone doesn't match) — in every `null` case the
 * caller falls back to `candidate.command` unpinned, which then fails loudly
 * on its own if nothing can run it.
 */
export function resolvePinnedManagerInstall(
  candidate: SetupCandidate,
  projectRoot: string,
  allowExec: boolean,
  opts: ResolvePinnedManagerOptions = {},
): PinnedManagerResolution | null {
  if (candidate.kind !== 'deps' || !NODE_MANAGER_KINDS.has(candidate.name)) return null

  const pin = resolvePin(projectRoot, opts.facts)
  if (pin === null || pin.manager !== candidate.name) return null

  const installArgv = frozenInstallArgv(candidate.name)
  // Unreachable given NODE_MANAGER_KINDS (every kind has an entry in
  // INSTALL_VERBS too); kept so a future kind added to one table without the
  // other fails closed.
  if (installArgv === undefined) return null

  const runnerFor = opts.runnerFor ?? spawnRunner
  let fallback: { source: PinnedManagerSource; prefix: string[]; version: string } | null = null

  for (const probe of probesFor(candidate.name, projectRoot, allowExec)) {
    const result = runnerFor(probe.binary).run(probe.versionArgs, { cwd: probe.cwd })
    if (result.exitCode !== 0) continue

    const version = result.stdout.trim()
    // A version this ladder can't safely quote is treated the same as a
    // non-match: it never becomes `resolvedVersion`/`command` text.
    if (!SAFE_VERSION_RE.test(version)) continue
    if (stripHashSuffix(version) === stripHashSuffix(pin.version)) {
      return {
        command: [...probe.prefix, ...installArgv].join(' '),
        source: probe.source,
        resolvedVersion: version,
        versionMismatch: false,
      }
    }
    if (fallback === null) fallback = { source: probe.source, prefix: probe.prefix, version }
  }

  if (fallback === null) return null // nothing on PATH, proto, or mise at all

  // Generic wording, not "sdlc setup": this package is published standalone
  // (@sksizer/detect-runners) and read by more than one caller (sdlc,
  // waypost, a bare npm consumer) — naming a specific caller here would be a
  // false claim for every one of them but sdlc's own eventual setup flow.
  const warning =
    `echo "package manager mismatch: ${candidate.name} ${fallback.version} found, repo pins` +
    ` ${pin.version} (packageManager)" >&2;`
  return {
    command: `${warning} ${[...fallback.prefix, ...installArgv].join(' ')}`,
    source: fallback.source,
    resolvedVersion: fallback.version,
    versionMismatch: true,
  }
}

/**
 * `opts.facts`'s own pin when supplied (re-validated the same way
 * {@link readPackageManagerPin} validates a file-read one — `AspectFacts`'s
 * own parsing checks shape, not shell-safety), else a fresh file read.
 */
function resolvePin(projectRoot: string, facts: AspectFacts | undefined): PackageManagerPin | null {
  const factsPin = facts?.packageJson?.packageManagerPin
  if (factsPin === undefined) return readPackageManagerPin(projectRoot)
  if (!NODE_MANAGER_KINDS.has(factsPin.manager)) return null
  if (!SAFE_VERSION_RE.test(factsPin.version)) return null
  return factsPin
}
