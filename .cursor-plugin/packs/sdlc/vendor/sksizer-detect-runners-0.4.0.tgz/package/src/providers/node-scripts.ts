/**
 * package.json `scripts` — npm, pnpm, yarn or bun.
 *
 *   - The run verb is DERIVED from the repo, not assumed.
 *   - The lockfile is searched UPWARD from each manifest, so a nested package
 *     in a workspace resolves to the workspace's manager rather than to the
 *     npm default.
 *
 * Manifest content (scripts, name, the package-manager pin) comes from the
 * shared `AspectFacts` catalog every provider now receives — this provider
 * stops calling `ctx.readJson()` itself. `ctx.files('package.json')` stays:
 * it is the enumeration the fingerprint/cache layer records against this
 * provider's own probe, and it is also how a MALFORMED manifest is still
 * noticed (`collectAspectsFrom` silently drops one it cannot parse, so a
 * file present in the listing but absent from the facts is exactly the
 * unparseable case below).
 */

import type { AspectCatalog, AspectFacts } from '../aspects.ts'
import type { ProviderContext, RunnerProvider } from '../contract.ts'
import { managerFromField, NODE_LOCKFILE_MANAGERS, type NodeManager } from '../managers.ts'
import type { Diagnostic, ProviderResult, RunnerBrand, Task } from '../model.ts'
import { dirOf, looksPersistent, taskId, tierOf } from './shared.ts'

const CHAIN = [
  {
    label: 'runner',
    hint: 'The package manager runs the `scripts` entries declared in a package.json.',
  },
  {
    label: 'directory',
    hint: 'The directory the package sits in. A grouping this catalog adds, not part of the command.',
  },
  { label: 'package', hint: "The package's declared name, or its path when it has none." },
  { label: 'script', hint: 'The key under `scripts` in that package.json.' },
]

/** Fallback when no lockfile and no `packageManager` field is found anywhere. */
const NPM: NodeManager = { kind: 'npm', runVerb: ['npm', 'run'], dirFlag: '--prefix' }

/**
 * The Node.js hexagonal mark. Node.js is a trademark of the OpenJS
 * Foundation; it is used here nominatively, to identify the tool. Icon
 * path and color: simple-icons v16 (CC0), slug `nodedotjs`.
 */
const BRAND: RunnerBrand = {
  icon: '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M11.998,24c-0.321,0-0.641-0.084-0.922-0.247l-2.936-1.737c-0.438-0.245-0.224-0.332-0.08-0.383 c0.585-0.203,0.703-0.25,1.328-0.604c0.065-0.037,0.151-0.023,0.218,0.017l2.256,1.339c0.082,0.045,0.197,0.045,0.272,0l8.795-5.076 c0.082-0.047,0.134-0.141,0.134-0.238V6.921c0-0.099-0.053-0.192-0.137-0.242l-8.791-5.072c-0.081-0.047-0.189-0.047-0.271,0 L3.075,6.68C2.99,6.729,2.936,6.825,2.936,6.921v10.15c0,0.097,0.054,0.189,0.139,0.235l2.409,1.392 c1.307,0.654,2.108-0.116,2.108-0.89V7.787c0-0.142,0.114-0.253,0.256-0.253h1.115c0.139,0,0.255,0.112,0.255,0.253v10.021 c0,1.745-0.95,2.745-2.604,2.745c-0.508,0-0.909,0-2.026-0.551L2.28,18.675c-0.57-0.329-0.922-0.945-0.922-1.604V6.921 c0-0.659,0.353-1.275,0.922-1.603l8.795-5.082c0.557-0.315,1.296-0.315,1.848,0l8.794,5.082c0.57,0.329,0.924,0.944,0.924,1.603 v10.15c0,0.659-0.354,1.273-0.924,1.604l-8.794,5.078C12.643,23.916,12.324,24,11.998,24z M19.099,13.993 c0-1.9-1.284-2.406-3.987-2.763c-2.731-0.361-3.009-0.548-3.009-1.187c0-0.528,0.235-1.233,2.258-1.233 c1.807,0,2.473,0.389,2.747,1.607c0.024,0.115,0.129,0.199,0.247,0.199h1.141c0.071,0,0.138-0.031,0.186-0.081 c0.048-0.054,0.074-0.123,0.067-0.196c-0.177-2.098-1.571-3.076-4.388-3.076c-2.508,0-4.004,1.058-4.004,2.833 c0,1.925,1.488,2.457,3.895,2.695c2.88,0.282,3.103,0.703,3.103,1.269c0,0.983-0.789,1.402-2.642,1.402 c-2.327,0-2.839-0.584-3.011-1.742c-0.02-0.124-0.126-0.215-0.253-0.215h-1.137c-0.141,0-0.254,0.112-0.254,0.253 c0,1.482,0.806,3.248,4.655,3.248C17.501,17.007,19.099,15.91,19.099,13.993z"/></svg>',
  color: '#5fa04e',
}

export const nodeScriptsProvider: RunnerProvider = {
  id: 'node-scripts',
  kind: 'parse',
  chain: CHAIN,
  brand: BRAND,
  // No `binary`: the run verb is resolved per package (npm/pnpm/yarn/bun,
  // see `managerFor` below), so a single static name would be wrong.

  async collect(ctx: ProviderContext, facts: AspectCatalog): Promise<ProviderResult> {
    const manifests = await ctx.files('package.json')
    if (manifests.length === 0) {
      return { status: 'absent', tasks: [], diagnostics: [] }
    }

    const diagnostics: Diagnostic[] = []
    const tasks: Task[] = []
    const managerCache = new Map<string, NodeManager>()
    const byDir = new Map(facts.units.map((u) => [u.dir, u]))

    for (const file of manifests.sort()) {
      const dir = dirOf(file)
      const pkg = byDir.get(dir)?.packageJson
      if (pkg === undefined || pkg.manifestPath !== file) {
        // Test suites keep deliberately malformed manifests; a real one failing
        // to parse is worth surfacing, a fixture doing so is noise.
        if (!/(^|\/)(fixtures|__fixtures__)\//.test(file)) {
          diagnostics.push({ severity: 'warning', message: 'unparseable manifest', source: file })
        }
        continue
      }

      const entries = Object.entries(pkg.scripts)
      if (entries.length === 0) continue

      const manager = await managerFor(ctx, byDir, dir, managerCache)
      const label = pkg.name !== undefined && pkg.name !== '' ? pkg.name : dir

      for (const [script, body] of entries) {
        // The manager's own directory flag — `--prefix`, `--dir` or `--cwd`,
        // see `NodeManager.dirFlag` — addresses any manifest, workspace member
        // or not, and keeps the command correct when run from the catalog root.
        const argv =
          dir === '.'
            ? [...manager.runVerb, script]
            : [...manager.runVerb, manager.dirFlag, dir, script]
        tasks.push({
          id: taskId('node-scripts', file, script),
          runner: 'node-scripts',
          path: ['node-scripts', dir === '.' ? '.' : tierOf(dir), label, script],
          argv,
          cwd: '.',
          display: argv.join(' '),
          parameters: [],
          source: file,
          origin: 'declared',
          detail: body,
          tags: ['node-scripts', manager.kind, dir],
          persistent: {
            // Bare `vite` is the dev server, but `vite build` exits — the most
            // common `build` script in the ecosystem, so an unqualified `vite`
            // match would call essentially every Vite project's build a server.
            // `--watch` still wins, including on `vite build --watch`.
            value: looksPersistent(script) || /--watch|nuxt dev|vite\b(?!\s+build)/.test(body),
            declared: false,
          },
          executes: 'local',
        })
      }
    }

    return {
      status: tasks.length > 0 ? 'ok' : 'absent',
      aspect: {
        id: 'node-scripts',
        evidence: [{ kind: 'manifest', detail: 'package.json#scripts' }],
      },
      tasks,
      diagnostics,
    }
  },
}

/**
 * The manager for a directory, walking up to the catalog root. Cached per
 * directory because sibling packages share an answer and each miss costs a
 * chain of map lookups.
 *
 * At each ancestor, ITS OWN declared `packageManager` field wins over ITS OWN
 * lockfile (`unit.packageJson.packageManagerPin`, recorded independent of a
 * same-directory lockfile, over `unit.packageManager`, recorded only
 * alongside one) before the walk continues to the next ancestor — matching
 * corepack's own precedence, and needed so a package.json can declare a pin
 * even when the workspace's lockfile lives at the root.
 *
 * `AspectFacts` only ever gets a `packageManager` fact for a directory that
 * ALSO has a `package.json` (see `attachPackageManager`'s own doc comment) —
 * a lockfile sitting one level above the nearest `package.json`, with no
 * `package.json` of its own at that exact level (a `pnpm-workspace.yaml`-only
 * root, say), has no unit to read it from. When this ancestor's unit has no
 * `package.json` of its own — meaning `collectAspects` never had a reason to
 * probe for a lockfile here — this falls back to a direct, live check so
 * that ancestor is not silently skipped; an ancestor that DOES have a
 * `package.json` already got this exact probe inside `collectAspects`, so
 * its absence there is a real, cached "no lockfile," not a gap to re-check.
 */
async function managerFor(
  ctx: ProviderContext,
  byDir: ReadonlyMap<string, AspectFacts>,
  dir: string,
  cache: Map<string, NodeManager>,
): Promise<NodeManager> {
  const hit = cache.get(dir)
  if (hit !== undefined) return hit

  const segments = dir === '.' ? [] : dir.split('/')
  for (let depth = segments.length; depth >= 0; depth--) {
    const current = depth === 0 ? '.' : segments.slice(0, depth).join('/')
    const unit = byDir.get(current)

    const pin = unit?.packageJson?.packageManagerPin
    if (pin !== undefined) {
      const declared = managerFromField(`${pin.manager}@${pin.version}`)
      if (declared !== null) return remember(cache, dir, declared)
    }

    if (unit?.packageManager !== undefined) {
      const manager = managerFromField(unit.packageManager.kind)
      if (manager !== null) return remember(cache, dir, manager)
    } else if (unit?.packageJson === undefined) {
      const manager = await findLockfileDirect(ctx, current)
      if (manager !== null) return remember(cache, dir, manager)
    }
  }
  return remember(cache, dir, NPM)
}

/**
 * A live probe for a lockfile at exactly `dir` — the same check
 * `attachPackageManager`/`findLockfile` (`aspects.ts`) runs for a directory
 * that has a `package.json`, run here for one that does not, since
 * `AspectFacts` never builds a unit (and so never runs that check) for a
 * directory whose only manifest evidence is a bare lockfile.
 */
async function findLockfileDirect(ctx: ProviderContext, dir: string): Promise<NodeManager | null> {
  for (const { files, manager } of NODE_LOCKFILE_MANAGERS) {
    for (const name of files) {
      const rel = dir === '.' ? name : `${dir}/${name}`
      if (await ctx.exists(rel)) return manager
    }
  }
  return null
}

function remember(cache: Map<string, NodeManager>, dir: string, manager: NodeManager): NodeManager {
  cache.set(dir, manager)
  return manager
}
