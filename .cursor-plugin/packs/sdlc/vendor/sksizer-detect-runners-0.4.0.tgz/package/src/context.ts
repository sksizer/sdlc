/**
 * The `ProviderContext` builder.
 *
 * Extracted out of `collect.ts` so more than one caller can build the same
 * memoized `files()`/`readJson()`/`readText()`/`exists()` primitives without
 * one of them importing the other — `aspects.ts` needs exactly this context
 * to read manifests, and `collect.ts` in turn reads `aspects.ts`'s output now
 * that providers are rewired to consume it, which would have made a mutual
 * import a cycle had this stayed inside `collect.ts`.
 */

import { readFile } from 'node:fs/promises'
import { join } from 'node:path'

import type { AsyncCommandRunner } from '@sksizer/command-seam'

import type { ProviderContext } from './contract.ts'
import { createLister, pathExists } from './discovery.ts'

export function createContext(args: {
  absRoot: string
  allowExec: boolean
  makeRunner: (binary: string) => AsyncCommandRunner
  which: (binary: string) => string | null
  signal: AbortSignal
  discovery: 'git' | 'walk'
  /** Extra paths to skip during discovery, on top of the built-in list. */
  excludePaths?: string[] | undefined
  /**
   * Union this package's own {@link DEFAULT_EXCLUDES "built-in list"} into
   * `excludePaths` (default `true`). A caller with its own, narrower
   * exclude-list contract to hold to exactly (`@sksizer/manifest-graph`'s
   * Rust-parity walker) passes `false` so `excludePaths` is the WHOLE list,
   * not an addition to this package's broader one.
   */
  useBuiltinExcludes?: boolean | undefined
}): ProviderContext {
  const { absRoot, allowExec, makeRunner, which, signal, discovery, excludePaths } = args
  const useBuiltinExcludes = args.useBuiltinExcludes ?? true

  const files = createLister(
    absRoot,
    discovery,
    makeRunner('git'),
    excludePaths ?? [],
    useBuiltinExcludes,
  )

  // Two providers reading the same package.json should cost one read. Scoped
  // to this context, so it dies when the call returns.
  const textCache = new Map<string, Promise<string | null>>()
  const readText = (relPath: string): Promise<string | null> => {
    let hit = textCache.get(relPath)
    if (hit === undefined) {
      hit = readFile(join(absRoot, relPath), 'utf-8').catch(() => null)
      textCache.set(relPath, hit)
    }
    return hit
  }

  const jsonCache = new Map<string, Promise<unknown>>()
  const readJson = (relPath: string): Promise<unknown> => {
    let hit = jsonCache.get(relPath)
    if (hit === undefined) {
      hit = readText(relPath).then((text) => (text === null ? null : safeParse(text)))
      jsonCache.set(relPath, hit)
    }
    return hit
  }

  return {
    root: absRoot,
    runner: makeRunner,
    files,
    readJson,
    readText,
    exists: (relPath) => pathExists(absRoot, relPath),
    which,
    allowExec,
    discovery,
    signal,
  }
}

/** `null` rather than a throw: a malformed manifest is a diagnostic, not a crash. */
function safeParse(text: string): unknown {
  try {
    return JSON.parse(text)
  } catch {
    return null
  }
}
