# @sksizer/detect-runners

Find the task runners a directory uses, and normalize their tasks into one
searchable model.

A repository of any size runs its work through several tools at once — a build
graph, a justfile, package.json scripts, a Makefile — and each answers only for
itself. "How do I start that app?" then needs you to know which tool owns it
before you can even look. This inverts that: one inventory, keyed by the call
chain you would actually type.

```ts
import { collect, tasks } from "@sksizer/detect-runners";

const catalog = await collect(process.cwd(), { allowExec: true });
for (const task of tasks(catalog)) {
  console.log(task.display); //  moon run web:dev
}
```

Or from a shell:

```sh
detect-runners --exec --table
```

## Built-in runners

| Runner | Found by | Reads |
|---|---|---|
| `moon` | `.moon/workspace.yml` | `moon query tasks` / `projects` |
| `mise` | `mise.toml`, `mise-tasks/` | `mise tasks --json` |
| `just` | `justfile` | `just --dump`, or the file itself |
| `node-scripts` | `package.json` | `scripts`, with the verb derived from the lockfile |
| `make` | `Makefile` | targets at column 0 |
| `cargo` | `Cargo.toml` | the conventional verbs |
| `sbt` | `build.sbt`, `project/build.properties` | `sbt projects tasks` |
| `python` | `pyproject.toml` | configured `[tool.*]` sections (run against the project directory, e.g. `ruff check sub`), and `[project.scripts]` / `[tool.poetry.scripts]` routed by the lockfile's manager (`uv run --project sub`, `poetry --directory sub run`) |
| `composer` | `composer.json` | `scripts` |
| `deno-tasks` | `deno.json`, `deno.jsonc` | `tasks` |
| `turbo` | `turbo.json` | v2 `tasks`, with a v1 `pipeline` fallback |
| `maven` | `pom.xml` | the conventional lifecycle verbs |
| `swiftpm` | `Package.swift` | the conventional `swift build/test/run` verbs |
| `gradle` | `build.gradle`, `build.gradle.kts`, `settings.gradle(.kts)` | `gradle tasks --all` when execution is allowed, else the conventional lifecycle verbs; run through `./gradlew` when a wrapper is present |
| `go-task` | `Taskfile.yml` and its `.yaml`/lowercase/`.dist.` variants | `task --list-all --json` when execution is allowed, else the `tasks:` map read by a narrow hand-written YAML reader |
| `rake` | `Rakefile` | `rake -AT` when execution is allowed, else tasks scanned out of the Ruby source |
| `docker-compose` | `compose.yaml`, `compose.yml`, `docker-compose.yml`, `docker-compose.yaml` — one winner per directory, in that precedence order | the `services:` map, read by a narrow hand-written YAML reader; each service becomes `docker compose -f <file> up <service>`, `executes: "container"` |
| `github-actions` | `.github/workflows/*.yml`, `*.yaml`, at the repository root only | the `on:` trigger, read by a narrow hand-written YAML reader; each workflow declaring `workflow_dispatch` becomes `gh workflow run <file>`, `executes: "remote"` |

## Aspect facts (`@sksizer/detect-runners/aspects`)

`collect()` answers "what can I run here." `collectAspects()` answers a
narrower question underneath that — "what does each directory's manifest say
about it" — for a caller that wants the raw facts and none of the task
enumeration: a dependency-graph builder, an installer picking a package
manager, a doctor check reading which git-hook manager a repo uses.

```ts
import { collectAspects } from "@sksizer/detect-runners/aspects";

const { units } = await collectAspects(process.cwd(), { allowExec: true });
for (const unit of units) {
  if (unit.cargo) console.log(unit.dir, "is a crate:", unit.cargo.manifestPath);
}
```

One `AspectFacts` record per directory that has a manifest this module reads
— `Cargo.toml`, `package.json`, a justfile, a makefile, a root mise config —
plus a moon project's own `layer`/`stack`/`language` when `allowExec` is on
and `moon query projects` reports it. `hookManagers` (`lefthook`, `husky`,
`pre-commit`) and `toolTrust` (`mise`, `direnv`) are repository-wide and only
ever populated on the root unit (`dir: "."`). Every manifest is read once,
through the same memoized `files()`/`readJson()`/`readText()`/`exists()`
primitives the built-in providers use — this module is simply another caller
of them, not a second copy of the reading.

Like `collect()`, the one subprocess this can make (`moon query projects`,
for `moon.role`) is gated on `allowExec`, off by default.

## Install and pinned-manager resolution

Two more standalone helpers, moved here from sdlc's own local `lib/config/`
so `waypost` and a bare npm consumer get the same answers sdlc's own `setup`
already relied on:

- **`resolveInstall(projectRoot, facts?)`** — one dependency-install verb per
  detected ecosystem (`bun install`, `cargo fetch`, `pip install -r
  requirements.txt`, …), the strongest Node lockfile signal winning when more
  than one is present. `hasMissingDeps`/`missingDeps` answer the follow-up
  question — which detected ecosystem has no installed-dependencies directory
  yet. All three take an optional `facts` — the `AspectFacts` for
  `projectRoot`'s own directory, from a `collectAspects()` a caller already
  ran — to skip re-reading `package.json`/`Cargo.toml`; omit it and they read
  the filesystem themselves.
- **`resolvePinnedManagerInstall(candidate, projectRoot, allowExec, opts?)`** —
  given a `SetupCandidate` from `resolveInstall`, resolves the concrete
  command that installs at the version the repository's `packageManager`
  field pins: a manager already on `PATH` at that version, else `mise exec`
  at that version, else whatever is found with a warning noting the mismatch.
  `readPackageManagerPin(projectRoot)` reads just the pin.

## Five things to know

### Execution is opt-in, and trust is the gate

`allowExec` defaults to `false`. Some runners can only be read by asking them.
`moon query tasks` evaluates the repository's own toolchain configuration, and
mise merges tasks across several config files and can run `[hooks]` while doing
it — so pointing this at a repository you did not write is code execution.
Providers declare `kind: "parse" | "exec"`, and only `parse` providers run by
default.

`allowExec` alone cannot gate that, because the scanned repository writes
`waypost.config.json`, and a setting a repository can write is a setting it can
grant itself. So the CLIs ask a person once, per repository, and remember the
answer outside the repository — see [Trust](#trust). The library itself gates on
`allowExec` and nothing else: `collect()` never reads the trust store, so a
programmatic caller passing `allowExec: false` is never affected by a decision it
did not ask about.

A runner withheld this way is reported, not hidden:

```ts
{ runner: "moon", status: "absent", skippedForExec: true,
  diagnostics: [{ severity: "info", message: "moon needs to run a subprocess…" }] }
```

`just` is a `parse` provider because it has both paths: `just --dump` when the
binary is available and execution is allowed, and a source scan otherwise. The
fallback finds the same recipes — it just cannot see docs, parameter types or
private flags, and it says so in `diagnostics`.

`rake`, `go-task` and `gradle` are the same shape. Each reads files with no
help from anything, and each asks its own tool instead when execution is
allowed and the binary is there: `rake -AT` sees tasks a Rakefile builds in a
loop, `task --list-all --json` resolves `includes:` and real YAML, and
`gradle tasks --all` replaces five conventional verbs with the build's actual
task list. The parse path is the floor and never gets worse; the upgrade is
never a requirement. Which path ran is always in `diagnostics`, and a warning
about a limitation is not emitted on the path where the limitation does not
apply.

### `argv` and `display` are different strings

```ts
{
  argv:    ["just", "release-lib"],
  display: "just release-lib <lib> <bump> *flags",
  parameters: [
    { name: "lib",   required: true,  variadic: false },
    { name: "bump",  required: true,  variadic: false },
    { name: "flags", required: false, variadic: true  },
  ],
}
```

`argv` is executable and carries no placeholders. `display` is for showing and
copying. **Never spawn `display`, and never rebuild a command by joining it** —
`<lib>` handed to a shell is an input redirection, and `*flags` is a glob.

### Tool presence is checked, not claimed

A `RunnerReport` carries `tool: { binary, found, path? }` for every provider
that declares a `binary`. `collect()` fills it by running `ctx.which()` — a
PATH lookup with no subprocess — so a provider cannot report itself as
present. Presence is filled even when the provider was skipped for exec or
threw, because it is a fact about the machine, not about how collection went.

```ts
{ runner: "just", tool: { binary: "just", found: false } }
```

Fourteen of the sixteen built-ins declare a `binary`. `node-scripts` and
`python` do not: which tool actually runs (npm/pnpm/yarn/bun, or uv/poetry)
is resolved per directory, so a single static name would be wrong. The CLI
turns this into a `warning` diagnostic when a runner is configured — its
marker file is present — but its declared binary is missing from PATH; a
runner that is simply absent stays silent.

### A task's `executes` target is separate from how it was found

`Task.executes: "local" | "remote" | "container"` says what running the task
does. `RunnerProvider.kind` (`parse`/`exec`) says something different: what
this package must do to read the repo and learn the task exists. A GitHub
Actions workflow file is `parse`-detected — it is read as YAML — but
`remote` to run, since GitHub's own runners execute it, not this machine. A
docker-compose service is `container` regardless of how its definition was
read.

`github-actions` and `docker-compose` are built-in providers, and the reason
the axis exists. Both are `kind: "parse"` — their definitions are plain data on
disk — and neither emits a task that runs on this machine. Everything else in
the roster is `"local"`, so a consumer filtering on `executes` is filtering on
a real distinction rather than a constant. A UI that shows `cargo build` and
`gh workflow run release.yml` in the same list needs to tell them apart before
someone clicks: one compiles locally, the other spends CI minutes on a hosted
runner.

`tests/providers.test.ts` holds the roster's declared `executes` intent as a
map, asserts it covers `builtinProviders` exactly, and checks that no
provider emits a value it did not intend — so a new provider cannot land
without someone stating what its tasks do when run.

### Collection is a function, not a snapshot

Every `collect()` call re-probes. Nothing is held between calls, so a catalog
cannot go stale after someone adds a task. Reads are memoized within a single
`collect()` and die with it.

Storing an answer is a separate layer a caller opts into, described under
[The cache](#the-cache). A caller that does not reach for it gets a fresh
probe, always.

## Adding a runner

The built-ins have no privileges yours will not have.

```ts
import { collect, builtinProviders, type RunnerProvider } from "@sksizer/detect-runners";

const house: RunnerProvider = {
  id: "house",
  kind: "parse",
  chain: [
    { label: "runner", hint: "our in-house runner" },
    { label: "task", hint: "an entry in house.toml" },
  ],
  async collect(ctx) {
    const found = await ctx.files("house.toml");
    return { status: found.length ? "ok" : "absent", tasks: /* … */ [], diagnostics: [] };
  },
};

await collect(root, { providers: [...builtinProviders, house] });
```

Two rules keep providers honest, and both exist so they stay testable:

- **Never spawn.** `ctx.runner(binary)` returns an injected runner, so a test
  supplies recorded output instead of needing the binary installed.
- **Never read the filesystem for discovery.** `ctx.files()` applies the
  caller's chosen strategy; a provider reaching past it would disagree with
  every other provider about which files exist.

From the CLI, a `--config` module exporting `providers` is merged with the
built-ins, so a house runner needs no program and no fork.

### Brand (optional)

A provider may declare a `brand` — an inline SVG `icon` and a hex `color` — and the collector copies
it onto that runner's `RunnerReport`, so visual surfaces can show a mark and a tint next to the
name. It is optional end to end: a provider without one renders as plain text, and nothing may
require it. It lives on the report rather than on each task because a catalog carries thousands of
tasks and only a handful of runners; per-task icons would bloat every `--json` dump. The built-ins
ship each tool's own mark (or its ecosystem's) as CC0 path data from
[simple-icons](https://simple-icons.github.io/simple-icons-website/), used nominatively — the
trademarks belong to their owners — and fall back to a small original glyph where simple-icons has
no CC0 icon for the tool. Colors are verified brand colors.

```ts
const house: RunnerProvider = {
  // …
  brand: {
    icon: '<svg viewBox="0 0 24 24" fill="currentColor">…</svg>',
    color: "#2f6feb",
  },
};
```

## Discovery

`git` lists tracked and untracked-but-not-ignored files — fast, and it skips
build output without needing to name it. `walk` walks the tree excluding
well-known directories, and works in a directory that is not a repository at
all. `auto` (the default) picks `git` when there is a repository and `walk`
otherwise. They genuinely disagree — a gitignored project directory is invisible
to one and visible to the other — so the resolved mode is recorded on the
catalog rather than left implicit.

## CLI

```text
detect-runners [options] [dir]

  --output list|json|table     output form (default: list)
  --json | --list | --table    aliases for the three --output values
  --cached                     answer from the last stored probe (see below)
  --exec | --no-exec           allow or forbid runners that run a subprocess
                               (--exec is this run only; it records nothing)
  --only a,b   --exclude a,b   restrict the runner set
  --exclude-path P             leave a path out of discovery (repeatable)
  --declared                   drop synthesized tasks (see below)
  --discovery git|walk|auto
  --config PATH                a module exporting { providers }
  -C, --dir PATH               directory to inspect (default: cwd)

  config                       read and write the layered settings (below)
  trust                        record that this repository may be read by
                               running it (below)
  clean                        remove the data this tool stores outside your
                               repositories (below)
  guide                        how to use and extend this tool, in Markdown
```

`detect-runners guide` prints usage-and-extension instructions for people and
for agents; `guide extend` is the provider contract and `guide trust` the exec
gate.

### Removing what it has stored

Three things live outside your repositories, and `clean` is how they go away.
Bare `clean` reports them and removes nothing.

```text
detect-runners clean                  show each store, where it is, and what it holds
detect-runners clean --cache          stored probe results
detect-runners clean --trust          forget which repositories you have trusted
detect-runners clean --config --yes   your user configuration file
detect-runners clean --all --yes      all three
detect-runners clean --json           the same answer as one JSON object
```

`--json` answers the same thing as one object: a `stores` array of
`{key, flag, what, path, bytes, removed}`, all three on a bare report and only
the ones you named on a removal. `bytes` is null when nothing was stored, which
is what separates "there was nothing to remove" from "it would not delete" —
both are `removed: false`. The closing note about trust being asked for again
goes to stderr under `--json`, so stdout stays one parseable document.

`--config` and `--all` want `--yes` because the three are not equally
replaceable: the cache is derived and costs one slow probe, trust costs
re-answering a question per repository, and the configuration is the only thing
here you wrote by hand. Nothing inside a repository is ever touched — a
project's own `waypost.config.json` belongs to that project.

The directory is resolved upward to the project root, so running from a
subdirectory inspects the whole repository — matching what `moon` and `just`
already do for their own config. `-C` applies to `config` too, so
`detect-runners config path -C /elsewhere` reports that directory's files
rather than this one's.

## The cache

Some runners are slow to ask. moon starts its toolchain, sbt starts a JVM, mise
reads and merges a config tree. The store keeps the last answer per (root,
runner) so a surface can paint something at once instead of an empty screen.

**The data surfaces stay fresh by default.** `--json`, `--list` and `--table`
re-probe every run, because a script or an agent reading them must get what the
repository has right now. Those runs also WRITE the store, so an interactive
surface started afterwards has something to paint. `--cached` inverts it for one
run: it answers from the store, and probes only the runners the store has
nothing for.

`--cached` on a repository with no stored answer is not an error. It probes,
stores the result, and says so:

```text
detect-runners: --cached: nothing cached for this repository yet — probed it fresh, and this run stores the result
```

Staleness is reported on **stderr**, so `--list` stays pipeable and `--json`
stays parseable:

```text
detect-runners: --cached: stale: just (35s old, refresh usually about 149ms)
detect-runners: --cached: not cached, probed now: github-actions
```

The refresh cost is measured in THIS repository, from a rolling window of the
last five probe durations, reported as their median. Where a repository has no
measurement yet the line says so rather than inventing a number —
`moon (2h old, refresh cost not measured here yet)`. Slowness is likewise
measured, never declared: there is no `slow` field on the provider contract,
because the same provider is quick against a small repository and slow against
a large one.

`--json --cached` gains a `cache` array beside the catalog, one entry per
selected runner — `{ runner, state, reason?, ageMs?, estimateMs, slow }`, where
`state` is `"fresh"`, `"stale"` or `"miss"`. Plain `--json` does not carry it: a
freshly probed catalog has no staleness to describe, and a key that is always
present and always says `fresh` teaches a consumer to ignore it. Under
`--cached`, `generatedAt` is the OLDEST contributing probe time — a catalog is
only as fresh as its stalest row.

### Where it lives, and why not beside trust

`$XDG_CACHE_HOME/waypost/`, or `~/.cache/waypost/` when that variable is unset. One
file per (root, runner), written to a temp file and renamed, and
format-versioned both in the path and inside each file.

XDG **cache**, deliberately not the `~/.local/state/waypost/` the trust store uses.
Losing this directory costs time and nothing else: a user who clears their
caches pays one slow probe. Losing the trust store would silently un-trust
repositories, and a consent record a cache sweep can erase is not a consent
record. Everything here is reconstructible by asking again; nothing in the trust
store is.

**The cache is not part of the execution gate.** A cached answer is never a
trust grant, clearing the cache never changes what is trusted, and an exec
provider withheld for want of execution is never stored at all — `writeEntry`
refuses both errored reports and reports carrying `skippedForExec`. Under
`allowExec: false` a cached read reports each exec runner as fresh and carries
the same withheld report `collect()` would have produced, from the same helper.
Trust is resolved by `@sksizer/sdlc-tool`'s `policyExecGate`, layered over
`@sksizer/cli-tool/trust`'s marker store and gate, which never reads the
cache.

### Invalidation is a content hash, never an mtime

A stored entry carries a digest over the bytes of the files it depends on.
`touch`ing a justfile does not invalidate it, and neither does a rewrite to
identical bytes — which is what a formatter, a `git checkout` of the same
content, or a rebuilt generated file does all day.

For a `parse` provider the coverage is close to exact, and free. `ProviderContext`
mediates every read a provider makes, so recording what it touched records
precisely what it read.

Reads alone are not enough, though, and the difference matters. A provider that
discovers by listing — every `.github/workflows/*.yml`, every `compose.yaml`
below the root — depends on the ANSWER to its query, not only on the files that
answer happened to name. A file added later matching the same pattern was never
read, so it moves no recorded hash, and the entry would stay fresh while the
provider's real answer had changed. So the patterns a provider passes to
`ctx.files()` are recorded alongside the paths and re-expanded on every read:
they are watch patterns the provider never had to declare.

For an `exec` provider it is **deliberately incomplete.** Such a provider reads
only its markers — moon checks `.moon/workspace.yml`, sbt lists the root
`*.sbt` files — while the TOOL merges files the provider never opens: moon's
`.moon/tasks/**` and each project's own `moon.yml`, mise's nested `mise.toml`
files, sbt's `project/**`.
`RunnerProvider.watch` closes the part a basename can express, and exec entries
additionally expire after four hours as a backstop for what a fingerprint cannot
see.

Even then it is a good signal rather than a proof. A task set can change with no
watched file changing at all: a plugin version resolving differently, a global
`~/.config/mise/config.toml`, an environment variable a build script reads.
Every consumer of a cached answer must tolerate a stale hit, which is what the
reported staleness and the exec max age are for.

One more limit: a fingerprint hashes at most 256 paths. A repository with
thousands of `build.gradle` files hits that cap, and the run adds an `info`
diagnostic saying so rather than letting the entry look fresher than it is.

### `watch`, for provider authors

```ts
const moonProvider: RunnerProvider = {
  id: "moon",
  kind: "exec",
  watch: ["moon.yml"],
  // …
};
```

`watch` is basenames in the same pattern language `ctx.files()` already speaks —
an exact basename, or `*suffix` matched against the basename. Not a path glob.
They are re-expanded on every read, never taken from the stored entry, so a file
that did not exist when the entry was written still invalidates it.

A `parse` provider needs no `watch`: its recorded reads cover every byte it
read, and its recorded queries cover files that appear later matching the same
patterns. An `exec` provider wants one for each family of files its tool merges
behind its back — those are the files nothing in the provider ever asks for.

It is the only cache-related field on the contract, on purpose. There is no
`slow` (measured per repository, and a static default would only ever apply on
the first run, when there is nothing cached to be stale about), and no TTL knob,
cache-policy field or invalidation-strategy enum — `kind` already separates the
providers whose fingerprint is exact from those that need the max-age backstop.

### From a program

```ts
import { cacheDir, collectAndCache, readCachedCatalog } from "@sksizer/detect-runners";

const store = cacheDir();
// Paints now: hashes a few files, probes nothing.
const stored = await readCachedCatalog(root, options, store);
// Probes for real and stores what came back.
const fresh = await collectAndCache(root, options, store);
```

`readCachedCatalog` returns `{ catalog, runners, allFresh }` and never throws:
an unreadable store, an unlistable root, a fingerprint that cannot be computed
all degrade to a miss, which is the state a caller would have been in with no
cache at all. Stale rows are kept and labelled rather than dropped — a row the
caller is told is stale is the reason the function exists.

`collectAndCache` returns `collect()`'s catalog untouched but for the truncation
diagnostic above. Writing the store is best-effort: a read-only home or a full
disk costs the next run some time and never fails the collection.

## Trust

Reading some runners means running them. Trust is the consent to that, asked
once and remembered per repository, in the same shape mise uses.

```text
detect-runners trust                 trust the repository at the resolved root
detect-runners trust --untrust       remove this repository's trust
detect-runners trust --show          report this root's trust status
detect-runners trust --list          every trusted path, one per line
detect-runners trust --json          the same answer as one JSON object
detect-runners trust --help          this list
```

Every one of these answers in the machine form too. `--json` gives one object
per invocation — `{"root": …, "trusted": …, "changed": …, "by": …, "rule": …}`
for the three root-scoped modes, so a caller never has to branch on the flag
it just passed, and `{"trusted": [paths]}` for `--list`. `by` is
`"marker" | "path" | "owner" | null` — which layer decided, see "The policy"
below — and `rule` is the matching `trust.paths`/`trust.owners` entry, present
only when `by` is `"path"` or `"owner"`. A `--untrust` that found nothing still
prints its document and reports the miss through exit 1 and stderr, so a parser
is never handed an empty stdout to interpret.

`-C` applies here too, so `detect-runners trust -C /elsewhere` grants that
directory's root rather than this one's. `waypost` reads the same store, so a
repository trusted with one tool is trusted by the other and is described in the
same words.

The store — `@sksizer/cli-tool/trust`'s `trustStore({ tool: 'waypost' })` — is a
directory of marker files at `$XDG_STATE_HOME/waypost/trusted/`, or
`~/.local/state/waypost/trusted/` when that variable is unset. XDG **state**, not
config: trust is state a program maintains, not configuration a person
hand-edits, and a consent record that travels in a dotfiles repo onto a new
machine has stopped being consent. One file per trusted root, so two processes
trusting two repositories at once cannot lose each other's write.

### The policy

A root can also be trusted with no marker at all, through a `trust` block in
the USER layer of the config file (never the project layer — see "A repository
cannot trust itself" below):

```jsonc
// ~/.config/waypost/config.json
{
  "trust": {
    "paths": ["/home/me/work/**"], // @sksizer/sdlc-tool's glob dialect
    "owners": ["my-org"] // case-insensitive `origin` remote owners
  }
}
```

`@sksizer/sdlc-tool`'s `policyExecGate` decides trust in order — a marker in
the store, then `trust.paths` (a glob over the resolved, symlink-free root),
then `trust.owners` (the `origin` remote's owner) — and that precedence, the
glob dialect (`*`, `?`, `**`, a trailing `/**` never matching the directory
itself) and the origin-remote threat model are documented once, in
`packages/ts/sdlc-tool/README.md`; this package adds no vocabulary of its own
beyond expanding a leading `~` in a `trust.paths` entry against `$HOME`. `way
trust --show`/`detect-runners trust --show` report which layer decided
(`by`/`rule`); the plain grant still writes a marker on a policy-trusted root
(a standing policy can change out from under a repository, and the marker is
the more durable of the two), and `--untrust` says when the policy still
covers the root after the marker is gone.

**A repository cannot trust itself.** `allowExec: true` in `waypost.config.json` is
ignored with a warning, because that file lives inside the repository being
scanned. The project layer may still LOWER `allowExec` to `false` — a repository
asking not to be shelled out for is asking for less than it was already given.
Raising it is the user file's job, or `--exec`'s. A project-layer `trust` block
is rejected outright, with the same warning style — trust has no "lower" state
to honour from inside the repository, so a `trust.paths`/`trust.owners` entry
there is dropped before the merge.

**Trust is one of two conditions, not the whole gate.** Execution must also be
enabled, and `detect-runners` leaves it off: its `allowExec` default is `false`,
so trusting a repository and running `detect-runners` again collects exactly what
it did before. Turn execution on too — `--exec` for one run, or `allowExec: true`
in the user file — and trust decides the rest. `waypost` differs only in supplying
that first half from its own default, which is why trust alone is enough there.
When runners are withheld, the CLI says on stderr which of the two halves is
missing.

`--exec` is the escape hatch, and it records nothing. It is consent for one run:
a person typed it, with intent, at the moment of running. Persisting it would
turn one deliberate run into a standing grant nobody remembers giving, which
makes it the right flag for a script or a CI job.

### What decides

`configured` below is `allowExec` after the layers and the calling tool's own
default. For `detect-runners` that is `false` unless a user file or a flag says
otherwise; `waypost` defaults it to `true`.

| configured `allowExec` | trusted | flag | effective | why |
| --- | --- | --- | --- | --- |
| any | any | `--no-exec` | `false` | the flag is the last word, and the store is not even read |
| any | any | `--exec` | `true` | consent for this run, typed by a person; nothing is recorded |
| `false` | any | none | `false` | a file said no; trusting the repository would change nothing |
| `true` | no | none | `false` | willing in principle, but this repository has not been trusted |
| `true` | yes | none | `true` | the only combination that runs a subprocess |

### The tradeoff

A decision is keyed on the absolute, symlink-resolved repository PATH, not on a
hash of the repository's contents. A repository you trusted that later pulls
hostile changes stays trusted, and `trust --untrust` is the only remedy. The
alternative is worse: content-hashing every runner config in a monorepo would
re-prompt on ordinary edits, and a prompt that fires on every edit trains people
to approve without reading, which is weaker security than an honest weaker rule.

Two paths that name one repository — a symlinked checkout, a `/tmp` that is
really `/private/tmp` — are one decision, because a person answering the question
answered it about the repository, not about the spelling they used to reach it.

## Configuration

The collection options that matter to a person are the same few every time —
which runners to skip, whether execution is allowed, how to discover files —
and typing them as flags on every invocation is how a tool stops being used. So
they are settable once, per user and per project, and the flags stay for the
exceptions.

Both CLIs read the same file, and it is named after `waypost` rather than after
this package: `waypost` is the name a user types, and naming the file after the
library would name it after the thing they never type.

### Layers

Lowest precedence first.

| Layer | Where |
|---|---|
| defaults | built in — `DEFAULT_CONFIG` |
| user | `$XDG_CONFIG_HOME/waypost/config.json`, or `~/.config/waypost/config.json` when `XDG_CONFIG_HOME` is unset |
| project | `waypost.config.json` at the project root the directory resolves upward to |
| flags | the command line |

XDG is used on every platform, macOS included. That is a choice rather than a
universal macOS convention: `gh` is fully XDG on macOS and this follows its
layout, while `mise` keeps its cache in `~/Library/Caches`. One story on every
platform means no storage-related platform branch anywhere in the package. What
it costs on macOS is that `~/.cache` is backed up by Time Machine while
`~/Library/Caches` is not, so a wholly regenerable cache goes into backups.
Setting `XDG_CACHE_HOME` or `XDG_STATE_HOME` moves either store anywhere you
prefer.

`WAYPOST_CONFIG=/path/to/file` replaces the user layer's **location** and nothing
else. The named file is read instead of the XDG path; the project layer is
still read from the project root, still merges on top, and cannot be turned off
this way. A relative path resolves against the project root. Naming a file that
does not exist is an error rather than a silent empty layer — an env var
pointing at nothing is a typo, not a choice.

### Merging

Objects merge key-wise. Everything else — scalars and arrays alike — replaces
wholesale.

```text
user    { runners: { disabled: ["cargo"], order: ["moon"] } }
project { runners: {                      order: ["just"] } }
result  { runners: { disabled: ["cargo"], order: ["just"] } }
```

`runners` merged key-wise, so `disabled` survived from the user layer; `order`
was replaced entire rather than concatenated to `["moon", "just"]`. Arrays
replace because both of ours answer "which ones, in what order", and a project
that says `order: ["just"]` means that list. `--exclude` on the command line
replaces `runners.disabled` for the same reason, and `--exclude-path` replaces
`excludePaths`.

### The file

Schema v1, every key optional:

```jsonc
{
  "runners": {
    // Runner ids to skip entirely. Becomes CollectOptions.exclude.
    "disabled": ["cargo"],
    // Preferred display order. Runners not named here follow alphabetically.
    "order": ["moon", "just"]
  },
  // Willingness to run subprocess-only runners. Trust is the gate above it, and
  // --exec / --no-exec still wins. A PROJECT file may only lower this to false;
  // a `true` here is ignored with a warning (see Trust).
  "allowExec": false,
  // git | walk | auto — how files are found.
  "discovery": "auto",
  // Paths that are not project structure, on top of the built-in list. A bare
  // name matches any path segment; a value with a slash matches from the root
  // and takes the tree beneath it.
  "excludePaths": ["crates/manifest-graph/tests/mini-repo"],
  // USER LAYER ONLY — a project-layer trust block is rejected the same way a
  // project-layer allowExec: true is (see Trust). Pre-authorizes a class of
  // repositories without a per-repository `trust` marker.
  "trust": {
    "paths": ["/home/me/work/**"],
    "owners": ["my-org"]
  }
}
```

### Two ways to turn something off

`runners.disabled` turns a RUNNER off — it is never probed anywhere in this
project. `excludePaths` leaves every runner on and narrows WHERE they look.

The second is what a repository wants for a tree holding real manifests that
belong to nobody: a test-fixture repo, a vendored sample, a scaffolding
template. A detector is right to find those and right to report a broken one —
they are simply not tasks anyone can run, and turning off the runner to hide
them would also hide the tasks you do have.

```jsonc
{ "excludePaths": [
  "crates/manifest-graph/tests/mini-repo",  // a fixture repo, not a project
  "testdata"                                // any directory of that name
] }
```

The two forms are the only syntax; this is deliberately not glob. A bare name
matches any single path segment at any depth, which is the only useful reading
for something like `node_modules`. A value containing a slash is matched from
the root, segment by segment — so `src/app` does not also take
`src/application`, and naming a fixture tree does not exclude every directory
in the repository that happens to be called `tests`.

Changing this stales the cache. The exclusion set lives outside the tree, so
nothing about hashing the repository would notice it moved; the stored entry
records the set it was probed under, and a mismatch re-probes with
`reason: "excludes"`.

`runners.order` currently reorders the reports behind `--list`, `--table` and
`--json`. The `waypost` terminal UI and web view do not consume it yet.

An unknown key is a warning naming the file and the key, and the rest of the
file still loads — a config written for a newer version must not brick an older
one:

```text
warning: /repo/waypost.config.json: unknown setting "colour" (ignored)
```

A file that is malformed, or that holds a wrong-typed value, is an error naming
the file and the problem:

```text
detect-runners: /repo/waypost.config.json: allowExec must be true or false, got a string
```

There is no silent fallback. A setting that quietly did not apply is worse than
one that refused to load.

### `config`

```text
detect-runners config list [--json]                          every setting, and the layer it came from
detect-runners config get <key>                              one setting's effective value, as JSON
detect-runners config set <key> <value> [--user|--project]   write a setting (default --project)
detect-runners config unset <key> [--user|--project]         remove a setting (default --project)
detect-runners config path                                   where each layer's file lives
detect-runners config --help                                 this list
```

Keys are dotted: `runners.disabled`, `runners.order`, `allowExec`, `discovery`.
A value is read as JSON and falls back to the bare string when that fails, so
`set discovery git` and `set runners.order '["moon","just"]'` both work and a
plain word needs no quoting.

`list` annotates each value with the layer that supplied it, which is the
question you ask when a setting is not what you expected:

```text
$ detect-runners config list
runners.disabled  ["cargo"]        (project)
runners.order     ["moon","just"]  (project)
allowExec         true             (user)
discovery         "auto"           (default)
user:    /Users/you/.config/waypost/config.json (exists)
project: /repo/waypost.config.json (exists)
```

The settings go to stdout and the file locations and warnings to stderr, so
`--json` stays machine-readable and the plain listing stays greppable. `get`
splits the same way: the value alone on stdout, any unknown-key warning on
stderr, so `$(config get discovery)` is safe to script against and a file with
an ignored key still says so.

A write preserves keys this version does not recognize, so editing a file that
a newer version wrote does not silently delete what it put there.

Exit codes split on whether the command or the world is at fault: **2** when the
command as typed cannot run — an unknown subcommand, option, setting name or
wrong-typed value, all decided from the arguments and the schema with no file
read — and **1** when a well-formed command failed against the state it found: a
file that will not parse, an `unset` on a key that was not set, a `get` with no
value. A script can act on that: 2 means fix the command, 1 means look at the
state. [[S-0015-standalone-cli-shape]] makes that split universal, and reserves
10-63 for a tool that numbers its own outcomes; this one does not.

`runConfigCommand` is exported, so a tool built on this library gets the same
command surface without reimplementing it. It takes the calling tool's own
defaults, which sit between the built-in defaults and the user file — `list` and
`get` then report the value that tool will actually run with rather than the
library's. `waypost` uses this to default `allowExec` to `true`.

## Declared versus synthesized

`cargo test` and `ruff check .` are not written down anywhere; they are what a
crate or a ruff-configured project runs by convention. Those carry
`origin: "synthesized"`. A moon task or a just recipe carries
`origin: "declared"`. Filter on it, or pass `--declared`, when you want only
what a repository actually stated.

## License

MIT
