#!/usr/bin/env bun
/**
 * `dfv` — verify a changeset against the rules that govern it.
 *
 * The standalone front door to this package. It needs nothing but a git repo:
 * the instruction-file provider reads the `CLAUDE.md` / `AGENTS.md` files
 * already there, so `dfv` works in any checkout.
 *
 * It deliberately ships one provider. Any other rule corpus — an SDLC
 * standards tree, a house style registry — is a `RuleSourceProvider` supplied
 * by whatever owns that corpus, and teaching this binary about one would put
 * that knowledge in a package built to stay blind to it. `sdlc verify changes`
 * is the same pipeline with the standards provider registered.
 */

import { Git } from '@sksizer/easy-git'

import { changedFiles, fileDiffs, resolveBase } from './changeset.js'
import { exitCodeFor } from './findings.js'
import { instructionFiles } from './providers/instruction-files.js'
import { discoverSources, verify } from './run.js'
import { estimateTokens, formatTokens, jobLabel } from './tokens.js'
import { DEFAULT_CONFIG, type Severity, type VerifyConfig } from './types.js'

const USAGE = `dfv — verify a changeset against the rules that govern it

Every CLAUDE.md / AGENTS.md governs its own directory. dfv finds the ones whose
scope encloses a changed file and asks each, separately, about only its files.

Usage
  dfv [options]

Options
  --base <ref>        Compare against <ref>. Default: uncommitted work only.
                      Use a branch name for the whole branch, @{u} to include
                      unpushed commits.
  --dry-run           Show what would be judged, and what it would cost, without
                      dispatching anything. Free and fast.
  --blocking          Exit non-zero on findings at or above the severity floor.
  --severity <level>  violation (default), tension, or drift.
  --engine <name>     claude (default), codex, antigravity, or opencode.
  --model <id>        Model to judge with. Default: the engine's own.
  --concurrency <n>   Judgements in flight at once. Default: ${DEFAULT_CONFIG.concurrency}.
  --max-files <n>     Files per judgement; a broader source is split into that
                      many-file shards, judged concurrently against the same
                      rules. 0 disables. Default: ${DEFAULT_CONFIG.maxFilesPerJob}.
  --exclude <glob>    Drop matching paths. Repeatable.
  --json              Emit the run as JSON instead of prose.
  -C <dir>            Run against <dir> instead of the current directory.
  -h, --help          This text.

Exit codes
  0  clean, or advisory (the default — findings are reported, not enforced)
  1  findings at or above the floor, with --blocking
  2  the run could not be completed
`

interface Options {
  base?: string
  dryRun: boolean
  json: boolean
  cwd: string
  config: VerifyConfig
}

/** Read one value that must follow its flag. */
function value(argv: string[], i: number, flag: string): string {
  const v = argv[i + 1]
  if (v === undefined || v.startsWith('-')) {
    throw new Error(`${flag} needs a value`)
  }
  return v
}

function parse(argv: string[]): Options | 'help' {
  const opts: Options = {
    dryRun: false,
    json: false,
    cwd: process.cwd(),
    config: { ...DEFAULT_CONFIG, exclude: [] },
  }
  const exclude: string[] = []

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i]!
    switch (arg) {
      case '-h':
      case '--help':
        return 'help'
      case '--dry-run':
        opts.dryRun = true
        break
      case '--json':
        opts.json = true
        break
      case '--blocking':
        opts.config.blocking = true
        break
      case '--base':
        opts.base = value(argv, i++, arg)
        break
      case '-C':
        opts.cwd = value(argv, i++, arg)
        break
      case '--engine':
        opts.config.engine = value(argv, i++, arg)
        break
      case '--model':
        opts.config.model = value(argv, i++, arg)
        break
      case '--exclude':
        exclude.push(value(argv, i++, arg))
        break
      case '--severity': {
        const v = value(argv, i++, arg)
        if (v !== 'violation' && v !== 'tension' && v !== 'drift') {
          throw new Error(`--severity expects violation, tension, or drift (got '${v}')`)
        }
        opts.config.severityFloor = v as Severity
        break
      }
      case '--concurrency': {
        const n = Number.parseInt(value(argv, i++, arg), 10)
        if (!Number.isInteger(n) || n < 1)
          throw new Error('--concurrency expects a positive integer')
        opts.config.concurrency = n
        break
      }
      case '--max-files': {
        const n = Number.parseInt(value(argv, i++, arg), 10)
        if (!Number.isInteger(n) || n < 0)
          throw new Error('--max-files expects a non-negative integer')
        opts.config.maxFilesPerJob = n
        break
      }
      default:
        throw new Error(`unknown option '${arg}' (try --help)`)
    }
  }
  opts.config.exclude = exclude
  return opts
}

function plural(n: number, word: string): string {
  return `${n} ${word}${n === 1 ? '' : 's'}`
}

export async function main(argv: string[]): Promise<number> {
  let opts: Options | 'help'
  try {
    opts = parse(argv)
  } catch (err) {
    process.stderr.write(`dfv: ${err instanceof Error ? err.message : String(err)}\n`)
    return 2
  }
  if (opts === 'help') {
    process.stdout.write(USAGE)
    return 0
  }

  const git = new Git(opts.cwd)
  const root = git.topLevel()
  if (root === null) {
    process.stderr.write(`dfv: ${opts.cwd} is not inside a git repository\n`)
    return 2
  }

  // Default to uncommitted work: it is the faster run, and mid-change it is
  // what you are about to be judged on.
  const base = opts.base ?? 'HEAD'
  const rooted = new Git(root)
  // Resolved once, then passed to changedFiles/fileDiffs/reporting alike —
  // so the ref that gets judged and the ref that gets printed can never
  // silently diverge.
  const resolvedBase = resolveBase(rooted, base)
  const baseLabel = resolvedBase === base ? base : `${base} (resolved to ${resolvedBase})`

  let files: string[]
  try {
    files = changedFiles(rooted, resolvedBase)
  } catch (err) {
    process.stderr.write(
      `dfv: could not diff against '${baseLabel}': ${err instanceof Error ? err.message : String(err)}\n`,
    )
    return 2
  }

  if (files.length === 0) {
    if (opts.json)
      process.stdout.write(
        JSON.stringify({ base, resolvedBase, changedFiles: [], jobs: [], findings: [] }, null, 2) +
          '\n',
      )
    else process.stderr.write(`dfv: no changes against ${baseLabel}.\n`)
    return 0
  }

  const sources = await discoverSources([instructionFiles()], {
    projectRoot: root,
    changedFiles: files,
  })
  const run = await verify({
    projectRoot: root,
    sources,
    changedFiles: files,
    diffs: fileDiffs(rooted, resolvedBase, files),
    config: opts.config,
    dryRun: opts.dryRun,
  })

  if (opts.json) {
    process.stdout.write(JSON.stringify({ base, resolvedBase, ...run }, null, 2) + '\n')
    return exitCodeFor(run.findings, opts.config)
  }

  if (run.jobs.length === 0) {
    process.stderr.write(
      `dfv: ${plural(files.length, 'changed file')}, but no CLAUDE.md or AGENTS.md governs any of them.\n`,
    )
    return 0
  }

  if (opts.dryRun) {
    const bytes = run.outcomes.reduce((n, o) => n + o.promptBytes, 0)
    const shards = run.jobs.filter((j) => j.shard !== undefined).length
    process.stderr.write(
      `dfv --dry-run: would judge ${plural(files.length, 'changed file')} against ${baseLabel} ` +
        `in ${plural(run.jobs.length, 'job')}` +
        (shards > 0 ? ` (${shards} of them shards)` : '') +
        `, ~${formatTokens(estimateTokens(bytes))} tokens of prompt total.\n\n`,
    )
    for (const o of run.outcomes) {
      process.stderr.write(
        `  ${String(o.job.files.length).padStart(3)} ${o.job.files.length === 1 ? 'file ' : 'files'}  ` +
          `${formatTokens(estimateTokens(o.promptBytes)).padStart(6)} tok  ${jobLabel(o.job)}\n`,
      )
    }
    if (run.skipped.length > 0) {
      process.stderr.write(
        `\n${plural(run.skipped.length, 'rule source')} not in scope, costing nothing.\n`,
      )
    }
    process.stderr.write('\nNothing was dispatched. Drop --dry-run to run it.\n')
    return 0
  }

  // Judgements, not rule sources: a sharded source contributes several, and
  // reporting "13/17 rule sources" when there are 17 jobs over 12 sources
  // would be counting two different things in one fraction.
  const judged = run.outcomes.filter((o) => o.error === undefined).length
  const sourceCount = new Set(run.jobs.map((j) => j.source.id)).size
  process.stderr.write(
    `dfv: ${judged}/${run.jobs.length} judgements over ${plural(sourceCount, 'rule source')} ` +
      `covered ${plural(files.length, 'changed file')} against ${baseLabel}.\n`,
  )
  for (const o of run.outcomes) {
    if (o.error !== undefined) process.stderr.write(`  ! ${jobLabel(o.job)}: ${o.error}\n`)
    if (o.oversize !== undefined) {
      process.stderr.write(
        `  ~ ${jobLabel(o.job)}: ~${formatTokens(estimateTokens(o.oversize.bytes))} tokens of prompt — ` +
          'judgements at this scope are less reliable\n',
      )
    }
  }

  if (run.findings.length === 0) {
    process.stderr.write(
      run.degraded ? '\nNo findings, but the run was incomplete.\n' : '\nNo findings.\n',
    )
    return 0
  }

  let current = ''
  for (const f of run.findings) {
    if (f.sourceId !== current) {
      current = f.sourceId
      process.stderr.write(`\n${f.sourcePath}\n`)
    }
    const where = f.line === undefined ? f.file : `${f.file}:${f.line}`
    process.stderr.write(`  ${f.severity.padEnd(9)}  ${where}\n      ${f.why}\n`)
    process.stderr.write(`      > ${(f.evidence.split('\n')[0] ?? '').slice(0, 120)}\n`)
  }
  process.stderr.write(
    `\n${plural(run.findings.length, 'finding')}` +
      (opts.config.blocking ? '.\n' : ' (advisory — pass --blocking to gate on these).\n'),
  )

  return exitCodeFor(run.findings, opts.config)
}

if (import.meta.main) process.exit(await main(process.argv.slice(2)))
