import { join } from 'node:path'

import type { BaseDirs, Home, SystemBaseDirsOptions } from './base-dirs.ts'
import { systemBaseDirs } from './base-dirs.ts'
import { VENDOR, assertSegment, standaloneDir, suiteDir } from './vendor.ts'

/**
 * Which constructor produced a {@link FleetTier}.
 *
 * Exposed so a caller — or a gate run over a third party's install — can tell
 * a fleet address from a standalone one without parsing the segment string.
 */
export type TierKind = 'vendor' | 'suite' | 'standalone'

/** Every {@link TierKind}. */
export const TIER_KINDS: readonly TierKind[] = ['vendor', 'suite', 'standalone']

/**
 * A directory addressed by tier and home — or the untiered scratch root — plus
 * any scope and app segments below it. Immutable: every builder method returns
 * a new value.
 */
export class FleetPath {
  /** The resolved root this path hangs off: a home's base, or scratch. */
  readonly base: string
  /** Validated segments below {@link base}, outermost first. */
  readonly segments: readonly string[]

  constructor(base: string, segments: readonly string[]) {
    this.base = base
    this.segments = Object.freeze([...segments])
  }

  /** The absolute directory, joined with the host's separator. */
  get path(): string {
    return this.segments.length === 0 ? this.base : join(this.base, ...this.segments)
  }

  /**
   * The segments below the base, always `/`-separated.
   *
   * This is the value the parity fixture pins: the Rust twin and this one must
   * produce the same string here for the same input, or the Rust arm and the
   * TS CLI of one capability split their state.
   */
  get relative(): string {
    return this.segments.join('/')
  }

  /**
   * Key this location by a content root's minted id:
   * `.scoped('vaults', vaultId)` appends `vaults/<vaultId>`.
   *
   * Both arguments are validated as single path segments.
   */
  scoped(kind: string, key: string): FleetPath {
    assertSegment('scope kind', kind)
    assertSegment('scope', key)
    return new FleetPath(this.base, [...this.segments, kind, key])
  }

  /** Append one app's own directory. Validated as a single path segment. */
  app(app: string): FleetPath {
    assertSegment('app', app)
    return new FleetPath(this.base, [...this.segments, app])
  }

  toString(): string {
    return this.path
  }
}

/**
 * One rung of the vertical axis — who shares the state — bound to a set of
 * base directories. Pick a home off it to get a directory.
 *
 * Tiers are distinct addresses. `vendor().durable()`, `suite(k).durable()` and
 * `standalone(t).durable()` are different locations and the SDK never reads two
 * and merges them. A given piece of state lives at exactly one tier and the
 * caller names the tier it means. "Look up both" is something a specific
 * reader does deliberately, per file, at its own call site — never a per-key
 * cascade baked in here, which starts as two lines and ends as deep-merge
 * with array-override rules nobody can predict.
 */
export class FleetTier {
  /** The directory segment this tier contributes, e.g. `com.sizerllc.determined`. */
  readonly segment: string

  /** Which constructor produced this tier. */
  readonly kind: TierKind

  readonly #bases: BaseDirs

  constructor(bases: BaseDirs, kind: TierKind, segment: string) {
    this.#bases = bases
    this.kind = kind
    this.segment = segment
  }

  /** Long-lived state that must survive a cache purge. */
  durable(): FleetPath {
    return this.home('durable')
  }

  /** User-editable configuration. */
  config(): FleetPath {
    return this.home('config')
  }

  /** Regenerable data. The OS may delete this at any time. */
  cache(): FleetPath {
    return this.home('cache')
  }

  /** Log files. Never under `cache` — the OS purges cache. */
  logs(): FleetPath {
    return this.home('logs')
  }

  /** Pidfiles, sockets, locks. Never under `cache`. */
  runtime(): FleetPath {
    return this.home('runtime')
  }

  /** The same five homes, named dynamically. Table-driven callers use this. */
  home(home: Home): FleetPath {
    return new FleetPath(this.#bases[home], [this.segment])
  }
}

/**
 * The entry point: base directories resolved once, then the tiers off them.
 *
 * ```ts
 * const fleet = Fleet.fromSystem();
 * fleet.suite('determined').cache().scoped('vaults', vaultId).app('vault-search').path;
 * // <cache>/com.sizerllc.determined/vaults/<vaultId>/vault-search
 * ```
 *
 * The product tier of the design — one product's own directory — is not here.
 * It is the Tauri bundle-identifier directory, and this package takes no
 * Tauri dependency: the headless platform server, the Bun CLI fleet and the
 * ontological CLI all consume it and none of them has Tauri.
 */
export class Fleet {
  /** The roots every path in this instance hangs off. Resolved at construction. */
  readonly bases: Readonly<BaseDirs>

  /**
   * Build from injected roots — the seam a nitro server arm uses, handing in
   * roots from `useRuntimeConfig()` because it cannot read the environment.
   */
  constructor(bases: BaseDirs) {
    this.bases = Object.freeze({ ...bases })
  }

  /**
   * Build from the environment, reading it exactly once. Every input is
   * injectable, so a test asserts exact paths without a real home directory.
   *
   * Throws {@link FleetError} when no home directory can be found.
   */
  static fromSystem(opts: SystemBaseDirsOptions = {}): Fleet {
    return new Fleet(systemBaseDirs(opts))
  }

  /** Shared by every product line the company ships: `com.sizerllc`. */
  vendor(): FleetTier {
    return new FleetTier(this.bases, 'vendor', VENDOR)
  }

  /**
   * Shared by the products that share user data: `com.sizerllc.<suiteKey>`.
   *
   * `suiteKey` is a caller-supplied constant, not something derived from a
   * bundle id — derivation would yield the brand being retired.
   */
  suite(suiteKey: string): FleetTier {
    return new FleetTier(this.bases, 'suite', suiteDir(suiteKey))
  }

  /**
   * One general tool's own root: the bare `tool` name, with no vendor segment.
   *
   * For a tool this company ships into other people's repositories. It is not
   * part of this vendor's suite, so it must not write under this vendor's
   * namespace; it owns `~/.config/<tool>` the way any general CLI does. See
   * {@link standaloneDir}.
   *
   * Use {@link Fleet.suite} for anything that ships as part of this fleet. The
   * two are different addresses and nothing merges them.
   */
  standalone(tool: string): FleetTier {
    return new FleetTier(this.bases, 'standalone', standaloneDir(tool))
  }

  /**
   * The platform temp directory, untiered: state that does not outlive the
   * call that wrote it.
   *
   * A thin wrapper over the platform temp dir. It adds nothing, and that is
   * its whole value: with it, "no direct OS path call outside this package" is
   * a greppable invariant instead of a rule with exceptions.
   *
   * Not {@link FleetTier.runtime}. Runtime holds state that does outlive the
   * call and describes a live process — a pidfile, a socket, a lock — and the
   * OS sweeps temp while such a process is still running.
   */
  scratch(): FleetPath {
    return new FleetPath(this.bases.scratch, [])
  }
}
