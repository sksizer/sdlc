# @sksizer/fleet

One answer to "where does this state live?" for every product the company
ships.

Two axes. The **tier** says who shares the state. The **home** says how durable
it is. A caller names both.

```ts
import { Fleet } from '@sksizer/fleet';

const fleet = Fleet.fromSystem();

fleet.vendor().config().path;
// ~/Library/Application Support/com.sizerllc

fleet.suite('determined').cache().scoped('vaults', vaultId).app('vault-search').path;
// ~/Library/Caches/com.sizerllc.determined/vaults/<vaultId>/vault-search
```

## Tiers

| tier | segment | shared by |
|---|---|---|
| vendor | `com.sizerllc` | every product line the company ships |
| suite | `com.sizerllc.<suiteKey>` | the products that share user data |
| standalone | `<tool>` | one general tool, shipped outside this fleet |

`VENDOR` is the only string constant in the package. The suite segment is
composed from it. `suiteKey` is a caller-supplied constant — it is not derived
from a bundle identifier, because derivation would name a brand being retired.
`FleetTier.kind` reports which constructor produced a tier.

The design's product tier — one product's own directory — is not here. That is
the Tauri bundle-identifier directory, and this package takes no Tauri
dependency: the headless platform server, the Bun CLI fleet and the ontological
CLI all consume it and none of them has Tauri.

**Tiers are distinct addresses and there is no merge.** `vendor().durable()`,
`suite(k).durable()` and `standalone(t).durable()` are different locations. This
package never reads two and merges them. A given piece of state lives at
exactly one tier and the caller names the tier it means. Looking up both is
something a specific reader does deliberately, per file, at its own call site —
never a per-key cascade baked in here.

### A general tool supplies its own root

The vendor and suite tiers govern a SUITE: products that share one owner. A
general tool this company ships into other people's repositories is not in that
suite, and `suite('sdlc')` would write this company's vendor namespace onto a
stranger's machine.

`standalone(tool)` is the tier for that tool. Its segment is the bare tool name
— `~/.config/<tool>`, what a general CLI idiomatically owns — with no vendor
composition.

```ts
fleet.standalone('sdlc').config().path; // ~/.config/sdlc
```

## Homes

| home | macOS | Linux/other | Windows |
|---|---|---|---|
| durable | `~/Library/Application Support` | `$XDG_DATA_HOME`, `~/.local/share` | `%APPDATA%` |
| config | `~/Library/Application Support` | `$XDG_CONFIG_HOME`, `~/.config` | `%APPDATA%` |
| cache | `~/Library/Caches` | `$XDG_CACHE_HOME`, `~/.cache` | `%LOCALAPPDATA%` |
| logs | `~/Library/Logs` | `$XDG_STATE_HOME`, `~/.local/state` | `<durable>/logs` |
| runtime | `<durable>/run` | `$XDG_RUNTIME_DIR`, `<durable>/run` | `<durable>/run` |

`logs` never falls back to `cache` — the OS purges cache. `runtime` sits under
`durable` for the same reason: the OS may purge cache while the process a
pidfile describes is still alive.

## Scratch

`Fleet.scratch()` returns the platform temp directory: `$TMPDIR` or `/tmp`, and
`%TEMP%` / `%TMP%` on Windows. It adds nothing to the platform answer, which is
the point — "no direct OS path call outside this package" becomes greppable
instead of a rule with exceptions.

Scratch is not a `Home` and not a tier. It holds state that does not outlive a
single call; the `runtime` home holds state that does and describes a live
process — a pidfile, a socket, a lock.

## Injectable roots

Nothing below `systemBaseDirs` reads the environment. A `Fleet` resolves its
roots once, at construction, and every path after that is pure string work.
`scratch` is resolved from the injected environment for that reason, rather
than by calling `os.tmpdir()`, which would read the real `process.env`.

That is what lets both arms of a nitro app call one seam. The CLI arm builds
roots from the environment; the server arm cannot — nitro breaks
`import.meta.url` — so it hands in roots it got from `useRuntimeConfig()`:

```ts
const fleet = new Fleet(useRuntimeConfig().fleetBases);
```

Tests use the same seam to assert exact paths without touching a real home
directory.

## Failure

Every base directory can fail to resolve; headless CI and sandboxes do not
always have a home. `systemBaseDirs` and `Fleet.fromSystem` throw `FleetError`
rather than assert, and `overrides` rescues an environment with no home at all.

## Parity

`packages/fleet-parity/parity.json` is the contract between this package and
the Rust `fleet` crate: a table of (tier, home, scope, app) to expected
relative path, plus a `scratch_cases` list for the untiered scratch root, read
by both twins with base directories stubbed —
`rootedBaseDirs('/stub')` here, `BaseDirs::rooted("/stub")` there, the same
layout. It sits outside both packages because it belongs to neither. Neither
twin may add a path shape the other lacks — a new case goes in the fixture
first. If they drift, the Rust arm and the TS CLI of the same capability split
their state.

## API

```ts
const VENDOR: 'com.sizerllc';
function suiteDir(suiteKey: string): string;
function standaloneDir(tool: string): string;
function isVendorBundleId(bundleId: string): boolean;
function isValidSegment(key: string): boolean;

type Home = 'durable' | 'config' | 'cache' | 'logs' | 'runtime';
const HOMES: readonly Home[];
type TierKind = 'vendor' | 'suite' | 'standalone';
const TIER_KINDS: readonly TierKind[];
interface BaseDirs { durable; config; cache; logs; runtime; scratch: string }
interface SystemBaseDirsOptions {
  platform?: string;
  env?: Record<string, string | undefined>;
  home?: string;
  overrides?: Partial<BaseDirs>;
}
function systemBaseDirs(opts?: SystemBaseDirsOptions): BaseDirs;
function rootedBaseDirs(root: string): BaseDirs;

class Fleet {
  constructor(bases: BaseDirs);
  static fromSystem(opts?: SystemBaseDirsOptions): Fleet;
  readonly bases: Readonly<BaseDirs>;
  vendor(): FleetTier;
  suite(suiteKey: string): FleetTier;
  standalone(tool: string): FleetTier;
  scratch(): FleetPath;
}

class FleetTier {
  readonly segment: string;
  readonly kind: TierKind;
  durable(): FleetPath;
  config(): FleetPath;
  cache(): FleetPath;
  logs(): FleetPath;
  runtime(): FleetPath;
  home(home: Home): FleetPath;
}

class FleetPath {
  readonly base: string;
  readonly segments: readonly string[];
  get path(): string;      // absolute, host separator
  get relative(): string;  // below the base, always "/"-separated
  scoped(kind: string, key: string): FleetPath;
  app(app: string): FleetPath;
}

class FleetError extends Error {}
```

`suiteKey`, `tool`, `kind`, `key` and `app` are each validated as a single path
segment: non-empty, no separator, no `..`, matching `^[a-z0-9][a-z0-9._-]*$/i`
— the rule `@sksizer/vault-path` already applies to app slugs. An invalid one
throws `FleetError`.

## Resolving the package

```json
"exports": { ".": { "bun": "./index.ts", "node": "./index.ts",
                    "types": "./dist/index.d.ts", "default": "./dist/index.js" } }
```

Both `bun` and `node` resolve the TypeScript source. Bun runs it directly; node
strips the types (on by default since 23.6, and via
`--experimental-strip-types` before that). The `node` condition is not
decoration: `@sksizer/vault-path` is source-shipped and imports this package, so
without it every node-run CLI in the determined fleet — `vault-engine`,
`vault-search`, `mail-sync`, `photo-match` — fails to start against an unbuilt
`dist/`, which is the normal state of a fresh checkout. `default` keeps the
compiled output for bundlers and for any consumer that is neither.
