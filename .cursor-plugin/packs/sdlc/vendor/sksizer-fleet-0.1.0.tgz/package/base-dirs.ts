import { homedir } from 'node:os'
import { join } from 'node:path'

import { FleetError } from './errors.ts'

/**
 * The horizontal axis: how durable a piece of state is. The vertical axis —
 * who shares it — is the tier (see `fleet.ts`).
 *
 * A caller names both: `suite('determined').cache()`.
 */
export type Home = 'durable' | 'config' | 'cache' | 'logs' | 'runtime'

/** Every {@link Home}, in table order. */
export const HOMES: readonly Home[] = ['durable', 'config', 'cache', 'logs', 'runtime']

/**
 * The per-OS roots the whole package is built on.
 *
 * This is the injectable seam. Nothing below it reads the environment: a
 * `Fleet` resolves its roots once, at construction, and every path after that
 * is pure string work. That is what lets the two arms of a nitro app share one
 * SDK call — the CLI arm builds these from the environment, the server arm
 * hands in roots it got from `useRuntimeConfig()`, because nitro breaks
 * `import.meta.url` and the server arm has no environment to read.
 */
export interface BaseDirs {
  /** Long-lived state that must survive a cache purge. */
  durable: string
  /** User-editable configuration. */
  config: string
  /** Regenerable data. The OS may delete this at any time. */
  cache: string
  /** Log files. Never folded into `cache` — the OS purges cache. */
  logs: string
  /** Pidfiles, sockets, locks. Never under `cache`; see {@link systemBaseDirs}. */
  runtime: string
  /**
   * The platform temp directory. Not a {@link Home}: nothing here outlives the
   * call that wrote it, so it is untiered and reached through `Fleet.scratch()`
   * rather than through a tier.
   */
  scratch: string
}

/** Every key of {@link BaseDirs}: the five homes plus `scratch`. */
const BASE_DIR_KEYS: readonly (keyof BaseDirs)[] = [...HOMES, 'scratch']

/** Directory name for runtime state where the platform offers none (trap 2). */
const RUNTIME_FALLBACK_SEGMENT = 'run'

/**
 * Every base directory under one stub root: `<root>/durable`, `<root>/config`,
 * `<root>/cache`, `<root>/logs`, `<root>/scratch`, and runtime at
 * `<root>/durable/run`.
 *
 * The test and parity-fixture seam. The Rust twin's `BaseDirs::rooted` has the
 * same layout, so a fixture row asserts identical absolute paths on both arms.
 */
export function rootedBaseDirs(root: string): BaseDirs {
  const durable = join(root, 'durable')
  return {
    durable,
    config: join(root, 'config'),
    cache: join(root, 'cache'),
    logs: join(root, 'logs'),
    runtime: join(durable, RUNTIME_FALLBACK_SEGMENT),
    scratch: join(root, 'scratch'),
  }
}

/** Inputs for {@link systemBaseDirs}. Every one is optional and injectable. */
export interface SystemBaseDirsOptions {
  /** Defaults to `process.platform`. */
  platform?: string
  /**
   * Defaults to `process.env`. Injecting this means the supplied environment
   * is the whole story: the host's real home directory is not consulted.
   */
  env?: Record<string, string | undefined>
  /** Home directory. Overrides `HOME` / `USERPROFILE` when given. */
  home?: string
  /**
   * Replace individual roots. An overridden root is taken as-is and needs no
   * home directory. It is not a base for the others: overriding `durable`
   * leaves `runtime` and `logs` where the per-OS table puts them.
   */
  overrides?: Partial<BaseDirs>
}

/**
 * The per-OS table this package owns so no caller has to.
 *
 * | home    | macOS                          | Linux/other                     | Windows              |
 * |---------|--------------------------------|---------------------------------|----------------------|
 * | durable | `~/Library/Application Support`| `$XDG_DATA_HOME`, `~/.local/share` | `%APPDATA%`, `<home>/AppData/Roaming` |
 * | config  | `~/Library/Application Support`| `$XDG_CONFIG_HOME`, `~/.config` | `%APPDATA%`, `<home>/AppData/Roaming` |
 * | cache   | `~/Library/Caches`             | `$XDG_CACHE_HOME`, `~/.cache`   | `%LOCALAPPDATA%`, `<home>/AppData/Local` |
 * | logs    | `~/Library/Logs`               | `$XDG_STATE_HOME`, `~/.local/state` | `<durable>/logs` |
 * | runtime | `<durable>/run`                | `$XDG_RUNTIME_DIR`, `<durable>/run` | `<durable>/run`  |
 * | scratch | `$TMPDIR`, `/tmp`              | `$TMPDIR`, `/tmp`               | `%TEMP%`, `%TMP%`, `<home>/AppData/Local/Temp` |
 *
 * Two of those cells are traps the table exists to absorb:
 *
 * - `logs` has no cross-platform library equivalent. macOS wants
 *   `~/Library/Logs`; where the OS offers nothing, logs land at
 *   `<durable>/logs`. They are never folded into `cache`.
 * - `runtime` only exists on Linux, and only when `XDG_RUNTIME_DIR` is set.
 *   Everywhere else it resolves under `<durable>/run` — deliberately not under
 *   cache, because the OS may purge cache while the process a pidfile
 *   describes is still alive.
 *
 * `scratch` is resolved from the injected environment rather than by calling
 * `os.tmpdir()`, which reads the real `process.env` and would make an injected
 * environment stop being the whole story. The Rust twin asks its own platform
 * the same question; the two roots need not match, because parity pins only
 * what sits below a root.
 *
 * Throws {@link FleetError} when a root falls back to the home directory and
 * none can be found. Headless CI and sandboxes do not always have one.
 */
export function systemBaseDirs(opts: SystemBaseDirsOptions = {}): BaseDirs {
  const platform = opts.platform ?? process.platform
  const env = opts.env ?? process.env
  const over = opts.overrides ? stripUndefined(opts.overrides) : {}

  let cachedHome: string | undefined
  const home = (): string => (cachedHome ??= resolveHome(opts, platform, env))

  const table = platformTable(platform, env, home)
  const roots = {} as BaseDirs
  for (const key of BASE_DIR_KEYS) {
    roots[key] = over[key] ?? table[key]()
  }
  return roots
}

/**
 * The per-OS table, one thunk per root. Deferred so that an overridden root
 * skips its cell, and with it the home lookup that cell would have made.
 */
function platformTable(
  platform: string,
  env: Record<string, string | undefined>,
  home: () => string,
): Record<keyof BaseDirs, () => string> {
  const posixScratch = (): string => absoluteEnv(env, 'TMPDIR', platform) ?? '/tmp'

  if (platform === 'darwin') {
    const support = (): string => join(home(), 'Library', 'Application Support')
    return {
      durable: support,
      config: support,
      cache: () => join(home(), 'Library', 'Caches'),
      logs: () => join(home(), 'Library', 'Logs'),
      runtime: () => join(support(), RUNTIME_FALLBACK_SEGMENT),
      scratch: posixScratch,
    }
  }

  if (platform === 'win32') {
    const roaming = (): string =>
      absoluteEnv(env, 'APPDATA', platform) ?? join(home(), 'AppData', 'Roaming')
    return {
      durable: roaming,
      config: roaming,
      cache: () => absoluteEnv(env, 'LOCALAPPDATA', platform) ?? join(home(), 'AppData', 'Local'),
      logs: () => join(roaming(), 'logs'),
      runtime: () => join(roaming(), RUNTIME_FALLBACK_SEGMENT),
      scratch: () =>
        absoluteEnv(env, 'TEMP', platform) ??
        absoluteEnv(env, 'TMP', platform) ??
        join(home(), 'AppData', 'Local', 'Temp'),
    }
  }

  const durable = (): string =>
    absoluteEnv(env, 'XDG_DATA_HOME', platform) ?? join(home(), '.local', 'share')
  return {
    durable,
    config: () => absoluteEnv(env, 'XDG_CONFIG_HOME', platform) ?? join(home(), '.config'),
    cache: () => absoluteEnv(env, 'XDG_CACHE_HOME', platform) ?? join(home(), '.cache'),
    logs: () => absoluteEnv(env, 'XDG_STATE_HOME', platform) ?? join(home(), '.local', 'state'),
    runtime: () =>
      absoluteEnv(env, 'XDG_RUNTIME_DIR', platform) ?? join(durable(), RUNTIME_FALLBACK_SEGMENT),
    scratch: posixScratch,
  }
}

function resolveHome(
  opts: SystemBaseDirsOptions,
  platform: string,
  env: Record<string, string | undefined>,
): string {
  if (opts.home !== undefined) {
    if (opts.home === '') {
      throw new FleetError('home must be a non-empty path')
    }
    return opts.home
  }

  const fromEnv = env['HOME'] || (platform === 'win32' ? env['USERPROFILE'] : undefined)
  if (fromEnv) return fromEnv

  // An injected environment is the whole story — falling back to the host's
  // real home here would make a test's paths depend on the machine running it.
  if (opts.env !== undefined) {
    throw new FleetError(
      'no home directory: the supplied environment sets neither HOME nor USERPROFILE',
    )
  }

  let host = ''
  try {
    host = homedir()
  } catch {
    host = ''
  }
  if (host) return host

  throw new FleetError(
    'no home directory: HOME is unset and the OS reports none — pass `home` or `overrides`',
  )
}

/**
 * An environment variable, honoured only when it names an absolute path.
 * The XDG spec says a relative value is invalid and must be ignored.
 */
function absoluteEnv(
  env: Record<string, string | undefined>,
  key: string,
  platform: string,
): string | undefined {
  const value = env[key]
  if (!value) return undefined
  return isAbsolutePath(value, platform) ? value : undefined
}

/** `path.isAbsolute` for a named platform rather than the host's. */
function isAbsolutePath(value: string, platform: string): boolean {
  if (platform === 'win32') {
    return /^[a-z]:[\\/]/i.test(value) || value.startsWith('\\\\') || value.startsWith('//')
  }
  return value.startsWith('/')
}

/** Drop explicit `undefined` entries so an override cannot blank out a root. */
function stripUndefined(overrides: Partial<BaseDirs>): Partial<BaseDirs> {
  const out: Partial<BaseDirs> = {}
  for (const key of BASE_DIR_KEYS) {
    const value = overrides[key]
    if (value !== undefined) out[key] = value
  }
  return out
}
