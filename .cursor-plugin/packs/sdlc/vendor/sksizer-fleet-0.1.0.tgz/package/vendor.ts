import { FleetError } from './errors.ts'

/**
 * The one string constant in this package. Every other segment is either
 * composed from it or supplied by the caller — a standalone tool's segment is
 * its own name and carries no vendor at all.
 *
 * `VENDOR` is a real prefix of every conformant bundle identifier
 * (`com.sizerllc.family.*`, `com.sizerllc.agentpants.desktop`), which is what
 * makes {@link isVendorBundleId} meaningful.
 */
export const VENDOR = 'com.sizerllc'

/**
 * The suite tier's directory segment: `com.sizerllc.<suiteKey>`.
 *
 * The segment is composed, never spelled out. It is not derivable from a
 * bundle id — derivation would yield `com.sizerllc.family`, the brand being
 * retired — so `suiteKey` stays a caller-supplied constant.
 */
export function suiteDir(suiteKey: string): string {
  assertSegment('suite', suiteKey)
  return `${VENDOR}.${suiteKey}`
}

/**
 * The standalone tier's directory segment: the bare `tool` name, with NO
 * vendor prefix.
 *
 * The vendor and suite tiers govern a SUITE — products that share one owner.
 * A general tool shipped into other people's repositories is not in that
 * suite, and composing {@link VENDOR} into its path would write this company's
 * namespace onto a stranger's machine. So a standalone tool supplies its own
 * root: `~/.config/<tool>`, what a general CLI idiomatically owns. A
 * reverse-DNS root would either encode our vendor, which is the bug, or invent
 * one, which names nobody.
 *
 * The function exists to hold that reasoning and to validate the name; the
 * composition it performs is deliberately none.
 */
export function standaloneDir(tool: string): string {
  assertSegment('standalone', tool)
  return tool
}

/**
 * Whether a bundle identifier sits under {@link VENDOR}.
 *
 * A migration tracker, not a gate. The Rust twin wraps the same prefix test
 * in a `debug_assert!`, so a non-conformant app surfaces at the moment
 * someone adopts the SDK in it and never breaks a release build; TS has no
 * debug assertion, so this stays a predicate the caller decides what to do
 * with. There is no allowlist for the legacy `com.sksizer.*` prefix — an
 * allowlist is how the drift becomes permanent.
 */
export function isVendorBundleId(bundleId: string): boolean {
  return bundleId.startsWith(VENDOR)
}

/** A path segment: a letter/digit, then letters/digits and `._-`. */
const SEGMENT = /^[a-z0-9][a-z0-9._-]*$/i

/**
 * Whether `key` is a safe single path segment.
 *
 * The rule is `vault-path`'s `assertValidApp`, lifted so the two packages
 * accept exactly the same slugs: the regex alone still admits `a..b`, so the
 * separator and `..` rejections stay explicit. The Rust twin's `valid_key`
 * is the same predicate.
 */
export function isValidSegment(key: string): boolean {
  if (key === '') return false
  if (key.includes('/') || key.includes('\\') || key.includes('..')) return false
  return SEGMENT.test(key)
}

/**
 * Throw unless `key` is a safe single path segment. `kind` names the argument
 * in the message — `suite`, `scope kind`, `scope`, `app` — matching the Rust
 * twin's `check_key`.
 */
export function assertSegment(kind: string, key: string): void {
  if (!isValidSegment(key)) {
    throw new FleetError(
      `invalid ${kind} key ${JSON.stringify(key)}: want a leading letter/digit ` +
        'then ._-, no path separator or ".."',
    )
  }
}
