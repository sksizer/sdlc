/**
 * `@sksizer/fleet` — one answer to "where does this state live?" for every
 * product the company ships, in Rust and TypeScript alike.
 *
 * Two axes. The tier says who shares the state (the vendor, a suite of
 * products that share user data, or one general tool shipped outside this
 * fleet). The home says how durable it is (durable, config, cache, logs,
 * runtime). A caller names both:
 *
 * ```ts
 * Fleet.fromSystem().suite('determined').cache().scoped('vaults', id).app('vault-search')
 * ```
 *
 * `Fleet.scratch()` sits outside both axes: the platform temp directory, for
 * state that does not outlive a single call.
 *
 * This module is the byte-identical twin of the Rust `fleet` crate. Identical
 * input must yield an identical relative path in both, and `tests/parity.test.ts`
 * pins that against a fixture both twins consume. If they drift, the Rust arm
 * and the TS CLI of the same capability split their state.
 */

export { FleetError } from './errors.ts'
export { VENDOR, isValidSegment, isVendorBundleId, standaloneDir, suiteDir } from './vendor.ts'
export { HOMES, rootedBaseDirs, systemBaseDirs } from './base-dirs.ts'
export type { BaseDirs, Home, SystemBaseDirsOptions } from './base-dirs.ts'
export { TIER_KINDS, Fleet, FleetPath, FleetTier } from './fleet.ts'
export type { TierKind } from './fleet.ts'
