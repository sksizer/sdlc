/**
 * Every failure this package raises. One class, so a consumer can tell a
 * fleet path problem from an unrelated `Error` without string matching.
 *
 * Nothing here ever aborts the process. Trap 3 of the design note: base
 * directories can fail to resolve — headless CI and sandboxes do not always
 * have a home — so resolution throws a catchable error and never asserts.
 */
export class FleetError extends Error {
  override readonly name = 'FleetError'

  constructor(message: string) {
    super(message)
  }
}
