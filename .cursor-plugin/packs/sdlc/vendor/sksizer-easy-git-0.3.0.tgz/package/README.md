# @sksizer/easy-git

A typed git client for TypeScript, in a synchronous and an awaitable form.
Each verb declares what *absence* means for it; every other failure throws.
`git.try.*` inspects, `raw()` bypasses. What actually performs the git is a
parameter.

```ts
import { Git, AsyncGit } from "@sksizer/easy-git";

const git = new Git(process.cwd());

git.currentBranch();             // "main", or null when detached
git.configGet("no.such.key");    // null — an unset key is an answer
git.worktrees();                 // Worktree[] — throws outside a repository
git.commit({ message: "feat" }); // throws CommandFailed on a non-zero exit

const r = git.try.worktrees();   // { ok: true, value } | { ok: false, error }

const async = new AsyncGit(process.cwd());
await async.currentBranch();
```

## Two clients, one surface

`Git` is synchronous and always shells out. That is a deliberate choice, not a
missing feature: sequential git one-shots gain nothing from being awaited, and
staying synchronous keeps a caller's call graph uncolored.

`AsyncGit` is the awaitable twin. Reach for it when the caller is a server
that must not block, when calls fan out concurrently, or when git should come
from something other than a subprocess.

Both drive the same verb table — one definition of every argv and every
parser — so they cannot drift apart. The test suite asserts it: the two
clients are run side by side against a recording runner and their argv
compared.

## Absence is an answer; failure is not

**Declared absence returns a value; everything else throws; `try` inspects;
`raw` bypasses.**

Every verb names the exit codes that mean "asked and answered: not there" for
*that* verb. `config --get` exits 1 for an unset key; `check-ignore` exits 1
for "none of these are ignored"; `merge-base` exits 1 for unrelated histories.
Those return the absence value — `null`, `[]`, `false` — exactly as before.
Any other non-zero exit throws `CommandFailed`, carrying the argv and the full
result.

| | on a declared absence | on anything else |
| --- | --- | --- |
| **`git.verb()`** | the absence value — `null`, `[]`, `false` | throws `CommandFailed` |
| **`git.try.verb()`** | `{ ok: true, value }` | `{ ok: false, error }` |
| **`git.raw(argv)`** | the raw `CommandResult`; you decide | the same |

Why it matters: a guard that runs `status --porcelain` outside a repository
used to receive `[]` and report a clean tree. It now throws. The failing check
can no longer ship as a passing one.

`git.try.*` is for callers that genuinely tolerate failure — a hook that must
not break a commit, an endpoint that must always answer:

```ts
const r = git.try.topLevel();
if (!r.ok) { console.error(r.error.result.stderr); return; }
use(r.value);
```

It mirrors the whole surface, sync and async, and costs nothing per verb. Two
rules keep it honest: it catches `CommandFailed` and nothing else, so a
`TypeError` still propagates; and a declared absence is `{ ok: true }`,
because absence is an answer.

### The honest limit: git overloads exit 128

For `show` and `log`, git spells *both* "that path/ref is not in the tree"
*and* "this is not a repository" as exit 128. `showAtRev` and `logSubject`
must therefore declare `absent: [128]`, and for those two verbs absence and
breakage remain indistinguishable — they keep exactly the weakness this
contract removes elsewhere. The contract narrows the failure surface; it does
not eliminate it.

Where the difference matters, probe with `hasHistory()` first:

```ts
// false = unborn HEAD; true = there is history; a throw = the store is broken.
if (!git.hasHistory()) return [];
const subject = git.logSubject("HEAD");     // a 128 here is now real breakage
```

**Not `objectExists("HEAD")`.** It is a predicate over both of git's "no"
codes, which is right for "does this name resolve?" and wrong for "does this
repo have history?". Measured against real stores, `cat-file -e HEAD` exits
**128** on an empty repository, **1** on a dangling HEAD ref, and **128** with
the object directory removed — so `objectExists` answers `false` for all three
and folds a *corrupt* store into "nothing here yet", which is the exact
confusion this contract exists to remove. `hasHistory()` — `resolveRef("HEAD")`
under the hood — separates them: **1** (→ `null`) for unborn, **0** for a dangling ref, **128**
(→ throw) for a missing object store.

## Paths come back NUL-split

`lsFiles`, `lsTree`, `diffNameOnly`, `diffNameStatus` and `diffTree` always
pass `-z`. git's default output *quotes* a path containing a space, a quote or
a non-ASCII byte (`"docs/a b.md"`), and a caller splitting on newlines reads the
quotes as part of the name. There is no option to turn this off.

`diffNameStatus` and `diffTree` return `{ status, path, from? }` rows. The
status token is verbatim — `R100`, not `R` — a rename or copy reports its
**destination** in `path` and its **source** in `from`, and `from` is absent on
every other status:

```ts
git.diffNameStatus({ cached: true });
// [{ status: "R100", path: "docs/renamed.md", from: "docs/a.md" },
//  { status: "A", path: "new.txt" }]
```

That record is three NUL fields (`R100`, old path, new path) where every other
record is two, which is what a hand-rolled caller-side split gets wrong.

`lsTree` is `-z` for the same reason, and returns
`{ mode, type, sha, sizeBytes, path }` rows. `sizeBytes` is set only for a blob
under `{ long: true }`; a tree or submodule reports `null`, because `--long`
prints `-` there and a fabricated `0` would be worse than nothing.

## Exit codes that are answers

Two verbs carry their answer in the exit code rather than in stdout, and both
are here because a caller reading `exitCode` by hand gets them wrong:

```ts
git.grep("TODO|FIXME", { extendedRegexp: true, lineNumber: true });
// [] when nothing matched — `git grep` exits 1 for "no matches", and a
// caller that treats non-zero as failure turns every clean scan into an error.
// 128 (not a repository, an unbalanced regex) and 129 (usage) still throw.

git.isAncestor(sha, "origin/main");
// false only when git said so (exit 1) — diverged or unrelated histories
// alike. A rev that does not resolve exits 128 and THROWS, because "not an
// ancestor" is usually the answer that lets a caller delete something.
```

An exit code only answers when git produced it. A `git` missing from PATH, a
timeout kill or an abort leaves the runner with no exit code of its own to
report, and every verb throws `CommandFailed` there — none of them reads that
as "no matches" or "no such key".

`aheadBehind` is here for a different reason: it owns a field order that is
easy to invert. `rev-list --left-right --count base...tip` prints the left
count first, and left is `base` — so that number is *behind*, not ahead.

```ts
git.aheadBehind("origin/main", "HEAD"); // { ahead: 2, behind: 1 }
```

Two more edges worth knowing, both exit 0 with empty output rather than an
error: `diffTree` on a **root commit** reports nothing unless you pass
`{ root: true }`, and a `grep` pathspec that matches no file is
indistinguishable from "no matches".

`diffTreeNumstat(rev, opts)` is the counting twin of `diffTree`, with the same
options and rows of `{ path, linesAdded, linesDeleted }` (`null` counts for a
binary file). Two verbs rather than one option, because git rejects
`--numstat` together with `--name-status`.

## Merging: a conflict is a value

`merge`, `rebase` and `rebaseContinue` are the verbs where a non-zero exit is
the answer you asked for. They declare exit 1 as absence and hand back an
outcome:

```ts
const out = git.merge("origin/main");
switch (out.status) {
  case "clean":    return out.fastForward ? "ff" : "merged";
  case "conflict": return resolve(git.lsFilesUnmerged());
}
// git refusing to merge at all still throws.
```

The exit code alone cannot carry this. Measured against git 2.50.1:

| | exit |
| --- | --- |
| `merge`, conflict | `1` — stdout carries the report |
| `merge`, unknown ref | `1` — **stdout empty** |
| `merge`, would overwrite local edits | `2` |
| `merge`, merge already in progress | `128` |
| `merge`, unrelated histories | `128` |
| `rebase`, conflict | `1` |
| `rebase`, unknown ref | `128` |
| `merge` / `rebase --abort`, none running | `128` |
| `merge-tree`, conflict | `1` — stdout carries the tree and paths |
| `merge-tree`, unmergeable name | `1` — **stdout empty** |
| `merge-tree`, unrelated histories | `128` |

A ref git cannot resolve exits **1, exactly like a conflict**. What separates
them is that a conflict always writes its report to stdout and a refusal
writes nothing there — a structural signal rather than a string match, because
git's messages are translatable and a locale must not change what an outcome
means.

`conflicts` on the outcome is that report, so treat it as a summary:
rename/rename and rename/delete have no parseable form in it, and under a
localized git it can be empty on a real conflict. **`lsFilesUnmerged()` is the
authoritative list.** Its stage detail is also what tells the shapes apart —
all of 1/2/3 is both-modified, 1+3 is we-deleted, 1+2 is they-deleted, 2+3
with no base is add/add. A resolver that assumes both-modified deletes files.
For the paths alone, `diffNameOnly({ diffFilter: "U" })` is cheaper.

One sharp edge git leaves in `checkoutSide`: on a path that is *not*
conflicted it exits 0 and does nothing. There is no error to catch, so take
the path list from `lsFilesUnmerged()` in the same breath, not from an
earlier one.

## Asking without checking out

`mergeTree` answers the same question as `merge` — would this merge, and where
would it conflict — against the object database alone. No index, no checkout,
no worktree, so it needs no clean tree to run in and leaves nothing to clean
up:

```ts
const out = git.mergeTree("main", "origin/topic");
if (out.status === "clean") {
  // `out.tree` is a real object: build the merge commit from it and push,
  // without ever materializing a working copy.
}
```

Surveying many branches is where this pays: predicting every open PR's merge
across a large repository costs seconds, while checking each one out to learn
the same thing costs minutes — and most of them merge cleanly, so the checkout
was wasted.

Two differences from `merge` are worth knowing. Its conflict list **is**
authoritative — git names the paths in a machine-readable section rather than
in prose, so there is no `lsFilesUnmerged()` to follow up with. And it takes
both sides as arguments rather than merging into the current branch, so
nothing depends on where `HEAD` happens to be.

## `log` hands back bytes

```ts
const raw = git.log({ format: "format:%x1e%H%x1f%s", numstat: true });
```

`log` returns stdout unsplit and untrimmed. The format is yours, and callers
frame their own records with `%x1e` / `%x1f` or interleave `--name-status`
blocks — splitting on newlines would cut those records in half. For a
one-record-per-line format, `logLines(opts)` is `log` plus that split.

It declares no absence code, deliberately. An empty repository exits 128 —
the same code a corrupt one gives — so `log` on a store with no commits
throws. Probe first, or tolerate:

```ts
if (git.hasHistory()) git.log({ format: "%H" });
const r = git.try.log({ format: "%H" });
```

## Refs, remotes and history

```ts
git.resolveRef("refs/heads/main");  // sha, or null when the ref does not resolve
git.hasHistory();                   // resolveRef("HEAD") !== null
git.headRef();                      // "main", or the literal "HEAD" when detached
git.currentBranch();                // "main", or null when detached
git.remote();                       // ["origin", …]; [] when there are none
git.remoteGetUrl("origin");         // URL, or null — git exits 2 for an unknown remote
git.remoteAdd("origin", url);
```

`resolveRef` passes `--verify --quiet`, so a ref that does not resolve is
`null` and an unreadable store still throws. That is what makes `hasHistory()`
the repository-health probe and `objectExists("HEAD")` the wrong one.

`headRef` and `currentBranch` differ only on a detached HEAD: `headRef` prints
the literal `"HEAD"`, `currentBranch` answers `null`. Pick by what the caller
needs to print.

## The whole surface

Every method exists on both `Git` and `AsyncGit` with the same name and
arguments; the async one returns a promise. Each also mirrors onto
`git.try.*`, which returns `{ ok, value } | { ok, error }` instead of throwing.
Every method takes call options (`timeoutMs`, `env`, and `signal` on the async
side) as its last argument — except `revParse`, which is variadic.

### Queries

"Absence" is the exit code this verb declares as an answer. Any other non-zero
exit throws `CommandFailed`.

| Method | git | Absence → value |
| --- | --- | --- |
| `showAtRev(rev, path)` | `show <rev>:<path>` | `128` → `null` |
| `revParse(...args)` | `rev-parse <args>` | `1` → `null` — needs `--verify --quiet` |
| `resolveRef(ref)` | `rev-parse --verify --quiet <ref>` | `1` → `null` |
| `hasHistory()` | `resolveRef("HEAD") !== null` | — |
| `headRef()` | `rev-parse --abbrev-ref HEAD` | none — literal `"HEAD"` when detached |
| `topLevel()` | `rev-parse --show-toplevel` | `128` → `null` (not a repository) |
| `gitCommonDir()` | `rev-parse --path-format=absolute --git-common-dir` | `128` → `null` |
| `currentBranch()` | `branch --show-current` | none — `null` when detached |
| `statusPorcelain({ paths })` | `status --porcelain` | none |
| `isDirty({ paths })` | `statusPorcelain().length > 0` | none |
| `branches(pattern)` | `branch --list --format=%(refname:short)` | none |
| `branchExists(name)` | `branches(name).includes(name)` | none |
| `worktrees()` | `worktree list --porcelain` | none |
| `mergeBase(a, b)` | `merge-base <a> <b>` | `1` → `null` (unrelated histories) |
| `logSubject(ref)` | `log -1 --format=%s <ref>` | `128` → `null` |
| `configGet(key)` | `config --get <key>` | `1` → `null` (unset) |
| `objectExists(rev)` | `cat-file -e <rev>` | `1`, `128` → `false` — see the caveat below |
| `lsRemote(remote, pattern, { heads, tags })` | `ls-remote` | none |
| `checkIgnore(paths)` | `check-ignore --stdin -z` | `1` → empty set (none ignored) |
| `lsFiles({ cached, others, excludeStandard, paths })` | `ls-files -z` | none |
| `forEachRef(pattern, { format, sort, count })` | `for-each-ref` | none — lines verbatim |
| `refs(pattern)` | `forEachRef` + `parseRefRows` | none |
| `diffNameOnly({ cached, diffFilter, rangeArgs, paths })` | `diff --name-only -z` | none |
| `diffNameStatus({ cached, range, noRenames, paths })` | `diff --name-status -z` | none |
| `log(opts)` | `log` | none — raw stdout, unsplit |
| `logLines(opts)` | `log`, split and filtered | none |
| `lsTree(rev, { recursive, long, paths })` | `ls-tree -z` | none |
| `diffTree(rev, { root, noRenames, paths })` | `diff-tree --name-status -z` | none |
| `diffTreeNumstat(rev, opts)` | `diff-tree --numstat -z` | none |
| `grep(pattern, { extendedRegexp, lineNumber, noColor, paths })` | `grep` | `1` → `[]` (no match) |
| `isAncestor(a, b)` | `merge-base --is-ancestor` | `1` → `false` |
| `aheadBehind(base, tip)` | `rev-list --left-right --count <base>...<tip>` | none |
| `remote()` | `remote` | none |
| `remoteGetUrl(name)` | `remote get-url <name>` | `2` → `null` (unknown remote) |

`objectExists` declares both `1` and `128` absent, so `false` cannot tell an
empty repository from a dangling HEAD or a missing object store. Use
`hasHistory()` to ask whether a repository has history.

### Mutations

Every mutation declares no absence: a non-zero exit throws `CommandFailed`,
because the only sane handling of "the write did not happen" is to surface it.

| Method | git |
| --- | --- |
| `fetch(remote, refspec, { prune, quiet, noWriteFetchHead })` | `fetch` |
| `add(paths, { all, update })` | `add` |
| `commit({ message, body, messageFile, allowEmpty, amend, noVerify, signoff })` | `commit` |
| `push(remote, refspec, { forceWithLease })` | `push` — `forceWithLease` takes `true` or a pinned `<ref>:<sha>` |
| `configSet(key, value, { scope })` | `config` |
| `init(path, { bare, initialBranch, quiet })` | `init` |
| `resetHard(rev)` | `reset --hard` |
| `deleteBranch(name, { force })` | `branch -d` / `-D` |
| `worktreeAdd(path, { branch, startPoint, detach })` | `worktree add` |
| `worktreeRemove(path, { force })` | `worktree remove` |
| `worktreeMove(from, to, { force })` | `worktree move` |
| `worktreePrune()` | `worktree prune` |
| `remoteAdd(name, url)` | `remote add` |
| `checkout(ref, { branch, resetBranch, force })` | `checkout` — `resetBranch` picks `-B` |
| `checkoutSide(side, paths)` | `checkout --ours\|--theirs --` |
| `mergeAbort()` / `rebaseAbort()` | `merge --abort` / `rebase --abort` |

### Integration

Exit 1 is declared absence: a conflict is an answer. Every other non-zero exit
throws.

| Method | git | Returns |
| --- | --- | --- |
| `merge(ref, { noFf, noCommit, message })` | `merge --no-edit` | `MergeOutcome` |
| `rebase(onto, { autostash })` | `rebase` | `RebaseOutcome` |
| `rebaseContinue()` | `-c core.editor=true rebase --continue` | `RebaseOutcome` |
| `mergeTree(ours, theirs, { mergeBase })` | `merge-tree --write-tree --name-only -z` | `MergeTreeOutcome` |
| `lsFilesUnmerged()` | `ls-files -u -z` | `UnmergedEntry[]` — mode, sha, stage, path |

### Escape hatches and re-rooting

| Method | What |
| --- | --- |
| `raw(argv, opts)` | Run anything. Returns `CommandResult`; you read `exitCode`. |
| `rawChecked(argv, opts)` | Same, but throws `CommandFailed` on a non-zero exit. |
| `at(cwd)` | The same client rooted elsewhere, reusing the runner or backend. |
| `try.*` | The whole surface again, returning `GitOutcome<T>` instead of throwing. |

`raw` is the honest answer for a one-off — `update-ref`, `symbolic-ref`,
`tag -a`, a patch from `diff --unified`. A verb earns its place by having a
parser worth sharing or an absence worth declaring, not by existing.

## Driving the CLI, or something else

`AsyncGit` talks to a **`GitBackend`**, which takes a `GitRequest` — a plain,
serializable description of one operation — and returns its typed result.
Deliberately not argv: argv is a CLI detail, and a backend built on a
pure-JavaScript git has no argv to receive.

```ts
import { AsyncGit, cliBackend, partialBackend } from "@sksizer/easy-git";

// The default: every request becomes a `git` subprocess.
new AsyncGit(cwd, { backend: cliBackend() });

// Anything else: implement what you can, and say so about the rest.
const backend = partialBackend("in-memory", {
  currentBranch: async () => "main",
  branches: async () => ["main", "topic"],
});
await new AsyncGit(cwd, { backend }).branchExists("topic"); // true
await new AsyncGit(cwd, { backend }).worktrees();           // UnsupportedRequest
```

Because a request is data, it can also be logged, queued, or replayed. The one
request that cannot cross that line is `raw`, which is argv by definition.

## Injecting the subprocess seam

`Git` takes a `CommandRunner` and `cliBackend` takes an `AsyncCommandRunner`,
both from [`@sksizer/command-seam`](https://github.com/sksizer/command-seam).
That is the layer to replace when you want a real `git` but your own spawning
— a fake in tests, a supervised child, a timeout policy of your own.

```ts
const fake: CommandRunner = {
  run: (argv) => ({ exitCode: 0, stdout: replies[argv.join(" ")] ?? "", stderr: "" }),
};
new Git(cwd, { runner: fake });
```

The seam's exports are re-exported here, so wiring a runner or catching a
`CommandFailed` needs one import rather than two.

## Also: git references

`parseGitUrl` turns any git reference — https, ssh, scp-style, `owner/repo`
shorthand, `github:owner/repo` — into its host, user, and project, over
`hosted-git-info`. `gitSshUrl` builds the scp-style clone URL back out of it.
Returns `null` on anything that is not a known git host — a parse, not a git
invocation, so nothing here throws.

```ts
parseGitUrl("git@github.com:sksizer/easy-git-ts.git");
// { type: "github", domain: "github.com", user: "sksizer",
//   project: "easy-git-ts", committish: null }
```

`parseRepoRef` is the question a clone command asks: given anything a person
might paste — a clone URL, the page of a pull request or a file, a bare
`owner/repo` — which repository, and what does `git clone` take? It returns
the host, owner and repo, a clone URL, and any branch the input named. An
explicit `https://…` or `git@…:` input keeps its protocol; shorthand takes
the `protocol` argument (default `https`).

```ts
parseRepoRef("https://github.com/sksizer/easy-git-ts/pull/12");
// { host: "github.com", owner: "sksizer", repo: "easy-git-ts",
//   cloneUrl: "https://github.com/sksizer/easy-git-ts.git", committish: null }
parseRepoRef("sksizer/easy-git-ts", "ssh").cloneUrl;
// "git@github.com:sksizer/easy-git-ts.git"
```

## Subpath exports

`@sksizer/easy-git/client` is everything above except `parseGitUrl` /
`gitSshUrl`, and so without `hosted-git-info` on your module graph. It stays
in `dependencies` either way — a bundle saving, not an install one.

`@sksizer/easy-git/testing` builds throwaway repositories:

- `makeGitFixture({ dir?, parent?, prefix?, identity?, initialBranch?, bare? })`
  — one initialized repo.
- `makeOriginAndCheckout({ parent?, identity?, initialBranch?, files? })` — an
  origin plus a **clone** of it.
- `makeBareAndWorker({ remoteName?, parent?, identity?, initialBranch? })` — a
  bare store plus an **independently-inited** worker that names it as a remote.
  Not a clone: the worker starts with no history and no tracking, so its first
  push is a genuine publish into an empty store. That is the shape a control
  plane keeping its state in refs on a shared store needs, and a clone cannot
  stand in for it.

All of them pin an identity and the commit dates through the environment, so a
suite that asserts on a sha gets the same sha every run. The identity is bound
as the fixture client's **client-level `env`**, so every call through
`fixture.git` carries it — the suite's own calls included, not just the ones
the fixture makes. `IDENTITY` is exported, so a suite asserting on dates reads
the pinned values instead of re-declaring them. `fixture.commit(msg, files,
{ date, env })` overrides them for one commit.

Pass `parent` to put two related repos under one directory (and `dir` to name
one exactly) — the way to have a suite delete a single tree at the end, or
assert on relative paths between two repositories.

## Also: finding a checkout without git

`checkoutRoot(path)` finds the git checkout containing `path` by walking up
for a `.git` entry — a pure filesystem check, no git process. `path` may be a
file or a directory. Returns `null` rather than throwing when there is no
checkout, and does not distinguish a linked worktree (`.git` as a file) from a
main checkout (`.git` as a directory) — callers that need `git`'s own answer
(bare repos, `GIT_DIR` overrides) use `Git#topLevel()` instead.

```ts
import { checkoutRoot } from "@sksizer/easy-git";

checkoutRoot("/repo/src/deep/file.ts"); // "/repo"
checkoutRoot("/tmp/not-a-repo");        // null
```

## What is not here

Any control-plane protocol with its own conflict semantics — a lease service's
CAS ref primitives, say. That is not general git, and it does not belong in a
general git client.

## License

MIT
