/**
 * The verb table — every git invocation this library knows, as data.
 *
 * A {@link GitVerb} pairs the argv to run with the exit codes that mean
 * "absent" for that invocation and the function that reads the result.
 * Nothing here spawns anything, so the same definitions drive the synchronous
 * `Git` client and the asynchronous CLI backend. Adding a verb means adding it
 * here once.
 *
 * {@link gate} is the single place a git result becomes either a value or a
 * `CommandFailed`. Both clients call it, so they cannot disagree.
 */

import { CommandFailed, type CommandResult } from '@sksizer/command-seam'

/**
 * One git invocation: what to run, which exits are answers, and how to read
 * what came back.
 */
export interface GitVerb<T> {
  argv: string[]
  /** Written to the child's stdin when set. */
  input?: string | undefined
  /**
   * Exit codes that mean "asked and answered: not there" for this verb — not
   * "git failed". `config --get` exits 1 for an unset key, `cat-file -e` exits
   * 1 for a missing object. Those codes reach {@link GitVerb.parse}, which
   * turns them into the verb's absence value; any other non-zero exit throws.
   *
   * A mutation declares `[]`: nothing about a failed `push` is an answer. That
   * is the whole checked/unchecked distinction, so there is no `checked` flag
   * to contradict it.
   */
  absent: readonly number[]
  /**
   * `argv` is the invocation that produced `result` — the verb's own argv
   * behind whatever repository binding the client added. A parse that raises
   * its own {@link CommandFailed} must report that, not {@link GitVerb.argv},
   * so every failure names the command that ran.
   */
  parse(result: CommandResult, argv: string[]): T
}

/**
 * Turn one git result into a value or a `CommandFailed`.
 *
 * The exit-code throw site for the whole library, shared by both clients so
 * they cannot disagree. A parse can raise its own `CommandFailed` for output
 * it cannot read (`aheadBehind`, the integration verbs); it is handed the same
 * argv this reports. `CommandFailed` is reused rather than wrapped in a
 * git-specific class, so one `instanceof` matches failures from easy-git and
 * from any other command-seam caller; a caller that must tell which git call
 * failed reads `e.argv`.
 *
 * `argv` overrides what the error reports. Both clients pass the argv they
 * actually ran, so a failure from a repository-bound client names its store.
 *
 * A result the seam flagged `neverExited` — `git` missing from PATH, a
 * timeout kill, an abort — is a failure whatever the verb declares: its
 * `exitCode` is the seam's stand-in `1`, and 1 is the absence code of half
 * this table (`configGet`, `resolveRef`, `mergeBase`, `checkIgnore`,
 * `isAncestor`, `grep`, `revParse`). Read as an absence it would answer "no
 * such key / ref / match" for a git that never ran.
 */
export function gate<T>(verb: GitVerb<T>, result: CommandResult, argv?: string[]): T {
  if (result.neverExited || (result.exitCode !== 0 && !verb.absent.includes(result.exitCode))) {
    throw new CommandFailed(argv ?? verb.argv, result)
  }
  return verb.parse(result, argv ?? verb.argv)
}

/**
 * A client-level environment bag under a per-call one, or `undefined` when
 * neither is set (so the runner inherits the parent environment untouched
 * rather than being handed an empty object).
 *
 * Shared by `Git` and `cliBackend` so the precedence rule has one definition.
 */
export function mergeEnv(
  base: Record<string, string> | undefined,
  call: Record<string, string> | undefined,
): Record<string, string> | undefined {
  if (base === undefined) return call
  if (call === undefined) return base
  return { ...base, ...call }
}

/**
 * The `--git-dir=` / `--work-tree=` flags that bind an invocation to one
 * repository, or `[]` when neither is set. Shared by `Git` and `cliBackend`.
 */
export function repoPrefix(gitDir: string | undefined, workTree: string | undefined): string[] {
  const prefix: string[] = []
  if (gitDir !== undefined) prefix.push(`--git-dir=${gitDir}`)
  if (workTree !== undefined) prefix.push(`--work-tree=${workTree}`)
  return prefix
}

/** One row of `git worktree list --porcelain`. */
export interface Worktree {
  /** Absolute path of the worktree. */
  path: string
  /** HEAD sha, or null for an entry that reports none (a bare store). */
  head: string | null
  /** Checked-out branch shortname, or null when detached. */
  branch: string | null
  detached: boolean
  /**
   * The entry is a bare repository — git printed a literal `bare` line for it.
   *
   * Read from that line rather than inferred from `head === null`: an
   * unborn-HEAD checkout reports `HEAD 0000000000000000000000000000000000000000`,
   * and a prunable entry keeps the HEAD it had.
   */
  bare: boolean
}

/** One row of `git ls-remote`. */
export interface RemoteRef {
  sha: string
  ref: string
}

/** One row of a `--name-status` diff. */
export interface DiffEntry {
  /**
   * The status token, verbatim: `M`, `A`, `D`, and the similarity-scored
   * `R100` / `C085` a rename or copy carries. A caller that wants the letter
   * writes `status[0]`; a truncating library would lose the score for good.
   */
  status: string
  /**
   * The path the status is about. For a rename or copy, the destination —
   * where the file is now.
   */
  path: string
  /**
   * The source path of a rename or copy, and absent on every other status.
   *
   * An `R`/`C` record is three fields, so the source is there to report.
   * Present iff `status` starts with `R` or `C`.
   */
  from?: string
}

// ── parse helpers ───────────────────────────────────────────────────────────

// A parser only ever sees exit 0 or one of the verb's declared `absent` codes
// — the gate has already rejected everything else — so a non-zero exit here
// means absence, never failure.

/** Trimmed stdout, or null on a declared absence or an empty result. */
function trimmedOrNull(r: CommandResult): string | null {
  if (r.exitCode !== 0) return null
  const out = r.stdout.trim()
  return out === '' ? null : out
}

/** Non-blank lines of a command's stdout, verbatim. */
export function splitLines(out: string): string[] {
  return out.split('\n').filter((l) => l.trim() !== '')
}

/** Non-blank stdout lines, empty array on a declared absence. Verbatim. */
function lines(r: CommandResult): string[] {
  if (r.exitCode !== 0) return []
  return splitLines(r.stdout)
}

/** {@link lines}, with each line trimmed — for output that pads its values. */
function trimmedLines(r: CommandResult): string[] {
  return lines(r).map((l) => l.trim())
}

/**
 * NUL-separated fields, empties dropped — the parser for every `-z` verb.
 *
 * `-z` exists because git's default output quotes a path containing a space,
 * a quote or a non-ASCII byte (`"docs/a b.md"`), and a line-splitting caller
 * silently reads the quotes as part of the name. NUL has no such escape, so
 * this is the only split that is right for paths.
 */
function nulFields(r: CommandResult): string[] {
  return r.stdout.split('\x00').filter((f) => f !== '')
}

/**
 * `--name-status -z` records into {@link DiffEntry} rows.
 *
 * A plain record is two fields — `M \0 path` — but a rename or copy is three:
 * `R100 \0 oldPath \0 newPath`. A parser that pairs fields two at a time
 * desynchronizes on the first rename and mislabels every record after it.
 * Shared with `diffTree`, which emits the same records.
 */
function nameStatusEntries(r: CommandResult): DiffEntry[] {
  const fields = nulFields(r)
  const out: DiffEntry[] = []
  for (let i = 0; i < fields.length;) {
    const status = fields[i]!
    // R/C carry a similarity score and both paths; the destination is at +2.
    const renamed = status.startsWith('R') || status.startsWith('C')
    const path = fields[i + (renamed ? 2 : 1)]
    if (path === undefined) break // truncated trailing record: no path to report
    // `from` is set only for R/C, so a plain record deep-equals `{status, path}`.
    out.push(renamed ? { status, path, from: fields[i + 1]! } : { status, path })
    i += renamed ? 3 : 2
  }
  return out
}

/** A mutation's result carries no value. */
function nothing(): void {}

/** No exit code is an answer here — the gate throws on any non-zero exit. */
const NONE: readonly number[] = []

// ── queries ─────────────────────────────────────────────────────────────────

/**
 * A file's content at a rev (`git show <rev>:<relPath>`), null if absent.
 *
 * `absent: [128]` is as sharp as git allows: it spells both "no such path in
 * that tree" and "not a repository" as 128, so this verb cannot separate
 * absence from breakage.
 */
export function showAtRev(rev: string, relPath: string): GitVerb<string | null> {
  return {
    argv: ['show', `${rev}:${relPath}`],
    absent: [128],
    // NOT trimmedOrNull: file content is returned verbatim, trailing newline
    // included, because a caller round-tripping a blob must get its bytes.
    parse: (r) => (r.exitCode === 0 ? r.stdout : null),
  }
}

/**
 * Trimmed `git rev-parse <args>` output — the general escape hatch, for a
 * query no dedicated verb covers.
 *
 * `absent: [1]`, the code `rev-parse --verify --quiet <ref>` returns for a ref
 * that does not resolve. {@link resolveRef} passes those flags for you; reach
 * for it rather than spelling them here.
 *
 * `absent: [1]` is about refs. For a non-ref query — `--is-inside-work-tree`,
 * `--show-toplevel`, `--git-common-dir` — git exits 128 outside a repository
 * and this throws rather than answering `null`. Use `git.try.revParse(...)`
 * with an explicit `!ok` branch, or {@link topLevel} / {@link gitCommonDir},
 * for which "not a repository" is the answer.
 */
export function revParse(...args: string[]): GitVerb<string | null> {
  return { argv: ['rev-parse', ...args], absent: [1], parse: trimmedOrNull }
}

/**
 * The sha `ref` resolves to (`rev-parse --verify --quiet`), or null when it
 * does not resolve.
 *
 * `absent: [1]` — an unborn HEAD, a branch that does not exist, a tag that was
 * never fetched. An unreadable store exits 128 and throws, so absence stays
 * separable from breakage. That is what makes `resolveRef("HEAD")` the
 * repository-health probe — see {@link objectExists}, which is not.
 */
export function resolveRef(ref: string): GitVerb<string | null> {
  return {
    argv: ['rev-parse', '--verify', '--quiet', ref],
    absent: [1],
    parse: trimmedOrNull,
  }
}

/**
 * HEAD's shortname (`rev-parse --abbrev-ref HEAD`).
 *
 * Reports the literal string `"HEAD"` on a detached HEAD, where
 * {@link currentBranch} reports `null`. Pick by what the caller wants to
 * print: a name that is always a string, or a branch or nothing.
 *
 * `absent: []` — an unborn HEAD exits 128, as does a non-repository, so both
 * throw.
 */
export function headRef(): GitVerb<string | null> {
  return {
    argv: ['rev-parse', '--abbrev-ref', 'HEAD'],
    absent: NONE,
    parse: trimmedOrNull,
  }
}

/**
 * Absolute repo top-level directory, or null outside a repo.
 *
 * `absent: [128]`: for this question "not a repository" is a genuine answer,
 * so `if (!git.topLevel())` is the idiomatic "am I in a repo?" check. Most
 * other verbs throw there — see {@link lsFiles}.
 */
export function topLevel(): GitVerb<string | null> {
  return { argv: ['rev-parse', '--show-toplevel'], absent: [128], parse: trimmedOrNull }
}

/**
 * The shared `.git` dir (worktree-aware) as an absolute path, or null outside
 * a repo.
 *
 * `--path-format=absolute` is passed for you: bare `--git-common-dir` answers
 * relative to the cwd — literally `.git` from a primary checkout — which a
 * caller then has to re-anchor.
 *
 * "Not a repository" is an answer here (`absent: [128]`); a variadic
 * `revParse("--git-common-dir")` throws there. Reach for this verb.
 */
export function gitCommonDir(): GitVerb<string | null> {
  return {
    argv: ['rev-parse', '--path-format=absolute', '--git-common-dir'],
    absent: [128],
    parse: trimmedOrNull,
  }
}

/**
 * What a symbolic ref points at, short form, or null when it is not one.
 *
 * `absent: [128]` because "not a symbolic ref" is the common, meaningful
 * answer, not a failure: `refs/remotes/<remote>/HEAD` is unset in any clone
 * made before the remote had a default branch, and in every repository whose
 * remote HEAD was never fetched. A caller asking for a default branch handles
 * the null by probing instead.
 *
 * The value is the full refname (`refs/remotes/origin/main`); the caller takes
 * the last segment when it wants the branch shortname.
 */
export function symbolicRef(ref: string): GitVerb<string | null> {
  return { argv: ['symbolic-ref', ref], absent: [128], parse: trimmedOrNull }
}

/**
 * Current branch shortname, or null when detached.
 *
 * `absent: []` — a detached HEAD and an empty repo both exit 0 with empty
 * stdout, so absence never needs an exit code here. Outside a repo git exits
 * 128, which throws. {@link headRef} is the variant that prints `"HEAD"` when
 * detached instead of answering `null`.
 */
export function currentBranch(): GitVerb<string | null> {
  return { argv: ['branch', '--show-current'], absent: NONE, parse: trimmedOrNull }
}

/**
 * `git status --porcelain` lines; empty array on a clean tree, and a throw
 * outside a repository (exit 128).
 *
 * Verbatim: the first two columns are the status, so ` M f.ts` (unstaged
 * modification) must not be trimmed down to `M f.ts` (staged one).
 */
export interface StatusPorcelainOptions {
  /**
   * Pathspecs, passed after `--`. Narrows the report to one subtree.
   */
  paths?: string[] | undefined
}

/** `git status --porcelain` lines. See {@link StatusPorcelainOptions}. */
export function statusPorcelain(opts: StatusPorcelainOptions = {}): GitVerb<string[]> {
  const argv = ['status', '--porcelain']
  if (opts.paths !== undefined && opts.paths.length > 0) argv.push('--', ...opts.paths)
  return { argv, absent: NONE, parse: lines }
}

/** Local branch shortnames matching `pattern` (all when omitted). */
export function branches(pattern?: string | undefined): GitVerb<string[]> {
  const argv = ['branch', '--list', '--format=%(refname:short)']
  if (pattern !== undefined) argv.push(pattern)
  return { argv, absent: NONE, parse: trimmedLines }
}

/** `git worktree list --porcelain`, parsed. Throws outside a repository. */
export function worktrees(): GitVerb<Worktree[]> {
  return {
    argv: ['worktree', 'list', '--porcelain'],
    absent: NONE,
    parse(r) {
      const out: Worktree[] = []
      let cur: Partial<Worktree> | null = null
      const flush = () => {
        if (cur?.path !== undefined) {
          out.push({
            path: cur.path,
            head: cur.head ?? null,
            branch: cur.branch ?? null,
            detached: cur.detached ?? false,
            bare: cur.bare ?? false,
          })
        }
      }
      for (const line of r.stdout.split('\n')) {
        if (line.startsWith('worktree ')) {
          flush()
          cur = { path: line.slice('worktree '.length) }
        } else if (cur !== null && line.startsWith('HEAD ')) {
          cur.head = line.slice('HEAD '.length)
        } else if (cur !== null && line.startsWith('branch ')) {
          cur.branch = line.slice('branch '.length).replace(/^refs\/heads\//, '')
        } else if (cur !== null && line === 'detached') {
          cur.detached = true
        } else if (cur !== null && line === 'bare') {
          cur.bare = true
        }
      }
      flush()
      return out
    },
  }
}

/**
 * Merge base of two revs, or null when the two histories are unrelated
 * (exit 1). A rev that does not resolve exits 128 and throws.
 */
export function mergeBase(a: string, b: string): GitVerb<string | null> {
  return { argv: ['merge-base', a, b], absent: [1], parse: trimmedOrNull }
}

/**
 * Subject line of a ref's HEAD commit (`log -1 --format=%s`), or null.
 *
 * `absent: [128]`, which git also uses for a broken repository — the same
 * overload as {@link showAtRev}. A caller that must tell an empty history from
 * a broken one probes {@link resolveRef} with `HEAD` first.
 */
export function logSubject(ref: string): GitVerb<string | null> {
  return {
    argv: ['log', '-1', '--format=%s', ref],
    absent: [128],
    parse(r) {
      if (r.exitCode !== 0) return null
      // Only trailing newlines: a subject's own leading whitespace is content.
      const out = r.stdout.replace(/\n+$/, '')
      return out === '' ? null : out
    },
  }
}

/** `git config --get <key>`, or null when unset (exit 1). */
export function configGet(key: string): GitVerb<string | null> {
  return { argv: ['config', '--get', key], absent: [1], parse: trimmedOrNull }
}

/**
 * True iff `rev` resolves to an object (`cat-file -e`).
 *
 * A predicate, so both of git's "no" codes are absence: 1 for a well-formed
 * name with no object behind it, 128 for a name it cannot even parse.
 *
 * That breadth is what makes it a predicate, and also what disqualifies it as
 * a repository-health probe. `false` here does not mean "no history": measured
 * against real stores, `cat-file -e HEAD` exits 128 on an empty repository, 1
 * on a dangling HEAD ref, and 128 again with the object directory removed — so
 * `objectExists("HEAD")` answers `false` for all three and folds a corrupt
 * store into "nothing here yet". Ask "does this repo have history?" with
 * `hasHistory()` ({@link resolveRef} on `HEAD`), which is `false` only for the
 * unborn case and throws when the store is unreadable.
 */
export function objectExists(rev: string): GitVerb<boolean> {
  return {
    argv: ['cat-file', '-e', rev],
    absent: [1, 128],
    parse: (r) => r.exitCode === 0,
  }
}

/**
 * `ls-remote` rows for a remote (optionally pattern- and kind-filtered).
 *
 * `absent: []` — a remote with no matching refs answers with exit 0 and no
 * output, so `[]` means "no refs". An unreachable remote exits 128 and throws.
 */
export interface LsRemoteOptions {
  /** `--heads` — branches only. */
  heads?: boolean | undefined
  /** `--tags` — tags only. Set with `heads` to ask for both. */
  tags?: boolean | undefined
}

/** Refs on a remote, optionally pattern-filtered. See {@link LsRemoteOptions}. */
export function lsRemote(
  remote: string,
  pattern?: string | undefined,
  opts: LsRemoteOptions = {},
): GitVerb<RemoteRef[]> {
  const argv = ['ls-remote']
  if (opts.heads) argv.push('--heads')
  if (opts.tags) argv.push('--tags')
  argv.push(remote)
  if (pattern !== undefined) argv.push(pattern)
  return {
    argv,
    absent: NONE,
    // Same sha-TAB-ref rows `for-each-ref` prints, so the same parser.
    parse: (r) => parseRefRows(splitLines(r.stdout)),
  }
}

/**
 * The subset of `relPaths` that .gitignore rules ignore
 * (`check-ignore --stdin -z`, NUL-delimited through the seam's `input`).
 *
 * `absent: [1]` — "none of these paths are ignored". Outside a repository git
 * exits 128 and this throws, so a caller cannot mistake "could not ask" for
 * "nothing is ignored".
 *
 * A fail-closed caller — a guard deciding whether a path may be read or
 * published — must use `git.try.checkIgnore` with an explicit `!ok` branch
 * that refuses. It must neither let the `CommandFailed` escape nor read it as
 * "not ignored":
 *
 * ```ts
 * const got = git.try.checkIgnore(paths);
 * if (!got.ok) return denyEverything(got.error); // could not ask ⇒ refuse
 * ```
 */
export function checkIgnore(relPaths: string[]): GitVerb<Set<string>> {
  return {
    argv: ['check-ignore', '--stdin', '-z'],
    input: relPaths.join('\x00') + '\x00',
    absent: [1],
    parse: (r) => new Set(r.stdout.split('\x00').filter((c) => c !== '')),
  }
}

/** Options for {@link lsFiles}. */
export interface LsFilesOptions {
  /** `--cached` — files in the index. */
  cached?: boolean | undefined
  /** `--others` — files git is not tracking. */
  others?: boolean | undefined
  /** `--exclude-standard` — apply .gitignore and friends. */
  excludeStandard?: boolean | undefined
  /** Pathspecs, passed after `--`. */
  paths?: string[] | undefined
}

/**
 * Tracked and/or untracked file paths (`git ls-files -z`).
 *
 * `absent: []` — no matching files is exit 0 with empty stdout, so `[]` means
 * "none". Outside a repository git exits 128 and this throws: a guard that
 * cannot read the index has not "found zero files to check".
 *
 * Note the asymmetry with {@link topLevel}, which guards commonly call on the
 * adjacent line: `topLevel()` returns null outside a repository and this verb
 * throws there. Both are correct — "not a repository" answers "where is the
 * root?" but not "which files are here?" — but a reader who assumes the two
 * behave alike writes `if (!git.topLevel()) return; git.lsFiles()` and is not
 * protected. Only a `try` / catch is.
 */
export function lsFiles(opts: LsFilesOptions = {}): GitVerb<string[]> {
  const argv = ['ls-files', '-z']
  if (opts.cached) argv.push('--cached')
  if (opts.others) argv.push('--others')
  if (opts.excludeStandard) argv.push('--exclude-standard')
  if (opts.paths !== undefined && opts.paths.length > 0) argv.push('--', ...opts.paths)
  return { argv, absent: NONE, parse: nulFields }
}

/** Options for {@link forEachRef}. */
export interface ForEachRefOptions {
  /** `--format=` value; defaults to `%(objectname)%09%(refname)`. */
  format?: string | undefined
  /** `--sort=` key, e.g. `-committerdate`. */
  sort?: string | undefined
  /** `--count=` cap on the rows returned. */
  count?: number | undefined
}

/** The `forEachRef` format {@link refs} parses: sha, TAB, full refname. */
export const REF_FORMAT = '%(objectname)%09%(refname)'

/**
 * `git for-each-ref` rows, one per line, verbatim.
 *
 * `absent: []` — a pattern matching nothing is exit 0 with empty stdout, so
 * `[]` means "no such refs". Outside a repository, and for an unknown format
 * or sort field, git exits 128 and this throws.
 *
 * Lines rather than parsed rows because the format is the caller's: the
 * default gives sha-TAB-refname, which {@link parseRefRows} splits.
 */
export function forEachRef(
  pattern: string | string[],
  opts: ForEachRefOptions = {},
): GitVerb<string[]> {
  const argv = ['for-each-ref', `--format=${opts.format ?? REF_FORMAT}`]
  if (opts.sort !== undefined) argv.push(`--sort=${opts.sort}`)
  if (opts.count !== undefined) argv.push(`--count=${opts.count}`)
  argv.push(...(typeof pattern === 'string' ? [pattern] : pattern))
  return { argv, absent: NONE, parse: lines }
}

/**
 * {@link forEachRef} rows in the default format, split into `{ sha, ref }`.
 *
 * Split at the first tab: a refname cannot contain one, but a caller-chosen
 * format could, and splitting on every tab would silently truncate.
 */
export function parseRefRows(rows: string[]): RemoteRef[] {
  const out: RemoteRef[] = []
  for (const row of rows) {
    const tab = row.indexOf('\t')
    if (tab <= 0) continue
    out.push({ sha: row.slice(0, tab), ref: row.slice(tab + 1) })
  }
  return out
}

/** Options for {@link diffNameOnly}. */
export interface DiffNameOnlyOptions {
  /** `--cached` — diff the index against HEAD rather than the worktree. */
  cached?: boolean | undefined
  /** `--diff-filter=` selector, e.g. `ACMR`. */
  diffFilter?: string | undefined
  /**
   * The diff range, as argv tokens rather than one string: the two-dot form is
   * two tokens (`[base, "HEAD"]`) and the three-dot form is one
   * (`["base...HEAD"]`), and callers need both spellings. Named `rangeArgs` to
   * keep `range` meaning a single token everywhere else.
   */
  rangeArgs?: string[] | undefined
  /** Pathspecs, passed after `--`. */
  paths?: string[] | undefined
}

/**
 * Changed paths (`git diff --name-only -z`).
 *
 * `absent: []` — no changes is exit 0 with empty stdout, because this verb
 * never passes `--exit-code`. Outside a repository `git diff` exits **129**
 * (a usage error, not the 128 most git commands give); undeclared either way,
 * so it throws.
 */
export function diffNameOnly(opts: DiffNameOnlyOptions = {}): GitVerb<string[]> {
  const argv = ['diff', '--name-only', '-z']
  if (opts.cached) argv.push('--cached')
  if (opts.diffFilter !== undefined) argv.push(`--diff-filter=${opts.diffFilter}`)
  if (opts.rangeArgs !== undefined) argv.push(...opts.rangeArgs)
  if (opts.paths !== undefined && opts.paths.length > 0) argv.push('--', ...opts.paths)
  return { argv, absent: NONE, parse: nulFields }
}

/** Options for {@link diffNameStatus}. */
export interface DiffNameStatusOptions {
  /** `--cached` — diff the index against HEAD rather than the worktree. */
  cached?: boolean | undefined
  /** The diff range as a single token, e.g. `origin/main..HEAD`. */
  range?: string | undefined
  /** `--no-renames` — report a rename as a delete plus an add. */
  noRenames?: boolean | undefined
  /** Pathspecs, passed after `--`. */
  paths?: string[] | undefined
}

/**
 * Changed paths with their status (`git diff --name-status -z`).
 *
 * `absent: []` — no changes is exit 0 with empty stdout, including before the
 * first commit, where `--cached` diffs against the empty tree. Outside a
 * repository `git diff` exits 129 and this throws.
 *
 * See {@link DiffEntry} for what a rename record costs a naive parser.
 */
export function diffNameStatus(opts: DiffNameStatusOptions = {}): GitVerb<DiffEntry[]> {
  const argv = ['diff', '--name-status', '-z']
  if (opts.cached) argv.push('--cached')
  if (opts.noRenames) argv.push('--no-renames')
  if (opts.range !== undefined) argv.push(opts.range)
  if (opts.paths !== undefined && opts.paths.length > 0) argv.push('--', ...opts.paths)
  return { argv, absent: NONE, parse: nameStatusEntries }
}

/** Options for {@link log}. */
export interface LogOptions {
  /** A single starting rev. */
  rev?: string | undefined
  /** A range expression as one token, e.g. `origin/main..HEAD`. */
  range?: string | undefined
  /**
   * The `--format=` value, caller-chosen and passed through verbatim.
   *
   * git reads a placeholder string as `tformat:`, which terminates each
   * record with a newline; pass `"format:%H…"` explicitly for the older
   * separator semantics, which a caller framing its own records with `%x1e`
   * usually wants.
   */
  format?: string | undefined
  /** `--max-count=`. */
  maxCount?: number | undefined
  /** `--no-merges`. */
  noMerges?: boolean | undefined
  /** `--reverse` — oldest first. */
  reverse?: boolean | undefined
  /** `--no-renames` — no rename detection in `nameStatus` / `numstat` output. */
  noRenames?: boolean | undefined
  /** `--name-status` — append each commit's changed paths and statuses. */
  nameStatus?: boolean | undefined
  /** `--numstat` — append each commit's per-file added/deleted line counts. */
  numstat?: boolean | undefined
  /** `--relative` — report paths relative to the client's cwd. */
  relative?: boolean | undefined
  /** Revs to exclude, emitted after `--not` (so after the positive revs). */
  notRefs?: string[] | undefined
  /** Pathspecs, passed after `--`. */
  paths?: string[] | undefined
}

/**
 * `git log`, as raw stdout.
 *
 * Callers choose their own `--format`, and several frame their own records
 * with `%x1e` / `%x1f` separators or interleave `--name-status` blocks — so
 * the library returns the bytes and does not split them. A caller that wants
 * lines uses the client's `logLines`.
 *
 * `absent: []`, deliberately. An empty repository exits 128 — the same code a
 * corrupt one gives, and the same code as a rev that does not resolve — so
 * declaring 128 absent would hand back `""` for a broken store. A caller that
 * must tolerate an empty history probes `hasHistory()` first (not
 * `objectExists("HEAD")` — see {@link objectExists}), or uses `git.try.log()`.
 *
 * {@link logSubject} is the fixed-format convenience for the one question that
 * needs no format.
 */
export function log(opts: LogOptions = {}): GitVerb<string> {
  const argv = ['log']
  if (opts.format !== undefined) argv.push(`--format=${opts.format}`)
  if (opts.maxCount !== undefined) argv.push(`--max-count=${opts.maxCount}`)
  if (opts.noMerges) argv.push('--no-merges')
  if (opts.reverse) argv.push('--reverse')
  if (opts.noRenames) argv.push('--no-renames')
  if (opts.nameStatus) argv.push('--name-status')
  if (opts.numstat) argv.push('--numstat')
  if (opts.relative) argv.push('--relative')
  if (opts.rev !== undefined) argv.push(opts.rev)
  if (opts.range !== undefined) argv.push(opts.range)
  // `--not` negates every rev after it, so the positive revs must precede it.
  if (opts.notRefs !== undefined && opts.notRefs.length > 0) {
    argv.push('--not', ...opts.notRefs)
  }
  if (opts.paths !== undefined && opts.paths.length > 0) argv.push('--', ...opts.paths)
  // Verbatim, trailing newline included: the caller's format decides where a
  // record ends, and trimming would eat the terminator it relies on.
  return { argv, absent: NONE, parse: (r) => r.stdout }
}

/** One row of `git ls-tree`. */
export interface TreeEntry {
  /** The six-digit mode, verbatim: `100644`, `100755`, `040000`, `160000`. */
  mode: string
  type: 'blob' | 'tree' | 'commit'
  sha: string
  /**
   * Blob size in bytes — set only under `long`, and only for a blob. `--long`
   * prints `-` for a tree or submodule, which reads back as `null` rather than
   * a fabricated zero.
   */
  sizeBytes: number | null
  path: string
}

/** Options for {@link lsTree}. */
export interface LsTreeOptions {
  /** `-r` — descend into subtrees, so only blobs come back. */
  recursive?: boolean | undefined
  /** `--long` — include each blob's size. */
  long?: boolean | undefined
  /** Pathspecs, passed after `--`. */
  paths?: string[] | undefined
}

/**
 * The entries of a tree at a rev (`git ls-tree -z`).
 *
 * `absent: []` — a pathspec matching nothing is exit 0 with empty stdout, so
 * `[]` means "no such entries"; a rev that does not resolve exits 128 and
 * throws, so an unreadable rev cannot read as "the tree is empty".
 */
export function lsTree(rev: string, opts: LsTreeOptions = {}): GitVerb<TreeEntry[]> {
  const argv = ['ls-tree', '-z']
  if (opts.recursive) argv.push('-r')
  if (opts.long) argv.push('--long')
  argv.push(rev)
  if (opts.paths !== undefined && opts.paths.length > 0) argv.push('--', ...opts.paths)
  return {
    argv,
    absent: NONE,
    parse(r) {
      const out: TreeEntry[] = []
      for (const record of nulFields(r)) {
        // `<mode> <type> <sha>[ <size>]\t<path>` — the TAB is the only
        // separator that cannot appear in the metadata half, and a path may
        // contain spaces, so split there first and never on whitespace alone.
        const tab = record.indexOf('\t')
        if (tab < 0) continue
        const meta = record
          .slice(0, tab)
          .split(/\s+/)
          .filter((f) => f !== '')
        const [mode, type, sha, size] = meta
        if (mode === undefined || type === undefined || sha === undefined) continue
        out.push({
          mode,
          type: type as TreeEntry['type'],
          sha,
          // `--long` writes `-` where a size makes no sense (tree, submodule).
          sizeBytes: size === undefined || size === '-' ? null : Number(size),
          path: record.slice(tab + 1),
        })
      }
      return out
    },
  }
}

/** Options for {@link diffTree}. */
export interface DiffTreeOptions {
  /**
   * `--root` — report a root commit's contents as adds rather than nothing.
   *
   * Without it `diff-tree` on the first commit exits 0 with empty output,
   * because a root commit has no parent to diff against. A caller walking a
   * whole history and not passing this silently loses the first commit.
   */
  root?: boolean | undefined
  /** `--no-renames` — report a rename as a delete plus an add. */
  noRenames?: boolean | undefined
  /** Pathspecs, passed after `--`. */
  paths?: string[] | undefined
}

/**
 * The unified diff text itself, for the same rev/staged shape
 * {@link diffNameOnly} selects paths for. Empty string on failure or when
 * nothing differs.
 */
export function diffText(
  rev?: string | undefined,
  opts: { staged?: boolean | undefined; paths?: string[] | undefined } = {},
): GitVerb<string> {
  const argv = ['diff']
  if (opts.staged === true) argv.push('--cached')
  if (rev !== undefined) argv.push(rev)
  if (opts.paths !== undefined && opts.paths.length > 0) argv.push('--', ...opts.paths)
  // Any non-zero exit is reported as "no diff" rather than thrown: a bad rev
  // (128) and being outside a repository (129) both mean there is nothing to
  // judge, which is what the caller acts on either way.
  return { argv, absent: [1, 128, 129], parse: (r) => (r.exitCode === 0 ? r.stdout : '') }
}

/**
 * One untracked file rendered as an all-added diff
 * (`diff --no-index -- /dev/null <path>`), so a new file reaches a consumer in
 * the same shape as a modified one. Empty string when unreadable.
 *
 * `--no-index` exits 1 whenever the inputs differ, which for a real file is
 * always — so a non-zero exit here is the success case, and only empty output
 * means failure.
 */
export function diffAddedFile(relPath: string): GitVerb<string> {
  return {
    argv: ['diff', '--no-index', '--', '/dev/null', relPath],
    // 1 is the SUCCESS case here — `--no-index` returns it whenever the inputs
    // differ, which for a real file is always. 2 is its usage/read error, and
    // yields the empty stdout the parser already treats as failure.
    absent: [1, 2],
    parse: (r) => r.stdout,
  }
}

// ── mutations (checked — the caller throws CommandFailed on non-zero) ────────

/**
 * The paths and statuses one commit changed (`git diff-tree --name-status -z`).
 *
 * `diffNameStatus` for a commit rather than the worktree or index, sharing
 * that verb's parser and its {@link DiffEntry} rows. `--no-commit-id` keeps
 * the sha out of the records.
 *
 * `absent: []` — a rev that does not resolve exits 128 and throws.
 *
 * For per-file line counts use {@link diffTreeNumstat}: git rejects
 * `--numstat` together with `--name-status` (exit 129), so the two shapes are
 * two verbs.
 */
export function diffTree(rev: string, opts: DiffTreeOptions = {}): GitVerb<DiffEntry[]> {
  const argv = ['diff-tree', '-r', '--no-commit-id']
  if (opts.root) argv.push('--root')
  if (opts.noRenames) argv.push('--no-renames')
  argv.push('--name-status', '-z', rev)
  if (opts.paths !== undefined && opts.paths.length > 0) argv.push('--', ...opts.paths)
  return { argv, absent: NONE, parse: nameStatusEntries }
}

/** One row of a `--numstat` diff. */
export interface NumstatEntry {
  path: string
  /** Added lines, or null for a binary file, where git prints `-`. */
  linesAdded: number | null
  /** Deleted lines, or null for a binary file. */
  linesDeleted: number | null
}

/**
 * Per-file line counts for one commit (`git diff-tree --numstat -z`).
 *
 * The counting twin of {@link diffTree}, with the same options. A binary file
 * has no line counts: git prints `-` for both, which reads back as `null`.
 *
 * `absent: []` — a rev that does not resolve exits 128 and throws.
 */
export function diffTreeNumstat(rev: string, opts: DiffTreeOptions = {}): GitVerb<NumstatEntry[]> {
  const argv = ['diff-tree', '-r', '--no-commit-id']
  if (opts.root) argv.push('--root')
  if (opts.noRenames) argv.push('--no-renames')
  argv.push('--numstat', '-z', rev)
  if (opts.paths !== undefined && opts.paths.length > 0) argv.push('--', ...opts.paths)
  return {
    argv,
    absent: NONE,
    parse(r) {
      const out: NumstatEntry[] = []
      for (const record of nulFields(r)) {
        // `<added>\t<deleted>\t<path>`: only the first two tabs separate, and
        // the rest of the record is the path — raw bytes, tabs included,
        // because `-z` turns off git's quoting. Splitting on every tab would
        // truncate a path that contains one.
        const firstTab = record.indexOf('\t')
        const secondTab = firstTab < 0 ? -1 : record.indexOf('\t', firstTab + 1)
        if (secondTab < 0) continue
        const added = record.slice(0, firstTab)
        const deleted = record.slice(firstTab + 1, secondTab)
        out.push({
          path: record.slice(secondTab + 1),
          linesAdded: added === '-' ? null : Number(added),
          linesDeleted: deleted === '-' ? null : Number(deleted),
        })
      }
      return out
    },
  }
}

/** Options for {@link grep}. */
export interface GrepOptions {
  /** `-E` — extended POSIX regular expressions. */
  extendedRegexp?: boolean | undefined
  /** `-n` — prefix each hit with its line number. */
  lineNumber?: boolean | undefined
  /** `--no-color` — never emit SGR escapes, whatever the config says. */
  noColor?: boolean | undefined
  /** Pathspecs, passed after `--`. */
  paths?: string[] | undefined
}

/**
 * Matching lines from the working tree (`git grep`), verbatim.
 *
 * `absent: [1]`: `git grep` exits 1 for "no matches", a legitimate answer. A
 * real failure is 128 (not a repository, an unbalanced regex) or 129 (a usage
 * error), and those throw.
 *
 * The one dull edge: a pathspec that matches no file also exits 1, so a typo'd
 * path reads as "no matches" rather than as an error. git gives us nothing to
 * separate the two.
 *
 * Lines, not `-z`: the output is `path:line:text`, not a path listing, and `-z`
 * only changes the separator after the path — a caller still has to split the
 * record, and would then have to do it two different ways.
 */
export function grep(pattern: string, opts: GrepOptions = {}): GitVerb<string[]> {
  const argv = ['grep']
  if (opts.lineNumber) argv.push('-n')
  if (opts.extendedRegexp) argv.push('-E')
  if (opts.noColor) argv.push('--no-color')
  argv.push(pattern)
  if (opts.paths !== undefined && opts.paths.length > 0) argv.push('--', ...opts.paths)
  return { argv, absent: [1], parse: lines }
}

/**
 * True iff `a` is an ancestor of `b` (`git merge-base --is-ancestor`).
 *
 * A boolean carried entirely by the exit code. `absent: [1]` — measured: `b`
 * reachable from `a` → 0; a genuine "no", diverged or unrelated alike → 1; a
 * rev that does not resolve → **128, which throws**. A typo'd rev must never
 * read as "not an ancestor", because that answer is usually the one that lets
 * a caller delete something.
 */
export function isAncestor(a: string, b: string): GitVerb<boolean> {
  return {
    argv: ['merge-base', '--is-ancestor', a, b],
    absent: [1],
    parse: (r) => r.exitCode === 0,
  }
}

/** Commits each side of a fork point has that the other does not. */
export interface AheadBehind {
  /** Commits on `tip` that are not on `base`. */
  ahead: number
  /** Commits on `base` that are not on `tip`. */
  behind: number
}

/**
 * How far `tip` has diverged from `base`
 * (`git rev-list --left-right --count base...tip`).
 *
 * The verb owns the field order: git prints the left count first, and left is
 * `base` — so the first number is *behind*, not ahead.
 *
 * `absent: []` — unrelated histories are still a counted answer (exit 0); a
 * rev that does not resolve exits 128 and throws.
 */
export function aheadBehind(base: string, tip: string): GitVerb<AheadBehind> {
  const argv = ['rev-list', '--left-right', '--count', `${base}...${tip}`]
  return {
    argv,
    absent: NONE,
    parse(r, ranArgv) {
      const m = /^(\d+)\s+(\d+)/.exec(r.stdout)
      // Exit 0 with output we cannot read is not an answer; reporting it as
      // 0/0 would be indistinguishable from "in sync", the one state a caller
      // acts on.
      if (m === null) throw new CommandFailed(ranArgv, r)
      return { behind: Number(m[1]), ahead: Number(m[2]) }
    },
  }
}

/**
 * Configured remote names (`git remote`).
 *
 * `absent: []` — a repository with no remotes is exit 0 with empty stdout.
 * Outside a repository git exits 128 and this throws.
 */
export function remote(): GitVerb<string[]> {
  return { argv: ['remote'], absent: NONE, parse: trimmedLines }
}

/**
 * A remote's fetch URL (`git remote get-url <name>`), or null when no remote
 * by that name is configured.
 *
 * `absent: [2]` — measured: git reports an unknown remote as exit 2, not 1 or
 * 128. Outside a repository it exits 128 and this throws.
 */
export function remoteGetUrl(name: string): GitVerb<string | null> {
  return { argv: ['remote', 'get-url', name], absent: [2], parse: trimmedOrNull }
}

// ── mutations (absent: [] — any non-zero exit throws CommandFailed) ──────────

/** Options for {@link fetch}. */
export interface FetchOptions {
  /** `--prune` — drop remote-tracking refs the remote no longer has. */
  prune?: boolean | undefined
  /** `--quiet` — suppress the progress report on stderr. */
  quiet?: boolean | undefined
  /**
   * `--no-write-fetch-head` — do not touch `.git/FETCH_HEAD`.
   *
   * The flag a fetch running beside other work wants: FETCH_HEAD is one file
   * per repository, so two concurrent fetches in the same store race over it
   * and a caller that only wanted refs updated gets a corrupted one.
   */
  noWriteFetchHead?: boolean | undefined
}

/**
 * `git fetch <remote> [refspec…]`.
 *
 * `absent: []` — nothing about a failed fetch is an answer. A caller that
 * tolerates an unreachable remote uses `git.try.fetch(…)`.
 *
 * `refspec` takes an array, for fetching several refs in one invocation.
 */
export function fetch(
  remote: string,
  refspec?: string | string[] | undefined,
  opts: FetchOptions = {},
): GitVerb<void> {
  const argv = ['fetch']
  if (opts.quiet) argv.push('--quiet')
  if (opts.prune) argv.push('--prune')
  if (opts.noWriteFetchHead) argv.push('--no-write-fetch-head')
  argv.push(remote)
  if (refspec !== undefined) argv.push(...(typeof refspec === 'string' ? [refspec] : refspec))
  return { argv, absent: NONE, parse: nothing }
}

/** Options for {@link add}. */
export interface AddOptions {
  /** `--all` — stage deletions and untracked files too, not just changes. */
  all?: boolean | undefined
  /** `--update` — stage changes and deletions to tracked files only. */
  update?: boolean | undefined
}

/** Stage paths. */
export function add(paths: string[], opts: AddOptions = {}): GitVerb<void> {
  const argv = ['add']
  if (opts.all) argv.push('--all')
  if (opts.update) argv.push('--update')
  argv.push(...paths)
  return { argv, absent: NONE, parse: nothing }
}

/** Options for {@link commit}. */
export interface CommitOptions {
  /** The subject, as `-m`. */
  message?: string | undefined
  /**
   * A second `-m`, rendered as the body after a blank line. Ignored under
   * `messageFile` — git rejects `-F` and `-m` together.
   */
  body?: string | undefined
  /** `-F` — take the whole message from a file. Wins over `message`. */
  messageFile?: string | undefined
  /** `--allow-empty` — commit even when nothing is staged. */
  allowEmpty?: boolean | undefined
  /** `--amend` — replace the previous commit rather than adding one. */
  amend?: boolean | undefined
  /** `--no-verify` — skip the commit hooks. */
  noVerify?: boolean | undefined
  /** `--signoff` — append a `Signed-off-by` trailer. */
  signoff?: boolean | undefined
}

/**
 * Commit with an inline message or a message file (exactly one).
 *
 * `absent: []`. A failing commit hook is a failure, not an answer — and its
 * output goes to **stdout**, so a caller that must report it reads
 * `e.result.stdout`, not stderr.
 */
export function commit(opts: CommitOptions): GitVerb<void> {
  const argv = ['commit']
  if (opts.allowEmpty) argv.push('--allow-empty')
  if (opts.amend) argv.push('--amend')
  if (opts.noVerify) argv.push('--no-verify')
  if (opts.signoff) argv.push('--signoff')
  if (opts.messageFile !== undefined) argv.push('-F', opts.messageFile)
  else {
    argv.push('-m', opts.message ?? '')
    if (opts.body !== undefined) argv.push('-m', opts.body)
  }
  return { argv, absent: NONE, parse: nothing }
}

/** Options for {@link configSet}. */
export interface ConfigSetOptions {
  /**
   * Which file to write. Omitted means git's default: `--local` inside a
   * repository, something else outside one.
   */
  scope?: 'local' | 'global' | 'system' | undefined
}

/** `git config <key> <value>` — the write twin of {@link configGet}. */
export function configSet(key: string, value: string, opts: ConfigSetOptions = {}): GitVerb<void> {
  const argv = ['config']
  if (opts.scope !== undefined) argv.push(`--${opts.scope}`)
  argv.push(key, value)
  return { argv, absent: NONE, parse: nothing }
}

/** Options for {@link init}. */
export interface InitOptions {
  /** `--bare` — a store with no working tree. */
  bare?: boolean | undefined
  /** `-b` — the initial branch name, rather than git's configured default. */
  initialBranch?: string | undefined
  /** `--quiet` — suppress the "Initialized empty repository" line. */
  quiet?: boolean | undefined
}

/**
 * `git init [path]`. `path` defaults to the client's `cwd`.
 *
 * Pass `initialBranch`: without it the branch name comes from the developer's
 * `init.defaultBranch`, so a fixture assuming `main` fails on some machines.
 */
export function init(path?: string | undefined, opts: InitOptions = {}): GitVerb<void> {
  const argv = ['init']
  if (opts.quiet) argv.push('--quiet')
  if (opts.bare) argv.push('--bare')
  if (opts.initialBranch !== undefined) argv.push('-b', opts.initialBranch)
  if (path !== undefined) argv.push(path)
  return { argv, absent: NONE, parse: nothing }
}

/** Options for {@link clone}. */
export interface CloneOptions {
  /** `--depth <n>` — a shallow clone with that much history. */
  depth?: number | undefined
  /**
   * `--branch <ref>` — the branch or tag to land on.
   *
   * A commit sha is NOT a `--branch` argument: git refuses one. Clone
   * without it and `checkout` the sha afterwards.
   */
  branch?: string | undefined
  /** `--bare` — a store with no working tree. */
  bare?: boolean | undefined
  /** `--quiet` — suppress the progress lines. */
  quiet?: boolean | undefined
}

/**
 * `git clone [--depth n] [--branch ref] [--bare] <url> [dest]`.
 *
 * The one verb in this table that does not run inside a repository — it
 * makes one. A client's `cwd` is where a relative `dest` resolves, and both
 * clients bind it the same way they bind every other call.
 */
export function clone(
  url: string,
  dest?: string | undefined,
  opts: CloneOptions = {},
): GitVerb<void> {
  const argv = ['clone']
  if (opts.quiet) argv.push('--quiet')
  if (opts.bare) argv.push('--bare')
  if (opts.depth !== undefined) argv.push('--depth', String(opts.depth))
  if (opts.branch !== undefined) argv.push('--branch', opts.branch)
  argv.push(url)
  if (dest !== undefined) argv.push(dest)
  return { argv, absent: NONE, parse: nothing }
}

/**
 * Push a refspec.
 *
 * `forceWithLease` takes `true` for the bare `--force-with-lease`, or a
 * string for the pinned `--force-with-lease=<ref>:<sha>` form. Pin it
 * whenever the expected remote sha is known: the bare flag trusts whatever
 * the local remote-tracking ref happens to say, and a background fetch can
 * quietly bring that up to date — after which the lease vetoes nothing and a
 * concurrent push is erased.
 */
export function push(
  remote: string,
  refspec: string,
  opts: { forceWithLease?: boolean | string | undefined } = {},
): GitVerb<void> {
  const argv = ['push']
  const lease = opts.forceWithLease
  if (typeof lease === 'string') argv.push(`--force-with-lease=${lease}`)
  else if (lease) argv.push('--force-with-lease')
  argv.push(remote, refspec)
  return { argv, absent: NONE, parse: nothing }
}

/** `git reset --hard <rev>`. */
export function resetHard(rev: string): GitVerb<void> {
  return { argv: ['reset', '--hard', rev], absent: NONE, parse: nothing }
}

/** Delete a local branch (`-d`, or `-D` with `{force: true}`). */
export function deleteBranch(
  name: string,
  opts: { force?: boolean | undefined } = {},
): GitVerb<void> {
  return {
    argv: ['branch', opts.force ? '-D' : '-d', name],
    absent: NONE,
    parse: nothing,
  }
}

/** `git worktree add [--detach] [-b branch] <path> [startPoint]`. */
export function worktreeAdd(
  path: string,
  opts: {
    branch?: string | undefined
    startPoint?: string | undefined
    detach?: boolean | undefined
  } = {},
): GitVerb<void> {
  const argv = ['worktree', 'add']
  if (opts.detach) argv.push('--detach')
  if (opts.branch !== undefined) argv.push('-b', opts.branch)
  argv.push(path)
  if (opts.startPoint !== undefined) argv.push(opts.startPoint)
  return { argv, absent: NONE, parse: nothing }
}

/** `git worktree remove [--force] <path>`. */
export function worktreeRemove(
  path: string,
  opts: { force?: boolean | undefined } = {},
): GitVerb<void> {
  const argv = ['worktree', 'remove']
  if (opts.force) argv.push('--force')
  argv.push(path)
  return { argv, absent: NONE, parse: nothing }
}

/** Options for {@link worktreeMove}. */
export interface WorktreeMoveOptions {
  /** `--force` — move even when the worktree is dirty or locked. */
  force?: boolean | undefined
}

/** `git worktree move [--force] <from> <to>`. */
export function worktreeMove(
  from: string,
  to: string,
  opts: WorktreeMoveOptions = {},
): GitVerb<void> {
  const argv = ['worktree', 'move']
  if (opts.force) argv.push('--force')
  argv.push(from, to)
  return { argv, absent: NONE, parse: nothing }
}

/** `git worktree prune`. */
export function worktreePrune(): GitVerb<void> {
  return { argv: ['worktree', 'prune'], absent: NONE, parse: nothing }
}

/** `git remote add <name> <url>`. */
export function remoteAdd(name: string, url: string): GitVerb<void> {
  return { argv: ['remote', 'add', name, url], absent: NONE, parse: nothing }
}

// ── integration ─────────────────────────────────────────────────────────────
//
// `merge` and `rebase` are the verbs where a non-zero exit carries the answer:
// a conflict is the outcome a caller asked about, not a failure to report. So
// exit 1 is declared absent and the parse turns it into a `conflict` outcome.
//
// Which is only safe because the parse looks past the exit code. Measured
// against git 2.50.1, and the assumptions did not survive:
//
//   git merge, conflict                     1   (stdout carries the report)
//   git merge, unknown ref                  1   (stdout empty)
//   git merge, would overwrite local edits  2
//   git merge, merge already in progress    128
//   git merge, unrelated histories          128
//   git merge, outside a repository         128
//   git rebase, conflict                    1
//   git rebase --continue, still conflicted 1
//   git rebase, unknown ref                 128
//   git rebase/merge --abort, none running  128
//
// An unknown ref exits 1 exactly like a conflict, so the exit code alone
// cannot tell them apart. The discriminator is that a conflict always writes
// its report to stdout and a refusal writes nothing there — a structural
// signal rather than a string match, because git's messages are translatable
// and a locale must not change what an outcome means.

/** How an integration attempt ended. */
export type IntegrationOutcome<Extra> =
  | ({ status: 'clean' } & Extra)
  /**
   * Conflicted. `conflicts` is a best-effort read of git's own report — it
   * has no parseable form for rename/rename or rename/delete, and it is
   * translatable, so it can be empty on a real conflict. Ask
   * {@link lsFilesUnmerged} or `diffNameOnly({ diffFilter: "U" })` for the
   * authoritative list.
   */
  | { status: 'conflict'; conflicts: string[] }

export type MergeOutcome = IntegrationOutcome<{
  fastForward: boolean
  alreadyUpToDate: boolean
}>

export type RebaseOutcome = IntegrationOutcome<{ alreadyUpToDate: boolean }>

/** `CONFLICT (content|add/add|…): Merge conflict in <path>` */
const CONFLICT_MERGE_IN = /^CONFLICT \([^)]*\): Merge conflict in (.+)$/
/** `CONFLICT (modify/delete): <path> deleted in <x> and modified in <y>…` */
const CONFLICT_MODIFY_DELETE = /^CONFLICT \(modify\/delete\): (.+?) deleted in .+? and modified in /

/** Paths git named in its own conflict report. Best effort — see the type. */
function conflictPaths(stdout: string): string[] {
  const seen = new Set<string>()
  for (const line of stdout.split('\n')) {
    const m = CONFLICT_MERGE_IN.exec(line) ?? CONFLICT_MODIFY_DELETE.exec(line)
    if (m?.[1] !== undefined) seen.add(m[1])
  }
  return [...seen]
}

/**
 * Read an exit-1 integration result: a conflict, or a refusal that must throw.
 *
 * Empty stdout means git declined before it started merging — an unknown ref,
 * a name it cannot resolve. That is not an answer, so it fails like any other
 * broken invocation.
 */
function conflictOrThrow(
  argv: string[],
  r: CommandResult,
): { status: 'conflict'; conflicts: string[] } {
  if (r.stdout.trim() === '') throw new CommandFailed(argv, r)
  return { status: 'conflict', conflicts: conflictPaths(r.stdout) }
}

/** Options for {@link merge}. */
export interface MergeOptions {
  /** `--no-ff` — always record a merge commit, even where a fast-forward fits. */
  noFf?: boolean | undefined
  /** `--no-commit` — merge the trees but leave the commit to the caller. */
  noCommit?: boolean | undefined
  /** `-m` — the merge commit's message. */
  message?: string | undefined
}

/**
 * Merge `ref` into the current branch (`git merge --no-edit`).
 *
 * `--no-edit` is unconditional: an editor prompt in a non-interactive caller
 * is a hang, not a prompt.
 *
 * `absent: [1]` — a conflict is this verb's "asked and answered". See the
 * section note above for the measured codes and why the parse looks at
 * stdout rather than trusting the exit code alone.
 */
export function merge(ref: string, opts: MergeOptions = {}): GitVerb<MergeOutcome> {
  const argv = ['merge', '--no-edit']
  if (opts.noFf) argv.push('--no-ff')
  if (opts.noCommit) argv.push('--no-commit')
  if (opts.message !== undefined) argv.push('-m', opts.message)
  argv.push(ref)
  const verb: GitVerb<MergeOutcome> = {
    argv,
    absent: [1],
    parse(r, ranArgv) {
      if (r.exitCode !== 0) return conflictOrThrow(ranArgv, r)
      return {
        status: 'clean',
        fastForward: /^Fast-forward$/m.test(r.stdout),
        alreadyUpToDate: /^Already up[- ]to[- ]date\.?$/m.test(r.stdout),
      }
    },
  }
  return verb
}

/**
 * `git merge --abort`.
 *
 * `absent: []` — exit 128 means no merge was in progress, and a caller that
 * asked to abort one has been told something it did not know.
 */
export function mergeAbort(): GitVerb<void> {
  return { argv: ['merge', '--abort'], absent: NONE, parse: nothing }
}

/** Options for {@link rebase}. */
export interface RebaseOptions {
  /** `--autostash` — shelve and restore a dirty tree around the replay. */
  autostash?: boolean | undefined
}

/**
 * Replay the current branch onto `onto` (`git rebase`).
 *
 * `absent: [1]` for the same reason as {@link merge}. An unknown ref exits
 * 128 here rather than 1, so this verb is the less ambiguous of the two —
 * the stdout check costs nothing and keeps the two parses identical.
 */
export function rebase(onto: string, opts: RebaseOptions = {}): GitVerb<RebaseOutcome> {
  const argv = ['rebase']
  if (opts.autostash) argv.push('--autostash')
  argv.push(onto)
  const verb: GitVerb<RebaseOutcome> = {
    argv,
    absent: [1],
    parse(r, ranArgv) {
      if (r.exitCode !== 0) return conflictOrThrow(ranArgv, r)
      return {
        status: 'clean',
        alreadyUpToDate: /is up to date/m.test(r.stdout),
      }
    },
  }
  return verb
}

/** `git rebase --abort`. `absent: []` — 128 means no rebase was running. */
export function rebaseAbort(): GitVerb<void> {
  return { argv: ['rebase', '--abort'], absent: NONE, parse: nothing }
}

/**
 * `git rebase --continue`, with the editor stubbed out.
 *
 * `-c core.editor=true` rather than an environment variable: the verb table
 * describes an invocation, and git's own config override keeps that
 * description complete.
 *
 * `absent: [1]` — the replay can conflict again on the next commit, which is
 * an answer, not a failure.
 */
export function rebaseContinue(): GitVerb<RebaseOutcome> {
  const verb: GitVerb<RebaseOutcome> = {
    argv: ['-c', 'core.editor=true', 'rebase', '--continue'],
    absent: [1],
    parse(r, ranArgv) {
      if (r.exitCode !== 0) return conflictOrThrow(ranArgv, r)
      return { status: 'clean', alreadyUpToDate: false }
    },
  }
  return verb
}

/**
 * How a merge would end, computed without a working tree.
 *
 * `tree` is the merged tree git wrote to the object database — real enough to
 * hand to `commit-tree`, so a clean prediction is also the whole answer: a
 * caller that only needs the merge commit never checks anything out. On a
 * conflict the tree holds the conflict-marked blobs instead.
 */
export type MergeTreeOutcome =
  | { status: 'clean'; tree: string }
  /** Unlike {@link MergeOutcome}, `conflicts` is git's own list — see {@link mergeTree}. */
  | { status: 'conflict'; tree: string; conflicts: string[] }

/** Options for {@link mergeTree}. */
export interface MergeTreeOptions {
  /** `--merge-base=<ref>` — fix the base instead of letting git pick it. */
  mergeBase?: string | undefined
}

/**
 * `git merge-tree --write-tree`: what merging `theirs` into `ours` would do,
 * against the object database alone — no index, no checkout, no worktree.
 *
 * The cheap half of {@link merge}. Predicting every open PR's merge across a
 * 10,000-file monorepo costs seconds here; checking each one out to learn the
 * same thing costs minutes, and most of them turn out to merge cleanly.
 *
 * `-z` rather than the plain listing: otherwise git C-quotes any path that
 * needs it (`"w\303\251ird \"name\".txt"`), and a caller matching those
 * strings against real paths silently misses the files most worth attention.
 *
 * Unlike {@link merge}, the conflict list is authoritative — git names the
 * paths in a machine-readable section rather than in translatable prose — so
 * there is no need to follow up with {@link lsFilesUnmerged}.
 *
 * `absent: [1]`, with this section's usual discriminator. Measured against
 * git 2.50.1:
 *
 *     clean                  0    `<tree>`
 *     conflict               1    `<tree>` then the conflicted paths
 *     unmergeable name       1    stdout empty
 *     unrelated histories    128
 *
 * A name git cannot merge exits 1 exactly like a conflict, so once again only
 * stdout separates an answer from a refusal.
 */
export function mergeTree(
  ours: string,
  theirs: string,
  opts: MergeTreeOptions = {},
): GitVerb<MergeTreeOutcome> {
  const argv = ['merge-tree', '--write-tree', '--name-only', '-z']
  if (opts.mergeBase !== undefined) argv.push(`--merge-base=${opts.mergeBase}`)
  argv.push(ours, theirs)
  return {
    argv,
    absent: [1],
    parse(r, ranArgv) {
      const fields = r.stdout.split('\x00')
      const tree = fields[0] ?? ''
      if (tree === '') throw new CommandFailed(ranArgv, r)
      if (r.exitCode === 0) return { status: 'clean', tree }
      // `<tree>\0<path>\0…\0\0<info records>` — the paths run to the first
      // empty field, which is what separates them from git's own commentary.
      const conflicts: string[] = []
      for (const field of fields.slice(1)) {
        if (field === '') break
        conflicts.push(field)
      }
      return { status: 'conflict', tree, conflicts }
    },
  }
}

// ── conflict inspection ─────────────────────────────────────────────────────

/** One `git ls-files -u` row — the same path appears once per present stage. */
export interface UnmergedEntry {
  mode: string
  sha: string
  /** 1 = merge base, 2 = ours, 3 = theirs. */
  stage: 1 | 2 | 3
  path: string
}

/** `<mode> <sha> <stage>\t<path>` */
const UNMERGED_ROW = /^(\d+) ([0-9a-f]+) ([123])\t(.*)$/

/**
 * `git ls-files -u`, parsed — the stage detail behind a conflict.
 *
 * Which stages are present is what distinguishes the conflict shapes: all of
 * 1/2/3 is both-modified, 1+3 is we-deleted, 1+2 is they-deleted, and 2+3
 * with no base is add/add. A resolver that treats every conflict as
 * both-modified will delete files.
 *
 * `absent: []` — a tree with nothing unmerged is exit 0 and empty stdout, so
 * `[]` means "no conflicts". Outside a repository git exits 128 and this
 * throws: a resolver that cannot read the index has not "found no conflicts".
 *
 * For the paths alone, `diffNameOnly({ diffFilter: "U" })` is cheaper.
 */
export function lsFilesUnmerged(): GitVerb<UnmergedEntry[]> {
  return {
    argv: ['ls-files', '-u', '-z'],
    absent: NONE,
    parse(r) {
      const rows: UnmergedEntry[] = []
      for (const chunk of r.stdout.split('\x00')) {
        const m = UNMERGED_ROW.exec(chunk)
        if (m === null) continue
        rows.push({
          mode: m[1]!,
          sha: m[2]!,
          stage: Number(m[3]) as 1 | 2 | 3,
          path: m[4]!,
        })
      }
      return rows
    },
  }
}

// ── checkout ────────────────────────────────────────────────────────────────

/** Which side of a conflict to take wholesale. */
export type ConflictSide = 'ours' | 'theirs'

/**
 * `git checkout --ours|--theirs -- <paths>` — resolve paths to one side.
 *
 * `absent: []` — a checkout that did not happen is not an answer.
 *
 * Note the sharp edge git leaves here: on a path that is not conflicted this
 * exits 0 and does nothing. There is no error to catch, so a caller working
 * from a stale conflict list silently resolves nothing. Take the path list
 * from {@link lsFilesUnmerged} in the same breath, not from an earlier one.
 */
export function checkoutSide(side: ConflictSide, paths: string[]): GitVerb<void> {
  return {
    argv: ['checkout', `--${side}`, '--', ...paths],
    absent: NONE,
    parse: nothing,
  }
}

/** Options for {@link checkout}. */
export interface CheckoutOptions {
  /** Create (or with `resetBranch`, repoint) this branch at `ref`. */
  branch?: string | undefined
  /**
   * `-B` rather than `-b`: point an existing branch at `ref` instead of
   * failing because it exists. What reusing one worktree across many branches
   * needs.
   */
  resetBranch?: boolean | undefined
  /** `--force` — discard local modifications rather than refusing. */
  force?: boolean | undefined
}

/**
 * `git checkout [-f] [-b|-B <branch>] <ref>`.
 *
 * `absent: []` — an unknown ref exits 1 here, and a checkout that did not
 * happen leaves the caller on a branch it does not expect. That is a failure,
 * not an absence.
 */
export function checkout(ref: string, opts: CheckoutOptions = {}): GitVerb<void> {
  const argv = ['checkout']
  if (opts.force) argv.push('--force')
  if (opts.branch !== undefined) argv.push(opts.resetBranch ? '-B' : '-b', opts.branch)
  argv.push(ref)
  return { argv, absent: NONE, parse: nothing }
}
