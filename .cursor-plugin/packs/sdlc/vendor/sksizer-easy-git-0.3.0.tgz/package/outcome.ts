/**
 * The inspection door — `git.try.*`, and the {@link GitOutcome} it returns.
 *
 * For callers that genuinely tolerate failure: a hook that must never break a
 * commit, a status endpoint that must always answer. `try` is a facade over
 * the whole client rather than a per-verb option, so a new verb costs nothing
 * here. Two rules make it honest:
 *
 *   - It catches `CommandFailed` and nothing else. A `TypeError` from a
 *     programmer mistake propagates; this is not a blanket catch.
 *   - A declared absence is `{ ok: true }`. `git.try.configGet("no.such.key")`
 *     is `{ ok: true, value: null }`, because absence is an answer, not a
 *     failure.
 */

import { CommandFailed } from '@sksizer/command-seam'

/** The result of a git call that was allowed to fail. */
export type GitOutcome<T> = { ok: true; value: T } | { ok: false; error: CommandFailed }

/**
 * The methods `try` mirrors: everything but the escape hatches, the
 * re-rooting helper, and `try` itself. `raw` already returns a
 * `CommandResult` and never throws; `rawChecked` is the deliberate throwing
 * door; `at(cwd)` returns a fresh client that has its own `.try`.
 */
type Triable<C> = Omit<C, 'raw' | 'rawChecked' | 'at' | 'try' | 'cwd'>

/** Every synchronous client method, returning a {@link GitOutcome}. */
export type TriedSync<C> = {
  [K in keyof Triable<C>]: Triable<C>[K] extends (...a: infer A) => infer R
    ? (...a: A) => GitOutcome<R>
    : never
}

/** Every awaitable client method, promising the same union. */
export type TriedAsync<C> = {
  [K in keyof Triable<C>]: Triable<C>[K] extends (...a: infer A) => Promise<infer R>
    ? (...a: A) => Promise<GitOutcome<R>>
    : never
}

/** `CommandFailed` becomes an outcome; anything else stays a throw. */
function asOutcome<T>(error: unknown): GitOutcome<T> {
  if (error instanceof CommandFailed) return { ok: false, error }
  throw error
}

/**
 * A `Proxy` rather than a generated object: it mirrors whatever the client
 * has, including composed methods like `isDirty` that call through the gated
 * ones, without a per-verb entry to keep in step. Methods are invoked on the
 * client itself, not on the proxy, so private state stays reachable.
 */
function facade<C extends object, F>(client: C, wrap: (call: () => unknown) => F): unknown {
  return new Proxy(client, {
    get(target, prop) {
      // Read from the target, not the proxy: a getter (`try` itself) must run
      // against the real client rather than recursing through the facade.
      const value: unknown = Reflect.get(target, prop)
      if (typeof value !== 'function') return value
      const method = value as (...a: unknown[]) => unknown
      return (...args: unknown[]) => wrap(() => method.apply(target, args))
    },
  })
}

/** Wrap a synchronous client so every method returns a {@link GitOutcome}. */
export function triedSync<C extends object>(client: C): TriedSync<C> {
  return facade(client, (call): GitOutcome<unknown> => {
    try {
      return { ok: true, value: call() }
    } catch (error) {
      return asOutcome(error)
    }
  }) as TriedSync<C>
}

/** Wrap an awaitable client so every method promises a {@link GitOutcome}. */
export function triedAsync<C extends object>(client: C): TriedAsync<C> {
  return facade(client, async (call): Promise<GitOutcome<unknown>> => {
    try {
      return { ok: true, value: await call() }
    } catch (error) {
      return asOutcome(error)
    }
  }) as TriedAsync<C>
}
