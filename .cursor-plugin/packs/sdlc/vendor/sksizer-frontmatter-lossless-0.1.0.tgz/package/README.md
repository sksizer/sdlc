# @sksizer/frontmatter-lossless

Byte-exact Markdown frontmatter framing: split a note into verbatim YAML and
body with source offsets, and recompose it losslessly — BOM, CRLF, and fence
bytes preserved. No dependencies.

A TypeScript peer port of the `frontmatter-lossless` Rust crate, mirrored
function-for-function and held identical by a shared conformance corpus: a
framing change in either language fails the other's suite.
