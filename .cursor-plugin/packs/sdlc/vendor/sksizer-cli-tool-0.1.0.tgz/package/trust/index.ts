/**
 * `@sksizer/cli-tool/trust` — per-repository consent to run a repository's
 * own scripts, so a tool can ask "has a person consented to running this
 * repository's scripts?" once and remember the answer.
 *
 * {@link trustStore} builds one store per tool name: a directory of marker
 * files under `$XDG_STATE_HOME/<tool>/trusted/`, keyed on the
 * symlink-resolved repository root. {@link resolveExecGate} combines a
 * tool's configured value, an explicit per-run flag and the store into the
 * one boolean the tool acts on; {@link withheldHint} is the one sentence
 * every surface shows when that gate withholds something.
 *
 * Ported from `@sksizer/detect-runners`'s `src/trust.ts`, generalised
 * across tools — see the reasoning in `./store.ts` and `./gate.ts`.
 */

export { TRUST_MARKER_DIR, resolveTrustRoot, trustStore, trustStoreDir } from './store.ts'
export type { TrustResult, TrustStore, TrustStoreOptions } from './store.ts'

export { resolveExecGate, withheldHint } from './gate.ts'
export type { ExecGate, ResolveExecGateArgs } from './gate.ts'
