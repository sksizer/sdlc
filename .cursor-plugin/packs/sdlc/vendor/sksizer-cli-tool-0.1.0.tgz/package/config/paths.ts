/**
 * Named directories, and the `{token}` expansion over them.
 *
 * A `paths:` map — name → directory — lives in both config files, and the
 * machine's entry wins per name, since a directory is a fact about a
 * machine. Any other path-valued setting then refers to an entry as
 * `{name}`, so `~/Developer` is written once however many settings need it.
 *
 * Also home to {@link resolveConfigPath}, the one `~` and relative expansion
 * every config path value goes through. This module imports nothing else
 * from the package, so a schema can use its pieces without a cycle.
 */

import { isAbsolute, resolve } from 'node:path'

import { z } from 'zod'

/** What a `paths:` name may look like. */
export const PATH_NAME = /^[A-Za-z][A-Za-z0-9_]*$/

/**
 * Expand a single config path value relative to `baseDir`.
 *
 * URLs (`scheme://…`) and bare words that do not look like paths pass
 * through untouched — a value may legitimately be a name rather than a
 * place. A leading `~` expands to $HOME; a relative path resolves against
 * `baseDir`, which is the project root for a project file and, for a machine
 * file, whatever the reading tool considers its working root.
 */
export function resolveConfigPath(value: string, baseDir: string): string {
  if (value.includes('://')) return value
  const looksLikePath = value.includes('/') || value.startsWith('.') || value.startsWith('~')
  if (!looksLikePath) return value
  let p = value
  if (p.startsWith('~')) {
    p = p.replace(/^~/, process.env['HOME'] ?? '')
  }
  if (!isAbsolute(p)) p = resolve(baseDir, p)
  return p
}

/** Name → absolute directory. */
export type PathTokens = Record<string, string>

/**
 * The effective `paths:` map: the project's entries under the machine's,
 * each expanded and made absolute against `baseDir`.
 */
export function pathTokens(
  baseDir: string,
  machine: Record<string, string>,
  project: Record<string, string>,
): PathTokens {
  const out: PathTokens = {}
  for (const [name, raw] of [...Object.entries(project), ...Object.entries(machine)]) {
    out[name] = resolve(baseDir, resolveConfigPath(raw, baseDir))
  }
  return out
}

/** Thrown by {@link expandTokens} for a `{name}` that nothing defines. */
export class TokenError extends Error {}

export interface ExpandOptions {
  /**
   * How the message tells a person to define a missing name. Defaults to
   * "define it under `paths:`"; a tool that has two files names them.
   */
  defineHint?: string | undefined
}

/**
 * `value` with every `{name}` replaced from `tokens`.
 *
 * A name nothing defines is a {@link TokenError} rather than an empty
 * string: a setting that silently expands to `/repo` instead of
 * `/Users/me/dev/repo` fails somewhere far from the typo. The message says
 * where the token was found (`where`, e.g. `repos:`), how to define it, and
 * what is available.
 */
export function expandTokens(
  value: string,
  tokens: Record<string, string>,
  where: string,
  opts: ExpandOptions = {},
): string {
  const defineHint = opts.defineHint ?? 'define it under paths:'
  return value.replace(/\{([^{}]*)\}/g, (_, name: string) => {
    const hit = tokens[name]
    if (hit === undefined) {
      const known = Object.keys(tokens).map((n) => `{${n}}`)
      throw new TokenError(
        `unknown token '{${name}}' in ${where} '${value}'; ${defineHint}` +
          (known.length > 0 ? ` (available: ${known.join(', ')})` : ''),
      )
    }
    return hit
  })
}

export interface PathsSchemaOptions {
  /**
   * Names a consuming setting defines itself, which `paths:` may not
   * shadow — `host`, `owner`, `repo` for a checkout layout, say.
   */
  reserved?: readonly string[] | undefined
}

/**
 * The `paths:` map as a schema: a name (see {@link PATH_NAME}, never one of
 * `reserved`) → a directory.
 */
export function pathsSchema(opts: PathsSchemaOptions = {}): z.ZodRecord<z.ZodString, z.ZodString> {
  const reserved = opts.reserved ?? []
  return z.record(
    z
      .string()
      .regex(PATH_NAME, 'a path name is letters, digits and _, starting with a letter')
      .refine((n) => !reserved.includes(n), {
        message:
          reserved.length > 0
            ? `a path may not be named after a reserved token (${reserved.join(', ')})`
            : 'reserved name',
      }),
    z
      .string()
      .trim()
      .min(1)
      .describe('A directory. `~` expands; relative resolves against the project root.'),
  )
}
