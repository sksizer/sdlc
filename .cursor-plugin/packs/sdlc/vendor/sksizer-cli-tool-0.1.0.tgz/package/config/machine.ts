/**
 * The machine-level config file — the committed project file's twin for
 * values that describe THIS machine rather than a project.
 *
 * A project file is committed, so a path like `~/Developer` that only means
 * something on one laptop has no honest place in it. The machine file lives
 * in the fleet config home of the tool's standalone tier
 * (`<config>/<tool>/config.yaml`, the same directory devlink writes its
 * `home` redirect into), is never committed, and carries only keys that are
 * machine-specific by nature.
 *
 * The contract: Zod is the single source of truth, every key has a default,
 * the loader never throws and degrades to the all-defaults object, and it is
 * memoised per path. The path is a function, not a constant, so a test or a
 * one-off run relocates the file through an environment variable instead of
 * writing into the developer's real config home.
 */

import { existsSync, readFileSync } from 'node:fs'
import { join } from 'node:path'

import { Fleet } from '@sksizer/fleet'
import { parse as yamlParse } from 'yaml'
import type { z } from 'zod'

/** `sdlc` → `SDLC`; `pr-updater` → `PR_UPDATER`. The stem devlink uses too. */
export function envStem(tool: string): string {
  return tool.toUpperCase().replace(/[^A-Z0-9]+/g, '_')
}

export interface MachineConfigFileOptions<S extends z.ZodTypeAny> {
  /** The tool's standalone name: the directory segment under the config home. */
  tool: string
  /** Every key with a default; the loader parses `{}` to get the defaults. */
  schema: S
  /** Env var that relocates the file. Default `<STEM>_MACHINE_CONFIG`. */
  env?: string
  /** The file's name inside the tool's config dir. Default `config.yaml`. */
  fileName?: string
  /** How to reach the fleet, per call: tests inject a rooted one. Default `Fleet.fromSystem()`. */
  fleet?: () => Fleet
}

export interface MachineConfigFile<S extends z.ZodTypeAny> {
  readonly tool: string
  readonly schema: S
  /** The env var that relocates the file (tests, one-off runs). */
  readonly env: string
  /** `<config-home>/<tool>/config.yaml`, unless {@link env} says otherwise. */
  path(): string
  /**
   * The file, all defaults filled. Missing file, unreadable file, YAML error,
   * non-mapping document and schema failure all degrade to the defaults.
   * Memoised per path, so a run that swaps {@link env} is read fresh.
   */
  load(): z.output<S>
  /** Drop the memoised value. Call from tests between runs. */
  clearCache(): void
}

export function machineConfigFile<S extends z.ZodTypeAny>(
  opts: MachineConfigFileOptions<S>,
): MachineConfigFile<S> {
  const { tool, schema } = opts
  const env = opts.env ?? `${envStem(tool)}_MACHINE_CONFIG`
  const fileName = opts.fileName ?? 'config.yaml'
  const fleet = opts.fleet ?? (() => Fleet.fromSystem())
  let cache: { path: string; value: z.output<S> } | null = null

  const path = (): string => {
    const override = process.env[env]
    if (override !== undefined && override.trim() !== '') return override
    return join(fleet().standalone(tool).config().path, fileName)
  }

  const loadUncached = (file: string): z.output<S> => {
    const defaults = schema.parse({}) as z.output<S>
    if (!existsSync(file)) return defaults
    let raw: unknown
    try {
      raw = yamlParse(readFileSync(file, 'utf-8'))
    } catch {
      return defaults
    }
    if (raw === null || raw === undefined) raw = {}
    if (typeof raw !== 'object' || Array.isArray(raw)) return defaults
    const result = schema.safeParse(raw)
    return result.success ? (result.data as z.output<S>) : defaults
  }

  return {
    tool,
    schema,
    env,
    path,
    load() {
      const file = path()
      if (cache !== null && cache.path === file) return cache.value
      const value = loadUncached(file)
      cache = { path: file, value }
      return value
    },
    clearCache() {
      cache = null
    },
  }
}
