/**
 * What a command needs from the config before it can run, and the one
 * message every unmet need renders: the command, the key, what the key is
 * for (its own schema description), and where to set it.
 *
 * A tool builds one {@link ConfigNeeds} from its two schemas. A command then
 * declares `{ config: 'dotted.key' }`, optionally with an input that stands
 * in for the setting (`--authority` for `lease_authority`), and asks `met`
 * before its handler runs.
 */

import { existsSync } from 'node:fs'
import { join } from 'node:path'

import type { z } from 'zod'

import type { MachineConfigFile } from './machine.ts'
import { keyDescription, leafSchema } from './schema.ts'
import { valueAt, valueIsSet } from './value.ts'

/** A setting a command cannot run without. */
export interface ConfigNeed {
  /** Dotted path into the config: `lease_authority`, `paths.dev`. */
  config: string
  /**
   * An input key that stands in for the setting when given on the command
   * line (`authority` for `--authority`). The need is met when that input is
   * present and non-empty, whatever the config says.
   */
  unlessInput?: string
}

/** Which files may carry a key. */
export interface KeyScopes {
  project: boolean
  machine: boolean
}

export interface ConfigNeedsOptions<P extends z.ZodTypeAny, M extends z.ZodTypeAny> {
  /** The tool's command name, for the message (`sdlc`). */
  tool: string
  /** The committed project file's name (`sdlc.yaml`), looked for at the project root. */
  projectFile: string
  projectSchema: P
  /** The machine file; its schema says which keys it may carry. */
  machine: MachineConfigFile<M>
  /**
   * How to see the whole shape, appended to the message after a semicolon:
   * `` `sdlc config scaffold` shows the full shape ``.
   */
  scaffoldHint?: string
}

export interface MetOptions {
  /** The hydrated project config (all defaults filled). */
  project: unknown
  /** The raw command input, so `unlessInput` can stand in. */
  input?: Record<string, unknown> | undefined
}

export interface MessageOptions {
  /** Where the project file would be; the message names it or says it is absent. */
  projectRoot: string
  /** The command's words after the tool name (`['lease', 'list']`); absent → "this op". */
  command?: readonly string[] | undefined
}

export interface ConfigNeeds {
  /** Which files' schemas carry `key`. */
  keyScopes(key: string): KeyScopes
  /** Whether either schema knows `key`. */
  keyExists(key: string): boolean
  /** The first sentence of either schema's description for `key`, or null. */
  keyDescription(key: string): string | null
  /** Whether `need` is met: the input stands in, or the setting is set in either file. */
  met(need: ConfigNeed, opts: MetOptions): boolean
  /** The one message every unmet need renders. */
  message(need: ConfigNeed, opts: MessageOptions): string
  /**
   * Where `key` can be set, as prose: the files whose schema carries it, the
   * one a person is standing in first. Outside a project (no project file at
   * the root) the machine file leads and the project file is described rather
   * than pointed at, since the root is not one.
   */
  whereToSet(key: string, projectRoot: string): string
}

export function configNeeds<P extends z.ZodTypeAny, M extends z.ZodTypeAny>(
  opts: ConfigNeedsOptions<P, M>,
): ConfigNeeds {
  const { tool, projectFile, projectSchema, machine, scaffoldHint } = opts
  const machineSchema = machine.schema

  const keyScopes = (key: string): KeyScopes => ({
    project: leafSchema(projectSchema, key) !== null,
    machine: leafSchema(machineSchema, key) !== null,
  })

  const whereToSet = (key: string, projectRoot: string): string => {
    const scopes = keyScopes(key)
    const inProject = existsSync(join(projectRoot, projectFile))
    const project = inProject
      ? join(projectRoot, projectFile)
      : `an ${projectFile} at the project root (none above ${projectRoot})`
    const machineText = `the machine config (${machine.path()})`
    if (scopes.machine && scopes.project) {
      return inProject ? `${project} or ${machineText}` : `${machineText} or ${project}`
    }
    return scopes.machine ? machineText : project
  }

  return {
    keyScopes,
    keyExists: (key) => {
      const scopes = keyScopes(key)
      return scopes.project || scopes.machine
    },
    keyDescription: (key) =>
      keyDescription(projectSchema, key) ?? keyDescription(machineSchema, key),
    met(need, { project, input }) {
      if (need.unlessInput !== undefined && valueIsSet(input?.[need.unlessInput])) return true
      if (valueIsSet(valueAt(project, need.config))) return true
      return valueIsSet(valueAt(machine.load(), need.config))
    },
    message(need, { projectRoot, command }) {
      const who = command === undefined ? 'this op' : `\`${tool} ${command.join(' ')}\``
      const flag = need.unlessInput === undefined ? '' : ` (or pass --${toFlag(need.unlessInput)})`
      const what =
        keyDescription(projectSchema, need.config) ?? keyDescription(machineSchema, need.config)
      const hint = scaffoldHint === undefined ? '' : `; ${scaffoldHint}`
      return (
        `${who} needs \`${need.config}\`, and it is not set${flag}.` +
        (what === null ? '' : ` ${what}`) +
        ` Set it in ${whereToSet(need.config, projectRoot)}${hint}.`
      )
    },
    whereToSet,
  }
}

function toFlag(key: string): string {
  return key.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`)
}
