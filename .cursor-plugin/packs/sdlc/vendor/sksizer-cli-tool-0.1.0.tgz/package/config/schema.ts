/**
 * Walk a Zod object schema by dotted key to the schema for one setting, so a
 * message about it can quote the setting's own `.describe()` prose.
 *
 * Reads Zod's private `_def` layout — `type` tag and `innerType` — for the
 * four wrappers (`optional`, `nullable`, `default`, `prefault`) and the
 * `record` tag. Tag names rather than `instanceof`, so a second copy of zod
 * in a consumer's tree still resolves. The tripwire test in `tests/` fails
 * loudly if a zod release moves this layout.
 */

import type { z } from 'zod'

interface Def {
  type?: string
  innerType?: unknown
}

const WRAPPERS = new Set(['optional', 'nullable', 'default', 'prefault'])

function defOf(schema: unknown): Def {
  return ((schema as { _def?: Def })._def ?? {}) as Def
}

/** `schema` with its optional / nullable / default / prefault wrappers peeled. */
export function unwrapSchema(schema: z.ZodTypeAny): z.ZodTypeAny {
  let cur: z.ZodTypeAny = schema
  for (;;) {
    const def = defOf(cur)
    if (def.type === undefined || !WRAPPERS.has(def.type) || def.innerType === undefined) return cur
    cur = def.innerType as z.ZodTypeAny
  }
}

/** The object schema's `{ key: subSchema }` map, or `{}` for a non-object. */
export function shapeOf(schema: z.ZodTypeAny): Record<string, z.ZodTypeAny> {
  const shape = (schema as unknown as { shape?: unknown }).shape
  if (shape && typeof shape === 'object') return shape as Record<string, z.ZodTypeAny>
  return {}
}

/**
 * The schema at `key`, wrappers kept (a `.describe()` sits on the outermost
 * wrapper). A key under a record (`paths.dev`) resolves to the record, since
 * its entries have no schema of their own. Null when `key` names nothing.
 */
export function leafSchema(schema: z.ZodTypeAny, key: string): z.ZodTypeAny | null {
  let cur: z.ZodTypeAny = schema
  for (const seg of key.split('.')) {
    const inner = unwrapSchema(cur)
    const next = shapeOf(inner)[seg]
    if (next !== undefined) {
      cur = next
      continue
    }
    return defOf(inner).type === 'record' ? cur : null
  }
  return cur
}

/** Whether `key` names something `schema` knows. */
export function keyExists(schema: z.ZodTypeAny, key: string): boolean {
  return leafSchema(schema, key) !== null
}

/**
 * The first sentence of the schema's description for `key`, or null when
 * the schema does not describe it.
 */
export function keyDescription(schema: z.ZodTypeAny, key: string): string | null {
  const leaf = leafSchema(schema, key)
  if (leaf === null) return null
  const text = String((leaf as { description?: unknown }).description ?? '').trim()
  if (text === '') return null
  const m = /^(.*?[.!?])(?:\s|$)/.exec(text)
  return m === null ? text : m[1]!
}
