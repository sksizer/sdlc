/**
 * What devlink needs to know about one tool: how to recognise a checkout of
 * it, what to run inside one, and which environment variables steer it.
 *
 * A spec is data the tool itself declares once and passes to every devlink
 * call. Nothing here touches the filesystem.
 */

export interface ToolSpec {
  /**
   * The command name — `sdlc`, `way`. It is the PATH name `install` writes,
   * the standalone fleet segment the state lives under (`<config>/<name>/`),
   * and the stem of every environment variable.
   */
  name: string
  /**
   * A path, relative to a checkout root, that exists in every checkout of this
   * tool and in nothing else — the test for "is this directory a checkout".
   * Usually the source entry itself, e.g. `solutions/ontological/cli/sdlc.ts`.
   */
  marker: string
  /**
   * The source entry to run under Bun inside a selected checkout, relative to
   * the checkout root. Defaults to {@link marker}.
   */
  entry?: string
  /**
   * The executable `install` symlinks onto PATH, relative to the checkout root.
   * The tool's own launcher: a bash script that resolves before any runtime is
   * chosen, or a shebang JavaScript shim that calls {@link execSelection}.
   */
  launcher: string
  /**
   * Extra PATH names `install` also writes, each a symlink to the same
   * launcher. `waypost` installs as both `way` and `waypost`.
   */
  aliases?: readonly string[]
  /**
   * Environment variables whose PRESENCE turns off the cwd layer and the link
   * redirect. The explicit `<NAME>_HOME` override still applies. sdlc names
   * `CLAUDE_PLUGIN_ROOT` here so a machine-wide link never changes which code
   * a harness's skills run.
   */
  suppressors?: readonly string[]
}

/** `sdlc` → `SDLC`; `pr-updater` → `PR_UPDATER`. */
export function envStem(spec: ToolSpec): string {
  return spec.name.toUpperCase().replace(/[^A-Z0-9]+/g, '_')
}

/** The explicit override: an absolute checkout path that always wins. */
export function homeVar(spec: ToolSpec): string {
  return `${envStem(spec)}_HOME`
}

/** Set to `0` to turn the cwd layer off for a shell. */
export function cwdDevVar(spec: ToolSpec): string {
  return `${envStem(spec)}_CWD_DEV`
}

/** Set to `1` to silence the launcher's "running X (why)" line on stderr. */
export function quietVar(spec: ToolSpec): string {
  return `${envStem(spec)}_QUIET`
}

/** The source entry a selected checkout runs, relative to its root. */
export function entryOf(spec: ToolSpec): string {
  return spec.entry ?? spec.marker
}

/** Every PATH name `install` writes: the tool's own, then its aliases. */
export function pathNames(spec: ToolSpec): string[] {
  return [spec.name, ...(spec.aliases ?? [])]
}

/**
 * Reject a spec that would produce an unusable launcher or state path before
 * any filesystem work happens. Returns the spec so a tool can declare
 * `export const SPEC = validateSpec({...})`.
 */
export function validateSpec(spec: ToolSpec): ToolSpec {
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(spec.name)) {
    throw new Error(
      `devlink: tool name must be a single path segment, got ${JSON.stringify(spec.name)}`,
    )
  }
  for (const [field, value] of [
    ['marker', spec.marker],
    ['entry', spec.entry ?? spec.marker],
    ['launcher', spec.launcher],
  ] as const) {
    if (value.length === 0 || value.startsWith('/') || value.split('/').includes('..')) {
      throw new Error(
        `devlink: ${field} must be a relative path inside the checkout, got ${JSON.stringify(value)}`,
      )
    }
  }
  return spec
}
