/**
 * The verbs, as functions returning typed results. A tool mounts them under
 * its own `dev` noun with whatever CLI framework it has; `cli.ts` is the
 * framework-free mount for a tool that has none.
 *
 *   install [--bin-dir]   symlink this checkout's launcher onto PATH
 *   link [checkout]       make a checkout the machine-wide one; recorded
 *   use <#n|path|canonical>  switch to a checkout from history, a path, or
 *                         back to the canonical install; recorded
 *   off                   back to the canonical install; recorded
 *   status                what runs now, and every layer's state
 *   history               every checkout ever linked, most recent first
 *
 * Every verb honours `dryRun`: it computes and reports, and writes nothing.
 */

import { lstatSync, mkdirSync, realpathSync, symlinkSync, unlinkSync, type Stats } from 'node:fs'
import { homedir } from 'node:os'
import { join, resolve as resolvePath } from 'node:path'

import { gitHead } from './git-head.ts'
import {
  cwdCheckout,
  isCheckout,
  resolve,
  samePath,
  suppressed,
  type ResolveOptions,
  type Selection,
} from './resolve.ts'
import {
  appendHistory,
  clearActive,
  historyPath,
  homePath,
  readActive,
  readHistory,
  writeActive,
  type HistoryEvent,
} from './state.ts'
import { cwdDevVar, entryOf, homeVar, pathNames, type ToolSpec } from './spec.ts'

export interface OpOptions extends ResolveOptions {
  /** Compute and report; write nothing. */
  dryRun?: boolean
  /** Injectable clock for deterministic history in tests. */
  now?: () => Date
}

export class DevlinkError extends Error {
  override name = 'DevlinkError'
}

function checkoutOrThrow(spec: ToolSpec, path: string): string {
  const abs = resolvePath(path)
  if (!isCheckout(spec, abs)) {
    throw new DevlinkError(`not a ${spec.name} checkout (missing ${spec.marker}): ${abs}`)
  }
  return abs
}

function stamp(opts: OpOptions): string {
  return (opts.now ?? (() => new Date()))().toISOString()
}

// ── install ───────────────────────────────────────────────────────────────────

/**
 * `${XDG_BIN_HOME:-$HOME/.local/bin}` — the default install destination.
 *
 * Not a fleet home, deliberately: this is a directory on the user's PATH, not
 * a place the tool stores anything. The contract is "a shell finds an
 * executable here", which no tiered directory satisfies.
 */
export function defaultBinDir(env: Record<string, string | undefined> = process.env): string {
  const xdg = env['XDG_BIN_HOME']
  return xdg && xdg.length > 0 ? xdg : join(env['HOME'] ?? homedir(), '.local', 'bin')
}

export function isOnPath(
  dir: string,
  env: Record<string, string | undefined> = process.env,
): boolean {
  const raw = env['PATH']
  if (!raw) return false
  const target = resolvePath(dir)
  return raw.split(':').some((d) => d.length > 0 && resolvePath(d) === target)
}

/** The first `name` found on PATH, or null. */
export function findOnPath(
  name: string,
  env: Record<string, string | undefined> = process.env,
): string | null {
  const raw = env['PATH']
  if (!raw) return null
  for (const dir of raw.split(':')) {
    if (dir.length === 0) continue
    const candidate = join(dir, name)
    try {
      lstatSync(candidate)
      return candidate
    } catch {
      // keep looking
    }
  }
  return null
}

export type LinkStatus = 'created' | 'exists' | 'replaced'

export interface InstalledLink {
  name: string
  linkPath: string
  status: LinkStatus
}

export interface InstallResult {
  binDir: string
  /** The launcher every symlink points at (realpath). */
  target: string
  links: InstalledLink[]
  onPath: boolean
  dryRun: boolean
}

export interface InstallInput {
  /** The checkout whose launcher to install. Required: the caller knows where it runs from. */
  checkout: string
  binDir?: string | undefined
}

export function install(spec: ToolSpec, input: InstallInput, opts: OpOptions = {}): InstallResult {
  const env = opts.env ?? process.env
  const checkout = checkoutOrThrow(spec, input.checkout)
  const launcher = join(checkout, spec.launcher)
  let target: string
  try {
    target = realpathSync(launcher)
  } catch {
    throw new DevlinkError(`launcher not found: ${launcher}`)
  }
  const binDir = input.binDir ? resolvePath(input.binDir) : defaultBinDir(env)
  const dryRun = opts.dryRun ?? false

  const links: InstalledLink[] = []
  for (const name of pathNames(spec)) {
    const linkPath = join(binDir, name)
    links.push({ name, linkPath, status: placeSymlink(linkPath, target, dryRun) })
  }
  return { binDir, target, links, onPath: isOnPath(binDir, env), dryRun }
}

function placeSymlink(linkPath: string, target: string, dryRun: boolean): LinkStatus {
  let existing: Stats | null = null
  try {
    existing = lstatSync(linkPath)
  } catch {
    existing = null
  }
  if (existing === null) {
    if (!dryRun) {
      mkdirSync(join(linkPath, '..'), { recursive: true })
      symlinkSync(target, linkPath)
    }
    return 'created'
  }
  if (!existing.isSymbolicLink()) {
    throw new DevlinkError(
      `refusing to overwrite a non-symlink at ${linkPath} — move it aside first`,
    )
  }
  let pointsTo: string | null = null
  try {
    pointsTo = realpathSync(linkPath)
  } catch {
    pointsTo = null // broken symlink → replace
  }
  if (pointsTo === target) return 'exists'
  if (!dryRun) {
    unlinkSync(linkPath)
    symlinkSync(target, linkPath)
  }
  return 'replaced'
}

// ── link / use / off ──────────────────────────────────────────────────────────

export interface LinkResult {
  checkout: string
  entry: string
  homePath: string
  /** What the link was before, or null. */
  previous: string | null
  branch: string | null
  head: string | null
  wrote: boolean
  dryRun: boolean
}

export interface LinkInput {
  /**
   * The checkout to link. Default: the checkout above the cwd, else `self`.
   * A missing default is an error — there is nothing to link.
   */
  checkout?: string | undefined
  label?: string | undefined
}

function activate(
  spec: ToolSpec,
  event: 'link' | 'use',
  checkout: string,
  label: string | undefined,
  opts: OpOptions,
): LinkResult {
  const dryRun = opts.dryRun ?? false
  const previous = readActive(spec, opts)
  const { branch, head } = gitHead(checkout)
  if (!dryRun) {
    writeActive(spec, checkout, opts)
    const record: HistoryEvent = { at: stamp(opts), event, checkout, branch, head }
    if (label !== undefined) record.label = label
    appendHistory(spec, record, opts)
  }
  return {
    checkout,
    entry: join(checkout, entryOf(spec)),
    homePath: homePath(spec, opts),
    previous,
    branch,
    head,
    wrote: !dryRun,
    dryRun,
  }
}

export function link(spec: ToolSpec, input: LinkInput = {}, opts: OpOptions = {}): LinkResult {
  let checkout: string
  if (input.checkout !== undefined) {
    checkout = checkoutOrThrow(spec, input.checkout)
  } else {
    const above = cwdCheckout(spec, opts.cwd ?? process.cwd()) ?? opts.self ?? null
    if (above === null) {
      throw new DevlinkError(
        `no checkout to link: not inside a ${spec.name} checkout — pass a path`,
      )
    }
    checkout = checkoutOrThrow(spec, above)
  }
  return activate(spec, 'link', checkout, input.label, opts)
}

export interface OffResult {
  homePath: string
  /** The link that was cleared, or null when none was set. */
  previous: string | null
  wrote: boolean
  dryRun: boolean
}

export function off(spec: ToolSpec, opts: OpOptions = {}): OffResult {
  const dryRun = opts.dryRun ?? false
  const previous = readActive(spec, opts)
  if (!dryRun) {
    clearActive(spec, opts)
    if (previous !== null) {
      appendHistory(spec, { at: stamp(opts), event: 'off', checkout: null }, opts)
    }
  }
  return { homePath: homePath(spec, opts), previous, wrote: !dryRun, dryRun }
}

export type UseResult = ({ kind: 'checkout' } & LinkResult) | ({ kind: 'canonical' } & OffResult)

export interface UseInput {
  /**
   * `canonical` (or `off`) clears the link. `#n` or a bare integer picks the
   * n-th entry of `history` (1 = most recent). Anything else is a checkout path.
   */
  target: string
  label?: string | undefined
}

export function use(spec: ToolSpec, input: UseInput, opts: OpOptions = {}): UseResult {
  const target = input.target.trim()
  if (target === 'canonical' || target === 'off') {
    return { kind: 'canonical', ...off(spec, opts) }
  }
  const indexMatch = /^#?(\d+)$/.exec(target)
  if (indexMatch !== null) {
    const index = Number(indexMatch[1])
    const entries = history(spec, opts)
    const hit = entries.find((e) => e.index === index)
    if (hit === undefined) {
      throw new DevlinkError(
        entries.length === 0
          ? `history is empty — link a checkout first`
          : `no history entry #${index} (1..${entries.length})`,
      )
    }
    if (!hit.valid) {
      throw new DevlinkError(`history entry #${index} is no longer a checkout: ${hit.checkout}`)
    }
    return { kind: 'checkout', ...activate(spec, 'use', hit.checkout, input.label, opts) }
  }
  return {
    kind: 'checkout',
    ...activate(spec, 'use', checkoutOrThrow(spec, target), input.label, opts),
  }
}

// ── history ───────────────────────────────────────────────────────────────────

export interface HistoryEntry {
  /** 1 = most recently selected. */
  index: number
  checkout: string
  /** True when the directory still carries the marker. */
  valid: boolean
  /** True when this is the link on disk right now. */
  active: boolean
  /** The most recent event that selected it. */
  lastEvent: 'link' | 'use'
  lastAt: string
  /** Recorded at the most recent selection. */
  branch: string | null
  head: string | null
  label: string | null
  /** How many times it has been selected. */
  times: number
}

/** Every checkout ever linked, most recently selected first, one row per path. */
export function history(spec: ToolSpec, opts: OpOptions = {}): HistoryEntry[] {
  const active = readActive(spec, opts)
  const byPath = new Map<string, HistoryEntry>()
  const events = readHistory(spec, opts)
  for (let i = events.length - 1; i >= 0; i--) {
    const e = events[i] as HistoryEvent
    if (e.event === 'off' || e.checkout === null) continue
    const key = resolvePath(e.checkout)
    const seen = byPath.get(key)
    if (seen !== undefined) {
      seen.times += 1
      continue
    }
    byPath.set(key, {
      index: byPath.size + 1,
      checkout: e.checkout,
      valid: isCheckout(spec, e.checkout),
      active: active !== null && samePath(active, e.checkout),
      lastEvent: e.event,
      lastAt: e.at,
      branch: e.branch ?? null,
      head: e.head ?? null,
      label: e.label ?? null,
      times: 1,
    })
  }
  return [...byPath.values()]
}

// ── status ────────────────────────────────────────────────────────────────────

export interface StatusResult {
  selection: Selection
  env: { var: string; value: string | null }
  cwd: { var: string; checkout: string | null; suppressed: boolean }
  link: { path: string; value: string | null; valid: boolean; suppressed: boolean }
  /** The launcher's own checkout, when it has one. */
  self: string | null
  history: { path: string; entries: number }
  path: { names: Array<{ name: string; found: string | null }> }
}

export function status(spec: ToolSpec, opts: OpOptions = {}): StatusResult {
  const env = opts.env ?? process.env
  const cwd = opts.cwd ?? process.cwd()
  const isSuppressed = suppressed(spec, env)
  const linked = readActive(spec, opts)
  return {
    selection: resolve(spec, opts),
    env: { var: homeVar(spec), value: env[homeVar(spec)] ?? null },
    cwd: {
      var: cwdDevVar(spec),
      checkout: cwdCheckout(spec, cwd),
      suppressed: isSuppressed || env[cwdDevVar(spec)] === '0',
    },
    link: {
      path: homePath(spec, opts),
      value: linked,
      valid: linked !== null && isCheckout(spec, linked),
      suppressed: isSuppressed,
    },
    self: opts.self ?? null,
    history: { path: historyPath(spec, opts), entries: history(spec, opts).length },
    path: { names: pathNames(spec).map((name) => ({ name, found: findOnPath(name, env) })) },
  }
}
