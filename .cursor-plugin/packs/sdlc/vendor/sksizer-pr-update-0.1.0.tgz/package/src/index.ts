/**
 * `@sksizer/pr-update` — survey and update out-of-date, stacked pull
 * requests, as a library. A host (sdlc's own `pr survey`/`pr update` ops, or
 * anything else) builds a `PrUpdateConfig` and a `Ports` and calls
 * `runSurvey`/`runUpdate` directly; the `pr-update` binary (`src/cli.ts`) is
 * one particular host, not a required layer in front of these.
 */

export { prUpdateConfigSchema, DEFAULT_PR_UPDATE_CONFIG, type PrUpdateConfig } from './config.ts'
export { ConfigFileError, loadConfigFile } from './config-file.ts'
export { standalonePorts } from './defaults.ts'
export type { Ports, RunVerb } from './ports.ts'

export {
  branchMatchesGlob,
  chooseStrategy,
  matchOverride,
  type Strategy,
  type StrategyDecision,
  type StrategySignals,
} from './strategy.ts'

export {
  measure,
  nearestBehindAncestor,
  num,
  parentEdges,
  renderSurveyText,
  resolveTargets,
  runSurvey,
  statusFor,
  surveyRows,
  topoOrder,
  unpushedLocalWork,
  SCOPE_SHAPE,
  row as surveyRowSchema,
  output as surveyOutputSchema,
  type MergePrediction,
  type RepoTarget,
  type SurveyArgs,
  type SurveyEnv,
  type SurveyReport,
  type SurveyRow,
  type SurveyStatus,
} from './survey.ts'

export {
  applyStrategyOverride,
  renderUpdateText,
  runUpdate,
  selectTargets,
  toResult,
  input as updateInputSchema,
  output as updateOutputSchema,
  result as updateResultSchema,
  type SkippedPr,
  type UpdateArgs,
  type UpdateEnv,
  type UpdateOutput,
} from './update.ts'

export {
  describeOutcome,
  isStalePush,
  tally,
  updateAll,
  updateOne,
  WORK_BRANCH,
  type UpdateOutcome,
  type UpdateResult,
  type UpdateSettings,
  type UpdateTarget,
} from './update/execute.ts'

export {
  isLockfile,
  matchRegenerate,
  planPaths,
  rebuildVerbs,
  unclaimed,
  type PathPlan,
  type RegenerateRule,
  type ResolverKind,
} from './update/resolvers.ts'

// `./update/tui.tsx` is deliberately NOT re-exported here: a static export
// from this barrel would make every consumer of the package pay for Ink and
// React on import, which is exactly what `update.ts`'s own dynamic
// `await import('./update/tui.tsx')` (inside `runUpdate`'s `--interactive`
// path) exists to avoid. It has no package export of its own — it is
// reached only through that dynamic import, never imported directly.
