/**
 * `PrUpdateConfig` — everything `survey`/`update` read to decide scope and
 * strategy, standalone from any host's own config file.
 *
 * Mirrors sdlc's `pr_update:` block field-for-field (including every
 * default), because sdlc's own `sdlc pr survey`/`sdlc pr update` are thin
 * wrappers over this package and must behave identically to before the
 * extraction — a value read from `sdlc.yaml` and handed to `runSurvey`/
 * `runUpdate` here must mean exactly what it meant inline.
 *
 * Zod-backed (not a plain interface) because a standalone run also loads this
 * from a `.pr-update.yaml` file — see `loadConfigFile` — and every key needs
 * the same default whichever way it arrives, so the verb works with no config
 * file at all.
 */

import { z } from 'zod'

export const prUpdateConfigSchema = z.object({
  author: z
    .string()
    .trim()
    .min(1)
    .nullable()
    .default(null)
    .describe(
      "Only survey/update PRs by this author. `@me` is gh's own token for the authenticated user. Null (the default) means every author.",
    ),
  include_drafts: z.boolean().default(true).describe('Whether draft PRs are surveyed and updated.'),
  strategy: z
    .enum(['rebase', 'merge'])
    .default('rebase')
    .describe(
      "How an out-of-date branch is brought up to date. `rebase` (default) keeps each PR's history linear; `merge` never rewrites history.",
    ),
  overrides: z
    .array(
      z.object({
        base: z
          .string()
          .trim()
          .min(1)
          .optional()
          .describe("Glob matched against the PR's base branch name."),
        label: z.string().trim().min(1).optional().describe('Exact PR label name.'),
        strategy: z
          .enum(['rebase', 'merge', 'skip'])
          .describe('What to do when this rule matches.'),
      }),
    )
    .default([])
    .describe(
      'Per-PR strategy overrides, first match wins. Beats the `reviewed`/`max_rebase_commits` guards; does NOT beat `unpushed_local`.',
    ),
  guards: z
    .object({
      unpushed_local: z
        .enum(['skip', 'merge'])
        .default('skip')
        .describe(
          'What to do when the head branch is checked out in another worktree holding commits the remote does not have. Non-negotiable — no override defeats it.',
        ),
      reviewed: z
        .enum(['merge', 'rebase'])
        .default('merge')
        .describe('What to do when a PR carries at least one submitted review.'),
      max_rebase_commits: z
        .number()
        .int()
        .min(0)
        .default(20)
        .describe(
          'Above this many commits ahead of base, fall back to `merge`. 0 disables the guard.',
        ),
    })
    .prefault({})
    .describe(
      'Automatic step-downs from `rebase` to `merge` (or `skip`). Only ever step down; never turn a configured `merge` into a rebase.',
    ),
  lockfile_install: z
    .string()
    .trim()
    .min(1)
    .nullable()
    .default(null)
    .describe(
      'Shell verb that rebuilds lockfiles from their manifests, run in the update worktree. Null (the default) leaves a lockfile conflict for a human.',
    ),
  resolvers: z
    .array(
      z.object({
        paths: z
          .array(z.string().trim().min(1))
          .min(1)
          .describe('Globs matched against each conflicted path, repo-relative.'),
        run: z
          .string()
          .trim()
          .min(1)
          .describe('Shell verb that rebuilds the artifact, run in the update worktree.'),
      }),
    )
    .default([])
    .describe('Project-specific conflict resolvers for generated artifacts, first match wins.'),
  verify: z
    .enum(['none', 'check'])
    .default('none')
    .describe(
      'What must pass before an updated branch is pushed. `none` (default) — CI on the PR is the real gate. `check` runs the caller-resolved verify verb list, trust-gated by the host.',
    ),
})

export type PrUpdateConfig = z.infer<typeof prUpdateConfigSchema>

/** Every key at its built-in default — the verb works with no config at all. */
export const DEFAULT_PR_UPDATE_CONFIG: PrUpdateConfig = prUpdateConfigSchema.parse({})
