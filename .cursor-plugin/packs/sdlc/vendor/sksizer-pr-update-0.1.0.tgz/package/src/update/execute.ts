/**
 * Bringing one PR up to date, and a run of them.
 *
 * The shape is dictated by two facts about updating many PRs at once.
 *
 * **One worktree, reused.** A checkout of a monorepo is expensive and doing it
 * per PR is not affordable at fifty. So the run creates one ephemeral worktree
 * and resets it between PRs. Nothing here ever touches the user's checkout:
 * the branch we work on is a single run-scoped name repointed with `checkout
 * -B`, never the PR's own branch. That matters beyond tidiness — a PR's branch
 * may be checked out in somebody's live worktree, and git refuses to check out
 * the same branch twice. Working on a scratch branch and pushing `HEAD:<head>`
 * sidesteps the question entirely.
 *
 * **One stuck PR must not end the run.** Every failure mode is a recorded
 * outcome, never a throw: a conflict nothing claims, a rebuild verb that
 * fails, a push rejected by a concurrent update. The run continues and the
 * report says what happened to each PR. The alternative — stopping at the
 * first hard PR — means the easy forty-nine never get updated.
 *
 * Order matters and comes from the caller: a stack must be updated
 * parent-first, because updating a child before its parent is work that has
 * to be redone the moment the parent moves.
 *
 * Nothing is written without `apply`. A dry run walks the same code, predicts
 * the same conflicts, and pushes nothing.
 */

import { CommandFailed, Git } from '@sksizer/easy-git'

import type { CommandResult } from '@sksizer/command-seam'
import {
  planPaths,
  rebuildVerbs,
  unclaimed,
  type PathPlan,
  type RegenerateRule,
} from './resolvers.ts'

/**
 * The scratch branch every PR is built on. Never a PR's own branch.
 *
 * Renamed off the pre-extraction `sdlc/pr-update` (this package's old home
 * inside sdlc's own tree) — a standalone package run against an arbitrary
 * repository should not leave a branch name behind that presumes its host.
 */
export const WORK_BRANCH = 'pr-update/scratch'

/** Runs one shell verb in `cwd`. The seam tests drive instead of a subprocess. */
export type RunVerb = (verb: string, cwd: string) => CommandResult

/** What the executor needs to know about one PR. Gathered by the survey. */
export interface UpdateTarget {
  number: number
  head: string
  base: string
  /**
   * The head sha as observed when the run started. A rebase force-push is
   * pinned to it, so a PR somebody pushed to mid-run is rejected rather than
   * overwritten.
   */
  headOid: string | null
  strategy: 'rebase' | 'merge'
}

export interface UpdateSettings {
  remote: string
  resolvers: readonly RegenerateRule[]
  lockfileInstall: string | null
  /** Shell verbs that must pass before a push. Empty means push unverified. */
  verifyVerbs: readonly string[]
}

/** How one PR's update ended. Every arm is a report, never an exception. */
export type UpdateOutcome =
  | { status: 'up-to-date' }
  | { status: 'updated'; resolved: PathPlan[]; pushed: boolean }
  | { status: 'conflict'; needsHuman: { path: string; why: string }[] }
  | { status: 'failed'; reason: string }

export interface UpdateResult extends UpdateTarget {
  outcome: UpdateOutcome
}

/**
 * A push rejection caused by the remote having moved, not by anything wrong
 * with what we built. Worth reporting distinctly: the answer is to re-run,
 * not to go and look at the branch.
 */
export function isStalePush(stderr: string): boolean {
  return (
    /\brejected\b/i.test(stderr) &&
    /(non-fast-forward|fetch first|stale info|cannot lock ref)/i.test(stderr)
  )
}

function failureText(e: unknown): string {
  if (e instanceof CommandFailed) {
    const err = e.result.stderr.trim()
    return err === ''
      ? e.result.stdout.trim().split('\n')[0] || 'command failed'
      : err.split('\n')[0]!
  }
  return e instanceof Error ? e.message : String(e)
}

/**
 * The conflicted paths git itself reports, which is the authoritative list.
 *
 * An integration outcome's own `conflicts` is a best-effort read of a
 * translatable message and has no parseable form for rename/rename, so it is
 * useful for a report and not for a decision.
 */
function conflictedPaths(git: Git): string[] {
  return git.diffNameOnly({ diffFilter: 'U' })
}

/**
 * Update one PR in an already-prepared worktree.
 *
 * The caller owns the worktree's lifetime; this owns what happens inside it
 * for one PR, including leaving it clean enough for the next one. A caught
 * failure always aborts the in-progress merge or rebase, because a worktree
 * left mid-integration would corrupt every PR after it.
 */
export function updateOne(
  git: Git,
  target: UpdateTarget,
  settings: UpdateSettings,
  runVerb: RunVerb,
  opts: { apply: boolean; worktree: string },
): UpdateOutcome {
  const base = `${settings.remote}/${target.base}`
  const head = `${settings.remote}/${target.head}`

  try {
    git.checkout(head, { branch: WORK_BRANCH, resetBranch: true, force: true })
  } catch (e) {
    return { status: 'failed', reason: `checkout ${head}: ${failureText(e)}` }
  }

  // Nothing to do is the common answer in a run over every open PR, and it
  // must cost nothing: no integration, no rebuild, no push.
  const counts = git.try.aheadBehind(base, 'HEAD')
  if (counts.ok && counts.value.behind === 0) return { status: 'up-to-date' }

  let outcome
  try {
    outcome =
      target.strategy === 'rebase' ? git.rebase(base, { autostash: false }) : git.merge(base)
  } catch (e) {
    abortIntegration(git, target.strategy)
    return { status: 'failed', reason: `${target.strategy} ${base}: ${failureText(e)}` }
  }

  const resolved: PathPlan[] = []
  if (outcome.status === 'conflict') {
    const paths = conflictedPaths(git)
    // An empty list after a reported conflict means rerere replayed a
    // resolution recorded earlier in this run. The tree is already correct.
    const plans =
      paths.length === 0 ? [] : planPaths(paths, settings.resolvers, settings.lockfileInstall)
    const needsHuman = unclaimed(plans)
    if (needsHuman.length > 0) {
      abortIntegration(git, target.strategy)
      return { status: 'conflict', needsHuman }
    }
    const failure = applyResolution(git, plans, runVerb, opts.worktree, target)
    if (failure !== null) {
      abortIntegration(git, target.strategy)
      return { status: 'failed', reason: failure }
    }
    resolved.push(...plans)
  }

  for (const verb of settings.verifyVerbs) {
    const res = runVerb(verb, opts.worktree)
    if (res.exitCode !== 0) {
      abortIntegration(git, target.strategy)
      return {
        status: 'failed',
        reason: `verify \`${verb}\` failed: ${res.stderr.trim().split('\n')[0] ?? ''}`,
      }
    }
  }

  if (!opts.apply) return { status: 'updated', resolved, pushed: false }

  try {
    pushUpdate(git, target, settings)
  } catch (e) {
    const reason =
      e instanceof CommandFailed && isStalePush(e.result.stderr)
        ? `push rejected — ${target.head} moved since the run started; re-run`
        : `push ${target.head}: ${failureText(e)}`
    return { status: 'failed', reason }
  }
  return { status: 'updated', resolved, pushed: true }
}

/**
 * Push the work branch onto the PR's own branch.
 *
 * A rebase rewrote history, so it needs `--force-with-lease` pinned to the sha
 * observed at the start of the run. The bare `--force-with-lease` would not
 * do: it compares against the remote-tracking ref this process just fetched,
 * which is exactly the value a mid-run push by someone else would have
 * updated. Pinning to the observed sha is what makes the lease mean "nobody
 * has touched this since I looked".
 *
 * Without a known sha there is nothing to pin to, and a force-push with no
 * lease is not something to do on someone's behalf — so it is refused.
 */
function pushUpdate(git: Git, target: UpdateTarget, settings: UpdateSettings): void {
  const refspec = `HEAD:refs/heads/${target.head}`
  if (target.strategy !== 'rebase') {
    git.push(settings.remote, refspec)
    return
  }
  if (target.headOid === null) {
    throw new Error(`refusing to force-push ${target.head} without a known head sha to pin to`)
  }
  git.push(settings.remote, refspec, {
    forceWithLease: `refs/heads/${target.head}:${target.headOid}`,
  })
}

/**
 * Run each rebuild verb, stage the result, and finish the integration.
 *
 * Returns a reason on failure, null on success — the caller aborts on a
 * reason, so this never leaves a half-resolved tree behind.
 */
function applyResolution(
  git: Git,
  plans: readonly PathPlan[],
  runVerb: RunVerb,
  worktree: string,
  target: UpdateTarget,
): string | null {
  // Give the rebuild a tree it can read: a file with conflict markers in it is
  // not valid input to a generator or a package manager. Either side works
  // because the rebuild overwrites the content anyway; `--ours` is the side
  // that already exists on the branch.
  const paths = plans.filter((p) => p.kind !== 'unclaimed').map((p) => p.path)
  if (paths.length > 0) {
    try {
      git.checkoutSide('ours', paths)
    } catch (e) {
      return `staging conflicted paths: ${failureText(e)}`
    }
  }

  for (const verb of rebuildVerbs(plans)) {
    const res = runVerb(verb, worktree)
    if (res.exitCode !== 0) {
      return `resolver \`${verb}\` failed: ${res.stderr.trim().split('\n')[0] ?? ''}`
    }
  }

  try {
    // `.` and not the conflicted paths alone: a generator legitimately rewrites
    // files beyond the ones that conflicted, and leaving those unstaged would
    // commit a half-regenerated tree. The pathspec is safe because the worktree
    // is ephemeral and held nothing but this integration.
    git.add(['.'])
    finishIntegration(git, target)
  } catch (e) {
    return `committing the resolution: ${failureText(e)}`
  }
  return null
}

/**
 * Conclude a resolved integration.
 *
 * A rebase continues; a merge is committed. `noVerify` because the project's
 * gate is `verify:`'s business, run once per PR under the caller's control —
 * git would otherwise fire the commit hooks here and nowhere else, which is a
 * gate whose scope is an accident of which strategy was chosen.
 */
function finishIntegration(git: Git, target: UpdateTarget): void {
  if (target.strategy === 'rebase') {
    git.rebaseContinue()
    return
  }
  git.commit({
    message: `Merge ${target.base} into ${target.head}`,
    body: 'Conflicts resolved by rebuilding the generated artifacts.',
    noVerify: true,
  })
}

/** Leave no integration in progress, whatever happened. */
function abortIntegration(git: Git, strategy: 'rebase' | 'merge'): void {
  if (strategy === 'rebase') git.try.rebaseAbort()
  else git.try.mergeAbort()
}

/** One PR's outcome as a short line for a report. */
export function describeOutcome(o: UpdateOutcome): string {
  switch (o.status) {
    case 'up-to-date':
      return 'already up to date'
    case 'updated':
      return o.pushed
        ? `updated${o.resolved.length > 0 ? ` (resolved ${o.resolved.length})` : ''}`
        : 'would update'
    case 'conflict':
      return `needs a human: ${o.needsHuman.map((c) => `${c.path} (${c.why})`).join(', ')}`
    case 'failed':
      return o.reason
  }
}

/**
 * Update a list of PRs in one ephemeral worktree.
 *
 * `targets` must already be in dependency order — the survey's topological
 * sort — because a stack updated child-first is work that gets redone.
 *
 * The worktree is created detached at the first target's base and torn down
 * in a `finally`, so an exception anywhere still leaves no stray checkout and
 * no registered worktree behind. The scratch branch is deleted with it.
 */
export function updateAll(
  git: Git,
  targets: readonly UpdateTarget[],
  settings: UpdateSettings,
  runVerb: RunVerb,
  opts: { apply: boolean; worktreeRoot: string; onResult?: (r: UpdateResult) => void },
): UpdateResult[] {
  const results: UpdateResult[] = []
  if (targets.length === 0) return results

  const start = `${settings.remote}/${targets[0]!.base}`
  git.worktreeAdd(opts.worktreeRoot, { detach: true, startPoint: start })
  const wt = git.at(opts.worktreeRoot)
  try {
    for (const target of targets) {
      const outcome = updateOne(wt, target, settings, runVerb, {
        apply: opts.apply,
        worktree: opts.worktreeRoot,
      })
      const result = { ...target, outcome }
      results.push(result)
      // Streamed rather than returned only at the end: a run over fifty PRs
      // takes minutes, and a caller rendering progress needs each one as it
      // lands.
      opts.onResult?.(result)
    }
  } finally {
    // Order matters: the scratch branch is checked out in the worktree, and
    // git refuses to delete a branch some worktree holds. Removing the
    // worktree releases it. Each step is `try` so a failure in one still
    // leaves the others to run — a stray worktree is worse than a stray
    // branch, and both are worse than an exception here masking the real one.
    git.try.worktreeRemove(opts.worktreeRoot, { force: true })
    git.try.worktreePrune()
    git.try.deleteBranch(WORK_BRANCH, { force: true })
  }
  return results
}

/** Run-level totals, for the closing line of a report. */
export function tally(results: readonly UpdateResult[]): Record<string, number> {
  const counts = { updated: 0, 'up-to-date': 0, conflict: 0, failed: 0 }
  for (const r of results) counts[r.outcome.status] += 1
  return counts
}
