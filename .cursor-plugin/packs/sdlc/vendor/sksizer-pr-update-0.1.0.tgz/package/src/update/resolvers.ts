/**
 * Resolving a conflict without asking anyone.
 *
 * Most conflicts in a repository that regenerates artifacts are not judgement
 * calls. Measured over the last 400 merges here, the conflicted files are
 * dominated by lockfiles and generated output — files nobody edits by hand and
 * whose correct content is whatever the generator says it is. For those the
 * answer is mechanical: take a side to get a tree, re-run the tool, stage what
 * it wrote.
 *
 * That is the whole idea of the ladder. Each rung claims paths it knows how to
 * rebuild, and a rung that claims a path owns the result. A conflict no rung
 * claims is left alone — an update that guessed at a source file would be
 * worse than one that reported it needed a human.
 *
 * The rungs, in order:
 *
 *   0. **rerere** — git replayed a resolution recorded earlier in this run.
 *      Free, and the reason a stack of siblings sharing a base costs one
 *      resolution rather than one per PR.
 *   1. **lockfile** — recognized built in, because every ecosystem has one and
 *      the resolution is always the same shape: take a side, re-derive from
 *      the merged manifest. The re-derivation needs a command only the host
 *      knows (`PrUpdateConfig.lockfile_install`); without one the path is left
 *      unclaimed rather than resolved to a lockfile that disagrees with its
 *      own manifest.
 *   2. **regenerate** — `PrUpdateConfig.resolvers`. A host's own codegen
 *      (`docs/index.md`, say) lives in that config, not in this file: this
 *      package is a reusable product and a consumer's own codegen is not its
 *      business.
 *
 * The judgement rung is deliberately absent. It belongs behind an explicit
 * opt-in and has its own guardrails; until it exists, an unclaimed conflict
 * ends the attempt for that PR and the run moves on.
 */

import { branchMatchesGlob } from '../strategy.ts'

/** Which rung resolved a path, recorded so every outcome is auditable. */
export type ResolverKind = 'rerere' | 'lockfile' | 'regenerate'

/**
 * Lockfiles, by exact basename.
 *
 * Matching on basename rather than a full path is deliberate: a monorepo has
 * one per workspace and they are all equally derived.
 *
 * `go.sum` is here for the same reason even though it is append-only: its
 * conflicts are two independent additions, and `go mod tidy` is the arbiter.
 */
const LOCKFILES = new Set([
  'bun.lock',
  'bun.lockb',
  'Cargo.lock',
  'composer.lock',
  'Gemfile.lock',
  'go.sum',
  'package-lock.json',
  'pnpm-lock.yaml',
  'poetry.lock',
  'uv.lock',
  'yarn.lock',
])

/** True when `path` is a lockfile any ecosystem would regenerate. */
export function isLockfile(path: string): boolean {
  const base = path.slice(path.lastIndexOf('/') + 1)
  return LOCKFILES.has(base)
}

/** A configured `paths` → `run` rule from `PrUpdateConfig.resolvers`. */
export interface RegenerateRule {
  paths: readonly string[]
  run: string
}

/** The first configured rule claiming `path`, or null. */
export function matchRegenerate(
  path: string,
  rules: readonly RegenerateRule[],
): RegenerateRule | null {
  for (const rule of rules) {
    if (rule.paths.some((p) => branchMatchesGlob(p, path))) return rule
  }
  return null
}

/** What to do about one conflicted path. */
export type PathPlan =
  | { kind: 'lockfile'; path: string; run: string }
  | { kind: 'regenerate'; path: string; run: string }
  | { kind: 'unclaimed'; path: string; why: string }

/**
 * Assign every conflicted path to a rung.
 *
 * Lockfiles are checked before the configured rules so a project cannot
 * accidentally shadow the built-in with a broad `**` glob — and so that the
 * common case needs no configuration at all.
 */
export function planPaths(
  conflicts: readonly string[],
  rules: readonly RegenerateRule[],
  lockfileInstall: string | null,
): PathPlan[] {
  return conflicts.map((path): PathPlan => {
    if (isLockfile(path)) {
      // Taking a side without re-deriving would push a lockfile that
      // disagrees with its own manifest — worse than not updating at all.
      return lockfileInstall === null
        ? { kind: 'unclaimed', path, why: 'lockfile, but no lockfile_install configured' }
        : { kind: 'lockfile', path, run: lockfileInstall }
    }
    const rule = matchRegenerate(path, rules)
    return rule === null
      ? { kind: 'unclaimed', path, why: 'no resolver claims it' }
      : { kind: 'regenerate', path, run: rule.run }
  })
}

/**
 * The distinct shell verbs a plan needs, in first-seen order.
 *
 * One rule usually claims several paths — `docs/index.md` and
 * `docs/glossary.md` are both `sdlc docs generate`, every lockfile in a
 * workspace is one `bun install` — and running a generator once per file it
 * owns would be wasted work and, for a tool that rewrites a whole directory,
 * actively misleading.
 */
export function rebuildVerbs(plans: readonly PathPlan[]): string[] {
  const seen = new Set<string>()
  const out: string[] = []
  for (const p of plans) {
    if (p.kind === 'unclaimed' || seen.has(p.run)) continue
    seen.add(p.run)
    out.push(p.run)
  }
  return out
}

/** Paths no rung claimed, with why. Non-empty means the PR needs a human. */
export function unclaimed(plans: readonly PathPlan[]): { path: string; why: string }[] {
  return plans
    .filter((p): p is Extract<PathPlan, { kind: 'unclaimed' }> => p.kind === 'unclaimed')
    .map((p) => ({ path: p.path, why: p.why }))
}
