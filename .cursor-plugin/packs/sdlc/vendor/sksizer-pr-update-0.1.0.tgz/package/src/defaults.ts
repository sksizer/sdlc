/**
 * The `Ports` a standalone `pr-update` run supplies for itself, with no host
 * (like sdlc's own repo registry or trust store) in front of it.
 *
 * A library consumer builds its own `Ports` instead — sdlc's thin wrapper ops
 * bind `locate` to `locateRepo`/`repoContainers`, `runVerb` to
 * `shellArmExec`, and `resolveVerifyVerbs` to `resolveWorkflowCommands`/
 * `requireTrustedVerbs`, none of which this package depends on.
 */

import { spawnRunner } from '@sksizer/command-seam'

import type { Ports } from './ports.ts'

/**
 * A standalone run has no repository registry to scan, so `--repo` naming
 * anything other than the local checkout always comes back unmeasurable —
 * honest, since there is nothing here to guess a path from.
 */
export function standalonePorts(): Ports {
  return {
    locate: () => null,
    runVerb: (verb, cwd) => spawnRunner('sh').run(['-c', verb], { cwd }),
    resolveVerifyVerbs() {
      // `verify: check` names a host-resolved verb list (sdlc's own
      // `workflows.check`, trust-gated); a standalone run has no such registry
      // and no trust store to gate one with. Failing loudly here beats
      // silently running zero verbs and reporting a push as verified when it
      // was not checked at all.
      throw new Error(
        'verify: check has no meaning in a standalone run — embed @sksizer/pr-update as a ' +
          "library and supply Ports.resolveVerifyVerbs, or set verify: 'none'",
      )
    },
  }
}
