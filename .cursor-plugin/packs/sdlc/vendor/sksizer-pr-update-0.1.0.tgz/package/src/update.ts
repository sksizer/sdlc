/**
 * `pr-update update` — bring out-of-date PRs up to date.
 *
 * The plan comes from `survey`, called directly rather than reimplemented, so
 * what this applies is exactly what that reports. Rows arrive in stack order
 * and are applied in it: a stack updated child-first is work that gets redone
 * the moment the parent moves.
 *
 * **Nothing is written without `apply`.** A bare invocation walks the whole
 * path — checkout, integrate, resolve — and pushes nothing, so the report
 * tells you which PRs would conflict before you have touched a remote. That
 * is the default because the failure mode of this verb is a bad force-push,
 * and a default that could cause one would be wrong.
 *
 * What is skipped, and why it is skipped rather than attempted:
 *
 *   - `strategy: skip` — the strategy guards already decided. A branch with
 *     unpushed work in somebody's worktree, or a fork we cannot push to.
 *   - `status: blocked` — its base is another PR that is itself behind.
 *     Updating it now integrates a base about to move.
 *   - `status: unknown` — drift could not be measured, so there is no
 *     evidence an update is wanted.
 *
 * `verify: check` runs the host-resolved `verifyVerbs` (see `Ports`) before a
 * push — trust-gating a project-sourced verb list is the host's business, not
 * this package's; `ports.resolveVerifyVerbs` is where that decision lives.
 */

import { join } from 'node:path'

import { z } from 'zod'

import { Git } from '@sksizer/easy-git'

import {
  describeOutcome,
  tally,
  updateAll,
  type UpdateResult,
  type UpdateTarget,
} from './update/execute.ts'
import { SCOPE_SHAPE, runSurvey, type SurveyEnv, type SurveyReport } from './survey.ts'
import type { Ports } from './ports.ts'
import type { PrUpdateConfig } from './config.ts'

/**
 * Show the checklist and run what the user ticks.
 *
 * Imported lazily so the Ink and React trees are only paid for when somebody
 * actually asks for a terminal UI — every other invocation of this op, and
 * every other op in the binary, never loads them.
 */
async function runChecklist(
  targets: readonly UpdateTarget[],
  skipped: readonly SkippedPr[],
  report: SurveyReport,
  run: (chosen: readonly UpdateTarget[], onResult?: (r: UpdateResult) => void) => UpdateResult[],
): Promise<UpdateResult[]> {
  if (!process.stdout.isTTY) {
    throw new Error('--interactive needs a terminal; use --apply for an unattended run')
  }
  const { render } = await import('ink')
  const { UpdateTui, toRows } = await import('./update/tui.tsx')
  const { createElement } = await import('react')

  const meta = new Map(report.prs.map((r) => [r.number, { base: r.base, behind: r.behind }]))
  const rows = toRows(targets, skipped, meta)
  const byNumber = new Map(targets.map((t) => [t.number, t]))

  return await new Promise<UpdateResult[]>((resolve) => {
    const app = render(
      createElement(UpdateTui, {
        rows,
        // The executor is synchronous and would block the render loop, so it
        // runs on a later tick: the checklist repaints into its "running"
        // state before git starts, rather than after the whole run is over.
        apply: (numbers, onResult) =>
          new Promise((done) => {
            setTimeout(() => {
              const chosen = numbers
                .map((n) => byNumber.get(n))
                .filter((t): t is UpdateTarget => t !== undefined)
              done(run(chosen, onResult))
            }, 0)
          }),
        onDone: (results) => resolve(results),
      }),
    )
    void app.waitUntilExit()
  })
}

/** A row the run declined to touch, and the reason, so nothing is silently dropped. */
export interface SkippedPr {
  number: number
  head: string
  reason: string
}

/**
 * Split the survey into what this run will act on and what it will not.
 *
 * Every row lands in exactly one list, AND every number `only` (`--pr`)
 * named lands somewhere too, even one the survey never reported (a typo, or
 * a PR that closed between the survey and this run) — it gets a synthetic
 * `skipped` entry rather than vanishing. A PR that quietly disappeared would
 * be the worst outcome here: the reader would assume it was fine.
 */
export function selectTargets(
  report: SurveyReport,
  only: readonly number[],
): { targets: UpdateTarget[]; skipped: SkippedPr[] } {
  const wanted = new Set(only)
  const seen = new Set<number>()
  const targets: UpdateTarget[] = []
  const skipped: SkippedPr[] = []

  for (const row of report.prs) {
    seen.add(row.number)
    const note = (reason: string): void => {
      skipped.push({ number: row.number, head: row.head, reason })
    }
    if (wanted.size > 0 && !wanted.has(row.number)) {
      // `note`, not a bare `continue`: a PR this run's own `--pr` scope
      // excludes is still a row the survey reported, and the doc comment
      // above (and the `skipped` schema's own description) both promise
      // every surveyed PR lands in `targets` or here — a PR that vanished
      // from both because `--pr` named other numbers would be exactly the
      // silent-disappearance case this function exists to rule out.
      note('not selected by --pr')
      continue
    }
    // The output schema types `strategy` as a plain string; only these two
    // are executable, and narrowing here is what makes that true downstream.
    if (row.strategy !== 'rebase' && row.strategy !== 'merge') {
      note(row.strategyReason)
    } else if (row.status === 'blocked') note(`blocked on #${row.blockedBy ?? '?'}`)
    else if (row.status === 'unknown') note('drift could not be measured')
    else if (row.status === 'up-to-date') note('already up to date')
    else {
      targets.push({
        number: row.number,
        head: row.head,
        base: row.base,
        headOid: row.headOid,
        strategy: row.strategy,
      })
    }
  }
  // A `--pr` number the survey never reported (a typo, or a PR that closed
  // between survey and this run) would otherwise vanish with no mention at
  // all — the loop above only ever sees `report.prs`'s own rows, so a wanted
  // number outside that set never reaches `note()`. Same invariant as the
  // rest of this function: every number this run was asked about ends up
  // somewhere, not silently dropped.
  for (const number of wanted) {
    if (!seen.has(number)) skipped.push({ number, head: '', reason: 'not found in survey' })
  }
  return { targets, skipped }
}

export const input = z.object({
  ...SCOPE_SHAPE,
  apply: z
    .boolean()
    .default(false)
    .describe(
      'Actually update the PRs. Without it the run rehearses everything — checkout, integration, conflict resolution — and pushes nothing, which is how you find out what would conflict before touching a remote.',
    ),
  interactive: z
    .boolean()
    .default(false)
    .describe(
      'Choose which PRs to update from a checklist, then watch them run. Implies --apply for the rows you tick — the checklist IS the confirmation, so asking twice would train you to stop reading it. Needs a terminal and text output; under --json there is nobody to ask.',
    ),
  pr: z
    .array(z.coerce.number().int())
    .default([])
    .describe(
      'Update only these PR numbers, repeatable. They are still applied in stack order and a PR whose parent is behind is still skipped, because updating onto a base about to move is wasted work.',
    ),
  trust: z
    .boolean()
    .default(false)
    .describe(
      'Treat this repo as trusted for this run, satisfying the trust gate on `verify: check`.',
    ),
  strategy: z
    .enum(['rebase', 'merge'])
    .optional()
    .describe(
      "Override this run's default strategy (`rebase` or `merge`) for every target — beating the config `strategy` default, but NOT a per-PR `overrides` rule (a protected base pinned to `merge` stays pinned) and NOT the non-negotiable `unpushed_local` guard.",
    ),
})

export const result = z.object({
  number: z.number(),
  head: z.string(),
  base: z.string(),
  strategy: z.string(),
  status: z.string().describe('up-to-date | updated | conflict | failed'),
  pushed: z.boolean(),
  detail: z.string(),
  conflicts: z
    .array(z.object({ path: z.string(), why: z.string() }))
    .optional()
    .describe(
      'Present when status is `conflict`: each unresolved path and why no resolver claimed it.',
    ),
})

export const output = z.object({
  applied: z.boolean().describe('False when this was a rehearsal.'),
  interactive: z
    .boolean()
    .default(false)
    .describe('True when the checklist ran; the per-PR lines were already shown live.'),
  results: z.array(result).describe('One per PR acted on, in the order applied.'),
  skipped: z
    .array(z.object({ number: z.number(), head: z.string(), reason: z.string() }))
    .describe('PRs deliberately not acted on. Every surveyed PR is here or in `results`.'),
  counts: z.object({
    updated: z.number(),
    upToDate: z.number(),
    conflict: z.number(),
    failed: z.number(),
    skipped: z.number(),
  }),
})

/** Map one executor result onto the `result` schema. Exported for direct testing. */
export function toResult(r: UpdateResult): z.infer<typeof result> {
  return {
    number: r.number,
    head: r.head,
    base: r.base,
    strategy: r.strategy,
    status: r.outcome.status,
    pushed: r.outcome.status === 'updated' && r.outcome.pushed,
    detail: describeOutcome(r.outcome),
    ...(r.outcome.status === 'conflict' ? { conflicts: r.outcome.needsHuman } : {}),
  }
}

export type UpdateArgs = z.infer<typeof input>
export type UpdateOutput = z.infer<typeof output>

/** Everything a run needs beyond the args and the config. */
export interface UpdateEnv extends SurveyEnv {
  ports: Ports
}

/**
 * `args.strategy`, folded into `cfg` for this run.
 *
 * Swaps only `strategy` — `overrides` and `guards` pass through untouched —
 * so `chooseStrategy` (`./strategy.ts`) still consults the ORIGINAL
 * `overrides` array (a per-PR rule keeps winning) and `guards.unpushed_local`
 * stays unconditional regardless of which default strategy is in effect. Only
 * the branch that falls through to "no override, no guard fired" ever sees
 * the swapped default. Exported and pure so this precedence is testable
 * without driving the whole survey/update pipeline.
 */
export function applyStrategyOverride(
  cfg: PrUpdateConfig,
  strategy: 'rebase' | 'merge' | undefined,
): PrUpdateConfig {
  return strategy === undefined ? cfg : { ...cfg, strategy }
}

/**
 * Run the update.
 *
 * Exported separately from any CLI/op wrapper so a test can invoke it
 * directly, and so a host embedding this package as a library never pays for
 * a preflight it does not need.
 */
export async function runUpdate(args: UpdateArgs, env: UpdateEnv): Promise<UpdateOutput> {
  const effectiveCfg = applyStrategyOverride(env.cfg, args.strategy)
  const report = runSurvey(args, { ...env, cfg: effectiveCfg })
  const { targets, skipped } = selectTargets(report, args.pr)

  // `--apply` is the user's intent and the checklist is a stronger form of
  // it; `dryRun` is the harness-wide override that must beat both, so a
  // global rehearsal never writes.
  const wantsWrite = (args.apply || args.interactive) && !env.dryRun

  const git = new Git(env.projectRoot, { runner: env.git })
  const worktreeRoot = join(env.projectRoot, '.pr-update', `${process.pid}.${Date.now()}`)
  // `verify: check` executes a resolved, host-trust-gated verb list in the
  // update worktree — resolved once here and reused across every target,
  // rather than inside `updateAll`'s per-PR loop.
  const verifyVerbs =
    effectiveCfg.verify === 'check' ? await env.ports.resolveVerifyVerbs({ trust: args.trust }) : []
  const settings = {
    remote: args.remote,
    resolvers: effectiveCfg.resolvers,
    lockfileInstall: effectiveCfg.lockfile_install,
    verifyVerbs,
  }
  const run = (chosen: readonly UpdateTarget[], onResult?: (r: UpdateResult) => void) =>
    updateAll(git, chosen, settings, env.ports.runVerb, {
      apply: wantsWrite,
      worktreeRoot,
      ...(onResult === undefined ? {} : { onResult }),
    })

  let results: UpdateResult[]
  if (args.interactive) {
    results = await runChecklist(targets, skipped, report, run)
  } else {
    results = run(targets)
  }

  const t = tally(results)
  return {
    applied: wantsWrite,
    interactive: args.interactive,
    results: results.map(toResult),
    skipped,
    counts: {
      updated: t['updated'] ?? 0,
      upToDate: t['up-to-date'] ?? 0,
      conflict: t['conflict'] ?? 0,
      failed: t['failed'] ?? 0,
      skipped: skipped.length,
    },
  }
}

/** Render an update report as the same text `pr-update update` prints. */
export function renderUpdateText(out: UpdateOutput): string {
  const lines: string[] = []
  // The checklist already printed each row as it landed; printing them again
  // underneath would be noise. Only the tally is new.
  if (!out.interactive) {
    for (const r of out.results) {
      const mark =
        r.status === 'updated' ? (r.pushed ? '✓' : '·') : r.status === 'failed' ? '✗' : '!'
      lines.push(`${mark} #${r.number}  ${r.strategy}  ${r.head}  ${r.detail}`)
    }
    for (const s of out.skipped) {
      lines.push(`- #${s.number}  ${s.head}  ${s.reason}`)
    }
  }
  const c = out.counts
  const mode = out.applied ? 'PR-UPDATE' : 'PR-UPDATE (rehearsal — nothing pushed)'
  lines.push(
    `\n${mode}: updated=${c.updated} up-to-date=${c.upToDate} ` +
      `conflict=${c.conflict} failed=${c.failed} skipped=${c.skipped}`,
  )
  return `${lines.join('\n')}\n`
}
