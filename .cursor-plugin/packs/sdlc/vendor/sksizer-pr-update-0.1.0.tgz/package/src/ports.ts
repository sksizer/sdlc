/**
 * What a host must supply that this package cannot know for itself.
 *
 * All three ports name a concern the host owns and this package deliberately
 * does not: where a named repository's checkout lives on this machine, how to
 * run a shell verb, and whether a project-sourced verb list may run at all in
 * this repository (a trust decision). A standalone run (see `defaults.ts`)
 * supplies simple, host-agnostic implementations of the same shapes; sdlc's
 * own thin wrapper ops bind them to `locateRepo`/`repoContainers`,
 * `shellArmExec`, and `resolveWorkflowCommands`/`requireTrustedVerbs`
 * respectively.
 */

import type { CommandResult } from '@sksizer/command-seam'

/** Runs one shell verb in `cwd`. Tests inject a fake instead of a subprocess. */
export type RunVerb = (verb: string, cwd: string) => CommandResult

export interface Ports {
  /**
   * Resolve `owner/name` to a local checkout path, or null when this machine
   * has none. Only ever asked about a repository this run was explicitly
   * pointed at (`--repo`) — never used to widen scope on its own.
   */
  locate: (slug: string) => string | null
  /** The resolver/verify shell-out seam — see {@link RunVerb}. */
  runVerb: RunVerb
  /**
   * Resolve `pr_update.verify: check`'s verb list for this run, applying
   * whatever trust policy the host enforces on a project-sourced verb list.
   * Returns the verbs to run before a push; rejects (throwing) when the verb
   * list may not run in this repository for this run.
   */
  resolveVerifyVerbs: (opts: { trust: boolean }) => Promise<readonly string[]>
}
