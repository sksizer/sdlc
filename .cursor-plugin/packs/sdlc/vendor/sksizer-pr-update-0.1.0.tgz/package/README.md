# @sksizer/pr-update

Survey every open pull request's drift from its base, and bring the ones that
are behind up to date — rebase or merge, one PR or a whole stack, with
conflicts predicted before anything is checked out.

```ts
import { prUpdateConfigSchema, runSurvey, standalonePorts } from "@sksizer/pr-update";
import { spawnRunner } from "@sksizer/command-seam";

const report = runSurvey(
  { repo: [], noFetch: false, noDrafts: false, limit: 100, remote: "origin" },
  {
    projectRoot: process.cwd(),
    dryRun: false,
    git: spawnRunner("git"),
    gh: spawnRunner("gh"),
    cfg: prUpdateConfigSchema.parse({}),
    ports: standalonePorts(),
  },
);
```

Or from a shell:

```sh
pr-update survey --output json
pr-update update --apply --strategy rebase
```

## Why this exists as its own package

A stack of PRs drifts constantly — every merge to `main` puts the next PR one
commit further behind, and a PR three deep in a stack can look clean while
sitting on a base that is itself stale. Catching that by eye does not scale
past a handful of PRs; surveying it costs a GitHub API call and a
`git merge-tree` per PR, both cheap enough to run on every one that is open.

This package started life inside a larger CLI. It moved out once "run this
standalone against any repository, with your own idea of trust and your own
GitHub client" stopped being a hypothetical — see [[T-4AQN]] and the Forge
port ([[T-DVLT]]) it now leaves to a caller entirely.

## Three things it knows that a per-PR check cannot

**Drift is measured locally.** GitHub only reports `mergeStateStatus: BEHIND`
when branch protection requires an up-to-date branch; without it the field
stays silent however far a branch has drifted. So behind-ness comes from
`git rev-list --left-right --count` over the remote-tracking refs.

**Staleness is transitive.** When PR A targets PR B's head branch, A is
stacked on B, and updating A before B is wasted work — A's base is about to
move. `survey` builds the stack graph, sorts it parent-first, and marks a
child `blocked` on the nearest ancestor that is itself behind, however many
levels up that ancestor sits.

**A rebase is not always safe.** `--force-with-lease` compares against the
*remote*, so it does not notice a checkout holding commits nobody has pushed;
rebasing over that would orphan the work with no warning. The
`guards.unpushed_local` guard checks for this ahead of every preference and no
override defeats it.

## Conflicts, predicted before anything is checked out

`survey` predicts each PR's merge with `git merge-tree`, which merges in the
object database and never touches a working tree — the only thing that makes
surveying every open PR affordable; a full checkout per PR would cost minutes,
not seconds, across a large stack. A conflict prediction carries the
conflicted paths and `conflictBaseSha` — the base ref's resolved commit at the
moment it was measured — so a caller (a router keying a delivery signature on
it, say) can tell whether the prediction is still fresh.

## Resolving a conflict without asking anyone

`update` walks a resolver ladder before giving up on a conflict: git's own
`rerere` replay, the built-in lockfile rule (take a side, re-run
`lockfile_install`), then a project's own `resolvers` — glob-matched paths
paired with the shell verb that rebuilds them (`sdlc docs generate`, say). A
conflict no rung claims is reported with the path and why, in
`update`'s structured `conflicts` field — never guessed at.

## Config layering

A CLI flag beats `.pr-update.yaml` in the project root, which beats the
built-in defaults — every key in `PrUpdateConfig` has one, so both `survey`
and `update` work with no config file at all. A host embedding this package as
a library (rather than running the `pr-update` binary) builds its own
`PrUpdateConfig` from whatever config format it already has; nothing here
requires `.pr-update.yaml`.

## The `Ports` a host supplies

Three things this package deliberately does not know for itself:

| Port | What it answers |
|---|---|
| `locate(slug)` | Where `owner/name` is checked out on this machine, or `null` |
| `runVerb(verb, cwd)` | Run one shell verb — the resolver/verify seam |
| `resolveVerifyVerbs({ trust })` | The trust-gated verb list `verify: check` runs before a push |

`standalonePorts()` gives a `pr-update` CLI run reasonable defaults for the
first two and refuses `verify: check` outright (a standalone run has no trust
store to gate a project-sourced verb list with — set `verify: 'none'`, or
embed this package as a library and supply real ports).

## GitHub today, a Forge port later

`survey` and `update` talk to GitHub directly through `@sksizer/easy-gh`'s
`Gh` client today — that dependency is a normal part of this package, not
something a caller injects. A separate Forge port already exists
([[T-DVLT]], with GitHub and Forgejo adapters over `@sksizer/easy-gh`/`curl`)
for the callers that need multi-forge PR facts — `classify`/`feedback` (via
`selectForge`) and the orchestrator's `prs` tick. The dashboard deliberately
stays off the port too, for its own reason (an async fan-out the port's
synchronous design doesn't fit, per `dashboard/server.ts`'s own comment) —
so this package is not the only GitHub-only holdout by choice. Routing
`survey`/`update` through the Forge port too — so a Forgejo repository could
use this package without any GitHub-specific code running — is deliberately
left for later, tracked alongside the router that first needs it
([[T-9Q4A]]).

## License

MIT
