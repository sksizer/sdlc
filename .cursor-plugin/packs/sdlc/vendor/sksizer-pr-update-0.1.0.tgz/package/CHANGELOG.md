# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Version 0.1.0 has never been published. Extracted from sdlc's own
`lib/services/pr/` (`strategy.ts`, `survey.ts`, `update.ts`, `update/`) so it
can run standalone and take a Forge port dependency, ahead of a router
consuming its predicted conflicts as feedback.

### Changed

- `survey` lists PRs through the `CodeHost` port (`@sksizer/code-host`) instead of
  `@sksizer/easy-gh`; `SurveyEnv.codeHost` swaps the adapter (default GitHub over
  `gh`).

### Added

- `runSurvey`/`runUpdate` as a library, plus a standalone `pr-update` CLI
  (`survey`/`update` subcommands) built on `@sksizer/cli-tool`.
- `conflictBaseSha` on a survey row's conflict prediction — the base ref's
  resolved SHA at the moment `merge-tree` measured it, so a caller can tell
  whether the prediction is still fresh.
- Structured `conflicts: {path, why}[]` alongside `update`'s existing
  free-text `detail`, for a caller that wants to act on unresolved paths
  rather than parse prose.
- `--strategy rebase|merge` on `pr-update update`, overriding the run's
  default strategy without bypassing a per-PR `overrides` rule or the
  non-negotiable `unpushed_local` guard.
- Optional `Ports.generators`: in-process rebuild steps, a ladder rung after
  `resolvers`.
- Optional `Ports.repair` and the `repair: { command, on }` config block: a
  last-resort repair for an unclaimed conflict or a failed verify step, called
  only under `--apply`. The executor rejects a repair that moves HEAD, creates
  refs, or leaves conflict markers or `git diff --check` errors, and commits
  and pushes itself. `updated` outcomes gain `repaired: {kind, note}[]`.
  `standalonePorts(cfg)` builds the repair from `repair.command`;
  `commandRepair` is exported for hosts.
- `baseOid` on every survey row and on `UpdateTarget`, with `repo`.
- Optional `Ports.attempts` and the `max_failed_attempts` config key (default
  `1`): an `--apply` run records each `conflict`/`failed` result, keyed by
  head and base sha, and later runs skip the PR until either moves. Success
  clears the record. `--retry-failed` ignores it for one run.
  `fileAttemptStore` keeps it in `.pr-update/attempts.json`;
  `standalonePorts(cfg, projectRoot)` wires it.
- `--confirm-push` and optional `Ports.confirmPush`: before each rebase
  force-push, the run shows the commits to push, how many it replaces and the
  diffstat, then asks y/N. A no leaves the branch alone and reports
  `push declined`. Needs `--apply`; not with `--interactive`. Without the
  port, `runUpdate` asks on the terminal (`terminalConfirmPush`), which needs
  a terminal on stdin and stderr. A bad combination throws `UpdateUsageError`.
  A prompt that throws counts as no.
- `verify: test` and the `test_command` config key. `Ports.resolveVerifyVerbs`
  now takes `which: 'check' | 'test'`. A standalone run answers `test` with
  `test_command` and fails before touching any PR when it is unset.

### Fixed

- The failed-attempts record is written with `atomicWrite` from
  `@sksizer/etag-write`, which fsyncs and removes its temp file on failure.
- A scratch worktree left by a killed run no longer fails every later run's
  checkout; `updateAll` removes it first when its process is gone.
- A rebase that stops on a second conflict after a resolved one now fails the
  update. Before, the executor pushed the half-replayed HEAD.
