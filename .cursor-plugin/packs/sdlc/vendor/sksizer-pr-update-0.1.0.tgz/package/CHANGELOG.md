# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Version 0.1.0 has never been published. Extracted from sdlc's own
`lib/services/pr/` (`strategy.ts`, `survey.ts`, `update.ts`, `update/`) so it
can run standalone and take a Forge port dependency, ahead of a router
consuming its predicted conflicts as feedback.

### Added

- `runSurvey`/`runUpdate` as a library, plus a standalone `pr-update` CLI
  (`survey`/`update` subcommands) built on `@sksizer/cli-tool`.
- `conflictBaseSha` on a survey row's conflict prediction — the base ref's
  resolved SHA at the moment `merge-tree` measured it, so a caller can tell
  whether the prediction is still fresh.
- Structured `conflicts: {path, why}[]` alongside `update`'s existing
  free-text `detail`, for a caller that wants to act on unresolved paths
  rather than parse prose.
- `--strategy rebase|merge` on `pr-update update`, overriding the run's
  default strategy without bypassing a per-PR `overrides` rule or the
  non-negotiable `unpushed_local` guard.
