/**
 * The GitHub model, typed.
 *
 * `gh` returns GraphQL-shaped JSON whose fields depend on what you asked for,
 * so every field here is total: a value, or the enum member that means "not
 * known". Absent and unknowable are the same answer to a caller, and giving
 * them one representation is what keeps a consumer from reading a field it
 * never requested as a fact.
 *
 * The enums are open on purpose. GitHub adds members, and a client that
 * crashes on an unrecognized one is worse than a client that carries it
 * through: unions end in `(string & {})` so a new value still types as the
 * enum while the known members keep their autocomplete.
 */

/** Can this PR merge? `UNKNOWN` also covers "GitHub has not computed it yet". */
export type MergeableState = 'MERGEABLE' | 'CONFLICTING' | 'UNKNOWN'

/**
 * The merge-button state.
 *
 * `BEHIND` only ever appears when branch protection *requires* an up-to-date
 * branch. Without that rule a branch a hundred commits behind still reports
 * `CLEAN`, so this is a corroborating hint about staleness and never the
 * measure of it — compute that from the commit graph.
 */
export type MergeStateStatus =
  | 'BEHIND'
  | 'BLOCKED'
  | 'CLEAN'
  | 'DIRTY'
  | 'DRAFT'
  | 'HAS_HOOKS'
  | 'UNKNOWN'
  | 'UNSTABLE'
  | (string & {})

export type PullRequestState = 'OPEN' | 'CLOSED' | 'MERGED' | (string & {})

export type ReviewDecision = 'APPROVED' | 'CHANGES_REQUESTED' | 'REVIEW_REQUIRED' | null

export type ReviewState =
  'APPROVED' | 'CHANGES_REQUESTED' | 'COMMENTED' | 'DISMISSED' | 'PENDING' | (string & {})

/** Who wrote something. `login` is normalized — a `[bot]` suffix is stripped. */
export interface Actor {
  login: string
  /** True when GitHub marks the account as a bot, or the login carried `[bot]`. */
  isBot: boolean
}

export interface Label {
  name: string
  color: string
  description: string
}

/**
 * A GitHub issue, off `gh issue list`/`gh issue view --json
 * number,title,body,labels,state`. Deliberately the small field set the
 * `issues` sync/linking surface needs ([[T-3YQO]]) — not the full PR-sized
 * model, since nothing here reads reviews/checks/comments off an issue.
 */
export interface IssueRow {
  number: number
  title: string
  body: string
  labels: Label[]
  state: string
}

export type CheckConclusion =
  | 'SUCCESS'
  | 'FAILURE'
  | 'NEUTRAL'
  | 'CANCELLED'
  | 'TIMED_OUT'
  | 'ACTION_REQUIRED'
  | 'SKIPPED'
  | 'STALE'
  | 'STARTUP_FAILURE'
  | (string & {})
  | null

/** One rolled-up check, with the two GitHub shapes folded into one. */
export interface CheckRun {
  /** A CheckRun's `name`, or a legacy StatusContext's `context`. */
  name: string
  /** `QUEUED` / `IN_PROGRESS` / `COMPLETED`; null for a status context. */
  status: string | null
  conclusion: CheckConclusion
  /**
   * The normalized verdict. A check still running is `pending`, not a pass —
   * treating "no failure yet" as green is how a red build merges.
   */
  verdict: 'pending' | 'success' | 'failure' | 'neutral'
  /** A CheckRun's `detailsUrl`, or a legacy StatusContext's `targetUrl` — where to read the log. Null when the forge gives none. */
  url: string | null
}

export interface Comment {
  /** GitHub's node/database id for this comment — null only when the source payload omits it (gh always sends one). A Forge port's activity feed signs on this, so it is read through even though no consumer here used it before. */
  id: string | null
  author: Actor | null
  body: string
  createdAt: string | null
}

export interface Review {
  /** Same reasoning as {@link Comment.id}. */
  id: string | null
  author: Actor | null
  body: string
  state: ReviewState
  submittedAt: string | null
}

/**
 * A pull request.
 *
 * Fields `gh` was not asked for come back at their "not known" value, so this
 * type is safe to build from any field subset. `number` is the only field
 * without one — a PR with no number is not a PR, and parsing returns null.
 */
export interface PullRequest {
  number: number
  state: PullRequestState
  title: string
  body: string
  url: string
  isDraft: boolean
  baseRefName: string
  headRefName: string
  /** Head commit sha, when requested — the thing to pin a force-push lease to. */
  headRefOid: string | null
  /**
   * True when the head branch lives in a fork. Its ref is then not on the
   * base repository's `origin`; fetch `refs/pull/<n>/head` instead.
   */
  isCrossRepository: boolean
  mergeable: MergeableState
  mergeStateStatus: MergeStateStatus
  reviewDecision: ReviewDecision
  author: Actor | null
  labels: Label[]
  checks: CheckRun[]
  comments: Comment[]
  reviews: Review[]
  mergedAt: string | null
  createdAt: string | null
  updatedAt: string | null
}

/** A repository coordinate. */
export interface OwnerRepo {
  owner: string
  repo: string
}
