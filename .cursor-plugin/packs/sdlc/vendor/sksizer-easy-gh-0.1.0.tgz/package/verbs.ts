/**
 * The verb table — every `gh` invocation this library knows, as data.
 *
 * Same shape and same reasoning as `@sksizer/easy-git`'s: a {@link GhVerb}
 * pairs the argv to run with the function that reads the result, and nothing
 * here spawns anything. That is what lets a synchronous client and an
 * asynchronous fan-out drive the same definitions without either duplicating
 * the other's parsing.
 *
 * `checked` marks a mutation: its only sane failure handling is to surface
 * stderr. Queries are unchecked and fold failure into an absence value.
 */

import type { CommandResult } from '@sksizer/command-seam'

import { parsePullRequest, type PullRequestJson } from './parse.ts'
import type { PullRequest } from './types.ts'

/** One `gh` invocation: what to run, and how to read what came back. */
export interface GhVerb<T> {
  argv: string[]
  /** True for mutations — throw on a non-zero exit instead of parsing. */
  checked: boolean
  parse(result: CommandResult): T
}

/**
 * The cheapest useful set: enough to identify a PR and nothing more.
 *
 * Reach for this whenever the question is "which PR is this branch?".
 * `mergeable` and `mergeStateStatus` are absent on purpose — GitHub computes
 * them per PR on demand, so asking for them across a fan-out of branches
 * turns a cheap listing into a rate-limit incident.
 */
export const PR_REF_FIELDS = ['number', 'state', 'headRefName', 'url'] as const

/**
 * The light field set for triage: everything needed to decide what to do with
 * a PR without paying for its body, comments, reviews, or check rollup.
 *
 * `mergeable` and `mergeStateStatus` are the expensive pair — GitHub computes
 * them lazily and answers `UNKNOWN` until it has, so a cold query over many
 * PRs commonly needs a retry. See {@link needsMergeStateRetry}.
 */
export const PR_LIST_FIELDS = [
  'number',
  'state',
  'title',
  'url',
  'isDraft',
  'baseRefName',
  'headRefName',
  'headRefOid',
  'isCrossRepository',
  'mergeable',
  'mergeStateStatus',
  'reviewDecision',
  'author',
  'labels',
  'mergedAt',
  'createdAt',
  'updatedAt',
] as const

/** {@link PR_LIST_FIELDS} plus the heavy ones a single PR can afford. */
export const PR_VIEW_FIELDS = [
  ...PR_LIST_FIELDS,
  'body',
  'comments',
  'reviews',
  'statusCheckRollup',
] as const

/** Parse a `--json` payload that is a single object. */
function oneOrNull(r: CommandResult): PullRequest | null {
  if (r.exitCode !== 0) return null
  let data: unknown
  try {
    data = JSON.parse(r.stdout)
  } catch {
    return null
  }
  return parsePullRequest(data as PullRequestJson)
}

/**
 * Parse a `--json` payload that is an array. Null — not `[]` — when the call
 * failed: a caller must be able to tell "no PRs" from "couldn't ask".
 */
function manyOrNull(r: CommandResult): PullRequest[] | null {
  if (r.exitCode !== 0) return null
  let data: unknown
  try {
    data = JSON.parse(r.stdout || '[]')
  } catch {
    return null
  }
  if (!Array.isArray(data)) return null
  const rows: PullRequest[] = []
  for (const item of data) {
    const pr = parsePullRequest(item as PullRequestJson)
    if (pr !== null) rows.push(pr)
  }
  return rows
}

/** A mutation's result carries no value. */
function nothing(): void {}

// ── queries ─────────────────────────────────────────────────────────────────

/** What to narrow a listing to. Every filter is optional; none means "all open". */
export interface PrListOptions {
  /**
   * `owner/name` to list from, instead of the repository at the client's cwd.
   * The only way to reach a repository this machine has no checkout of.
   */
  repo?: string | undefined
  state?: 'open' | 'closed' | 'merged' | 'all' | undefined
  /** Exact base branch filter (gh-side). */
  base?: string | undefined
  /**
   * Head branch filter. gh matches this as a prefix, so a caller needing an
   * exact match filters the rows itself — {@link pickPrForBranch} does.
   */
  head?: string | undefined
  /** Raw `--search` query, for anything the flags do not cover. */
  search?: string | undefined
  author?: string | undefined
  limit?: number | undefined
  /** Field subset; defaults to {@link PR_LIST_FIELDS}. */
  fields?: readonly string[] | undefined
}

/** `gh pr list …` — open PRs by default. */
export function prList(opts: PrListOptions = {}): GhVerb<PullRequest[] | null> {
  const argv = ['pr', 'list', '--state', opts.state ?? 'open']
  if (opts.repo !== undefined) argv.push('--repo', opts.repo)
  if (opts.base !== undefined) argv.push('--base', opts.base)
  if (opts.head !== undefined) argv.push('--search', `head:${opts.head}`)
  if (opts.search !== undefined) argv.push('--search', opts.search)
  if (opts.author !== undefined) argv.push('--author', opts.author)
  argv.push('--json', (opts.fields ?? PR_LIST_FIELDS).join(','))
  argv.push('--limit', String(opts.limit ?? 100))
  return { argv, checked: false, parse: manyOrNull }
}

/** `gh pr view <n> --json …` — one PR, with the heavy fields by default. */
export function prView(
  number: number,
  fields: readonly string[] = PR_VIEW_FIELDS,
): GhVerb<PullRequest | null> {
  return {
    argv: ['pr', 'view', String(number), '--json', fields.join(',')],
    checked: false,
    parse: oneOrNull,
  }
}

/**
 * Open PRs whose head *starts with* `branch` — gh's own search semantics.
 *
 * The common shape behind "which PR is this branch?", bundling the cheap
 * field set with a small limit. Pair it with {@link pickPrForBranch}, which
 * is what turns the prefix match into an exact one.
 */
export function openPrsForBranch(branch: string, limit = 5): GhVerb<PullRequest[] | null> {
  return prList({ head: branch, limit, fields: PR_REF_FIELDS })
}

/** `gh --version` — the install probe. */
export function version(): GhVerb<boolean> {
  return { argv: ['--version'], checked: false, parse: (r) => r.exitCode === 0 }
}

/** `gh auth status` — the credential probe. */
export function authStatus(): GhVerb<boolean> {
  return { argv: ['auth', 'status'], checked: false, parse: (r) => r.exitCode === 0 }
}

// ── mutations (checked — the caller throws CommandFailed on non-zero) ────────

export interface CreatePrOptions {
  head: string
  base: string
  title: string
  body: string
  draft?: boolean | undefined
}

/** `gh pr create …`, returning the URL gh prints (its last non-empty line). */
export function createPr(opts: CreatePrOptions): GhVerb<string> {
  const argv = ['pr', 'create', '--head', opts.head, '--base', opts.base]
  if (opts.draft) argv.push('--draft')
  argv.push('--title', opts.title, '--body', opts.body)
  return {
    argv,
    checked: true,
    parse(r) {
      const lines = r.stdout
        .split('\n')
        .map((l) => l.trim())
        .filter((l) => l !== '')
      const url = lines[lines.length - 1]
      if (url === undefined) throw new Error('gh pr create printed no URL')
      return url
    },
  }
}

/** `gh pr edit <n>` — retitle or rewrite the body. */
export function editPr(
  number: number,
  opts: { title?: string | undefined; body?: string | undefined },
): GhVerb<void> {
  const argv = ['pr', 'edit', String(number)]
  if (opts.title !== undefined) argv.push('--title', opts.title)
  if (opts.body !== undefined) argv.push('--body', opts.body)
  return { argv, checked: true, parse: nothing }
}

// ── helpers over the parsed rows ────────────────────────────────────────────

/**
 * The row whose `headRefName` exactly equals `branch`, or null.
 *
 * gh's `head:` search is a prefix match, so `task/foo` also returns
 * `task/foo-2`. Every caller that means one branch needs this filter.
 */
export function pickPrForBranch(rows: PullRequest[] | null, branch: string): PullRequest | null {
  if (rows === null) return null
  return rows.find((r) => r.headRefName === branch) ?? null
}

/**
 * True when GitHub has not finished computing this PR's mergeability.
 *
 * The answer is not stable on a cold query: GitHub kicks off the merge
 * computation when asked and answers `UNKNOWN` until it lands. A caller that
 * treats the first `UNKNOWN` as final will mis-triage a PR that is merely
 * slow, so re-ask a few times before believing it.
 */
export function needsMergeStateRetry(pr: PullRequest): boolean {
  return pr.mergeable === 'UNKNOWN' || pr.mergeStateStatus === 'UNKNOWN'
}
