# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [Unreleased]

Version 0.1.0 has never been published.

The client was written in-place inside an application
(`solutions/ontological/lib/util/gh.ts`) and promoted into a standalone package
on 2026-09-01.

### Added

- **`installed()` and `authenticated()` on the client.** The two halves of
  `ready()`, which composes them and short-circuits. The verbs already
  existed; only the client methods were missing, so a caller reporting the
  halves separately — "gh is not installed" and "gh is not logged in" send a
  person somewhere different — had to go through `raw()`.
- **`parsePrUrl`.** `{owner, repo, number}` from a GitHub pull-request URL,
  tolerant of the shapes an address bar produces (sub-pages, query strings,
  a trailing slash). No caller had this; each one that needed a PR number
  grepped `/pull/(\d+)` and dropped the repository.
- **`isCrossRepository`** on `PullRequest`, in `PR_LIST_FIELDS`. A fork's head
  branch is not on the base repository's `origin`, and a caller that fetches
  `headRefName` there gets a not-found it cannot explain. A caller measuring
  drift or planning a push needs it for the same reason.
- **A typed model.** `PullRequest`, `Review`, `CheckRun`, `Actor`, `Label`
  and their enums. The application it came from had none: PR state was an
  index-signature bag read through `as` casts at every site, which is how a
  missing case — no rule for a branch that is merely behind — stayed
  invisible. Every field is total, so a payload built from any `--json`
  subset is safe to read.
- **`prList` / `prView` / `editPr`.** Listing without a head filter, the
  expensive `mergeable` / `mergeStateStatus` pair, and body rewriting, none
  of which the original had.
- **`prViewSettled`.** Re-asks while GitHub is still computing mergeability.
  The first answer to a cold query is `UNKNOWN` for reasons that have nothing
  to do with the PR, and believing it mis-triages every slow one.
- **Normalized check verdicts.** `statusCheckRollup`'s two node types
  (`CheckRun`, legacy `StatusContext`) folded onto one `pending` / `success` /
  `failure` / `neutral` axis, with a running check reported as `pending`
  rather than as an absence of failure.
- **`normalizeAuthorLogin`.** The `[bot]` suffix fold that makes a login
  comparable across GraphQL and REST payloads.
- **`parseOwnerRepo`.** A remote reference to `{owner, repo}`, over
  `easy-git`'s `parseGitUrl` (0.3.0) — replacing the hand-rolled regex over
  `remote.origin.url` that every caller grows and that is always missing a
  URL shape.
- **Pure argv builders and parsers**, exported separately from the client so
  an async fan-out reuses them without duplicating parsing.
- **`PR_REF_FIELDS`** — the cheap four-field set. `mergeable` and
  `mergeStateStatus` are computed per PR on demand, so asking for them
  across a fan-out of branches turns a listing into a rate-limit incident;
  every call site that only needs to identify a PR keeps its cheap query.
- **`id` on `Comment`/`Review`, `url` on `CheckRun`.** No consumer inside
  this package used them, but a Forge port's normalized activity feed
  (`solutions/ontological/lib/services/pr/forge/`) signs each entry by id
  and links a failing check to its run — both need a stable identifier this
  client already receives off `gh`'s own payload and previously dropped.

### Notes

- `ACTION_REQUIRED` is classified `neutral`, not `failure`: it means a human
  must act, not that the build broke. This preserves the triage behaviour of
  the code the package was extracted from; widening the failing set changes
  verdicts and is a decision to take deliberately.
