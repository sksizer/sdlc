/**
 * `Gh` — the synchronous GitHub client, the twin of `@sksizer/easy-git`'s
 * `Git`, bound to one working directory and one {@link CommandRunner}.
 *
 * Authentication is `gh`'s, not ours: no token is read, stored, or passed.
 * That is the whole reason this shells out to the CLI instead of speaking
 * REST — the credential already exists in the user's keychain, and a library
 * that reaches for `GITHUB_TOKEN` is a library that can leak one.
 *
 * Tri-modal, same as the git client: queries return parsed values and never
 * throw, mutations throw `CommandFailed`, and `raw`/`rawChecked` are the
 * escape hatches.
 */

import {
  runChecked,
  spawnRunner,
  type CommandResult,
  type CommandRunner,
  type CommandRunOptions,
} from '@sksizer/command-seam'

import * as v from './verbs.ts'
import type { GhVerb, PrListOptions } from './verbs.ts'
import { parseOwnerRepo } from './repo.ts'
import type { OwnerRepo, PullRequest } from './types.ts'

/**
 * Factory of per-binary runners — the injectable subprocess seam a CLI tail
 * threads through its call graph. Production uses `spawnRunner`; tests supply
 * a recording factory so a whole tail runs offline.
 */
export type RunnerFactory = (binary: string) => CommandRunner

/** Default factory: real, spawnSync-backed runners. */
export const defaultRunnerFactory: RunnerFactory = spawnRunner

/** How long to wait between merge-state retries, in milliseconds. */
const MERGE_STATE_RETRY_DELAY_MS = 1_500

/** A typed gh client bound to one working directory. */
export class Gh {
  readonly cwd: string
  private readonly runner: CommandRunner

  constructor(cwd: string, opts: { runner?: CommandRunner } = {}) {
    this.cwd = cwd
    this.runner = opts.runner ?? spawnRunner('gh')
  }

  /** The same client rooted at a different directory (same runner). */
  at(cwd: string): Gh {
    return new Gh(cwd, { runner: this.runner })
  }

  // ── escape hatches ────────────────────────────────────────────────────────

  /** Unchecked passthrough for verbs not yet lifted into the API. */
  raw(argv: string[], opts: { timeoutMs?: number | undefined } = {}): CommandResult {
    return this.runner.run(argv, { cwd: this.cwd, ...opts })
  }

  /** Checked passthrough — throws `CommandFailed` on a non-zero exit. */
  rawChecked(argv: string[], opts: { timeoutMs?: number | undefined } = {}): CommandResult {
    return runChecked(this.runner, argv, { cwd: this.cwd, ...opts })
  }

  /** Run one verb from the table, honouring its checked/unchecked contract. */
  private exec<T>(verb: GhVerb<T>, timeoutMs?: number | undefined): T {
    const opts: CommandRunOptions = { cwd: this.cwd }
    if (timeoutMs !== undefined) opts.timeoutMs = timeoutMs
    const result = verb.checked
      ? runChecked(this.runner, verb.argv, opts)
      : this.runner.run(verb.argv, opts)
    return verb.parse(result)
  }

  // ── queries ───────────────────────────────────────────────────────────────

  /** Pull requests matching `opts`, or null when gh failed. */
  prList(opts: PrListOptions & { timeoutMs?: number | undefined } = {}): PullRequest[] | null {
    return this.exec(v.prList(opts), opts.timeoutMs)
  }

  /** One PR with the heavy fields, or null when gh failed. */
  prView(
    number: number,
    opts: { fields?: readonly string[] | undefined; timeoutMs?: number | undefined } = {},
  ): PullRequest | null {
    return this.exec(v.prView(number, opts.fields ?? v.PR_VIEW_FIELDS), opts.timeoutMs)
  }

  /**
   * The open PR whose head exactly equals `branch`, or null.
   *
   * Uses {@link PR_REF_FIELDS}: identifying a PR must not cost a merge-state
   * computation. Ask for more with `prList` when you actually need more.
   */
  openPrFor(branch: string, limit = 5): PullRequest | null {
    const rows = this.prList({ head: branch, limit, fields: v.PR_REF_FIELDS })
    return v.pickPrForBranch(rows, branch)
  }

  /**
   * {@link prView}, re-asked until GitHub settles the merge state.
   *
   * GitHub computes mergeability lazily: the first query kicks it off and
   * answers `UNKNOWN` while it runs. A caller that believes that first answer
   * mis-triages every PR that is merely slow to compute, so this re-asks
   * `attempts` times before returning what it has. The last answer is
   * returned whether or not it settled — `UNKNOWN` is a legitimate final
   * verdict and callers must still handle it.
   *
   * `sleep` is injected so a test does not spend real seconds waiting.
   */
  prViewSettled(
    number: number,
    opts: {
      attempts?: number | undefined
      fields?: readonly string[] | undefined
      sleep?: ((ms: number) => void) | undefined
      timeoutMs?: number | undefined
    } = {},
  ): PullRequest | null {
    const attempts = Math.max(1, opts.attempts ?? 3)
    const sleep = opts.sleep ?? sleepSync
    let last: PullRequest | null = null
    for (let i = 0; i < attempts; i += 1) {
      last = this.prView(number, opts)
      if (last === null || !v.needsMergeStateRetry(last)) return last
      if (i < attempts - 1) sleep(MERGE_STATE_RETRY_DELAY_MS)
    }
    return last
  }

  /** True iff the `gh` binary is on PATH and runs. */
  installed(): boolean {
    return this.exec(v.version())
  }

  /**
   * True iff `gh` holds credentials. Asked on its own only by a caller that
   * reports the two halves separately — "gh is missing" and "gh is not logged
   * in" are different things to tell a person, and a report that collapses
   * them sends someone to install software they already have.
   */
  authenticated(): boolean {
    return this.exec(v.authStatus())
  }

  /**
   * True iff `gh` is installed AND authenticated — the two-step probe.
   *
   * Short-circuits: an absent binary cannot be asked about credentials.
   */
  ready(): boolean {
    return this.installed() && this.authenticated()
  }

  /**
   * `{owner, repo}` for a remote of the repository at `cwd`, or null.
   *
   * Reads the remote from git config rather than asking GitHub: it is offline,
   * instant, and correct even when `gh` is not authenticated.
   */
  ownerRepo(remoteUrl: string | null): OwnerRepo | null {
    return remoteUrl === null ? null : parseOwnerRepo(remoteUrl)
  }

  // ── mutations (checked) ───────────────────────────────────────────────────

  /** Open a PR and return the URL gh prints. */
  createPr(opts: v.CreatePrOptions): string {
    return this.exec(v.createPr(opts))
  }

  /** Retitle or rewrite a PR body. */
  editPr(number: number, opts: { title?: string | undefined; body?: string | undefined }): void {
    this.exec(v.editPr(number, opts))
  }
}

/**
 * Block the calling thread. Crude on purpose: the synchronous client has no
 * event loop to await on, and the alternative — making every caller async to
 * accommodate one retry delay — colors the whole call graph.
 */
function sleepSync(ms: number): void {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms)
}
