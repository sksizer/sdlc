/**
 * `GithubCodeHost` — the `CodeHost` port over `@sksizer/easy-gh`'s `Gh` client.
 *
 * `getPr` is the fix for a real, confirmed duplication: `classify.ts` used to
 * hand-roll its own "re-ask `gh pr view` while mergeability is UNKNOWN" retry
 * loop (`fetchLiveState`/`mergeStateUnsettled`) against the raw `CommandRunner`
 * — the exact thing `Gh.prViewSettled`/`needsMergeStateRetry` already do, and
 * were never called from anywhere in this app. This adapter calls them.
 *
 * Per-line/inline review comments have no GraphQL equivalent (`gh pr view
 * --json` has no `reviewThreads`/per-line field) and no wrapper in
 * `@sksizer/easy-gh` — REST is the only way to get them
 * (`repos/{owner}/{repo}/pulls/<n>/comments`), so `getPr` fetches them with
 * `Gh.raw`, the escape hatch, and folds them into `activity` as
 * `kind: 'review-comment'`. This is the one raw-argv call left in the whole
 * classify/feedback/prs path, and it lives here, inside the adapter.
 */

import {
  Gh,
  normalizeAuthorLogin,
  parsePrUrl as ghParsePrUrl,
  PR_LIST_FIELDS,
  PR_REF_FIELDS,
  PR_VIEW_FIELDS,
  type CheckRun,
  type PullRequest,
} from '@sksizer/easy-gh'

import type { CommandRunner } from '@sksizer/command-seam'
import type {
  Actor,
  CheckSummary,
  CodeHost,
  CodeHostPr,
  CodeHostPrDetail,
  CodeHostPrSummary,
  PrRef,
} from './types.ts'

/** One entry from the REST `pulls/<n>/comments` per-line-comment endpoint. */
interface RestReviewComment {
  id: unknown
  user?: { login?: unknown } | null
  path?: unknown
  line?: unknown
  original_line?: unknown
  body?: unknown
  in_reply_to_id?: unknown
  html_url?: unknown
  created_at?: unknown
  updated_at?: unknown
}

/**
 * The REST per-line-comments endpoint returns a `[bot]`-suffixed login
 * (`github-actions[bot]`), unlike the GraphQL-sourced `Actor`s `easy-gh`'s
 * `parseActor` already normalizes for `pr.comments`/`pr.reviews` above — fold
 * it the same way here, or a `review-comment`'s displayed author would be the
 * only `Activity` entry showing the raw suffixed form.
 */
function toActor(login: string | null | undefined): Actor | null {
  if (login === null || login === undefined || login === '') return null
  const normalized = normalizeAuthorLogin(login)
  return { login: normalized, isBot: normalized !== login }
}

function checksSummaryFrom(checks: readonly CheckRun[]): CheckSummary {
  const rollup = checks.some((c) => c.verdict === 'failure')
    ? 'failure'
    : checks.some((c) => c.verdict === 'pending')
      ? 'pending'
      : checks.length === 0
        ? 'none'
        : 'success'
  const failed = checks.filter((c) => c.verdict === 'failure')
  const failing = failed.map((c) => c.name)
  const failingUrls = failed
    .filter((c): c is CheckRun & { url: string } => c.url !== null)
    .map((c) => ({ name: c.name, url: c.url }))
  // `blocked` is never populated here — this function is pure (no network
  // access), and detecting a billing/spending-limit block needs a `gh api`
  // annotations fetch per failing check. `GithubCodeHost.getPr` fills it in,
  // after this call, only when `failing.length > 0` — see `detectBlockedChecks`.
  return { rollup, failing, failingUrls, blocked: [] }
}

/**
 * A GitHub Actions check run's numeric REST id, recovered from its
 * `detailsUrl` (`.../actions/runs/<runId>/job/<jobId>`) — the one place it's
 * available at all: `gh pr view --json statusCheckRollup`'s GraphQL payload
 * never includes `databaseId`, and for an Actions-backed check the job id
 * embedded in that URL IS the check run's REST id (verified against a live
 * failing PR in this repo: `gh api repos/{o}/{r}/commits/{sha}/check-runs`
 * reports the same id `detailsUrl`'s `/job/<id>` names). A check whose URL
 * isn't shaped like an Actions job link (a third-party CI status, a legacy
 * `StatusContext`) yields `null` and is left alone by `detectBlockedChecks`
 * below — this can only ever narrow a CI-FAILED verdict to CI-BLOCKED for a
 * check it CAN inspect, never misclassify one it can't.
 */
export function actionsJobId(url: string): string | null {
  const m = /\/actions\/runs\/\d+\/job\/(\d+)(?:[/?#]|$)/.exec(url)
  return m === null ? null : m[1]!
}

/**
 * The fixed prefix GitHub's own system annotation uses for an account-level
 * block ("The job was not started because recent account payments have
 * failed or your spending limit needs to be increased. Please check the
 * 'Billing & plans' section in your settings" — verified against a real
 * blocked check run on this repo via `gh api
 * repos/sksizer/dev/check-runs/<id>/annotations`). Anchored at the start:
 * `/\bwas not started\b/i` (the prior pattern) also matched a user step's own
 * `::error::` output — Actions turns those into annotations too — so a test
 * step logging e.g. "Error: dev server was not started within 30s" would
 * downgrade a real failure to CI-BLOCKED. Never for a real code/test
 * failure, which always has at least one step that actually ran.
 */
const BLOCKED_ANNOTATION_PATTERN = /^The job was not started because\b/

interface RawAnnotation {
  message?: unknown
  /** GitHub's system annotation for this block is always `failure`, `path: '.github'` — checked alongside the message prefix so a user-step annotation can never match on message text alone. */
  annotation_level?: unknown
  path?: unknown
}

/**
 * Which of `failingUrls`' checks failed because GitHub never started the
 * job — fetched from each check run's annotations
 * (`repos/{owner}/{repo}/check-runs/{id}/annotations`), ONLY for checks
 * already known to be failing, never the whole rollup: a green PR costs zero
 * extra `gh api` calls, and a red PR costs exactly one call per failing
 * Actions-backed check (a third-party/legacy check with no recoverable id is
 * skipped, not charged a call that could never resolve). Degrades to "not
 * blocked" (excluded from the returned list) on any transport/parse failure
 * for that one check: a fetch or parse failure simply leaves that check
 * counted as failing (CI-FAILED), so an annotations-fetch hiccup never
 * silently downgrades a real failure to CI-BLOCKED or drops it entirely.
 */
export function detectBlockedChecks(
  gh: Gh,
  failingUrls: readonly { name: string; url: string }[],
): string[] {
  const blocked: string[] = []
  for (const { name, url } of failingUrls) {
    const jobId = actionsJobId(url)
    if (jobId === null) continue
    const result = gh.raw(['api', `repos/{owner}/{repo}/check-runs/${jobId}/annotations`])
    if (result.exitCode !== 0) continue
    let annotations: RawAnnotation[]
    try {
      const parsed: unknown = JSON.parse(result.stdout)
      annotations = Array.isArray(parsed) ? (parsed as RawAnnotation[]) : []
    } catch {
      continue
    }
    const isBlocked = annotations.some(
      (a) =>
        typeof a.message === 'string' &&
        BLOCKED_ANNOTATION_PATTERN.test(a.message) &&
        a.annotation_level === 'failure' &&
        a.path === '.github',
    )
    if (isBlocked) blocked.push(name)
  }
  return blocked
}

/**
 * Per-line review comments via the REST endpoint `@sksizer/easy-gh` has no
 * wrapper for. Degrades to `[]` on any failure (non-zero exit, parse error)
 * rather than throwing — matches `feedback.ts`'s old `fetchReviewComments`:
 * a review-comments fetch failure means "no per-line comments this round,"
 * not a reason to fail the whole `getPr` call.
 */
function fetchReviewComments(gh: Gh, prNumber: number): RestReviewComment[] {
  const result = gh.raw(['api', `repos/{owner}/{repo}/pulls/${prNumber}/comments`])
  if (result.exitCode !== 0) return []
  try {
    const parsed: unknown = JSON.parse(result.stdout)
    return Array.isArray(parsed) ? (parsed as RestReviewComment[]) : []
  } catch {
    return []
  }
}

function reviewCommentActivity(entries: readonly RestReviewComment[]): CodeHostPr['activity'] {
  const out: CodeHostPr['activity'] = []
  for (const raw of entries) {
    if (typeof raw.id !== 'number' && typeof raw.id !== 'string') continue
    const login = typeof raw.user?.login === 'string' ? raw.user.login : null
    const path = typeof raw.path === 'string' ? raw.path : undefined
    // `line` is null when the comment sits on an outdated diff position — fall back to `original_line`.
    const line =
      typeof raw.line === 'number'
        ? raw.line
        : typeof raw.original_line === 'number'
          ? raw.original_line
          : undefined
    const inReplyToId = raw.in_reply_to_id
    // No true thread-node-id is available through this REST endpoint;
    // `in_reply_to_id ?? id` is the pragmatic per-thread grouping id.
    const threadId = String(
      typeof inReplyToId === 'number' || typeof inReplyToId === 'string' ? inReplyToId : raw.id,
    )
    const url = typeof raw.html_url === 'string' ? raw.html_url : undefined
    const at = typeof raw.created_at === 'string' ? raw.created_at : null
    const updatedAt = typeof raw.updated_at === 'string' ? raw.updated_at : null
    out.push({
      id: String(raw.id),
      kind: 'review-comment',
      author: toActor(login),
      at,
      editedAt: updatedAt !== at ? updatedAt : null,
      body: typeof raw.body === 'string' ? raw.body : '',
      reviewState: null,
      location: {
        ...(path !== undefined ? { file: path } : {}),
        ...(line !== undefined ? { line } : {}),
        threadId,
        ...(url !== undefined ? { url } : {}),
      },
    })
  }
  return out
}

/**
 * Exported for `dashboard/server.ts`'s async PR-status fan-out — the
 * dashboard's `AsyncCommandRunner` fetches via `@sksizer/easy-gh`'s pure
 * `prView` verb directly (this whole port is deliberately synchronous, see
 * this module's top-of-file doc), then maps the result through this same
 * function so classify's verdict logic runs identically for both callers.
 */
export function codeHostPrFrom(
  pr: PullRequest,
  reviewComments: CodeHostPr['activity'],
): CodeHostPr {
  const mergeable: CodeHostPr['mergeable'] =
    // Preserve today's actual CONFLICTS trigger: either field alone used to
    // fire it (classify.ts's old Rule 3 checked `mergeable === 'CONFLICTING'
    // || mergeStateStatus === 'DIRTY'`, independent of the other field) —
    // this OR must be checked before falling back to `mergeable` alone, or a
    // PR GitHub reports as `MERGEABLE` with a stale-DIRTY merge-state (a real
    // combination) silently loses its conflict signal.
    pr.mergeable === 'CONFLICTING' || pr.mergeStateStatus === 'DIRTY'
      ? 'conflicting'
      : pr.mergeable === 'MERGEABLE'
        ? 'mergeable'
        : 'unknown'
  const reviewDecision: CodeHostPr['reviewDecision'] =
    pr.reviewDecision === 'APPROVED'
      ? 'approved'
      : pr.reviewDecision === 'CHANGES_REQUESTED'
        ? 'changes_requested'
        : pr.reviewDecision === 'REVIEW_REQUIRED'
          ? 'review_required'
          : null

  const activity: CodeHostPr['activity'] = [
    ...pr.comments.map((c) => ({
      id: c.id ?? '',
      kind: 'comment' as const,
      author: c.author,
      at: c.createdAt,
      editedAt: null,
      body: c.body,
      reviewState: null,
      location: null,
    })),
    ...pr.reviews.map((r) => ({
      id: r.id ?? '',
      kind: 'review' as const,
      author: r.author,
      at: r.submittedAt,
      editedAt: null,
      body: r.body,
      reviewState: r.state,
      location: null,
    })),
    ...reviewComments,
  ]

  return {
    number: pr.number,
    url: pr.url,
    title: pr.title,
    state: pr.state === 'MERGED' ? 'merged' : pr.state === 'CLOSED' ? 'closed' : 'open',
    isDraft: pr.isDraft,
    author: pr.author,
    baseRef: pr.baseRefName,
    headRef: pr.headRefName,
    headSha: pr.headRefOid,
    mergedAt: pr.mergedAt,
    mergeable,
    checks: checksSummaryFrom(pr.checks),
    reviewDecision,
    activity,
  }
}

export class GithubCodeHost implements CodeHost {
  readonly name = 'github' as const
  private readonly gh: Gh

  constructor(cwd: string, opts: { runner: CommandRunner }) {
    this.gh = new Gh(cwd, { runner: opts.runner })
  }

  listPrs(q: {
    state?: 'open' | 'closed' | 'all'
    author?: string
    limit?: number
  }): CodeHostPrSummary[] | null {
    const rows = this.gh.prList({
      state: q.state,
      author: q.author,
      limit: q.limit,
      // `PR_REF_FIELDS` plus only what `CodeHostPrSummary` reads. No `mergeable`/
      // `mergeStateStatus`: those make a listing expensive.
      fields: [...PR_REF_FIELDS, 'author', 'labels', 'isDraft', 'updatedAt'],
    })
    if (rows === null) return null
    return rows.map((pr) => ({
      number: pr.number,
      headRef: pr.headRefName,
      author: pr.author,
      labels: pr.labels.map((l) => l.name),
      isDraft: pr.isDraft,
      updatedAt: pr.updatedAt,
    }))
  }

  listPrDetails(q: {
    state?: 'open' | 'closed' | 'all'
    author?: string
    limit?: number
    repo?: string
  }): CodeHostPrDetail[] | null {
    const rows = this.gh.prList({
      state: q.state,
      author: q.author,
      limit: q.limit,
      repo: q.repo,
      // `reviews` is not in the default listing, and the rebase guard needs it.
      fields: [...PR_LIST_FIELDS, 'reviews'],
    })
    if (rows === null) return null
    return rows.map((pr) => ({
      number: pr.number,
      title: pr.title,
      url: pr.url,
      baseRef: pr.baseRefName,
      headRef: pr.headRefName,
      headSha: pr.headRefOid,
      isDraft: pr.isDraft,
      labels: pr.labels.map((l) => l.name),
      reviewCount: pr.reviews.length,
      isCrossRepository: pr.isCrossRepository,
    }))
  }

  getPr(number: number, _opts: { since: string | null }): CodeHostPr | null {
    // `classify` never does an incremental "since" fetch today — always the
    // full state — so `since` is accepted for interface-parity with a future
    // caller and ignored here, same as every current call site.
    const pr = this.gh.prViewSettled(number, { fields: PR_VIEW_FIELDS })
    if (pr === null) return null
    const reviewComments = reviewCommentActivity(fetchReviewComments(this.gh, number))
    const codeHostPr = codeHostPrFrom(pr, reviewComments)
    // Billing/spending-limit block detection: only when there's at least one
    // failing check to inspect — see `detectBlockedChecks`'s doc for why this
    // never costs a green PR anything.
    if (codeHostPr.checks.failing.length === 0) return codeHostPr
    const blocked = detectBlockedChecks(this.gh, codeHostPr.checks.failingUrls)
    if (blocked.length === 0) return codeHostPr
    return { ...codeHostPr, checks: { ...codeHostPr.checks, blocked } }
  }

  postComment(number: number, body: string): { id: string; createdAt: string } {
    // `gh pr comment` prints the new comment's URL on success, not JSON —
    // there is no id/createdAt to read off stdout, and nothing in this
    // codebase calls `postComment` yet (confirmed: no existing `gh pr
    // comment` call site to migrate). Rather than fabricate an id, re-list
    // the REST comments right after posting and return the newest one
    // matching this body — the same identity `feedback.ts` already reads
    // off that endpoint for every other comment.
    this.gh.rawChecked(['pr', 'comment', String(number), '--body', body])
    // `gh pr comment` posts to the issue-level conversation thread, not the
    // per-line review endpoint `fetchReviewComments` reads — look it up there.
    const rest = this.gh.raw(['api', `repos/{owner}/{repo}/issues/${number}/comments`])
    if (rest.exitCode === 0) {
      try {
        const parsed = JSON.parse(rest.stdout) as {
          id?: unknown
          body?: unknown
          created_at?: unknown
        }[]
        const match = [...parsed].reverse().find((c) => c.body === body)
        if (match !== undefined && (typeof match.id === 'number' || typeof match.id === 'string')) {
          return {
            id: String(match.id),
            createdAt:
              typeof match.created_at === 'string' ? match.created_at : new Date().toISOString(),
          }
        }
      } catch {
        // fall through to the honest-unknown return below
      }
    }
    // Posted successfully (rawChecked would have thrown otherwise) but the
    // follow-up lookup couldn't confirm which comment it created — return an
    // empty id rather than a fabricated one; a caller that needs the id for
    // signing should treat this as "posted, identity unconfirmed."
    return { id: '', createdAt: new Date().toISOString() }
  }

  updateBranch(number: number, style: 'merge' | 'rebase'): void {
    // `--rebase` for rebase is per the design doc's own note on
    // `gh pr update-branch` ("inferred", not verified against a real `gh`
    // install) — unverified here too; no existing call site to cross-check
    // against.
    const argv = ['pr', 'update-branch', String(number)]
    if (style === 'rebase') argv.push('--rebase')
    this.gh.rawChecked(argv)
  }

  parsePrUrl(url: string): PrRef | null {
    const ref = ghParsePrUrl(url)
    return ref === null
      ? null
      : { codeHost: 'github', owner: ref.owner, repo: ref.repo, number: ref.number }
  }

  prForBranch(branch: string): number | null {
    const pr = this.gh.openPrFor(branch)
    return pr === null ? null : pr.number
  }
}
