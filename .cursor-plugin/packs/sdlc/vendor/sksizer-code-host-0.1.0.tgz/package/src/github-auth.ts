import { Gh } from '@sksizer/easy-gh'

import type { AuthCheck, CodeHostAuthCheckDeps } from './types.ts'

/** Name of the `gh --version` check. a doctor command finds its gh probe result by this name. */
export const GH_INSTALLED_CHECK = 'gh installed'

/** `gh` is installed and logged in. The login check is skipped when `gh` is missing. */
export function githubAuthChecks(deps: CodeHostAuthCheckDeps): AuthCheck[] {
  const gh = new Gh(process.cwd(), { runner: deps.gh })
  const installed = gh.installed()
  const checks: AuthCheck[] = [
    { name: GH_INSTALLED_CHECK, ok: installed, fix: 'install gh: https://cli.github.com' },
  ]
  if (!installed) return checks
  const { ok, detail } = gh.authStatus()
  const firstLine = detail.split('\n')[0]
  checks.push({
    name: 'gh auth status',
    ok,
    ...(!ok && firstLine ? { detail: firstLine } : {}),
    fix: 'run: gh auth login',
  })
  return checks
}
