/**
 * The CodeHost port: what a code host (GitHub, Forgejo, ...) must answer so
 * a classifier or router (sdlc's `pr classify` and `lib/services/dispatch/`) never call
 * `gh`/a code host's REST API directly. GitHub (`./github.ts`) and Forgejo
 * (`./forgejo.ts`) are the adapters; `pr survey`/`pr update` read PRs through
 * `listPrDetails`.
 *
 * Shaped after `docs/planning/simple-dispatch-interfaces.html`'s Forge section
 * (the port was named `Forge` then), with three deliberate deviations from
 * that page, made once here
 * rather than re-argued at every call site:
 *
 *   - Every method is SYNCHRONOUS. This repo's `ctx.gh`/`ctx.git` are
 *     `CommandRunner`s over `spawnRunner` (`@sksizer/command-seam`), and
 *     every current caller (classify, feedback, the `prs` tick, survey,
 *     review) is sync end to end — going async here would color the whole
 *     call graph for no caller that needs it. The design doc's own "Open
 *     questions" section already flags async-vs-sync as undecided outside
 *     the host/session ports; this port answers it for itself.
 *   - `Activity` adds `id`/`editedAt` and a third `kind: 'review-comment'`
 *     (with an optional `location`) beyond the doc's `comment | review`:
 *     the Router's `DeliveryRecord` signs every feedback item by id, and
 *     `feedback.ts` already surfaces per-line/inline diff comments
 *     (GitHub's REST `pulls/<n>/comments`) as a distinct thing from a
 *     top-level PR comment or review. Folding them into `Activity` here
 *     keeps `CodeHost` itself at exactly the six methods the design doc names.
 *   - `PrFacts.behind`/`ahead` are assembled by `./facts.ts` from local git,
 *     per the design doc's own "Drift is not a forge field" rule — no
 *     adapter ever sets them.
 */

import { z } from 'zod'

import type { CommandRunner } from '@sksizer/command-seam'

export type CodeHostName = 'github' | 'forgejo'

/** One code host auth check a doctor command runs. */
export const AuthCheckSchema = z.object({
  name: z.string(),
  ok: z.boolean(),
  detail: z.string().optional(),
  fix: z.string().describe('One line to print when the check fails.'),
})
export type AuthCheck = z.infer<typeof AuthCheckSchema>

export interface CodeHostAuthCheckDeps {
  gh: CommandRunner
  env: NodeJS.ProcessEnv
  fetch?: typeof fetch
}

export interface Actor {
  login: string
  isBot: boolean
}

/**
 * One comment, review, or inline review comment newer than the `getPr`
 * caller's `since` cursor — unfiltered. `entrySurvives`
 * (`../ops/classify.ts`) is what applies the bot/self/recency filter, once,
 * for every code host; this type carries only what that filter and the Router's
 * signing need.
 */
export interface Activity {
  /** The signature's identity (Router `DeliveryRecord`, `../../dispatch/signature.ts`). */
  id: string
  kind: 'comment' | 'review' | 'review-comment'
  author: Actor | null
  /** Created/submitted timestamp. */
  at: string | null
  /** Last-edited timestamp, when the code host reports one; null when it doesn't track or wasn't asked for. */
  editedAt: string | null
  body: string
  /** Only set for `kind: 'review'` (e.g. `APPROVED`, `CHANGES_REQUESTED`). */
  reviewState: string | null
  /** Only set for `kind: 'review-comment'` — where in the diff it sits. */
  location: { file?: string; line?: number; threadId?: string; url?: string } | null
}

export interface CheckSummary {
  rollup: 'none' | 'pending' | 'success' | 'failure'
  /** Failing check names, in the code host's own rollup order. */
  failing: string[]
  /** Failing checks' log/details URLs, when the code host gives one — same order as `failing`, may be shorter (a check with no URL is skipped, not padded with undefined). */
  failingUrls: { name: string; url: string }[]
  /**
   * The subset of `failing` whose run never actually started — GitHub billed
   * or spending-limit-blocked the account, so the check reports
   * `conclusion: failure` with no steps, and the real reason ("The job was
   * not started because...") lives only in the check run's annotations
   * (`../code-host/github.ts`'s `detectBlockedChecks`, fetched only for checks
   * already known to be failing). `classify.ts`'s Rule 4 reads this to tell
   * an account-level block (verdict `CI-BLOCKED`) apart from a real code
   * failure (`CI-FAILED`) instead of conflating the two. Always `[]` for a
   * code host with no such concept (Forgejo has no billing-block failure mode
   * documented) or when `failing` is empty (nothing to check).
   */
  blocked: string[]
}

export interface CodeHostPr {
  number: number
  url: string
  title: string
  state: 'open' | 'closed' | 'merged'
  isDraft: boolean
  author: Actor | null
  baseRef: string
  headRef: string
  headSha: string | null
  mergedAt: string | null
  mergeable: 'mergeable' | 'conflicting' | 'unknown'
  checks: CheckSummary
  reviewDecision: 'approved' | 'changes_requested' | 'review_required' | null
  activity: Activity[]
}

/** `CodeHostPr` plus drift, measured locally (`./facts.ts`) — never a code host field. */
export interface PrFacts extends CodeHostPr {
  behind: number | null
  ahead: number | null
}

/** The cheap listing shape — enough to filter/triage without the heavy fields (mirrors `PR_REF_FIELDS`'s role in `@sksizer/easy-gh`). */
export interface CodeHostPrSummary {
  number: number
  headRef: string
  author: Actor | null
  labels: string[]
  /** Whether the PR is a draft — `orchestrator.pr_filters.exclude_drafts` (`ticks/_pr_filters.ts`) reads this to skip it before classification. */
  isDraft: boolean
  /** Last-activity time; the `prs` tick skips the full fetch while it is unchanged. `null` when the code host omitted it. */
  updatedAt: string | null
}

/**
 * One open PR with what `pr-update`'s survey needs to place it in a stack and
 * choose how to bring it up to date: both branch names, the head sha a
 * force-push lease is pinned to, the labels, how many reviews a rewrite would
 * outdate, and whether the head lives in a fork.
 */
export interface CodeHostPrDetail {
  number: number
  title: string
  url: string
  baseRef: string
  headRef: string
  /** Head commit sha; `null` when the code host omitted it. */
  headSha: string | null
  isDraft: boolean
  labels: string[]
  /** Submitted reviews. */
  reviewCount: number
  /** True when the head branch lives in a fork, so its ref is not on the base repository's remote. */
  isCrossRepository: boolean
}

export type PrRef = { codeHost: CodeHostName; owner: string; repo: string; number: number }

export type PrInput =
  | { kind: 'current' }
  | { kind: 'number'; number: number }
  | { kind: 'slug'; owner: string; repo: string; number: number }
  | { kind: 'url'; ref: PrRef }

export interface CodeHost {
  readonly name: CodeHostName
  /** Open (or matching `q.state`) PRs, cheaply. `null` when the code host call failed. */
  listPrs(q: {
    state?: 'open' | 'closed' | 'all'
    author?: string
    limit?: number
  }): CodeHostPrSummary[] | null
  /**
   * Open (or matching `q.state`) PRs with the fields a stack survey reads.
   * `q.repo` (`owner/name`) lists another repository than the checkout's own.
   * `null` when the code host call failed.
   */
  listPrDetails(q: {
    state?: 'open' | 'closed' | 'all'
    author?: string
    limit?: number
    repo?: string
  }): CodeHostPrDetail[] | null
  /** One PR with every field `classify`/the Router need. `null` when it doesn't exist or the call failed. `since` is accepted for a future incremental fetch; every adapter today ignores it and returns full state. */
  getPr(number: number, opts: { since: string | null }): CodeHostPr | null
  /** Posts a comment; throws on failure (a mutation, per this codebase's tri-modal convention — see `Gh`/`Git`). */
  postComment(number: number, body: string): { id: string; createdAt: string }
  /** Brings the PR's head up to date with its base; throws on failure. */
  updateBranch(number: number, style: 'merge' | 'rebase'): void
  /** `null` when `url` names no PR this code host recognizes. */
  parsePrUrl(url: string): PrRef | null
  /** The open PR whose head is exactly `branch`, or `null`. */
  prForBranch(branch: string): number | null
}
