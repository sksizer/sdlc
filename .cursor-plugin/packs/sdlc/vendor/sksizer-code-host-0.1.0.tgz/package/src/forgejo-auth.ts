import { FORGEJO_TOKEN_ENV } from './forgejo.ts'
import type { AuthCheck, CodeHostAuthCheckDeps } from './types.ts'

const TIMEOUT_MS = 5000

/**
 * The token env var is set, and `GET <baseUrl>/api/v1/user` accepts it. One
 * network call, skipped when the token or `baseUrl` is missing.
 */
export async function forgejoAuthChecks(
  deps: CodeHostAuthCheckDeps,
  baseUrl: string | null,
): Promise<AuthCheck[]> {
  const token = deps.env[FORGEJO_TOKEN_ENV]
  const hasToken = token !== undefined && token !== ''
  const checks: AuthCheck[] = [
    {
      name: `${FORGEJO_TOKEN_ENV} set`,
      ok: hasToken,
      fix: `export ${FORGEJO_TOKEN_ENV}=<token from Settings → Applications>`,
    },
  ]
  if (baseUrl === null) {
    checks.push({
      name: 'forgejo host',
      ok: false,
      detail: 'no parseable origin remote',
      fix: 'set an origin remote that points at the Forgejo host',
    })
    return checks
  }
  if (!hasToken) return checks

  const url = `${baseUrl}/api/v1/user`
  const failure = await getUserFailure(deps.fetch ?? fetch, url, token)
  checks.push({
    name: `GET ${url}`,
    ok: failure === null,
    ...(failure !== null ? { detail: failure } : {}),
    fix: `token rejected or host unreachable: create a new token and re-export ${FORGEJO_TOKEN_ENV}`,
  })
  return checks
}

/** Why the request did not return HTTP 200, or null when it did. */
async function getUserFailure(
  fetchFn: typeof fetch,
  url: string,
  token: string,
): Promise<string | null> {
  try {
    const res = await fetchFn(url, {
      headers: { Authorization: `token ${token}` },
      signal: AbortSignal.timeout(TIMEOUT_MS),
    })
    return res.status === 200 ? null : `HTTP ${res.status}`
  } catch (err) {
    return err instanceof Error ? err.message : String(err)
  }
}
