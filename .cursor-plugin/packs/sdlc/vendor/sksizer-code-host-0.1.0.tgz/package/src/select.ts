/**
 * Choosing a `CodeHost` for the repository at `cwd`, from its `origin` remote.
 *
 * A GitHub remote is the only case this codebase can name outright — a
 * self-hosted Forgejo instance lives at an operator-chosen domain, so "not
 * github.com" is the whole positive test for Forgejo. `sdlc.yaml`'s
 * `code_host.override` exists for the cases this heuristic gets wrong (a GitHub
 * Enterprise host) or cannot answer at all (no `origin` remote configured,
 * which falls back to GitHub — this port's only adapter before this task,
 * so a repository this heuristic can't read a remote for keeps behaving
 * exactly as it did).
 *
 * Every call site that used to construct `GithubCodeHost` directly
 * (`classify.ts`, the `prs` tick, ...) now calls `selectCodeHost` instead —
 * this is the one place that decision gets made, so no code outside
 * `code-host/` ever branches on a `CodeHost`'s name. a doctor command uses
 * `resolveCodeHost` and `authChecksFor` to run the chosen backend's auth checks.
 */

import { Git } from '@sksizer/easy-git'

import { spawnRunner, type CommandRunner } from '@sksizer/command-seam'
import { FORGEJO_TOKEN_ENV, ForgejoCodeHost } from './forgejo.ts'
import { forgejoAuthChecks } from './forgejo-auth.ts'
import { GithubCodeHost } from './github.ts'
import { githubAuthChecks } from './github-auth.ts'
import type { AuthCheck, CodeHost, CodeHostAuthCheckDeps, CodeHostName } from './types.ts'

/**
 * Pure: which code host `url` (an `origin` remote, or null when this checkout
 * has none) names, honoring an explicit `override` first.
 */
export function codeHostNameForRemote(
  url: string | null,
  override: CodeHostName | null,
): CodeHostName {
  if (override !== null) return override
  if (url === null) return 'github'
  return url.includes('github.com') ? 'github' : 'forgejo'
}

/** `{host, port, owner, repo}` from a git remote URL, in either shape `remote get-url` answers with. */
export interface GitRemoteRef {
  host: string
  /** Explicit `:port` off an `http(s)://` remote; null otherwise. An `ssh://` port is the SSH port, not the web API's. */
  port: number | null
  owner: string
  repo: string
}

/**
 * Parses `git@host:owner/repo.git` (scp-style) and
 * `https://host[:port]/owner/repo[.git]` (and `ssh://` with the same
 * authority shape). `@sksizer/easy-git`'s `parseGitUrl` is the wrong tool
 * here — it wraps `hosted-git-info`, which only recognizes a fixed
 * allowlist of well-known hosts (github.com, gitlab.com, ...) and returns
 * null for anything else, exactly the case a self-hosted Forgejo instance
 * always is.
 */
export function parseRemoteRef(url: string): GitRemoteRef | null {
  const trimmed = url.trim()
  const scp = /^[\w.-]+@([^:/]+):(.+)$/.exec(trimmed)
  const uri = /^[a-z][a-z0-9+.-]*:\/\/(?:[^@/]+@)?([^/:]+)(?::(\d+))?\/(.+)$/i.exec(trimmed)
  const match = scp ?? uri
  if (match === null) return null
  const host = match[1]!
  // `scp` has no port syntax: its `:` separates host and path.
  const isHttp = match === uri && /^https?:/i.test(trimmed)
  const port = isHttp && match[2] !== undefined ? Number(match[2]) : null
  const rest = match === uri ? match[3]! : match[2]!
  const path = rest.replace(/\.git$/, '').replace(/^\/+|\/+$/g, '')
  const parts = path.split('/').filter((p) => p !== '')
  if (parts.length < 2) return null
  const repo = parts[parts.length - 1]!
  const owner = parts[parts.length - 2]!
  return { host, port, owner, repo }
}

/**
 * Strips embedded `user:pass@`/`user@` userinfo from a `https://`/`ssh://`
 * remote URL before it goes anywhere this run might log or surface it (a
 * thrown error's `message` ends up in a terminal, a crash report, an
 * orchestrator log line — none of them the credential's intended audience).
 * A remote that failed {@link parseRemoteRef} is exactly the shape most
 * likely to carry one: `parseRemoteRef` already strips a plain `user@` for
 * the shapes it DOES recognize, so what reaches here is whatever it could
 * not make sense of, embedded credentials included.
 */
function redactRemoteUrl(url: string): string {
  return url.replace(/(^[a-z][a-z0-9+.-]*:\/\/)[^/@]+@/i, '$1***@')
}

/**
 * `ForgejoCodeHost` takes one `host` string and builds `https://${host}/...`.
 * Folding the port in here makes that URL hit a non-default port, and it is
 * the shape `ForgejoCodeHost.parsePrUrl`'s host compare expects (a PR URL's
 * authority includes `:port` too).
 */
function forgejoHost(ref: GitRemoteRef): string {
  return ref.port !== null ? `${ref.host}:${ref.port}` : ref.host
}

/** The backend name for the repository at `cwd`, and the `origin` URL it was read from. */
export function resolveCodeHost(
  cwd: string,
  gitRunner: CommandRunner,
  override: CodeHostName | null,
): { name: CodeHostName; remoteUrl: string | null } {
  // `.try`: a checkout outside a repository, or any other git failure reading
  // `origin`, means no remote, not an error.
  const remoteOutcome = new Git(cwd, { runner: gitRunner }).try.remoteGetUrl('origin')
  const remoteUrl = remoteOutcome.ok ? remoteOutcome.value : null
  return { name: codeHostNameForRemote(remoteUrl, override), remoteUrl }
}

type AuthChecks = (deps: CodeHostAuthCheckDeps, remoteUrl: string | null) => Promise<AuthCheck[]>

/** Each backend's auth checks, given the `origin` URL. Adding a backend adds one entry. */
const AUTH_CHECKS: Record<CodeHostName, AuthChecks> = {
  github: async (deps) => githubAuthChecks(deps),
  forgejo: (deps, remoteUrl) => {
    const ref = remoteUrl === null ? null : parseRemoteRef(remoteUrl)
    return forgejoAuthChecks(deps, ref === null ? null : `https://${forgejoHost(ref)}`)
  },
}

export function authChecksFor(name: CodeHostName): AuthChecks {
  return AUTH_CHECKS[name]
}

/**
 * Build the `CodeHost` for the repository at `cwd`. Throws when a Forgejo
 * adapter is needed but cannot be built (no readable remote, or no token).
 *
 * Two SEPARATE runners in, not one: `git`/`gh`/`curl` are each bound to a
 * specific binary in this codebase (`spawnRunner('git')`, `spawnRunner('gh')`,
 * ...), unlike a generic subprocess runner that takes the binary name as
 * part of its argv. `opts.git` resolves the `origin` remote; `opts.gh`
 * becomes `GithubCodeHost`'s runner when that is the answer; `opts.curl`
 * (optional — a real one is spawned when omitted) becomes `ForgejoCodeHost`'s,
 * so a test can fake the one call this function makes to a binary neither
 * `ctx.git` nor `ctx.gh` already covers, with no real subprocess.
 */
export function selectCodeHost(
  cwd: string,
  opts: {
    git: CommandRunner
    gh: CommandRunner
    curl?: CommandRunner
    override?: CodeHostName | null
  },
): CodeHost {
  const { name, remoteUrl } = resolveCodeHost(cwd, opts.git, opts.override ?? null)
  if (name === 'github') return new GithubCodeHost(cwd, { runner: opts.gh })

  if (remoteUrl === null) {
    throw new Error('selectCodeHost: no `origin` remote to build a Forgejo adapter from')
  }
  const ref = parseRemoteRef(remoteUrl)
  if (ref === null) {
    throw new Error(
      `selectCodeHost: could not parse a host/owner/repo from the origin remote (${redactRemoteUrl(remoteUrl)})`,
    )
  }
  const hostForAdapter = forgejoHost(ref)
  const token = process.env[FORGEJO_TOKEN_ENV]
  if (token === undefined || token === '') {
    throw new Error(
      `selectCodeHost: this run needs a Forgejo adapter for ${hostForAdapter}, but ${FORGEJO_TOKEN_ENV} is not set`,
    )
  }
  const curlRunner = opts.curl ?? spawnRunner('curl')
  return new ForgejoCodeHost({
    runner: curlRunner,
    cwd,
    host: hostForAdapter,
    owner: ref.owner,
    repo: ref.repo,
    token,
  })
}
