# @sksizer/code-host

The CodeHost port: what a code host must answer about pull requests, plus the
GitHub and Forgejo adapters behind it.

Callers that need PR facts (a classifier, a router, an orchestrator tick) ask
the port instead of calling `gh` or a REST API themselves, so a second host is
a new adapter and not a rewrite of every caller.

## What is here

| Export | What it is |
| --- | --- |
| `CodeHost` | The port: `listPrs`, `listPrDetails`, `getPr`, `postComment`, `updateBranch`, `parsePrUrl`, `prForBranch`. Every method is synchronous |
| `CodeHostPr`, `PrFacts`, `Activity`, `PrInput`, ... | The normalized shapes the port speaks (`types.ts`) |
| `GithubCodeHost`, `codeHostPrFrom` | GitHub adapter over `@sksizer/easy-gh` |
| `ForgejoCodeHost`, `forgejoPrFrom` | Forgejo adapter over `curl` and the Forgejo REST API; reads its token from `SDLC_FORGEJO_TOKEN` |
| `selectCodeHost`, `resolveCodeHost`, `codeHostNameForRemote` | Pick the adapter from the git remote |
| `githubAuthChecks`, `forgejoAuthChecks`, `authChecksFor` | The auth probes a doctor command runs |
| `assemblePrFacts` | Adds local-git drift (`behind`/`ahead`) to a `CodeHostPr` |
| `parsePrInput` | Parse a PR argument: a number, `#n`, `owner/repo#n`, or a URL |

## Boundaries

- Every shell-out goes through a `CommandRunner` from `@sksizer/command-seam`
  that the caller injects (`selectCodeHost` builds the default one). Tests pass
  fakes; nothing here touches the network.
- Git and GitHub access goes through `@sksizer/easy-git` and `@sksizer/easy-gh`.
- No `sdlc.yaml`, entities or ops. Verdicts (`classify`) stay with the caller;
  this package only produces the facts they read.

## Not here yet

The port has no write verbs beyond `postComment` and `updateBranch`. `openPr`,
`editPrBody`, `postReview` and `replyToThread` are the next additions, and
`@sksizer/pr-update` still calls `@sksizer/easy-gh` directly rather than going
through this port.

## License

MIT
